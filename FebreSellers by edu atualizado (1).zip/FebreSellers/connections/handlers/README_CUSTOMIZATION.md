# Customization Module — DESATIVADO

Este módulo dependia de:

- Cloud
- WebSocket
- API externa
- Dashboard

O bot está rodando em modo **offline/local**.
Todas as funções de customização remota foram removidas.

Para reativar:
- Restaurar WebSocket
- Restaurar Cloud Handlers
- Restaurar Socket Manager
