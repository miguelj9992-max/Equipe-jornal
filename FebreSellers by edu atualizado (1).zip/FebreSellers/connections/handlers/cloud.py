"""
Cloud Handlers DESATIVADOS
Módulo Cloud desligado.
Todos os endpoints retornam 'Cloud desativada'.
"""

def register_cloud_handlers():

    async def disabled(*args, **kwargs):
        return {
            "success": False,
            "message": "Cloud desativada"
        }

    # Retorna mapa vazio ou stubs
    return {
        # Configuration
        'cloud.getConfig': disabled,
        'cloud.updateCredentials': disabled,
        'cloud.updateLogChannel': disabled,
        'cloud.updateVerifiedRole': disabled,

        # Statistics
        'cloud.getStats': disabled,
        'cloud.getAuthLogs': disabled,

        # Gifts
        'cloud.getGifts': disabled,
        'cloud.getGift': disabled,
        'cloud.createGift': disabled,
        'cloud.updateGift': disabled,
        'cloud.deleteGift': disabled,

        # Tasks
        'cloud.getTasks': disabled,
        'cloud.getTask': disabled,
        'cloud.createTask': disabled,
        'cloud.updateTask': disabled,
        'cloud.deleteTask': disabled,

        # Verification
        'cloud.getVerificationMessage': disabled,
        'cloud.updateVerificationMessage': disabled,
        'cloud.updateMessageStyle': disabled,
        'cloud.resetVerificationMessage': disabled,
        'cloud.sendVerificationMessage': disabled,

        # WebSocket Control
        'cloud.connectWebSocket': disabled,
        'cloud.disconnectWebSocket': disabled,
        'cloud.getWebSocketStatus': disabled,
    }
