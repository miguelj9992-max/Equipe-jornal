"""
HTTP Polling DESATIVADO
Cloud/WebSocket fallback desabilitado.
"""

class HTTPPollingManager:
    def __init__(self, bot=None):
        self.bot = bot
        self.connected = False

    def set_bot(self, bot):
        self.bot = bot

    def set_callbacks(self, *args, **kwargs):
        pass

    async def initialize(self):
        print("[HTTPPolling] Desativado.")

    async def connect(self):
        print("[HTTPPolling] Cloud desativada — connect ignorado.")
        return False

    async def send(self, *args, **kwargs):
        return False

    async def request(self, *args, **kwargs):
        return {"success": False, "message": "Cloud desativada"}

    async def disconnect(self):
        pass

    def is_connected(self):
        return False
