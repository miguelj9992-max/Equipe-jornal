"""
SocketIOManager - Gerenciador de conexão Socket.IO com a Cloud API
Conecta ao servidor, autentica e processa eventos como auth_log.
"""
import asyncio
import json
import logging
import os
import traceback

logger = logging.getLogger(__name__)


class SocketIOManager:

    def __init__(self, bot=None):
        self.bot = bot
        self.sio = None
        self.connected = False
        self.should_reconnect = True
        self.reconnect_interval = 5
        self.reconnect_task = None
        self.server_url = None
        self._on_connect_cb = None
        self._on_disconnect_cb = None
        self._on_error_cb = None
        self._on_message_cb = None

    # ------------------------------------------------------------------
    # Config helpers
    # ------------------------------------------------------------------

    def _get_server_url(self) -> str:
        """Obtém primeiro o endpoint Socket.IO do backend de pagamentos.

        `config_api.json` pode apontar para o domínio do portal web, que fica
        atrás de Cloudflare e não aceita o handshake do bot. O arquivo de
        websocket é a fonte específica para esta conexão e deve ter prioridade.
        """
        try:
            paths = [
                os.path.join(os.path.dirname(__file__), '..', 'configs', 'config_websocket.json'),
                'configs/config_websocket.json',
            ]
            for p in paths:
                if os.path.exists(p):
                    with open(p, 'r', encoding='utf-8') as f:
                        cfg = json.load(f)
                    url = (cfg.get('websocket_cloud', {}).get('auth_server_url') or
                           cfg.get('websocket_cloud', {}).get('server_url') or
                           cfg.get('websocket_cloud', {}).get('http_url') or '').rstrip('/')
                    if url:
                        return url
        except Exception as e:
            logger.warning(f"[SocketIO] Erro ao ler config_websocket.json: {e}")

        # Fallback somente quando não houver endpoint websocket configurado.
        try:
            paths = [
                os.path.join(os.path.dirname(__file__), '..', 'configs', 'config_api.json'),
                'configs/config_api.json',
            ]
            for p in paths:
                if os.path.exists(p):
                    with open(p, 'r', encoding='utf-8') as f:
                        cfg = json.load(f)
                    url = cfg.get('cloud', '').rstrip('/')
                    if url:
                        return url
        except Exception as e:
            logger.warning(f"[SocketIO] Erro ao ler config_api.json: {e}")

        return ''

    def _get_bot_credentials(self) -> dict:
        """Retorna client_id e token do bot para autenticação."""
        try:
            from functions.database import database as db
            cloud_data = db.get_document('cloud_data') or {}
            return {
                'client_id': cloud_data.get('client_id', ''),
                'token': cloud_data.get('token', ''),
                'client_secret': cloud_data.get('client_secret', ''),
            }
        except Exception:
            return {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def set_bot(self, bot):
        self.bot = bot

    def set_callbacks(self, on_connect=None, on_disconnect=None,
                      on_error=None, on_message=None):
        self._on_connect_cb = on_connect
        self._on_disconnect_cb = on_disconnect
        self._on_error_cb = on_error
        self._on_message_cb = on_message

    def is_connected(self) -> bool:
        return self.connected

    async def initialize(self):
        await self.start()

    async def start(self):
        """Inicia a conexão Socket.IO em segundo plano (não bloqueia quem
        chamou). Antes, isso ficava esperando `_connect_loop()` terminar --
        e como a primeira tentativa de conexão podia levantar uma exceção
        (ver correção em `_connect_loop`), essa exceção subia direto para
        quem chamou `start()`/`initialize()` (o `on_ready` do bot), e o loop
        de reconexão nunca chegava a rodar de verdade: bastava a primeira
        tentativa falhar (ex: uma instabilidade passageira no servidor da
        Cloud) para o WebSocket ficar desconectado pelo resto da sessão do
        bot inteiro, sem nunca mais tentar de novo -- e sem nenhum aviso
        visível no console, já que o restante do fluxo dependia só de
        logger.error (ver nota em `_connect_loop`)."""
        self.server_url = self._get_server_url()
        if not self.server_url:
            logger.error("[SocketIO] URL do servidor não configurada — conexão abortada.")
            return

        self.should_reconnect = True
        if self.reconnect_task is None or self.reconnect_task.done():
            self.reconnect_task = asyncio.create_task(self._connect_loop())

    async def stop(self):
        self.should_reconnect = False
        if self.reconnect_task:
            self.reconnect_task.cancel()
        if self.sio:
            try:
                await self.sio.disconnect()
            except Exception:
                pass
        self.connected = False
        logger.info("[SocketIO] Desconectado.")

    # ------------------------------------------------------------------
    # Connection loop
    # ------------------------------------------------------------------

    async def _connect_loop(self):
        """Loop principal de conexão com reconexão automática.

        BUG CORRIGIDO: o `except Exception` abaixo estava comentado. Isso
        significa que se `_do_connect()` levantasse uma exceção (ex: o
        próprio erro de handshake 404 visto no console, ou qualquer outra
        falha de rede/DNS na primeira tentativa), ela NÃO era capturada
        aqui -- só o `asyncio.CancelledError` era. A exceção então escapava
        deste loop `while self.should_reconnect`, encerrando-o
        definitivamente: nenhuma nova tentativa de reconexão era feita pelo
        resto da execução do bot (só reconectaria reiniciando o processo
        inteiro). Como esse loop também nunca reportava nada no console via
        print() (só logger, que pode não aparecer -- ver nota no topo de
        tasks/cloud/cog.py), o problema passava despercebido: os logs de
        verificação em tempo real e o bloqueio de VPN parecem funcionar "às
        vezes sim, às vezes não" simplesmente porque dependem inteiramente
        de o WebSocket ter conseguido se conectar logo na primeira
        tentativa, sem nenhum aviso quando isso não acontece.
        """
        while self.should_reconnect:
            try:
                await self._do_connect()
                # _do_connect só retorna quando desconecta
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"[SocketIO] Erro na tentativa de conexão com {self.server_url}: {e}")
                logger.warning(f"[SocketIO] Erro na conexão: {e}")

            if not self.should_reconnect:
                break

            print(f"[SocketIO] Reconectando em {self.reconnect_interval}s...")
            logger.info(f"[SocketIO] Reconectando em {self.reconnect_interval}s...")
            await asyncio.sleep(self.reconnect_interval)

    async def _do_connect(self):
        """Faz uma tentativa de conexão e aguarda até desconectar."""
        try:
            import socketio as sio_lib
        except ImportError:
            logger.error("[SocketIO] Biblioteca 'python-socketio[asyncio_client]' não instalada.")
            await asyncio.sleep(30)
            return

        self.sio = sio_lib.AsyncClient(
            reconnection=False,
            logger=False,
            engineio_logger=False,
        )

        # ---- Eventos Socket.IO ----
        @self.sio.event
        async def connect():
            self.connected = True
            logger.info(f"[SocketIO] Conectado a {self.server_url}")
            # Autenticar
            creds = self._get_bot_credentials()
            if creds.get('client_id'):
                try:
                    await self.sio.emit('bot:auth', {
                        'clientId': creds['client_id'],
                        'token': creds.get('token', ''),
                        'clientSecret': creds.get('client_secret', ''),
                    })
                except Exception as e:
                    logger.warning(f"[SocketIO] Erro ao autenticar: {e}")
            if self._on_connect_cb:
                try:
                    await self._on_connect_cb()
                except Exception:
                    pass

        @self.sio.event
        async def disconnect():
            self.connected = False
            logger.info("[SocketIO] Desconectado do servidor.")
            if self._on_disconnect_cb:
                try:
                    await self._on_disconnect_cb()
                except Exception:
                    pass

        @self.sio.event
        async def auth_log(data):
            logger.info(f"[SocketIO] Evento auth_log recebido: {data}")
            if self._on_message_cb:
                try:
                    await self._on_message_cb({'event': 'auth_log', 'data': data})
                except Exception as e:
                    logger.error(f"[SocketIO] Erro ao processar auth_log: {e}")
                    traceback.print_exc()

        @self.sio.event
        async def redeem_gift(data):
            if self._on_message_cb:
                try:
                    await self._on_message_cb({'event': 'redeem_gift', 'data': data})
                except Exception as e:
                    logger.error(f"[SocketIO] Erro ao processar redeem_gift: {e}")

        @self.sio.event
        async def recover_members(data):
            if self._on_message_cb:
                try:
                    await self._on_message_cb({'event': 'recover_members', 'data': data})
                except Exception as e:
                    logger.error(f"[SocketIO] Erro ao processar recover_members: {e}")

        @self.sio.event
        async def remove_verified_role(data):
            if self._on_message_cb:
                try:
                    await self._on_message_cb({'event': 'remove_verified_role', 'data': data})
                except Exception as e:
                    logger.error(f"[SocketIO] Erro ao processar remove_verified_role: {e}")

        # ---- Conectar ----
        try:
            await self.sio.connect(
                self.server_url,
                transports=['websocket', 'polling'],
                wait_timeout=15,
            )
            await self.sio.wait()  # Aguarda até desconectar
        #except Exception as e:
            #logger.warning(f"[SocketIO] Falha ao conectar em {self.server_url}: {e}")
        finally:
            self.connected = False
            if self.sio:
                try:
                    await self.sio.disconnect()
                except Exception:
                    pass

    # ------------------------------------------------------------------
    # Stubs de API (usados por outras partes do código)
    # ------------------------------------------------------------------

    async def send(self, event, data=None):
        if self.sio and self.connected:
            try:
                await self.sio.emit(event, data or {})
                return True
            except Exception as e:
                logger.error(f"[SocketIO] Erro ao enviar {event}: {e}")
        return False

    async def request(self, event, data=None, timeout=15):
        return {'success': False, 'message': 'Use HTTP para requisições síncronas'}

    async def register_bot(self, *args, **kwargs):
        return {'success': False, 'message': 'Use HTTP'}

    async def get_gifts(self, *args, **kwargs):
        return {'success': False, 'data': {'gifts': []}}

    async def create_gift(self, *args, **kwargs):
        return {'success': False}

    async def delete_gift(self, *args, **kwargs):
        return {'success': False}

    async def update_definitions(self, *args, **kwargs):
        return {'success': False}

    async def check_user_verification(self, *args, **kwargs):
        return {'success': False}

    async def list_members(self, *args, **kwargs):
        return {'success': False, 'data': []}

    async def check_auth_count(self, *args, **kwargs):
        return {'success': False}

    async def recover_data(self, *args, **kwargs):
        return {'success': False}

    async def resend_bot_connected(self):
        pass
