"""
WSManager DESATIVADO
WebSocket / Cloud externo desligado.
"""

class WSManager:

    def __init__(self, bot=None):
        self.bot = bot
        self.connected = False

    async def initialize(self):
        print("[WSManager] Desativado.")

    async def connect(self):
        print("[WSManager] Cloud/WebSocket desativado — connect ignorado.")
        return False

    async def disconnect(self):
        self.connected = False

    def is_connected(self):
        return False

    async def send(self, *args, **kwargs):
        return False

    async def request(self, *args, **kwargs):
        return {"success": False, "message": "Cloud desativada"}

    # ===== Compatibilidade =====

    def set_bot(self, bot):
        self.bot = bot

    async def start(self):
        pass

    async def stop(self):
        pass

    def set_callbacks(self, *args, **kwargs):
        pass

    async def resend_bot_connected(self):
        pass

    # ===== API Methods fake =====

    async def register_bot(self, *args, **kwargs):
        return {"success": False}

    async def synchronize(self, *args, **kwargs):
        return {"success": False}

    async def get_gifts(self, *args, **kwargs):
        return {"success": False, "data": []}

    async def create_gift(self, *args, **kwargs):
        return {"success": False}

    async def delete_gift(self, *args, **kwargs):
        return {"success": False}

    async def update_definitions(self, *args, **kwargs):
        return {"success": False}

    async def check_user_verification(self, *args, **kwargs):
        return {"success": False}

    async def list_members(self, *args, **kwargs):
        return {"success": False, "data": []}

    async def check_auth_count(self, *args, **kwargs):
        return {"success": False}

    async def recover_data(self, *args, **kwargs):
        return {"success": False}
