import pymongo
import json

with open("config.json", "r", encoding="utf-8") as f:
    config = json.load(f)

with open("configs/config_mongo.json", "r", encoding="utf-8") as f:
    mongo_config = json.load(f)

mongo_url = mongo_config.get("mongoURL")
bot_id = config.get("botID")
database_name = mongo_config.get("databaseName", "sync_bots")

client = pymongo.MongoClient(
    mongo_url,
    # Timeouts curtos: se o Mongo travar/instabilizar, a chamada falha rápido
    # (em vez de travar o loop de eventos do bot por até 30s+ e derrubar o
    # gateway do Discord por falta de resposta ao heartbeat).
    serverSelectionTimeoutMS=5000,
    connectTimeoutMS=5000,
    socketTimeoutMS=5000,
    retryWrites=True,
    # retryReads=False: numa instabilidade do Atlas, o retry dobra o pior caso
    # (5s -> 10s por operação) e tenta de novo no MESMO socket problemático.
    # Como estas chamadas são síncronas no event loop, é melhor falhar rápido
    # (5s) e deixar o próximo ciclo tentar de novo.
    retryReads=False,
    maxPoolSize=20,
    minPoolSize=1,
)
database = client[database_name]
collection = database[bot_id]