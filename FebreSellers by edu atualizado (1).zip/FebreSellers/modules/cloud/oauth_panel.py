"""
Painel OAuth2 integrado ao bot de vendas.
Replica o /panel do bot de verificação dentro do painel > configurar cloud.

O domínio do serviço de autenticação é lido de `configs/config_api.json`;
o padrão instalado para este projeto é `https://febre-system-auth.shardweb.app`.
"""

import disnake
import logging
import asyncio
import aiohttp
import io
from datetime import datetime, timedelta
from functions.database import database as db
from functions.emoji import emoji

logger = logging.getLogger(__name__)


def _get_container_color_kwargs() -> dict:
    """Retorna os kwargs de accent_colour do Container com base na cor primária
    configurada em /painel > Personalização."""
    colors = db.get_document("custom_colors") or {}
    primary_color_hex = colors.get("primary")
    if primary_color_hex:
        try:
            return {"accent_colour": disnake.Colour(int(str(primary_color_hex).replace("#", ""), 16))}
        except Exception:
            pass
    return {}


# --------------------------------------------------------------------------- #
#  Helpers de banco de dados                                                    #
# --------------------------------------------------------------------------- #

def _get_oauth_data() -> dict:
    """Retorna o dicionário de dados OAuth2 armazenados no banco.
    Lê de cloud_data (fonte principal) e faz merge com cloud_oauth para compatibilidade.
    """
    cloud_data = db.get_document("cloud_data") or {}
    cloud_oauth = db.get_document("cloud_oauth") or {}
    # Prioriza cloud_data para client_id/client_secret (onde config_credenciais salva)
    merged = {**cloud_oauth, **cloud_data}

    # /painel > configurações > cargos é sempre a fonte de verdade para o
    # Cargo de Verificado, e /painel > configurações > canais é a fonte de
    # verdade para o Canal de Logs de Verificação. Se estiverem definidos
    # lá, eles têm prioridade sobre qualquer valor salvo separadamente aqui
    # no OAuth2 (evita ficar "preso" num valor antigo quando o usuário
    # atualiza o cargo em Configurações > Cargos ou o canal em
    # Configurações > Canais).
    cargos_config = db.get_document("cargos") or {}
    canais_config = db.get_document("canais") or {}

    verified_role_id = cargos_config.get("cargo_verificado")
    if not verified_role_id:
        verified_role_id = merged.get("verified_role_id") or cloud_oauth.get("verified_role_id")

    log_channel_id = canais_config.get("canal_de_logs_de_verificado")
    if not log_channel_id:
        log_channel_id = merged.get("log_channel_id") or cloud_oauth.get("log_channel_id")

    # Normaliza os campos OAuth dentro do merged
    result = {
        "client_id":       merged.get("client_id"),
        "client_secret":   merged.get("client_secret"),
        "verified_role_id": verified_role_id,
        "log_channel_id":  log_channel_id,
        "perms":           cloud_oauth.get("perms", []),
        "blacklist_ips":   cloud_oauth.get("blacklist_ips", []),
        "blacklist_users": cloud_oauth.get("blacklist_users", []),
        "users":           cloud_oauth.get("users", []),
        "message_config":  cloud_oauth.get("message_config", {}),
    }
    return result


def _save_oauth_data(data: dict):
    """Salva dados OAuth sincronizando cloud_oauth e cloud_data."""
    # Salvar tudo no cloud_oauth (dados específicos do OAuth)
    db.save_document("cloud_oauth", data)
    # Sincronizar client_id e client_secret para cloud_data também
    cloud_data = db.get_document("cloud_data") or {}
    changed = False
    for key in ("client_id", "client_secret"):
        if data.get(key) is not None and cloud_data.get(key) != data.get(key):
            cloud_data[key] = data[key]
            changed = True
    if changed:
        db.save_document("cloud_data", cloud_data)


def get_oauth_client_id() -> str | None:
    return _get_oauth_data().get("client_id")


def get_oauth_client_secret() -> str | None:
    return _get_oauth_data().get("client_secret")


def get_oauth_verified_role() -> str | None:
    return _get_oauth_data().get("verified_role_id")


def get_oauth_log_channel() -> str | None:
    return _get_oauth_data().get("log_channel_id")


def get_oauth_perms() -> list:
    return _get_oauth_data().get("perms", [])


def get_oauth_blacklist_ips() -> list:
    return _get_oauth_data().get("blacklist_ips", [])


def add_oauth_blacklist_ip(ip: str) -> None:
    """Adiciona um IP à blacklist, sem duplicar, sem limite (usado pelo
    bloqueio automático de VPN — diferente do fluxo manual do painel, que
    tem limite de 25 por ser preenchido um a um)."""
    if not ip or ip in ("Desconhecido", "N/A"):
        return
    data = _get_oauth_data()
    ips = data.get("blacklist_ips", [])
    if ip not in ips:
        ips.append(ip)
        data["blacklist_ips"] = ips
        _save_oauth_data(data)


def is_vpn_block_enabled() -> bool:
    """Verifica se o bloqueio automático de VPN/Proxy na verificação OAuth2
    está ativado nas definições da cloud."""
    cloud_config = db.get_document("cloud_data") or {}
    definitions = cloud_config.get("definitions", {})
    return bool(definitions.get("block_vpn", {}).get("enabled", False))


def set_vpn_block_enabled(enabled: bool) -> None:
    """Ativa/desativa o bloqueio automático de VPN/Proxy na verificação OAuth2."""
    cloud_config = db.get_document("cloud_data") or {}
    definitions = cloud_config.setdefault("definitions", {})
    definitions.setdefault("block_vpn", {})["enabled"] = bool(enabled)
    cloud_config["definitions"] = definitions
    db.save_document("cloud_data", cloud_config)


# Punições disponíveis para quem for pego usando VPN/Proxy/Datacenter na
# verificação. "none" só nega o cargo de verificado (comportamento antigo).
VPN_PUNISHMENTS = {
    "none":    "Nenhuma Punição",
    "kick":    "Expulsar Membro",
    "ban":     "Banir Membro",
    "timeout": "Castigar Membro",
}
_DEFAULT_VPN_TIMEOUT_MINUTES = 10


def get_vpn_punishment() -> str:
    """Retorna a punição configurada para quem for pego usando VPN/Proxy
    ('none', 'kick', 'ban' ou 'timeout'). Padrão: 'none'."""
    cloud_config = db.get_document("cloud_data") or {}
    definitions = cloud_config.get("definitions", {})
    value = definitions.get("block_vpn", {}).get("punishment", "none")
    return value if value in VPN_PUNISHMENTS else "none"


def set_vpn_punishment(punishment: str) -> None:
    """Define a punição aplicada a quem for pego usando VPN/Proxy."""
    if punishment not in VPN_PUNISHMENTS:
        punishment = "none"
    cloud_config = db.get_document("cloud_data") or {}
    definitions = cloud_config.setdefault("definitions", {})
    definitions.setdefault("block_vpn", {})["punishment"] = punishment
    cloud_config["definitions"] = definitions
    db.save_document("cloud_data", cloud_config)


def get_vpn_timeout_minutes() -> int:
    """Retorna a duração (em minutos) do timeout aplicado quando a punição
    configurada for 'timeout'. Padrão: 10 minutos."""
    cloud_config = db.get_document("cloud_data") or {}
    definitions = cloud_config.get("definitions", {})
    try:
        minutes = int(definitions.get("block_vpn", {}).get("timeout_minutes", _DEFAULT_VPN_TIMEOUT_MINUTES))
    except (TypeError, ValueError):
        minutes = _DEFAULT_VPN_TIMEOUT_MINUTES
    # Discord só permite timeout de até 28 dias (40320 minutos)
    return max(1, min(minutes, 40320))


def set_vpn_timeout_minutes(minutes: int) -> None:
    """Define a duração (em minutos) do timeout de VPN/Proxy."""
    try:
        minutes = int(minutes)
    except (TypeError, ValueError):
        minutes = _DEFAULT_VPN_TIMEOUT_MINUTES
    minutes = max(1, min(minutes, 40320))
    cloud_config = db.get_document("cloud_data") or {}
    definitions = cloud_config.setdefault("definitions", {})
    definitions.setdefault("block_vpn", {})["timeout_minutes"] = minutes
    cloud_config["definitions"] = definitions
    db.save_document("cloud_data", cloud_config)


def is_vpn_auto_blacklist_enabled() -> bool:
    """Verifica se o IP deve ser adicionado automaticamente à blacklist quando
    for detectado uso de VPN/Proxy. Padrão: DESATIVADO — o dono do servidor
    precisa ativar isso explicitamente, para evitar blacklist automática
    indesejada (ex: IPs de VPN legítimas usadas por engano)."""
    cloud_config = db.get_document("cloud_data") or {}
    definitions = cloud_config.get("definitions", {})
    return bool(definitions.get("block_vpn", {}).get("auto_blacklist", False))


def set_vpn_auto_blacklist_enabled(enabled: bool) -> None:
    """Ativa/desativa a adição automática do IP à blacklist ao detectar VPN/Proxy."""
    cloud_config = db.get_document("cloud_data") or {}
    definitions = cloud_config.setdefault("definitions", {})
    definitions.setdefault("block_vpn", {})["auto_blacklist"] = bool(enabled)
    cloud_config["definitions"] = definitions
    db.save_document("cloud_data", cloud_config)


def get_oauth_blacklist_users() -> list:
    return _get_oauth_data().get("blacklist_users", [])


# --------------------------------------------------------------------------- #
#  Cliente Mongo remoto (singleton reaproveitado)                               #
# --------------------------------------------------------------------------- #
#
# BUG CORRIGIDO: get_oauth_verified_users() e _get_mongo_users_collection()
# criavam um `pymongo.MongoClient(...)` NOVO a cada chamada e nunca o
# fechavam (nem reaproveitavam). Como get_oauth_verified_users() é chamada
# a cada 30s pelo loop de sincronização automática (tasks/cloud/cog.py), a
# cada 30 segundos uma conexão TCP nova ficava aberta e "vazando" (connection
# leak). Com o tempo isso esgotava as conexões disponíveis no MongoDB/pool
# do sistema, fazendo com que a busca dos usuários verificados recém-chegados
# passasse a falhar silenciosamente (caindo no `except` e retornando apenas o
# cache local desatualizado) — por isso o cargo não era dado, o log não era
# enviado e o usuário não contava como verificado, EXCETO logo após reiniciar
# o bot (quando o processo começa com zero conexões vazadas).
#
# A correção é reaproveitar um único MongoClient por processo (assim como o
# resto do bot já faz em connections/mongo_db.py) em vez de abrir um novo a
# cada verificação.
_verification_mongo_client = None
_verification_mongo_lock = None


def _get_verification_mongo_client(mongo_url: str):
    """Retorna um MongoClient singleton (criado uma única vez por processo)
    para a base de dados do site de verificação, evitando abrir uma conexão
    nova a cada chamada (o que causava vazamento de conexões)."""
    global _verification_mongo_client, _verification_mongo_lock
    import threading
    if _verification_mongo_lock is None:
        _verification_mongo_lock = threading.Lock()

    with _verification_mongo_lock:
        if _verification_mongo_client is None:
            from pymongo import MongoClient
            _verification_mongo_client = MongoClient(
                mongo_url,
                serverSelectionTimeoutMS=5000,
                connectTimeoutMS=5000,
                socketTimeoutMS=5000,
                # Uma tentativa só: com o Atlas lento, retryReads dobra o pior
                # caso de bloqueio (5s -> 10s). Falhar rápido e tentar no
                # próximo ciclo é melhor que travar o loop por mais tempo.
                retryReads=False,
                maxPoolSize=10,
                minPoolSize=1,
            )
        return _verification_mongo_client


def _get_verification_bot_id_and_mongo_url():
    """Resolve o bot_id (ID do próprio bot rodando) e a mongo_url usados
    para consultar a coleção onde o site de verificação salva os usuários."""
    import os
    import json as _json

    # IMPORTANTE: o "bot_id" usado como nome da coleção no Mongo é o ID
    # do PRÓPRIO bot que está rodando (o mesmo valor usado no "state" da
    # URL OAuth2 — veja build_auth_url(..., bot_id=str(inter.bot.user.id))
    # — e em config.json -> botID), e NÃO o client_id da aplicação OAuth2
    # exclusiva de verificação. São aplicações Discord diferentes; usar
    # o client_id aqui aponta para uma coleção que nunca foi populada.
    try:
        from connections.mongo_db import bot_id as _main_bot_id
    except Exception:
        _main_bot_id = None
    bot_id = _main_bot_id
    if not bot_id:
        cloud_data = db.get_document("cloud_data") or {}
        bot_id = cloud_data.get("client_id")

    mongo_url = os.environ.get("MONGO_URL", "")
    database_name = os.environ.get("DATABASE_NAME", "Lunar")
    if not mongo_url:
        try:
            config_path = os.path.join(
                os.path.dirname(__file__), "..", "..", "configs", "config_mongo.json"
            )
            with open(config_path, "r", encoding="utf-8") as f:
                mongo_cfg = _json.load(f)
            mongo_url = mongo_cfg.get("mongoURL", mongo_cfg.get("url", ""))
            database_name = mongo_cfg.get("databaseName", database_name)
        except Exception:
            pass

    return bot_id, mongo_url, database_name


def get_oauth_verified_users() -> list:
    """
    Retorna a lista de usuários verificados.
    Faz merge entre o banco local (cloud_oauth.users) e o MongoDB remoto
    (coleção bot_id -> documento cloud_oauth -> campo users), que é onde
    o site de verificação salva os dados após o OAuth2.
    """
    local_users = _get_oauth_data().get("users", [])

    try:
        collection = _get_mongo_users_collection()
        if collection is None:
            return local_users

        remote_doc = collection.find_one({"_id": "cloud_oauth"}) or {}
        remote_users = remote_doc.get("users", [])

        # Merge: remote tem precedencia (e a fonte do site)
        # Indexar por user id para deduplicar
        merged = {str(u.get("id")): u for u in local_users if u.get("id")}
        for u in remote_users:
            if u.get("id"):
                merged[str(u.get("id"))] = u

        return list(merged.values())

    except Exception as e:
        # IMPORTANTE: usar print() além do logger.warning aqui -- essa falha é
        # justamente a causa mais provável de "às vezes o usuário se verifica
        # e não conta no total nem envia log" (ver nota abaixo sobre chamadas
        # bloqueantes). Sem isso visível no console, essa falha passa
        # despercebida silenciosamente.
        print(f"[OAuthPanel] Erro ao buscar verificados no Mongo remoto: {e}")
        logger.warning(f"[OAuthPanel] Erro ao buscar verificados no Mongo remoto: {e}")
        return local_users


# ---------------------------------------------------------------------------
# Wrappers assíncronos (não-bloqueantes) das funções acima.
#
# BUG ENCONTRADO: get_oauth_verified_users(), update_oauth_user_tokens() e
# remove_oauth_verified_user() fazem chamadas SÍNCRONAS ao MongoDB (pymongo é
# uma biblioteca bloqueante, ao contrário de aiohttp/disnake). Elas são
# chamadas diretamente (sem thread separada) de dentro de coroutines que
# rodam em loops automáticos a cada 15s (revalidate_auth_loop) e 30s
# (sync_verified_loop) -- tasks/cloud/cog.py e tasks/cloud/revalidate_auth.py.
#
# Cada chamada bloqueia TODO o event loop do bot (não só essa task) enquanto
# espera a resposta do Mongo -- inclusive o recebimento/processamento de
# eventos do WebSocket da Cloud (onde chega o "auth_log" de quem acabou de se
# verificar). Se o Mongo estiver um pouco lento/instável nesse instante
# (comum com serviços remotos gratuitos/compartilhados), o bot trava por até
# alguns segundos repetidamente, podendo perder ou atrasar o evento de
# verificação que chegou durante o travamento -- exatamente o "às vezes não
# envia log e não conta no total" relatado, e explica por que é intermitente
# (só acontece quando a latência do Mongo coincide com uma verificação nova).
#
# A correção é rodar a chamada bloqueante em uma thread separada
# (asyncio.to_thread), liberando o event loop principal enquanto se espera o
# Mongo responder. Os loops periódicos (cog.py e revalidate_auth.py) foram
# atualizados para usar essas versões assíncronas.
async def get_oauth_verified_users_async() -> list:
    """Versão não-bloqueante de get_oauth_verified_users() -- usar sempre
    que possível dentro de código assíncrono (loops automáticos, etc.)."""
    return await asyncio.to_thread(get_oauth_verified_users)


async def update_oauth_user_tokens_async(user_id: str, access_token: str = None, refresh_token: str = None) -> None:
    """Versão não-bloqueante de update_oauth_user_tokens()."""
    await asyncio.to_thread(update_oauth_user_tokens, user_id, access_token, refresh_token)


async def remove_oauth_verified_user_async(user_id: str) -> None:
    """Versão não-bloqueante de remove_oauth_verified_user()."""
    await asyncio.to_thread(remove_oauth_verified_user, user_id)


def _parse_verified_at(raw) -> "datetime | None":
    """Tenta converter o campo verified_at (string ISO) para datetime.
    Retorna None se não for possível interpretar."""
    if not raw:
        return None
    try:
        return datetime.fromisoformat(str(raw).replace("Z", "+00:00")).replace(tzinfo=None)
    except Exception:
        return None


def build_verified_users_txt() -> disnake.File:
    """
    Gera um arquivo .txt com a lista completa de usuários verificados
    (ID, usuário, e-mail e data/hora da verificação), ordenados da
    verificação mais antiga para a mais recente.
    """
    users = get_oauth_verified_users()

    def _sort_key(u: dict):
        dt = _parse_verified_at(u.get("verified_at"))
        return dt or datetime.min

    users_sorted = sorted(users, key=_sort_key)

    lines = [
        "=" * 70,
        "LISTA DE USUÁRIOS VERIFICADOS (OAuth2)",
        f"Gerado em: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}",
        f"Total de usuários verificados: {len(users_sorted)}",
        "=" * 70,
        "",
    ]

    if not users_sorted:
        lines.append("Nenhum usuário verificado encontrado.")
    else:
        for i, u in enumerate(users_sorted, start=1):
            user_id = u.get("id", "N/A")
            username = u.get("username", "N/A")
            discriminator = str(u.get("discriminator", "0") or "0")
            display_name = f"{username}#{discriminator}" if discriminator not in ("0", "0000") else username
            email = u.get("email", "Não disponível")

            verified_dt = _parse_verified_at(u.get("verified_at"))
            verified_str = verified_dt.strftime("%d/%m/%Y %H:%M:%S") if verified_dt else "Desconhecido"

            lines.append(
                f"{i:>4}. {display_name} | ID: {user_id} | Email: {email} | Verificado em: {verified_str}"
            )

    content = "\n".join(lines)
    buffer = io.BytesIO(content.encode("utf-8"))
    filename = f"usuarios_verificados_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    return disnake.File(buffer, filename=filename)


# Períodos disponíveis no dashboard de verificações (mesmo padrão do dashboard de Rendimentos)
VERIFICATION_CHART_PERIODS = {
    "hoje": "Hoje",
    "7d": "7 dias",
    "30d": "30 dias",
    "total": "Total",
}


def _get_period_verified_users(period: str) -> list:
    """Retorna os usuários (com verified_at válido) dentro do período selecionado."""
    all_users = get_oauth_verified_users()
    dated_users = [u for u in all_users if _parse_verified_at(u.get("verified_at")) is not None]
    now = datetime.now()

    if period == "hoje":
        start = datetime(now.year, now.month, now.day)
    elif period == "7d":
        start = now - timedelta(days=7)
    elif period == "30d":
        start = now - timedelta(days=30)
    else:  # total
        return dated_users

    return [u for u in dated_users if _parse_verified_at(u.get("verified_at")) >= start]


def _compute_verification_period_stats(users_period: list, total_verified: int) -> dict:
    """Calcula as estatísticas (verificações no período, total geral, média por dia) exibidas no dashboard."""
    verifications = len(users_period)

    dates = sorted(_parse_verified_at(u.get("verified_at")) for u in users_period)
    if dates:
        span_days = max((dates[-1].date() - dates[0].date()).days + 1, 1)
    else:
        span_days = 1
    avg_per_day = verifications / span_days if span_days else 0.0

    return {
        "verifications": verifications,
        "total_verified": total_verified,
        "avg_per_day": avg_per_day,
    }


def _generate_verification_dashboard_chart(period: str, users_period: list) -> disnake.File:
    """Gera o gráfico de verificações (linha com área preenchida) no mesmo estilo do dashboard de Rendimentos."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.ticker import FuncFormatter, MaxNLocator

    now = datetime.now()
    teal = "#2dd4bf"
    bg = "#1e1f22"
    grid_color = "#3a3c41"
    text_color = "#b5bac1"

    x_positions: list = []
    y_values: list = []
    labels: list = []

    if period == "hoje":
        hourly = [0] * 24
        for u in users_period:
            dt = _parse_verified_at(u.get("verified_at"))
            if dt:
                hourly[dt.hour] += 1
        x_positions = list(range(24))
        y_values = hourly
        labels = [f"{h:02d}:00" for h in x_positions]

    elif period in ("7d", "30d"):
        days = 7 if period == "7d" else 30
        daily: dict = {}
        for i in range(days):
            d = (now - timedelta(days=days - 1 - i)).date()
            daily[d] = 0
        for u in users_period:
            dt = _parse_verified_at(u.get("verified_at"))
            if dt and dt.date() in daily:
                daily[dt.date()] += 1
        dates_sorted = sorted(daily.keys())
        x_positions = list(range(len(dates_sorted)))
        y_values = [daily[d] for d in dates_sorted]
        labels = [d.strftime("%d/%m") for d in dates_sorted]

    else:  # total
        if users_period:
            first_date = min(_parse_verified_at(u.get("verified_at")) for u in users_period).date()
            span_days = (now.date() - first_date).days + 1
        else:
            first_date = now.date()
            span_days = 1

        if span_days > 60:
            monthly: dict = {}
            for u in users_period:
                dt = _parse_verified_at(u.get("verified_at"))
                if dt:
                    key = dt.strftime("%Y-%m")
                    monthly[key] = monthly.get(key, 0) + 1
            keys_sorted = sorted(monthly.keys()) or [now.strftime("%Y-%m")]
            x_positions = list(range(len(keys_sorted)))
            y_values = [monthly.get(k, 0) for k in keys_sorted]
            labels = [datetime.strptime(k, "%Y-%m").strftime("%m/%Y") for k in keys_sorted]
        else:
            daily: dict = {}
            for i in range(span_days):
                d = first_date + timedelta(days=i)
                daily[d] = 0
            for u in users_period:
                dt = _parse_verified_at(u.get("verified_at"))
                if dt and dt.date() in daily:
                    daily[dt.date()] += 1
            dates_sorted = sorted(daily.keys())
            x_positions = list(range(len(dates_sorted)))
            y_values = [daily[d] for d in dates_sorted]
            labels = [d.strftime("%d/%m") for d in dates_sorted]

    if not x_positions:
        x_positions, y_values, labels = [0], [0], [""]

    legend_label = f"Verificações de {VERIFICATION_CHART_PERIODS.get(period, 'Hoje')}"

    plt.style.use("dark_background")
    fig, ax = plt.subplots(figsize=(9, 3.6), dpi=150)
    fig.patch.set_facecolor(bg)
    ax.set_facecolor(bg)

    ax.plot(x_positions, y_values, color=teal, linewidth=2, marker="o", markersize=3)
    ax.fill_between(x_positions, y_values, color=teal, alpha=0.2)

    max_y = max(y_values) if any(y_values) else 1
    ax.set_ylim(0, max_y * 1.2 if max_y > 0 else 1)

    ax.set_xticks(x_positions)
    step = max(1, len(x_positions) // 12)
    ax.set_xticklabels(
        [lbl if i % step == 0 else "" for i, lbl in enumerate(labels)],
        fontsize=8,
        color=text_color
    )
    ax.tick_params(axis="y", colors=text_color, labelsize=8)
    ax.tick_params(axis="x", colors=text_color, labelsize=8)
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{int(v)}"))
    ax.yaxis.set_major_locator(MaxNLocator(integer=True))

    ax.grid(True, color=grid_color, linewidth=0.6, alpha=0.6)
    for spine in ax.spines.values():
        spine.set_visible(False)

    ax.legend(
        [legend_label],
        loc="upper right",
        frameon=False,
        labelcolor="#dbdee1",
        fontsize=9,
        handlelength=1.5
    )

    plt.tight_layout()

    buffer = io.BytesIO()
    plt.savefig(buffer, format="png", dpi=150, facecolor=fig.get_facecolor())
    buffer.seek(0)
    plt.close(fig)

    return disnake.File(buffer, filename="dashboard_verificacoes.png")


def _build_verification_dashboard_components(period: str, stats: dict, filename: str) -> list:
    """Monta o Container (Components V2) do dashboard de verificações, no mesmo estilo do dashboard de Rendimentos."""
    period_label = VERIFICATION_CHART_PERIODS.get(period, "Hoje")

    buttons = [
        disnake.ui.Button(
            label=label,
            style=disnake.ButtonStyle.blurple if key == period else disnake.ButtonStyle.grey,
            custom_id=f"OAuthPanel_ChartPeriod_{key}"
        )
        for key, label in VERIFICATION_CHART_PERIODS.items()
    ]

    return [
        disnake.ui.Container(
            disnake.ui.TextDisplay(
                f"## \n"
                f"-# Painel > OAuth2 > **Gráfico de Verificações** > {period_label}"
            ),
            disnake.ui.Separator(),
            disnake.ui.TextDisplay(
                f"{emoji.members} **Verificações no período:** `{stats['verifications']}`\n"
                f"{emoji.correct} **Total de verificados:** `{stats['total_verified']}`\n"
                f"{emoji.chart} **Média por dia:** `{stats['avg_per_day']:.1f}`"
            ),
            disnake.ui.Separator(),
            disnake.ui.MediaGallery(
                disnake.MediaGalleryItem(media=f"attachment://{filename}")
            ),
            disnake.ui.ActionRow(*buttons),
            **_get_container_color_kwargs(),
        )
    ]


async def show_verification_dashboard(inter: disnake.Interaction, period: str = "hoje", as_new_message: bool = False):
    """Gera e exibe (ou atualiza) o dashboard de Gráfico de Verificações OAuth2 para o período selecionado."""
    all_users = get_oauth_verified_users()
    users_period = _get_period_verified_users(period)
    stats = _compute_verification_period_stats(users_period, total_verified=len(all_users))
    file = _generate_verification_dashboard_chart(period, users_period)
    components = _build_verification_dashboard_components(period, stats, filename=file.filename)

    send_kwargs = {
        "components": components,
        "files": [file],
        "flags": disnake.MessageFlags(is_components_v2=True),
    }

    if as_new_message:
        await inter.followup.send(**send_kwargs, ephemeral=True)
    else:
        # Edita a própria mensagem do dashboard (troca de período), removendo a imagem anterior
        await inter.response.edit_message(**send_kwargs, attachments=[])


def _get_mongo_users_collection():
    """Retorna a collection do bot atual no Mongo remoto do site de
    verificação, reaproveitando um MongoClient singleton (ver
    _get_verification_mongo_client) em vez de abrir uma conexão nova a cada
    chamada. Retorna None se não configurado / falhar a conexão."""
    try:
        bot_id, mongo_url, database_name = _get_verification_bot_id_and_mongo_url()

        if not bot_id or not mongo_url:
            return None

        client = _get_verification_mongo_client(mongo_url)
        return client[database_name][str(bot_id)]
    except Exception as e:
        logger.warning(f"[OAuthPanel] Erro ao conectar no Mongo: {e}")
        return None


def remove_oauth_verified_user(user_id: str) -> None:
    """
    Remove um usuário da lista de verificados (banco local + Mongo remoto).
    Usado quando o token OAuth2 dele foi revogado/expirou sem possibilidade
    de renovação — a partir daqui ele deixa de contar em "Total Verificados"
    e para de ser tratado como verificado em qualquer parte do sistema
    (painel, sync automático, /puxar verificados, etc.).
    """
    user_id = str(user_id)

    # Banco local
    try:
        local_data = db.get_document("cloud_oauth") or {}
        users = local_data.get("users", [])
        new_users = [u for u in users if str(u.get("id")) != user_id]
        if len(new_users) != len(users):
            local_data["users"] = new_users
            db.save_document("cloud_oauth", local_data)
    except Exception as e:
        logger.warning(f"[OAuthPanel] Erro ao remover {user_id} do banco local: {e}")

    # Mongo remoto (fonte usada pelo site de verificação).
    #
    # CORRECAO: antes isso fazia find_one (le o array inteiro) -> filtra em
    # Python -> $set do array inteiro de volta. Isso NAO e atomico: se o
    # site de verificacao gravar uma verificacao NOVA de outra pessoa nesse
    # documento entre o find_one e o update_one daqui, o $set com o array
    # inteiro sobrescreve/apaga essa gravacao concorrente -- e quanto mais
    # verificacoes simultaneas, maior a chance disso acontecer (ex: 3
    # pessoas se verificando ao mesmo tempo, so 1 sobrevive). Trocado por
    # $pull, que remove so o elemento certo do array de forma atomica no
    # proprio Mongo, sem nunca reescrever o array inteiro.
    try:
        collection = _get_mongo_users_collection()
        if collection is not None:
            id_variants = [user_id]
            if user_id.isdigit():
                id_variants.append(int(user_id))
            collection.update_one(
                {"_id": "cloud_oauth"},
                {"$pull": {"users": {"id": {"$in": id_variants}}}},
            )
    except Exception as e:
        logger.warning(f"[OAuthPanel] Erro ao remover {user_id} do Mongo: {e}")


def update_oauth_user_tokens(user_id: str, access_token: str = None, refresh_token: str = None) -> None:
    """Atualiza access_token/refresh_token de um usuário já verificado
    (banco local + Mongo), usado após renovar o token com sucesso."""
    user_id = str(user_id)

    def _patch(users: list) -> list:
        for u in users:
            if str(u.get("id")) == user_id:
                if access_token:
                    u["access_token"] = access_token
                if refresh_token:
                    u["refresh_token"] = refresh_token
        return users

    try:
        local_data = db.get_document("cloud_oauth") or {}
        users = local_data.get("users", [])
        if any(str(u.get("id")) == user_id for u in users):
            local_data["users"] = _patch(users)
            db.save_document("cloud_oauth", local_data)
    except Exception as e:
        logger.warning(f"[OAuthPanel] Erro ao atualizar tokens locais de {user_id}: {e}")

    # CORRECAO: mesmo problema do remove_oauth_verified_user -- trocado o
    # find_one + $set do array inteiro por um $set atomico so no elemento
    # do array que bate com o user_id (operador posicional "$"), usando o
    # array filter na query. Assim o revalidate_auth_loop (que roda a cada
    # 15s atualizando tokens) nunca mais sobrescreve/derruba verificacoes
    # novas que o site tenha acabado de gravar no mesmo documento.
    try:
        collection = _get_mongo_users_collection()
        if collection is not None:
            set_fields = {}
            if access_token:
                set_fields["users.$.access_token"] = access_token
            if refresh_token:
                set_fields["users.$.refresh_token"] = refresh_token
            if set_fields:
                id_variants = [user_id]
                if user_id.isdigit():
                    id_variants.append(int(user_id))
                collection.update_one(
                    {"_id": "cloud_oauth", "users.id": {"$in": id_variants}},
                    {"$set": set_fields},
                )
    except Exception as e:
        logger.warning(f"[OAuthPanel] Erro ao atualizar tokens remotos de {user_id}: {e}")


def get_oauth_message_config() -> dict:
    return _get_oauth_data().get("message_config", {"button_name": "", "button_emoji": "", "json": {}})


# --------------------------------------------------------------------------- #
#  URL helpers                                                                  #
# --------------------------------------------------------------------------- #

AUTH_BASE_URL   = "https://febre-system-auth.shardweb.app"
REDIRECT_URI    = f"{AUTH_BASE_URL}/api/auth/callback"
LOGIN_ROUTE     = f"{AUTH_BASE_URL}/response/login"

async def _safe_edit(inter, **kwargs):
    """Edit message safely regardless of whether response is done."""
    if inter.response.is_done():
        await inter.edit_original_message(**kwargs)
    else:
        await inter.response.edit_message(**kwargs)


async def _show_loading(inter):
    """Mostra 'Carregando informações...' antes de processar, igual ao padrão do bot."""
    await _safe_edit(inter,
        components=disnake.ui.TextDisplay(f"{emoji.loading} Carregando informações..."),
        flags=disnake.MessageFlags(is_components_v2=True)
    )



def _get_redirect_uri() -> str:
    """Retorna a redirect URI configurada no config_api.json."""
    try:
        from .cloud_config import get_auth_callback_url
        return get_auth_callback_url()
    except Exception:
        return REDIRECT_URI


def build_auth_url(client_id: str, guild_id: str | int = "", bot_id: str = "") -> str:
    """Gera a URL OAuth2 usando a redirect URI configurada no config_api.json.
    O state é enviado no formato bot_id:guild_id para o site conseguir
    buscar as credenciais corretas no MongoDB.
    """
    import urllib.parse
    redirect_uri = _get_redirect_uri()
    params = {
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "scope": "identify email guilds.join",
    }
    # Montar state no formato esperado pelo site: "bot_id:guild_id"
    if bot_id and guild_id:
        params["state"] = f"{bot_id}:{guild_id}"
    elif bot_id:
        params["state"] = f"{bot_id}:"
    elif guild_id:
        params["state"] = str(guild_id)
    return "https://discord.com/api/oauth2/authorize?" + urllib.parse.urlencode(params)


# --------------------------------------------------------------------------- #
#  Painel principal OAuth                                                       #
# --------------------------------------------------------------------------- #

async def panel_oauth(inter: disnake.Interaction, client: disnake.Client):
    """Abre o painel OAuth2 (equivalente ao /panel do bot de verificação)."""
    client_id     = get_oauth_client_id()
    client_secret = get_oauth_client_secret()
    verified_role = get_oauth_verified_role()
    log_channel   = get_oauth_log_channel()
    users         = get_oauth_verified_users()

    status_lines = (
        f"-# **Status:** `{'🟢 Configurado' if client_id else '🔴 Não Configurado'}`\n"
        f"-# **Client ID:** `{'✅ Definido' if client_id else '🔴 Não Definido'}`\n"
        f"-# **Client Secret:** `{'✅ Definido' if client_secret else '🔴 Não Definido'}`\n"
        f"-# **Cargo Verificado:** {f'<@&{verified_role}>' if verified_role else '`🔴 Não Definido`'}\n"
        f"-# **Canal de Logs:** {f'<#{log_channel}>' if log_channel else '`🔴 Não Definido`'}\n"
        f"-# **Total Verificados:** `{len(users)}`"
    )

    container = disnake.ui.Container(
        disnake.ui.Section(
            disnake.ui.TextDisplay(f"##   – OAuth2"),
            disnake.ui.TextDisplay(
                "- **Use as opções disponíveis abaixo para configurar, administrar e controlar "
                "o sistema de verificação OAuth2.**"
            ),
            accessory=disnake.ui.Thumbnail(media=client.user.display_avatar.url),
        ),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.TextDisplay(
            f"- **Informações do sistema:**\n{status_lines}"
        ),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.ActionRow(
            disnake.ui.StringSelect(
                custom_id="OAuthPanel_Menu",
                placeholder="[📦] - Navegação do painel",
                options=[
                    disnake.SelectOption(label="Gerenciar Mensagem",    value="message",    emoji=emoji.embed,    description="Configure a mensagem de verificação OAuth2."),
                    disnake.SelectOption(label="Blacklist",              value="blacklist",  emoji=emoji.wrong,    description="Gerencie IPs e usuários bloqueados."),
                ]
            )
        ),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.TextDisplay("-# **Controles do sistema**"),
        disnake.ui.ActionRow(
            disnake.ui.Button(label="Puxar Verificados",   style=disnake.ButtonStyle.green,  emoji=emoji.members,   custom_id="OAuthPanel_PullVerified"),
            disnake.ui.Button(label="Definições",          style=disnake.ButtonStyle.blurple, emoji=emoji.settings2, custom_id="OAuthPanel_Definitions"),
            disnake.ui.Button(label="Website",    style=disnake.ButtonStyle.blurple, emoji=emoji.web,       custom_id="OAuthPanel_Website"),
        ),
        disnake.ui.ActionRow(
            disnake.ui.Button(label="Gráfico de Verificações", style=disnake.ButtonStyle.grey, emoji=emoji.chart,  custom_id="OAuthPanel_Chart"),
            disnake.ui.Button(label="Exportar Verificados", style=disnake.ButtonStyle.grey, emoji=emoji.members, custom_id="OAuthPanel_ExportTxt"),
        ),
        **_get_container_color_kwargs(),
    )

    back_row = disnake.ui.ActionRow(
        disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="Cloud_Back"),
    )

    await inter.edit_original_message(
        components=[container, back_row],
        flags=disnake.MessageFlags(is_components_v2=True)
    )


# --------------------------------------------------------------------------- #
#  Sub-painéis                                                                  #
# --------------------------------------------------------------------------- #

async def panel_definitions(inter: disnake.MessageInteraction):
    verified_role = get_oauth_verified_role()
    log_channel   = get_oauth_log_channel()
    vpn_block_enabled = is_vpn_block_enabled()
    vpn_punishment = get_vpn_punishment()
    vpn_timeout_minutes = get_vpn_timeout_minutes()
    vpn_auto_blacklist = is_vpn_auto_blacklist_enabled()

    guild = inter.guild

    role_mention = (
        guild.get_role(int(verified_role)) if verified_role else None
    )
    chan_mention = (
        guild.get_channel(int(log_channel)) if log_channel else None
    )

    # Configurações > Cargos é a fonte única de verdade: se o cargo/canal
    # estiverem definidos lá, sempre exibimos como "herdado" daquele painel.
    cargos_config = db.get_document("cargos") or {}
    canais_config = db.get_document("canais") or {}
    role_inherited = bool(role_mention) and bool(cargos_config.get("cargo_verificado"))
    log_inherited = bool(chan_mention) and bool(canais_config.get("canal_de_logs_de_verificado"))

    role_status = (
        f"{role_mention.mention} `(herdado de Configurações > Cargos)`" if role_inherited
        else (role_mention.mention if role_mention else '`🔴 Não Configurado`')
    )
    log_status = (
        f"{chan_mention.mention} `(herdado de Configurações > Canais)`" if log_inherited
        else (chan_mention.mention if chan_mention else '`🔴 Não Configurado`')
    )

    container = disnake.ui.Container(
        disnake.ui.Section(
            disnake.ui.TextDisplay(f"##   – OAuth2"),
            disnake.ui.TextDisplay("- **Configure os cargos e canais de log do sistema OAuth2.**"),
            accessory=disnake.ui.Button(
                label="Voltar", emoji=emoji.back, style=disnake.ButtonStyle.danger,
                custom_id="OAuthPanel_Home"
            ),
        ),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.TextDisplay(
            f"## Cargos:\n"
            f"- -# **Cargo de verificado:** {role_status}\n"
            f"- -# Configure o cargo em **Painel > Configurações > Cargos**."
        ),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.TextDisplay(
            f"## Logs:\n"
            f"- -# **Logs de verificado:** {log_status}\n"
            f"- -# Configure o canal em **Painel > Configurações > Canais > Logs de Verificação**."
        ),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.TextDisplay("-# **Segurança**"),
        disnake.ui.ActionRow(
            disnake.ui.Button(
                label="Anti VPN",
                style=disnake.ButtonStyle.blurple,
                emoji=emoji.shield,
                custom_id="OAuthPanel_AntiVPN"
            ),
        ),
        **_get_container_color_kwargs(),
    )

    await _safe_edit(inter,
        components=[container],
        flags=disnake.MessageFlags(is_components_v2=True)
    )


class VPNTimeoutDurationModal(disnake.ui.Modal):
    def __init__(self):
        super().__init__(
            title="Duração do Timeout (VPN/Proxy)",
            custom_id="OAuthModal_VPNTimeoutDuration",
            components=[
                disnake.ui.Label(
                    text="Duração em minutos",
                    component=disnake.ui.TextInput(
                        custom_id="minutes",
                        placeholder="Ex: 10 (máximo 40320, ou seja, 28 dias)",
                        style=disnake.TextInputStyle.short,
                        required=True,
                        value=str(get_vpn_timeout_minutes()),
                    ),
                ),
            ],
        )

    async def callback(self, inter: disnake.ModalInteraction):
        raw = inter.text_values["minutes"].strip()
        try:
            minutes = int(raw)
            if minutes <= 0:
                raise ValueError
        except ValueError:
            await inter.response.send_message(
                "`🔴` Informe um número inteiro de minutos maior que zero.",
                ephemeral=True,
            )
            return
        set_vpn_timeout_minutes(minutes)
        await panel_definitions(inter)




async def panel_anti_vpn(inter: disnake.MessageInteraction):
    """Painel de configuração Anti-VPN/Proxy."""
    vpn_block_enabled = is_vpn_block_enabled()
    vpn_punishment = get_vpn_punishment()
    vpn_timeout_minutes = get_vpn_timeout_minutes()
    vpn_auto_blacklist = is_vpn_auto_blacklist_enabled()

    container = disnake.ui.Container(
        disnake.ui.Section(
            disnake.ui.TextDisplay(f"##   – OAuth2"),
            disnake.ui.TextDisplay("- **Configure a proteção contra VPN/Proxy do sistema OAuth2.**"),
            accessory=disnake.ui.Button(
                label="Voltar", emoji=emoji.back, style=disnake.ButtonStyle.danger,
                custom_id="OAuthPanel_Definitions"
            ),
        ),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.TextDisplay(
            f"## Segurança:\n"
            f"- -# **Bloquear VPN/Proxy:** {'`🟢 Ativado`' if vpn_block_enabled else '`🔴 Desativado`'}\n"
            f"- -# Quando ativado, usuários que se verificarem usando VPN, Proxy ou IP de "
            f"Datacenter não recebem (ou perdem) o cargo de verificado."
        ),
        disnake.ui.ActionRow(
            disnake.ui.Button(
                label="Desativar Bloqueio de VPN" if vpn_block_enabled else "Ativar Bloqueio de VPN",
                style=disnake.ButtonStyle.red if vpn_block_enabled else disnake.ButtonStyle.green,
                emoji=emoji.shield,
                custom_id="OAuthPanel_ToggleVPN"
            ),
        ),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.TextDisplay(
            f"## Punição por VPN/Proxy:\n"
            f"- -# **Punição atual:** `{VPN_PUNISHMENTS[vpn_punishment]}`\n"
            + (
                f"- -# **Duração do timeout:** `{vpn_timeout_minutes}` minuto(s)\n"
                if vpn_punishment == "timeout" else ""
            ) +
            f"- -# Escolha abaixo o que acontece com o usuário além de não receber o cargo."
        ),
        disnake.ui.ActionRow(
            disnake.ui.StringSelect(
                custom_id="OAuthPanel_VPNPunishmentSelect",
                placeholder="Escolha a punição para uso de VPN/Proxy",
                options=[
                    disnake.SelectOption(
                        label=label, value=value,
                        default=(value == vpn_punishment),
                    )
                    for value, label in VPN_PUNISHMENTS.items()
                ],
            )
        ),
        *(
            [disnake.ui.ActionRow(
                disnake.ui.Button(
                    label=f"Definir Duração do Timeout ({vpn_timeout_minutes} min)",
                    style=disnake.ButtonStyle.blurple,
                    emoji=emoji.settings2,
                    custom_id="OAuthPanel_VPNTimeoutDuration",
                ),
            )] if vpn_punishment == "timeout" else []
        ),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.TextDisplay(
            f"## Blacklist automática:\n"
            f"- -# **Adicionar IP à blacklist automaticamente:** "
            f"{'`🟢 Ativado`' if vpn_auto_blacklist else '`🔴 Desativado`'}\n"
            f"- -# Quando ativado, o IP de quem for pego usando VPN/Proxy é adicionado "
            f"automaticamente à blacklist (impedindo nova tentativa com o mesmo IP). "
            f"Quando desativado (padrão), você pode adicionar IPs manualmente pelo "
            f"menu **Blacklist**."
        ),
        disnake.ui.ActionRow(
            disnake.ui.Button(
                label="Desativar Blacklist Automática" if vpn_auto_blacklist else "Ativar Blacklist Automática",
                style=disnake.ButtonStyle.red if vpn_auto_blacklist else disnake.ButtonStyle.green,
                emoji=emoji.wrong,
                custom_id="OAuthPanel_ToggleVPNBlacklist",
            ),
        ),
        **_get_container_color_kwargs(),
    )

    await _safe_edit(inter,
        components=[container],
        flags=disnake.MessageFlags(is_components_v2=True)
    )


async def panel_website(inter: disnake.MessageInteraction):
    client_id     = get_oauth_client_id()
    client_secret = get_oauth_client_secret()
    users         = get_oauth_verified_users()

    auth_url = build_auth_url(client_id, bot_id=str(inter.bot.user.id)) if client_id else "Configure o Client ID e Secret primeiro."

    container = disnake.ui.Container(
        disnake.ui.Section(
            disnake.ui.TextDisplay(f"##   – OAuth2"),
            disnake.ui.TextDisplay("- **Informações de integração com o sistema OAuth2.**"),
            accessory=disnake.ui.Button(
                label="Voltar", emoji=emoji.back, style=disnake.ButtonStyle.danger,
                custom_id="OAuthPanel_Home"
            ),
        ),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.TextDisplay(
            f"## Estatísticas:\n"
            f"- -# **Total de Verificados:** `{len(users)}`"
        ),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.TextDisplay(
            f"## OAuth2:\n"
            f"- -# **Client Secret:** {'`✅ Definido`' if client_secret else '`🔴 Não Configurado`'}\n"
            f"- -# **Client ID:** {'`✅ Definido`' if client_id else '`🔴 Não Configurado`'}\n"
            f"- -# **Redirect URL para Developer Portal:**\n"
            f"`\n{REDIRECT_URI}\n`"
            + (f"\n- -# **Link de Verificação:**\n`\n{auth_url}\n`" if client_id and client_secret else "")
        ),
        disnake.ui.ActionRow(
            disnake.ui.Button(label="Definir Client ID",     style=disnake.ButtonStyle.blurple,
                              emoji=emoji.settings2, custom_id="OAuthPanel_SetClientID"),
            disnake.ui.Button(label="Definir Client Secret", style=disnake.ButtonStyle.blurple,
                              emoji=emoji.settings2, custom_id="OAuthPanel_SetClientSecret"),
        ),
        disnake.ui.ActionRow(
            disnake.ui.Button(label="Copiar Redirect URL",   style=disnake.ButtonStyle.grey,
                              emoji=emoji.web, custom_id="OAuthPanel_CopyRedirect",
                              disabled=not bool(client_id and client_secret)),
            disnake.ui.Button(label="Copiar Link Verificação", style=disnake.ButtonStyle.grey,
                              emoji=emoji.web, custom_id="OAuthPanel_CopyAuthURL",
                              disabled=not bool(client_id and client_secret)),
        ),
        **_get_container_color_kwargs(),
    )

    await _safe_edit(inter,
        components=[container],
        flags=disnake.MessageFlags(is_components_v2=True)
    )


async def panel_perms(inter: disnake.MessageInteraction):
    perms = get_oauth_perms()

    container = disnake.ui.Container(
        disnake.ui.Section(
            disnake.ui.TextDisplay(f"##   – OAuth2"),
            disnake.ui.TextDisplay("- **Gerencie quais usuários podem administrar o sistema OAuth2.**"),
            accessory=disnake.ui.Button(
                label="Voltar", emoji=emoji.back, style=disnake.ButtonStyle.danger,
                custom_id="OAuthPanel_Home"
            ),
        ),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.TextDisplay(f"- -# **Usuários com permissões:** `{len(perms)}/25`"),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.ActionRow(
            disnake.ui.StringSelect(
                custom_id="OAuthPanel_PermsMenu",
                placeholder="[📦] - Navegação de permissões",
                options=[
                    disnake.SelectOption(label="Adicionar Permissão",  value="add",  emoji=emoji.plus),
                    disnake.SelectOption(label="Remover Permissão",    value="rem",  emoji=emoji.wrong),
                    disnake.SelectOption(label="Visualizar Permissões",value="list", emoji=emoji.members),
                ]
            )
        ),
        **_get_container_color_kwargs(),
    )

    await _safe_edit(inter,
        components=[container],
        flags=disnake.MessageFlags(is_components_v2=True)
    )


async def panel_blacklist(inter: disnake.MessageInteraction):
    ips   = get_oauth_blacklist_ips()
    users = get_oauth_blacklist_users()

    container = disnake.ui.Container(
        disnake.ui.Section(
            disnake.ui.TextDisplay(f"##   – OAuth2"),
            disnake.ui.TextDisplay("- **Gerencie IPs e usuários bloqueados do sistema OAuth2.**"),
            accessory=disnake.ui.Button(
                label="Voltar", emoji=emoji.back, style=disnake.ButtonStyle.danger,
                custom_id="OAuthPanel_Home"
            ),
        ),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.TextDisplay(f"## IPs:\n- -# **IPs bloqueados:** `{len(ips)}/25`"),
        disnake.ui.ActionRow(
            disnake.ui.StringSelect(
                custom_id="OAuthPanel_BlacklistIPMenu",
                placeholder="[📦] - Navegação de IPs",
                options=[
                    disnake.SelectOption(label="Adicionar IP",    value="add",  emoji=emoji.plus),
                    disnake.SelectOption(label="Remover IP",      value="rem",  emoji=emoji.wrong),
                    disnake.SelectOption(label="Visualizar IPs",  value="list", emoji=emoji.members),
                ]
            )
        ),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.TextDisplay(f"## Usuários:\n- -# **Usuários bloqueados:** `{len(users)}/25`"),
        disnake.ui.ActionRow(
            disnake.ui.StringSelect(
                custom_id="OAuthPanel_BlacklistUserMenu",
                placeholder="[📦] - Navegação de Usuários",
                options=[
                    disnake.SelectOption(label="Adicionar Usuário",    value="add",  emoji=emoji.plus),
                    disnake.SelectOption(label="Remover Usuário",      value="rem",  emoji=emoji.wrong),
                    disnake.SelectOption(label="Visualizar Usuários",  value="list", emoji=emoji.members),
                ]
            )
        ),
        **_get_container_color_kwargs(),
    )

    await _safe_edit(inter,
        components=[container],
        flags=disnake.MessageFlags(is_components_v2=True)
    )


async def panel_message(inter: disnake.MessageInteraction):
    msg_cfg       = get_oauth_message_config()
    client_id     = get_oauth_client_id()
    client_secret = get_oauth_client_secret()
    has_json      = bool(msg_cfg.get("json"))
    has_btn       = bool(msg_cfg.get("button_name"))
    is_configured = bool(client_id and client_secret)
    can_post      = has_json and has_btn and is_configured

    container = disnake.ui.Container(
        disnake.ui.Section(
            disnake.ui.TextDisplay(f"##   – OAuth2"),
            disnake.ui.TextDisplay("- **Configure a mensagem de verificação do OAuth2.**"),
            accessory=disnake.ui.Button(
                label="Voltar", emoji=emoji.back, style=disnake.ButtonStyle.danger,
                custom_id="OAuthPanel_Home"
            ),
        ),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.TextDisplay(
            f"- -# **JSON:** `{'🟢 Configurado' if has_json else '🔴 Não Configurado'}`\n"
            f"- -# **Nome do botão:** `{msg_cfg.get('button_name') or '🔴 Não configurado'}`\n"
            f"- -# **Emoji do botão:** `{msg_cfg.get('button_emoji') or '🔴 Não configurado'}`\n"
            f"- -# **Client ID:** `{'🟢 Configurado' if client_id else '🔴 Não Configurado'}`\n"
            f"- -# **Client Secret:** `{'🟢 Configurado' if client_secret else '🔴 Não Configurado'}`"
        ),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.ActionRow(
            disnake.ui.StringSelect(
                custom_id="OAuthPanel_MessageMenu",
                placeholder="[📦] - Navegação da mensagem",
                options=[
                    disnake.SelectOption(label="Importar JSON",   value="import", emoji=emoji.reload),
                    disnake.SelectOption(label="Exportar JSON",   value="export", emoji=emoji.embed),
                    disnake.SelectOption(label="Limpar JSON",     value="reset",  emoji=emoji.wrong),
                ]
            )
        ),
        disnake.ui.ActionRow(
            disnake.ui.Button(label="Gerenciar Botão",      style=disnake.ButtonStyle.blurple,
                              emoji=emoji.settings2, custom_id="OAuthPanel_SetButton"),
            disnake.ui.Button(label="Visualizar Preview",   style=disnake.ButtonStyle.grey,
                              emoji=emoji.members, custom_id="OAuthPanel_Preview",
                              disabled=not (has_json and is_configured)),
            disnake.ui.Button(label="Abrir Editor",         style=disnake.ButtonStyle.link,
                              emoji=emoji.web, url="https://discohook.org/?data=eyJtZ"),
        ),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.ActionRow(
            disnake.ui.Button(label="Postar Mensagem", style=disnake.ButtonStyle.green,
                              emoji=emoji.correct, custom_id="OAuthPanel_PostMessage",
                              disabled=False),
        ),
        **_get_container_color_kwargs(),
    )

    await _safe_edit(inter,
        components=[container],
        flags=disnake.MessageFlags(is_components_v2=True)
    )


# --------------------------------------------------------------------------- #
#  Modais                                                                       #
# --------------------------------------------------------------------------- #

class PullVerifiedModal(disnake.ui.Modal):
    def __init__(self, bot):
        self.bot = bot
        super().__init__(
            title="Puxar Verificados",
            custom_id="OAuthModal_PullVerified",
            components=[
                disnake.ui.Label(
                    text="ID do Servidor de Origem (Opcional)",
                    component=disnake.ui.TextInput(
                        custom_id="guild_id",
                        placeholder="Deixe vazio para usar este servidor como origem",
                        style=disnake.TextInputStyle.short,
                        required=False,
                    ),
                ),
                disnake.ui.Label(
                    text="ID do Servidor de Destino (Opcional)",
                    component=disnake.ui.TextInput(
                        custom_id="dest_guild_id",
                        placeholder="Deixe vazio para usar este servidor como destino",
                        style=disnake.TextInputStyle.short,
                        required=False,
                    ),
                ),
                disnake.ui.Label(
                    text="Quantidade de Membros (Opcional)",
                    component=disnake.ui.TextInput(
                        custom_id="limit",
                        placeholder="Deixe vazio para puxar todos",
                        style=disnake.TextInputStyle.short,
                        required=False,
                    ),
                ),
            ],
        )

    async def callback(self, inter: disnake.ModalInteraction):
        await _process_pull_verified(inter, self.bot)


class SetClientIDModal(disnake.ui.Modal):
    def __init__(self):
        super().__init__(
            title="Definir Client ID",
            custom_id="OAuthModal_SetClientID",
            components=[
                disnake.ui.Label(
                    text="Client ID da aplicação",
                    component=disnake.ui.TextInput(
                        custom_id="client_id",
                        placeholder="Ex: 1234567890123456789",
                        style=disnake.TextInputStyle.short,
                        required=True,
                    ),
                ),
            ],
        )

    async def callback(self, inter: disnake.ModalInteraction):
        value = inter.text_values["client_id"].strip()
        data = _get_oauth_data()
        data["client_id"] = value
        _save_oauth_data(data)
        await panel_website(inter)


class SetClientSecretModal(disnake.ui.Modal):
    def __init__(self):
        super().__init__(
            title="Definir Client Secret",
            custom_id="OAuthModal_SetClientSecret",
            components=[
                disnake.ui.Label(
                    text="Client Secret da aplicação",
                    component=disnake.ui.TextInput(
                        custom_id="client_secret",
                        placeholder="Cole o Client Secret aqui",
                        style=disnake.TextInputStyle.short,
                        required=True,
                    ),
                ),
            ],
        )

    async def callback(self, inter: disnake.ModalInteraction):
        value = inter.text_values["client_secret"].strip()
        data = _get_oauth_data()
        data["client_secret"] = value
        _save_oauth_data(data)
        await panel_website(inter)


class SetButtonModal(disnake.ui.Modal):
    def __init__(self):
        cfg = get_oauth_message_config()
        super().__init__(
            title="Configurar Botão de Verificação",
            custom_id="OAuthModal_SetButton",
            components=[
                disnake.ui.Label(
                    text="Nome do botão",
                    component=disnake.ui.TextInput(
                        custom_id="button_name",
                        placeholder="Ex: Verificar-se",
                        style=disnake.TextInputStyle.short,
                        required=True,
                        value=cfg.get("button_name", ""),
                    ),
                ),
                disnake.ui.Label(
                    text="Emoji do botão (Opcional)",
                    component=disnake.ui.TextInput(
                        custom_id="button_emoji",
                        placeholder="Ex: ✔️ ou <:emoji:id>",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=cfg.get("button_emoji", ""),
                    ),
                ),
            ],
        )

    async def callback(self, inter: disnake.ModalInteraction):
        name  = inter.text_values["button_name"].strip()
        emoji_val = inter.text_values["button_emoji"].strip() or None
        data = _get_oauth_data()
        msg_cfg = data.get("message_config", {})
        msg_cfg["button_name"]  = name
        msg_cfg["button_emoji"] = emoji_val
        data["message_config"] = msg_cfg
        _save_oauth_data(data)
        await panel_message(inter)


class ImportJSONModal(disnake.ui.Modal):
    def __init__(self):
        super().__init__(
            title="Importar JSON da mensagem",
            custom_id="OAuthModal_ImportJSON",
            components=[
                disnake.ui.Label(
                    text="Conteúdo JSON (do Message Style)",
                    component=disnake.ui.TextInput(
                        custom_id="json_content",
                        placeholder="Cole o JSON exportado do Message Style",
                        style=disnake.TextInputStyle.paragraph,
                        required=True,
                    ),
                ),
            ],
        )

    async def callback(self, inter: disnake.ModalInteraction):
        import json as _json
        raw = inter.text_values["json_content"]
        try:
            parsed = _json.loads(raw)
        except Exception:
            await inter.response.send_message("`🔴` JSON inválido.", ephemeral=True)
            return
        # Remover campos não suportados
        for k in ("components", "actions", "flags"):
            parsed.pop(k, None)
        data = _get_oauth_data()
        msg_cfg = data.get("message_config", {})
        msg_cfg["json"] = parsed
        data["message_config"] = msg_cfg
        _save_oauth_data(data)
        await _show_loading(inter)
        await panel_message(inter)


class TextInputModal(disnake.ui.Modal):
    """Modal genérico de uma entrada de texto."""
    def __init__(self, title: str, custom_id: str, label: str, placeholder: str):
        super().__init__(
            title=title,
            custom_id=custom_id,
            components=[
                disnake.ui.Label(
                    text=label,
                    component=disnake.ui.TextInput(
                        custom_id="value",
                        placeholder=placeholder,
                        style=disnake.TextInputStyle.short,
                        required=True,
                    ),
                ),
            ],
        )


# --------------------------------------------------------------------------- #
#  Puxar Verificados                                                            #
# --------------------------------------------------------------------------- #

async def _process_pull_verified(inter: disnake.ModalInteraction, bot: disnake.Client):
    guild_id_input      = inter.text_values.get("guild_id", "").strip()
    dest_guild_id_input = inter.text_values.get("dest_guild_id", "").strip()
    limit_input         = inter.text_values.get("limit", "").strip()

    # Servidor de origem: de onde buscamos a lista de verificados
    src_guild_id  = guild_id_input or str(inter.guild.id)
    # Servidor de destino: para onde os membros serão puxados
    dest_guild_id = dest_guild_id_input or str(inter.guild.id)
    limit         = int(limit_input) if limit_input.isdigit() else None

    src_guild  = bot.get_guild(int(src_guild_id))
    dest_guild = bot.get_guild(int(dest_guild_id))

    if not dest_guild:
        await inter.response.send_message(
            "`🔴` Servidor de destino não encontrado. Verifique se o bot está nele.",
            ephemeral=True
        )
        return

    src_name  = src_guild.name  if src_guild  else f"ID {src_guild_id}"
    dest_name = dest_guild.name

    cross_server = src_guild_id != dest_guild_id

    await inter.response.send_message(
        f"`🔄` Iniciando processo de puxar verificados...\n"
        f"- **Origem:** {src_name}\n"
        f"- **Destino:** {dest_name}\n"
        f"- **Processando:** `0`/`?`\n"
        f"- **Puxados:** `0` | **Já no servidor:** `0`\n"
        f"- **Cargos adicionados:** `0` | **Erros:** `0`",
        ephemeral=True
    )

    # Buscar lista de verificados (da origem, se disponível; caso contrário, do banco global)
    if cross_server and src_guild:
        # Filtra apenas usuários que estão no servidor de origem
        all_users  = get_oauth_verified_users()
        src_member_ids = {str(m.id) for m in src_guild.members}
        users_list = [u for u in all_users if str(u.get("id", "")) in src_member_ids]
    else:
        users_list = get_oauth_verified_users()

    if limit:
        users_list = users_list[:limit]
    total = len(users_list)

    if total == 0:
        await inter.edit_original_message(content="`🔴` Nenhum usuário verificado encontrado na origem.")
        return

    # ── Renovar access_tokens expirados antes de tentar adicionar ──────────
    # (o site guarda o refresh_token e sabe renovar; sem isso, tokens com
    # mais de alguns dias falham com 403 "Invalid OAuth2 access token")
    await inter.edit_original_message(
        content=(
            f"`🔄` Renovando tokens de acesso antes de puxar...\n"
            f"- -# **Origem:** {src_name} → **Destino:** {dest_name}\n"
            f"- -# **Total de verificados:** `{total}`"
        )
    )
    # IMPORTANTE: o bot_id enviado ao site precisa ser o ID do PRÓPRIO bot em
    # execução (o mesmo valor usado no "state" da URL OAuth2 e como nome da
    # coleção no Mongo), e não o client_id da aplicação OAuth2 exclusiva de
    # verificação — são aplicações Discord diferentes. Usar o client_id aqui
    # fazia o site procurar credenciais numa coleção Mongo que nunca foi
    # populada, resultando em "Credenciais OAuth2 não configuradas" para
    # todo mundo mesmo com tudo configurado corretamente.
    cloud_data_for_refresh = db.get_document("cloud_data") or {}
    site_bot_id = str(bot.user.id) if bot.user else None
    if not site_bot_id:
        site_bot_id = cloud_data_for_refresh.get("client_id")
    refresh_summary = None
    if site_bot_id:
        try:
            bot_secret = cloud_data_for_refresh.get("bot_secret") or ""
            headers = {"X-Bot-Secret": bot_secret} if bot_secret else {}
            async with aiohttp.ClientSession() as refresh_session:
                from .cloud_config import get_auth_url
                async with refresh_session.post(
                    f"{get_auth_url()}/api/refresh_tokens_bulk",
                    json={"bot_id": site_bot_id, "user_ids": [str(u.get("id")) for u in users_list]},
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=60),
                ) as refresh_resp:
                    if refresh_resp.status == 200:
                        refresh_result = await refresh_resp.json()
                        results = refresh_result.get("results", {}) or {}
                        sem_refresh_token = sum(
                            1 for r in results.values()
                            if not r.get("success") and "refresh_token" in (r.get("error") or "")
                        )
                        outros_erros = refresh_result.get("failed", 0) - sem_refresh_token
                        # Pega um exemplo real de erro para diagnóstico (dos "outros erros")
                        exemplo_erro = None
                        for r in results.values():
                            if not r.get("success") and "refresh_token" not in (r.get("error") or ""):
                                exemplo_erro = r.get("error")
                                break
                        refresh_summary = (
                            f"Renovados: `{refresh_result.get('refreshed', 0)}` | "
                            f"Sem refresh_token salvo: `{sem_refresh_token}` | "
                            f"Outros erros: `{max(outros_erros, 0)}`"
                        )
                        if exemplo_erro:
                            refresh_summary += f"\n- -# **Exemplo de erro:** `{str(exemplo_erro)[:300]}`"
                        logger.info(f"[PullVerified] {refresh_summary}")
                        # Recarrega a lista para pegar os access_tokens atualizados
                        if cross_server and src_guild:
                            all_users  = get_oauth_verified_users()
                            src_member_ids = {str(m.id) for m in src_guild.members}
                            users_list = [u for u in all_users if str(u.get("id", "")) in src_member_ids]
                        else:
                            users_list = get_oauth_verified_users()
                        if limit:
                            users_list = users_list[:limit]
                    else:
                        body = await refresh_resp.text()
                        refresh_summary = f"`🔴` Falha ao renovar tokens em lote (status={refresh_resp.status})."
                        logger.warning(f"[PullVerified] Falha ao renovar tokens em lote (status={refresh_resp.status}): {body}")
        except Exception as e:
            refresh_summary = f"`🔴` Não foi possível renovar tokens em lote: {e}"
            logger.warning(f"[PullVerified] Não foi possível renovar tokens em lote: {e}")
    else:
        refresh_summary = "`🔴` client_id (bot_id do site) não configurado — pulando renovação de tokens."
        logger.warning("[PullVerified] client_id (bot_id do site) não configurado — pulando renovação de tokens.")

    await inter.edit_original_message(
        content=(
            f"- -# **Origem:** {src_name} → **Destino:** {dest_name}\n"
            f"- -# **Total de verificados:** `{total}`\n"
            f"- {refresh_summary}\n"
            f"`🔄` Iniciando o processo de puxar..."
        )
    )
    await asyncio.sleep(2)  # dá tempo do usuário ler o resumo antes de sobrescrever

    verified_role = get_oauth_verified_role()
    puxados = ja_no_servidor = cargos_adicionados = erros = 0
    exemplo_erro_puxar = None

    # IMPORTANTE: o Discord exige que o token "Bot" usado para adicionar o
    # membro (escopo guilds.join) seja da MESMA aplicação que emitiu o
    # access_token durante a verificação OAuth2. Como o "bot exclusivo" de
    # verificação (configurado em Cloud > Configurar Credenciais) é uma
    # aplicação Discord DIFERENTE do bot de vendas principal, usar
    # bot.http.token aqui sempre resulta em 403 "Invalid OAuth2 access
    # token" (code 50025) — mesmo com o access_token válido e recém-
    # renovado. Por isso usamos o token salvo em cloud_data["token"], que é
    # o token do bot exclusivo de verificação.
    oauth_bot_token = cloud_data_for_refresh.get("token") or bot.http.token

    for i, user_data in enumerate(users_list):
        try:
            member = None
            try:
                member = await dest_guild.fetch_member(int(user_data["id"]))
            except Exception:
                member = None

            if not member:
                try:
                    async with aiohttp.ClientSession() as session:
                        for attempt in range(2):  # 1 tentativa original + 1 retry se der 429
                            async with session.put(
                                f"https://discord.com/api/v10/guilds/{dest_guild_id}/members/{user_data['id']}",
                                headers={
                                    "Authorization": f"Bot {oauth_bot_token}",
                                    "Content-Type": "application/json"
                                },
                                json={"access_token": user_data.get("access_token", "")}
                            ) as resp:
                                if resp.status in (200, 201, 204):
                                    member = await dest_guild.fetch_member(int(user_data["id"]))
                                    puxados += 1
                                    break
                                elif resp.status == 429 and attempt == 0:
                                    try:
                                        retry_data = await resp.json()
                                        retry_after = float(retry_data.get("retry_after", 1))
                                    except Exception:
                                        retry_after = 1.0
                                    logger.warning(
                                        f"[PullVerified] Rate limit ao adicionar {user_data.get('id')}, "
                                        f"aguardando {retry_after:.2f}s e tentando novamente..."
                                    )
                                    await asyncio.sleep(retry_after + 0.1)
                                    continue
                                else:
                                    try:
                                        error_body = await resp.text()
                                    except Exception:
                                        error_body = "<sem corpo>"
                                    logger.warning(
                                        f"[PullVerified] Falha ao adicionar {user_data.get('id')} "
                                        f"(status={resp.status}): {error_body}"
                                    )
                                    if exemplo_erro_puxar is None:
                                        exemplo_erro_puxar = f"status={resp.status}: {error_body}"[:300]
                                    erros += 1
                                    break
                        else:
                            erros += 1
                except Exception as e:
                    logger.warning(f"[PullVerified] Exceção ao adicionar {user_data.get('id')}: {e}")
                    if exemplo_erro_puxar is None:
                        exemplo_erro_puxar = f"Exceção: {e}"[:300]
                    erros += 1
                    continue
            else:
                ja_no_servidor += 1

            # Pequeno intervalo entre requisições para evitar rate limit (429)
            await asyncio.sleep(0.4)

            if member and verified_role:
                role = dest_guild.get_role(int(verified_role))
                if role and role not in member.roles:
                    try:
                        await member.add_roles(role)
                        cargos_adicionados += 1
                    except Exception:
                        pass

            if (i + 1) % 3 == 0 or i == total - 1:
                await inter.edit_original_message(
                    content=(
                        f"- `🔄` Processando...\n"
                        f"  - -# **Origem:** {src_name} → **Destino:** {dest_name}\n"
                        f"  - -# **Processando:** `{i+1}`/`{total}`\n"
                        f"  - -# **Puxados:** `{puxados}` | **Já no servidor:** `{ja_no_servidor}`\n"
                        f"  - -# **Cargos adicionados:** `{cargos_adicionados}` | **Erros:** `{erros}`"
                    )
                )
        except Exception as e:
            logger.error(f"[PullVerified] Erro geral para usuário {user_data.get('id', '?')}: {e}")
            if exemplo_erro_puxar is None:
                exemplo_erro_puxar = f"Erro geral: {e}"[:300]
            erros += 1

    exemplo_erro_linha = f"\n  - -# **Exemplo de erro:** `{exemplo_erro_puxar}`" if exemplo_erro_puxar else ""
    await inter.edit_original_message(
        content=(
            f"- `✅` Processo concluído!\n"
            f"  - -# **Origem:** {src_name} → **Destino:** {dest_name}\n"
            f"  - -# **Total processado:** `{total}`\n"
            f"  - -# **Puxados:** `{puxados}` | **Já no servidor:** `{ja_no_servidor}`\n"
            f"  - -# **Cargos adicionados:** `{cargos_adicionados}` | **Erros:** `{erros}`"
            f"{exemplo_erro_linha}"
        )
    )


# --------------------------------------------------------------------------- #
#  Interaction dispatcher — chamado do cog.py                                   #
# --------------------------------------------------------------------------- #

async def dispatch(inter: disnake.MessageInteraction, bot: disnake.Client):
    """
    Roteador central de todas as interações do painel OAuth2.
    Chamar isso do on_message_interaction do Cloud cog.
    """
    cid = inter.data.custom_id if hasattr(inter.data, "custom_id") else inter.custom_id

    # ---- Navegação principal --------------------------------------------------
    if cid == "OAuthPanel_Home":
        await _show_loading(inter)
        await panel_oauth(inter, bot)
        return True

    if cid == "OAuthPanel_Menu":
        val = inter.values[0]
        await _show_loading(inter)
        if val == "perms":
            await panel_perms(inter)
        elif val == "message":
            await panel_message(inter)
        elif val == "blacklist":
            await panel_blacklist(inter)
        return True

    # ---- Controles principais -------------------------------------------------
    if cid == "OAuthPanel_PullVerified":
        await inter.response.send_modal(PullVerifiedModal(bot))
        return True

    if cid == "OAuthPanel_Definitions":
        await _show_loading(inter)
        await panel_definitions(inter)
        return True

    if cid == "OAuthPanel_AntiVPN":
        await _show_loading(inter)
        await panel_anti_vpn(inter)
        return True

    if cid == "OAuthPanel_ToggleVPN":
        set_vpn_block_enabled(not is_vpn_block_enabled())
        await _show_loading(inter)
        await panel_anti_vpn(inter)
        return True

    if cid == "OAuthPanel_VPNPunishmentSelect":
        set_vpn_punishment(inter.values[0])
        await _show_loading(inter)
        await panel_anti_vpn(inter)
        return True

    if cid == "OAuthPanel_VPNTimeoutDuration":
        await inter.response.send_modal(VPNTimeoutDurationModal())
        return True

    if cid == "OAuthPanel_ToggleVPNBlacklist":
        set_vpn_auto_blacklist_enabled(not is_vpn_auto_blacklist_enabled())
        await _show_loading(inter)
        await panel_anti_vpn(inter)
        return True

    if cid == "OAuthPanel_Website":
        await _show_loading(inter)
        await panel_website(inter)
        return True

    if cid == "OAuthPanel_Chart":
        try:
            await show_verification_dashboard(inter, "hoje", as_new_message=True)
        except Exception as e:
            logger.error(f"[OAuthPanel] Erro ao abrir dashboard de verificações: {e}")
            msg = "`🔴` Ocorreu um erro ao gerar o gráfico de verificações."
            if inter.response.is_done():
                await inter.followup.send(msg, ephemeral=True)
            else:
                await inter.response.send_message(msg, ephemeral=True)
        return True

    if cid.startswith("OAuthPanel_ChartPeriod_"):
        period = cid.split("OAuthPanel_ChartPeriod_", 1)[1]
        if period not in VERIFICATION_CHART_PERIODS:
            period = "hoje"
        try:
            await show_verification_dashboard(inter, period, as_new_message=False)
        except Exception as e:
            logger.error(f"[OAuthPanel] Erro ao trocar período do dashboard de verificações: {e}")
            msg = "`🔴` Ocorreu um erro ao atualizar o gráfico de verificações."
            if inter.response.is_done():
                await inter.followup.send(msg, ephemeral=True)
            else:
                await inter.response.send_message(msg, ephemeral=True)
        return True

    if cid == "OAuthPanel_ExportTxt":
        try:
            file = build_verified_users_txt()
        except Exception as e:
            logger.error(f"[OAuthPanel] Erro ao exportar usuários verificados: {e}")
            msg = "`🔴` Ocorreu um erro ao gerar o arquivo com os usuários verificados."
            if inter.response.is_done():
                await inter.followup.send(msg, ephemeral=True)
            else:
                await inter.response.send_message(msg, ephemeral=True)
            return True

        if inter.response.is_done():
            await inter.followup.send(
                content="`📄` Lista de usuários verificados exportada com sucesso:",
                file=file,
                ephemeral=True
            )
        else:
            await inter.response.send_message(
                content="`📄` Lista de usuários verificados exportada com sucesso:",
                file=file,
                ephemeral=True
            )
        return True

    # ---- Website / OAuth2 credenciais ----------------------------------------
    if cid == "OAuthPanel_SetClientID":
        await inter.response.send_modal(SetClientIDModal())
        return True

    if cid == "OAuthPanel_SetClientSecret":
        await inter.response.send_modal(SetClientSecretModal())
        return True

    if cid == "OAuthPanel_CopyRedirect":
        msg = f"`📋` Redirect URL para o Discord Developer Portal:\n`\n{REDIRECT_URI}\n`"
        if inter.response.is_done():
            await inter.followup.send(msg, ephemeral=True)
        else:
            await inter.response.send_message(msg, ephemeral=True)
        return True

    if cid == "OAuthPanel_CopyAuthURL":
        client_id = get_oauth_client_id()
        url = build_auth_url(client_id, bot_id=str(inter.bot.user.id)) if client_id else "Configure o Client ID primeiro."
        msg = f"`📋` Link de verificação:\n`\n{url}\n`"
        if inter.response.is_done():
            await inter.followup.send(msg, ephemeral=True)
        else:
            await inter.response.send_message(msg, ephemeral=True)
        return True

    # ---- Permissões ----------------------------------------------------------
    if cid == "OAuthPanel_PermsMenu":
        val = inter.values[0]
        if val == "add":
            await inter.response.send_modal(
                TextInputModal("Adicionar Permissão", "OAuthModal_PermAdd", "ID do usuário", "Ex: 123456789012345678")
            )
        elif val == "rem":
            await inter.response.send_modal(
                TextInputModal("Remover Permissão", "OAuthModal_PermRem", "ID do usuário", "Ex: 123456789012345678")
            )
        elif val == "list":
            perms = get_oauth_perms()
            if not perms:
                await inter.response.send_message("`🔴` Nenhum usuário com permissão.", ephemeral=True)
            else:
                lst = "\n".join(f"  - -# `{i+1}.` <@{u}> — [`{u}`]" for i, u in enumerate(perms))
                await inter.response.send_message(f"- `🟢` **Usuários com permissão:**\n{lst[:1900]}", ephemeral=True)
        return True

    if cid == "OAuthModal_PermAdd":
        user_id = inter.text_values["value"].strip()
        perms = get_oauth_perms()
        if len(perms) >= 25:
            await inter.response.send_message("`🔴` Limite de 25 permissões atingido.", ephemeral=True)
        elif user_id in perms:
            await inter.response.send_message("`🔴` Usuário já possui permissão.", ephemeral=True)
        else:
            perms.append(user_id)
            data = _get_oauth_data(); data["perms"] = perms; _save_oauth_data(data)
            await _show_loading(inter)
            await panel_perms(inter)
        return True

    if cid == "OAuthModal_PermRem":
        user_id = inter.text_values["value"].strip()
        perms = get_oauth_perms()
        if user_id not in perms:
            await inter.response.send_message("`🔴` Usuário não possui permissão.", ephemeral=True)
        else:
            perms.remove(user_id)
            data = _get_oauth_data(); data["perms"] = perms; _save_oauth_data(data)
            await _show_loading(inter)
            await panel_perms(inter)
        return True

    # ---- Blacklist -----------------------------------------------------------
    if cid == "OAuthPanel_BlacklistIPMenu":
        val = inter.values[0]
        if val == "add":
            await inter.response.send_modal(
                TextInputModal("Adicionar IP à Blacklist", "OAuthModal_BLIPAdd", "Endereço IP", "Ex: 192.168.1.1")
            )
        elif val == "rem":
            await inter.response.send_modal(
                TextInputModal("Remover IP da Blacklist", "OAuthModal_BLIPRem", "Endereço IP", "Ex: 192.168.1.1")
            )
        elif val == "list":
            ips = get_oauth_blacklist_ips()
            if not ips:
                await inter.response.send_message("`🔴` Nenhum IP bloqueado.", ephemeral=True)
            else:
                lst = "\n".join(f"  - -# `{i+1}.` `{ip}`" for i, ip in enumerate(ips))
                await inter.response.send_message(f"- `🟢` **IPs bloqueados:**\n{lst[:1900]}", ephemeral=True)
        return True

    if cid == "OAuthModal_BLIPAdd":
        ip = inter.text_values["value"].strip()
        ips = get_oauth_blacklist_ips()
        if len(ips) >= 25:
            await inter.response.send_message("`🔴` Limite de 25 IPs atingido.", ephemeral=True)
        elif ip in ips:
            await inter.response.send_message("`🔴` IP já está na blacklist.", ephemeral=True)
        else:
            ips.append(ip); data = _get_oauth_data(); data["blacklist_ips"] = ips; _save_oauth_data(data)
            await _show_loading(inter)
            await panel_blacklist(inter)
        return True

    if cid == "OAuthModal_BLIPRem":
        ip = inter.text_values["value"].strip()
        ips = get_oauth_blacklist_ips()
        if ip not in ips:
            await inter.response.send_message("`🔴` IP não está na blacklist.", ephemeral=True)
        else:
            ips.remove(ip); data = _get_oauth_data(); data["blacklist_ips"] = ips; _save_oauth_data(data)
            await _show_loading(inter)
            await panel_blacklist(inter)
        return True

    if cid == "OAuthPanel_BlacklistUserMenu":
        val = inter.values[0]
        if val == "add":
            await inter.response.send_modal(
                TextInputModal("Adicionar Usuário à Blacklist", "OAuthModal_BLUserAdd", "ID do usuário", "Ex: 123456789012345678")
            )
        elif val == "rem":
            await inter.response.send_modal(
                TextInputModal("Remover Usuário da Blacklist", "OAuthModal_BLUserRem", "ID do usuário", "Ex: 123456789012345678")
            )
        elif val == "list":
            users = get_oauth_blacklist_users()
            if not users:
                await inter.response.send_message("`🔴` Nenhum usuário bloqueado.", ephemeral=True)
            else:
                lst = "\n".join(f"  - -# `{i+1}.` <@{u}> — [`{u}`]" for i, u in enumerate(users))
                await inter.response.send_message(f"- `🟢` **Usuários bloqueados:**\n{lst[:1900]}", ephemeral=True)
        return True

    if cid == "OAuthModal_BLUserAdd":
        uid = inter.text_values["value"].strip()
        users = get_oauth_blacklist_users()
        if len(users) >= 25:
            await inter.response.send_message("`🔴` Limite de 25 usuários atingido.", ephemeral=True)
        elif uid in users:
            await inter.response.send_message("`🔴` Usuário já está na blacklist.", ephemeral=True)
        else:
            users.append(uid); data = _get_oauth_data(); data["blacklist_users"] = users; _save_oauth_data(data)
            await _show_loading(inter)
            await panel_blacklist(inter)
        return True

    if cid == "OAuthModal_BLUserRem":
        uid = inter.text_values["value"].strip()
        users = get_oauth_blacklist_users()
        if uid not in users:
            await inter.response.send_message("`🔴` Usuário não está na blacklist.", ephemeral=True)
        else:
            users.remove(uid); data = _get_oauth_data(); data["blacklist_users"] = users; _save_oauth_data(data)
            await _show_loading(inter)
            await panel_blacklist(inter)
        return True

    # ---- Mensagem ------------------------------------------------------------
    if cid == "OAuthPanel_MessageMenu":
        import json as _json
        val = inter.values[0]
        if val == "import":
            await inter.response.send_modal(ImportJSONModal())
        elif val == "export":
            msg_cfg = get_oauth_message_config()
            json_str = _json.dumps(msg_cfg.get("json", {}), indent=2, ensure_ascii=False)
            import io
            buf = io.BytesIO(json_str.encode("utf-8"))
            await inter.response.send_message(
                "`🟢` JSON exportado:",
                file=disnake.File(buf, filename="oauth-message.json"),
                ephemeral=True
            )
        elif val == "reset":
            data = _get_oauth_data()
            msg_cfg = data.get("message_config", {}); msg_cfg["json"] = {}
            data["message_config"] = msg_cfg; _save_oauth_data(data)
            await _show_loading(inter)
            await panel_message(inter)
        return True

    if cid == "OAuthPanel_SetButton":
        await inter.response.send_modal(SetButtonModal())
        return True

    if cid == "OAuthPanel_Preview":
        client_id     = get_oauth_client_id()
        msg_cfg       = get_oauth_message_config()
        msg_json      = msg_cfg.get("json", {})
        btn_name      = msg_cfg.get("button_name")
        btn_emoji_val = msg_cfg.get("button_emoji")

        auth_url = build_auth_url(client_id, inter.guild.id, bot_id=str(inter.bot.user.id))

        msg_opts: dict = {"content": msg_json.get("content")}
        if msg_json.get("embeds"):
            msg_opts["embeds"] = [disnake.Embed.from_dict(e) for e in msg_json["embeds"]]

        if btn_name:
            btn = disnake.ui.Button(label=btn_name, url=auth_url, style=disnake.ButtonStyle.link)
            if btn_emoji_val:
                btn.emoji = btn_emoji_val
            msg_opts["components"] = [disnake.ui.ActionRow(btn)]

        if inter.response.is_done():
            await inter.followup.send(**msg_opts, ephemeral=True)
        else:
            await inter.response.send_message(**msg_opts, ephemeral=True)
        return True

    if cid == "OAuthPanel_PostMessage":
        await _show_loading(inter)
        container = disnake.ui.Container(
            disnake.ui.TextDisplay("## `📤` Postar Mensagem"),
            disnake.ui.TextDisplay("- **Selecione o canal onde deseja postar a mensagem de verificação.**"),
            disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
            disnake.ui.ActionRow(
                disnake.ui.ChannelSelect(
                    custom_id="OAuthPanel_ChannelPostMessage",
                    placeholder="Selecione o canal",
                    channel_types=[disnake.ChannelType.text],
                    min_values=1, max_values=1
                )
            ),
            **_get_container_color_kwargs(),
        )
        await _safe_edit(inter,
            components=[container], flags=disnake.MessageFlags(is_components_v2=True)
        )
        return True

    if cid == "OAuthPanel_ChannelPostMessage":
        await _show_loading(inter)
        chan_id   = inter.values[0]
        client_id = get_oauth_client_id()
        msg_cfg   = get_oauth_message_config()
        msg_json  = msg_cfg.get("json", {})
        btn_name  = msg_cfg.get("button_name")
        btn_emoji_val = msg_cfg.get("button_emoji")

        channel = bot.get_channel(int(chan_id))
        if not channel:
            await _safe_edit(inter,
                components=[disnake.ui.Container(
                    disnake.ui.TextDisplay("`❌` Canal não encontrado."),
                    **_get_container_color_kwargs(),
                )],
                flags=disnake.MessageFlags(is_components_v2=True)
            )
            return True

        auth_url = build_auth_url(client_id, inter.guild.id, bot_id=str(inter.bot.user.id))
        msg_opts: dict = {}
        
        # Só adicionar content se não for None/vazio
        content = msg_json.get("content")
        if content:
            msg_opts["content"] = content
            
        if msg_json.get("embeds"):
            msg_opts["embeds"] = [disnake.Embed.from_dict(e) for e in msg_json["embeds"]]

        if btn_name:
            btn = disnake.ui.Button(label=btn_name, url=auth_url, style=disnake.ButtonStyle.link)
            if btn_emoji_val:
                btn.emoji = btn_emoji_val
            msg_opts["components"] = [disnake.ui.ActionRow(btn)]
        elif client_id:
            # Se não tiver botão configurado, adicionar botão padrão para não enviar mensagem vazia
            btn = disnake.ui.Button(label="Verificar", url=auth_url, style=disnake.ButtonStyle.link)
            msg_opts["components"] = [disnake.ui.ActionRow(btn)]

        # Garantir que a mensagem não seja vazia
        if not msg_opts:
            msg_opts["content"] = "Clique no botão abaixo para verificar."

        try:
            await channel.send(**msg_opts)
            await _safe_edit(inter,
                components=[disnake.ui.Container(
                    disnake.ui.TextDisplay(f"`🟢` Mensagem postada com sucesso em <#{chan_id}>!"),
                    **_get_container_color_kwargs(),
                )],
                flags=disnake.MessageFlags(is_components_v2=True)
            )
        except Exception as e:
            await _safe_edit(inter,
                components=[disnake.ui.Container(
                    disnake.ui.TextDisplay(f"`❌` Erro ao postar mensagem: {e}"),
                    **_get_container_color_kwargs(),
                )],
                flags=disnake.MessageFlags(is_components_v2=True)
            )
        return True

    return False  # Não era uma interação deste painel
