import aiohttp
import asyncio
import logging
import json
from datetime import timedelta

# Bridge para novo SocketIOManager de connections
try:
    from connections import get_manager as _get_ws_manager, initialize as init_ws
    from connections.socketio_manager import SocketIOManager
except ImportError:
    # Fallback se executado de diretório diferente
    from bot.connections import get_manager as _get_ws_manager, initialize as init_ws
    from bot.connections.socketio_manager import SocketIOManager

# Instância global do gerenciador WebSocket
websocket_manager = None
logger = logging.getLogger(__name__)

def get_websocket_manager():
    """Retorna a instância global do gerenciador WebSocket (bridge para novo SocketIOManager)"""
    global websocket_manager
    if websocket_manager is None:
        # Tentar obter do connections module
        websocket_manager = _get_ws_manager()
    if websocket_manager is None:
        # Criar novo manager se connections não foi inicializado
        # Respeitar config_socket.json
        import json
        import os
        try:
            config_path = os.path.join(os.path.dirname(__file__), '..', '..', 'configs', 'config_socket.json')
            with open(config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
            use_websocket = config.get('websocket', True)
        except:
            use_websocket = True
        
        bot_instance = get_bot_instance()
        if bot_instance:
            if use_websocket:
                websocket_manager = SocketIOManager(bot_instance)
            else:
                from connections.http_polling import HTTPPollingManager
                websocket_manager = HTTPPollingManager(bot_instance)
    return websocket_manager

def _get_http_base_url() -> str:
    """Obtém a URL base para chamadas HTTP da Sync Cloud API.
    Usa o config_api.json como fonte principal.
    """
    try:
        from .cloud_config import get_cloud_url
        return get_cloud_url()
    except Exception:
        # Fallback para config antigo
        try:
            from functions.database import database as db
            config = db.obter("configs/config_websocket.json") or {}
            websocket_cfg = (config.get("websocket_cloud") or {})
            http_cfg = (config.get("http") or {})
            return (
                websocket_cfg.get("http_url")
                or http_cfg.get("server_url")
                or websocket_cfg.get("server_url")
                or "https://discord.gg/BNvgyN9ekP"
            )
        except Exception:
            return "https://discord.gg/BNvgyN9ekP"

async def initialize_websocket():
    """Inicializa o WebSocket automaticamente se configurado"""
    from functions.database import database as db
    config = db.obter("configs/config_websocket.json")
    websocket_config = config.get("websocket_cloud", {})
    
    auto_start = websocket_config.get("auto_start", False)
    if not auto_start:
        logger.info("WebSocket auto-start desabilitado nas configurações")
        return
    
    try:
        # Aguardar um pouco para garantir que o bot está totalmente pronto
        logger.info("[CloudWebSocket] Aguardando bot estar totalmente pronto antes de conectar...")
        await asyncio.sleep(3)  # Aguardar 3 segundos antes de tentar conectar
        
        ws_manager = get_websocket_manager()
        
        # Verificar se já está conectado antes de tentar iniciar novamente
        if ws_manager.connected:
            logger.info("[CloudWebSocket] WebSocket já está conectado, pulando inicialização")
            return
        
        # Definir bot no WebSocketManager se disponível
        bot_instance = get_bot_instance()
        if bot_instance:
            ws_manager.set_bot(bot_instance)
            # Aguardar um pouco mais para garantir que o bot está totalmente configurado
            await asyncio.sleep(1)
        
        # Configurar callbacks
        async def on_connect():
            logger.info("[CloudWebSocket] WebSocket conectado com sucesso!")
        
        async def on_disconnect():
            # Não logar como warning - o WebSocketManager já cuida disso
            # Apenas logar como debug para não poluir os logs
            logger.debug("[CloudWebSocket] WebSocket desconectado - loop de reconexão ativo")
        
        async def on_error(e):
            logger.error(f"[CloudWebSocket] Erro no WebSocket: {e}")
        
        async def on_message(message_data):
            event = message_data.get('event')
            data = message_data.get('data', {})
            
            if event == 'auth_log':
                await process_auth_log(data)
            elif event == 'redeem_gift':
                await process_redeem_gift(data)
            elif event == 'recover_members':
                await process_recover_members(data)
            elif event == 'remove_verified_role':
                await process_remove_verified_role(data)
        
        ws_manager.set_callbacks(
            on_connect=on_connect,
            on_disconnect=on_disconnect,
            on_error=on_error,
            on_message=on_message
        )
        
        # Iniciar conexão
        logger.info("[CloudWebSocket] Iniciando conexão WebSocket...")
        await ws_manager.start()
        logger.info("[CloudWebSocket] WebSocket inicializado automaticamente")
        
    except Exception as e:
        logger.error(f"[CloudWebSocket] Erro ao inicializar WebSocket: {e}")
        import traceback
        traceback.print_exc()

def register_websocket_callbacks():
    """Registra callbacks de mensagens/desconexão/erro no WebSocket já conectado (não inicia conexão)."""
    try:
        ws_manager = get_websocket_manager()

        # Definir bot no WebSocketManager se disponível
        bot_instance = get_bot_instance()
        if bot_instance:
            ws_manager.set_bot(bot_instance)

        async def on_connect():
            logger.info("[CloudWebSocket] WebSocket callbacks registrados e conexão ativa!")

        async def on_disconnect():
            # Não logar como warning - o WebSocketManager já cuida disso
            # Apenas logar como debug para não poluir os logs
            logger.debug("[CloudWebSocket] WebSocket desconectado - loop de reconexão ativo")

        async def on_error(e):
            logger.error(f"[CloudWebSocket] Erro no WebSocket: {e}")

        async def on_message(message_data):
            event = message_data.get('event')
            data = message_data.get('data', {})
            
            logger.info(f"[DEBUG] on_message callback called with event: {event}")

            if event == 'auth_log':
                logger.info(f"[DEBUG] Processing auth_log event in callback")
                await process_auth_log(data)
            elif event == 'redeem_gift':
                await process_redeem_gift(data)
            elif event == 'recover_members':
                await process_recover_members(data)
            elif event == 'remove_verified_role':
                await process_remove_verified_role(data)

        ws_manager.set_callbacks(
            on_connect=on_connect,
            on_disconnect=on_disconnect,
            on_error=on_error,
            on_message=on_message
        )
    except Exception as e:
        logger.error(f"[CloudWebSocket] Erro ao registrar callbacks do WebSocket: {e}")

async def stop_websocket():
    """Para o WebSocket"""
    global websocket_manager
    if websocket_manager:
        await websocket_manager.stop()
        logger.info("[CloudWebSocket] WebSocket parado")

async def process_auth_log(auth_data: dict):
    """Processa log de autenticação recebido via WebSocket com timeout"""
    try:
        # Adicionar timeout para não bloquear indefinidamente
        await asyncio.wait_for(_process_auth_log_internal(auth_data), timeout=30.0)
    except asyncio.TimeoutError:
        logger.error("❌ Timeout ao processar log de auth (30s)")
    except Exception as e:
        logger.error(f"❌ Erro ao processar log de auth: {e}")
        import traceback
        traceback.print_exc()

async def _process_auth_log_internal(auth_data: dict):
    """Processamento interno do log de autenticação"""
    try:
        # Usar o mesmo sistema de detecção de duplicação do auth_logs.py
        # Criar identificador único usando o mesmo formato do auth_logs.py
        user_data = auth_data.get("user", {})
        user_id = user_data.get("id")
        verified_at = user_data.get("verified_at")
        unverified_at = user_data.get("unverified_at")
        
        # Identificar tipo de evento (verificação ou revogação) - mesmo formato do auth_logs.py
        is_revocation = unverified_at is not None
        event_type = "revoke" if is_revocation else "verify"

        from datetime import datetime
        import time
        timestamp = unverified_at if is_revocation else (verified_at or datetime.now().isoformat())
        log_id = f"{user_id}_{event_type}_{timestamp}"
        
        # Verificar se já foi processado RECENTEMENTE (usando variável global
        # compartilhada). Mesmo com log_id repetido — por exemplo se a Cloud
        # reenviar o mesmo "verified_at" de antes numa nova verificação após
        # uma desverificação — o log volta a ser processado depois que a
        # janela abaixo (mesma usada em auth_logs.py) expira.
        _DEDUP_WINDOW_SECONDS = 300  # 5 minutos
        
        if not hasattr(process_auth_log, '_processing'):
            process_auth_log._processing = {}
        
        vistos_em = process_auth_log._processing.get(log_id)
        if vistos_em is not None and (time.time() - vistos_em) < _DEDUP_WINDOW_SECONDS:
            logger.info(f"[AUTH_LOG] Processamento duplicado ignorado: {log_id}")
            return
        
        # Adicionar à lista de processamentos ANTES de processar (evitar race condition)
        process_auth_log._processing[log_id] = time.time()
        
        # Limpar processamentos antigos (fora da janela de dedup)
        process_auth_log._processing = {
            lid: vistos_em
            for lid, vistos_em in process_auth_log._processing.items()
            if (time.time() - vistos_em) < _DEDUP_WINDOW_SECONDS
        }
        if len(process_auth_log._processing) > 200:
            process_auth_log._processing = dict(
                sorted(process_auth_log._processing.items(), key=lambda item: item[1])[-100:]
            )
        
        logger.info(f"🔍 [AUTH_LOG] Dados recebidos: {auth_data}")
        
        from . import auth_logs
        
        # Obter instância do bot (precisamos de uma forma de acessar o bot)
        # Por enquanto, vamos usar uma abordagem global
        bot_instance = get_bot_instance()
        if bot_instance:
            logger.info(f"[AUTH_LOG] Bot instance encontrada")
            
            # Enviar log de auth com timeout
            try:
                success, message = await asyncio.wait_for(
                    auth_logs.send_auth_log(bot_instance, auth_data),
                    timeout=15.0
                )
                if success:
                    logger.info(f"Log de auth enviado: {message}")
                else:
                    logger.error(f"Erro ao enviar log de auth: {message}")
            except asyncio.TimeoutError:
                logger.error("❌ Timeout ao enviar log de auth (15s)")
            except Exception as e:
                logger.error(f"❌ Erro ao enviar log de auth: {e}")
            
            # Verificar se é verificação ou desverificação com timeout
            try:
                if auth_data.get("success") and "unverified_at" not in auth_data.get("user", {}):
                    # Verificação bem-sucedida — antes de dar o cargo, checar VPN/Proxy
                    # se o bloqueio estiver ativado nas definições
                    block_vpn = False
                    vpn_reason = None
                    try:
                        from .oauth_panel import is_vpn_block_enabled
                        if is_vpn_block_enabled():
                            ip = user_data.get("ip")
                            from . import vpn_check
                            block_vpn, vpn_reason = await asyncio.wait_for(
                                vpn_check.check_ip(ip), timeout=8.0
                            )
                    except Exception as e:
                        logger.warning(f"[AUTH_LOG] Erro ao checar VPN/Proxy: {e}")

                    if block_vpn:
                        logger.info(
                            f"[AUTH_LOG] Verificação de {user_id} bloqueada por VPN/Proxy: {vpn_reason}"
                        )
                        await asyncio.wait_for(
                            handle_vpn_blocked_user(bot_instance, auth_data, vpn_reason),
                            timeout=15.0
                        )
                    else:
                        logger.info(f"[AUTH_LOG] Verificação bem-sucedida, tentando dar cargo de verificado...")
                        await asyncio.wait_for(
                            give_verified_role(bot_instance, auth_data),
                            timeout=15.0
                        )
                elif not auth_data.get("success") or "unverified_at" in auth_data.get("user", {}):
                    # Desverificação ou falha - remover cargo
                    logger.info(f"[AUTH_LOG] Desverificação detectada, tentando remover cargo de verificado...")
                    await asyncio.wait_for(
                        remove_verified_role(bot_instance, auth_data),
                        timeout=15.0
                    )
                else:
                    logger.warning(f"[AUTH_LOG] Status de verificação não reconhecido")
            except asyncio.TimeoutError:
                logger.error("❌ Timeout ao processar cargo (15s)")
            except Exception as e:
                logger.error(f"❌ Erro ao processar cargo: {e}")
        else:
            logger.warning("Instância do bot não disponível para enviar log de auth")
            # Remover da lista de processamentos se não conseguiu processar
            process_auth_log._processing.pop(log_id, None)
            
    except Exception as e:
        logger.error(f"Erro ao processar log de auth: {e}")
        import traceback
        traceback.print_exc()
        # Em caso de erro, remover da lista para permitir nova tentativa
        try:
            user_data = auth_data.get("user", {})
            user_id = user_data.get("id")
            verified_at = user_data.get("verified_at")
            unverified_at = user_data.get("unverified_at")
            is_revocation = unverified_at is not None
            event_type = "revoke" if is_revocation else "verify"
            from datetime import datetime
            timestamp = unverified_at if is_revocation else (verified_at or datetime.now().isoformat())
            log_id = f"{user_id}_{event_type}_{timestamp}"
            if hasattr(process_auth_log, '_processing'):
                process_auth_log._processing.pop(log_id, None)
        except Exception:
            pass

async def give_verified_role(bot, auth_data: dict):
    """Dá o cargo de verificado para o usuário com retry logic"""
    max_retries = 3
    retry_delay = 2
    
    for attempt in range(max_retries):
        try:
            await _give_verified_role_internal(bot, auth_data)
            return  # Sucesso, sair do loop
        except Exception as e:
            if attempt < max_retries - 1:
                logger.warning(f"[GIVE_ROLE] Tentativa {attempt + 1}/{max_retries} falhou: {e}, tentando novamente...")
                await asyncio.sleep(retry_delay)
            else:
                logger.error(f"[GIVE_ROLE] Todas as tentativas falharam: {e}")
                raise

async def _give_verified_role_internal(bot, auth_data: dict):
    """Processamento interno de dar cargo"""
    try:
        logger.info(f"[GIVE_ROLE] Iniciando processo de dar cargo de verificado...")
        
        from functions.database import database as db
        
        user_data = auth_data.get("user", {})
        user_id = user_data.get("id")
        guild_id = auth_data.get("guild_id")
        
        if not user_id or not guild_id:
            logger.warning("Dados insuficientes para dar cargo de verificado")
            return
        
        # Obter ID do cargo de verificado
        cargos_config = db.get_document("cargos") or {}
        verified_role_id = cargos_config.get("cargo_verificado")
        
        if not verified_role_id:
            logger.warning("Cargo de verificado não configurado")
            return
        
        # Obter servidor e usuário
        guild = bot.get_guild(int(guild_id))
        if not guild:
            logger.warning(f"Servidor {guild_id} não encontrado")
            return
        
        try:
            member = await guild.fetch_member(int(user_id))
        except Exception:
            logger.warning(f"Membro {user_id} não encontrado no servidor {guild_id}")
            return
        
        # Obter cargo
        verified_role = guild.get_role(int(verified_role_id))
        if not verified_role:
            logger.warning(f"Cargo de verificado {verified_role_id} não encontrado")
            return
        
        # Verificar se o usuário já tem o cargo
        already_has_role = verified_role in member.roles
        
        # Dar o cargo se ainda não tiver
        if not already_has_role:
            await member.add_roles(verified_role, reason="Verificação automática via FebreCloud")
            logger.info(f"Cargo de verificado dado para {member.name} ({user_id}) no servidor {guild.name}")
        else:
            logger.info(f"Usuário {member.name} já tem o cargo de verificado")

        # Lógica para remover cargo de autorole (sempre verificar, mesmo se já tinha o cargo)
        cloud_config = db.get_document("cloud_data") or {}
        definitions = cloud_config.get("definitions", {})
        if definitions.get("remove_autorole", {}).get("enabled", False):
            logger.info(f"[REMOVE_AUTOROLE] Definição 'remove_autorole' está ativa.")
            cargos_config_autorole = db.get_document("cargos") or {}
            autorole_id = cargos_config_autorole.get("cargo_auto_role")
            
            if not autorole_id:
                logger.warning("[REMOVE_AUTOROLE] Cargo de autorole não configurado.")
            else:
                autorole = guild.get_role(int(autorole_id))
                if not autorole:
                    logger.warning(f"[REMOVE_AUTOROLE] Cargo de autorole {autorole_id} não encontrado no servidor.")
                elif autorole in member.roles:
                    try:
                        await member.remove_roles(autorole, reason="Remoção de autorole após verificação via FebreCloud")
                        logger.info(f"[REMOVE_AUTOROLE] Cargo de autorole removido de {member.name}.")
                    except Exception as e:
                        logger.error(f"[REMOVE_AUTOROLE] Erro ao remover cargo de autorole: {e}")
                else:
                    logger.debug(f"[REMOVE_AUTOROLE] Membro {member.name} não possuía o cargo de autorole.")
        
    except Exception as e:
        logger.error(f"Erro ao dar cargo de verificado: {e}")


async def handle_vpn_blocked_user(bot, auth_data: dict, motivo: str = None):
    """
    Trata um usuário cuja verificação foi bloqueada por uso de VPN/Proxy:
    - Não concede o cargo de verificado (ou remove, se por algum motivo já tiver)
    - Adiciona o IP à blacklist da OAuth2, SE a blacklist automática estiver
      ativada em Painel > Cloud > OAuth2 > Definições (por padrão vem
      DESATIVADA — precisa ser ativada explicitamente)
    - Aplica a punição configurada (nenhuma / kick / ban / timeout) em
      Painel > Cloud > OAuth2 > Definições
    - Envia um log distinto (reaproveitando o mesmo sistema de logs de auth)
    - Tenta avisar o usuário por DM
    """
    try:
        user_data = auth_data.get("user", {})
        user_id = user_data.get("id")
        guild_id = auth_data.get("guild_id")
        motivo = motivo or "VPN/Proxy detectado"

        logger.info(f"[VPN_BLOCK] Bloqueando verificação de {user_id}: {motivo}")

        from .oauth_panel import (
            add_oauth_blacklist_ip,
            is_vpn_auto_blacklist_enabled,
            get_vpn_punishment,
            get_vpn_timeout_minutes,
        )

        # Remove o cargo de verificado, caso por algum motivo já tenha sido concedido
        try:
            await remove_verified_role(bot, auth_data)
        except Exception as e:
            logger.warning(f"[VPN_BLOCK] Erro ao remover cargo de {user_id}: {e}")

        # Adiciona o IP à blacklist SOMENTE se a blacklist automática estiver
        # ativada nas definições (comportamento configurável, não é mais
        # automático por padrão).
        try:
            if is_vpn_auto_blacklist_enabled():
                ip = user_data.get("ip")
                if ip:
                    add_oauth_blacklist_ip(ip)
        except Exception as e:
            logger.warning(f"[VPN_BLOCK] Erro ao adicionar IP à blacklist: {e}")

        # Log distinto no canal configurado, reaproveitando o sistema de logs de auth
        try:
            from . import auth_logs
            blocked_user = dict(user_data)
            blocked_user["reason"] = motivo
            blocked_data = dict(auth_data)
            blocked_data["user"] = blocked_user
            blocked_data["success"] = False
            await auth_logs.send_auth_log(bot, blocked_data)
        except Exception as e:
            logger.warning(f"[VPN_BLOCK] Erro ao enviar log de bloqueio: {e}")

        # Busca o membro (usado tanto para a DM quanto para a punição)
        guild = None
        member = None
        if guild_id and user_id:
            try:
                guild = bot.get_guild(int(guild_id))
                member = await guild.fetch_member(int(user_id)) if guild else None
            except Exception:
                member = None

        punishment = get_vpn_punishment()

        # Tenta avisar o usuário por DM (best-effort, não é crítico se falhar).
        # Enviado ANTES de qualquer kick/ban, pois depois de kickado/banido
        # normalmente não é mais possível mandar DM.
        if member:
            try:
                extra = {
                    "kick": " Você também foi removido do servidor.",
                    "ban": " Você também foi banido do servidor.",
                    "timeout": f" Você também recebeu um timeout de {get_vpn_timeout_minutes()} minuto(s) no servidor.",
                }.get(punishment, "")
                await member.send(
                    "`🔴` Sua verificação não pôde ser concluída porque foi detectado o uso de "
                    "VPN, Proxy ou IP de datacenter. Desative a VPN/Proxy e tente se verificar novamente."
                    f"{extra}"
                )
            except Exception:
                pass

        # Aplica a punição configurada (além de negar o cargo de verificado)
        if member and punishment != "none":
            try:
                if punishment == "kick":
                    await member.kick(reason=f"Verificação bloqueada por VPN/Proxy: {motivo}")
                elif punishment == "ban":
                    await member.ban(reason=f"Verificação bloqueada por VPN/Proxy: {motivo}")
                elif punishment == "timeout":
                    minutes = get_vpn_timeout_minutes()
                    await member.timeout(
                        duration=timedelta(minutes=minutes),
                        reason=f"Verificação bloqueada por VPN/Proxy: {motivo}",
                    )
            except Exception as e:
                logger.warning(
                    f"[VPN_BLOCK] Erro ao aplicar punição '{punishment}' em {user_id}: {e}"
                )

    except Exception as e:
        logger.error(f"[VPN_BLOCK] Erro ao processar bloqueio de VPN: {e}")

async def remove_verified_role(bot, auth_data: dict):
    """Remove o cargo de verificado do usuário com retry logic"""
    max_retries = 3
    retry_delay = 2
    
    for attempt in range(max_retries):
        try:
            await _remove_verified_role_internal(bot, auth_data)
            return  # Sucesso, sair do loop
        except Exception as e:
            if attempt < max_retries - 1:
                logger.warning(f"[REMOVE_ROLE] Tentativa {attempt + 1}/{max_retries} falhou: {e}, tentando novamente...")
                await asyncio.sleep(retry_delay)
            else:
                logger.error(f"[REMOVE_ROLE] Todas as tentativas falharam: {e}")
                raise

async def _remove_verified_role_internal(bot, auth_data: dict):
    """Processamento interno de remover cargo"""
    try:
        logger.info(f"[REMOVE_ROLE] Iniciando processo de remover cargo de verificado...")
        
        from functions.database import database as db
        
        user_data = auth_data.get("user", {})
        user_id = user_data.get("id")
        guild_id = auth_data.get("guild_id")
        
        if not user_id or not guild_id:
            logger.warning("Dados insuficientes para remover cargo de verificado")
            return
        
        # Obter ID do cargo de verificado
        cargos_config = db.get_document("cargos") or {}
        verified_role_id = cargos_config.get("cargo_verificado")
        
        if not verified_role_id:
            logger.warning("Cargo de verificado não configurado")
            return
        
        # Obter servidor e usuário
        guild = bot.get_guild(int(guild_id))
        if not guild:
            logger.warning(f"Servidor {guild_id} não encontrado")
            return
        
        try:
            member = await guild.fetch_member(int(user_id))
        except Exception:
            logger.warning(f"Membro {user_id} não encontrado no servidor {guild_id} durante a remoção do cargo")
            return
        
        # Obter cargo
        verified_role = guild.get_role(int(verified_role_id))
        if not verified_role:
            logger.warning(f"⚠️ Cargo de verificado {verified_role_id} não encontrado")
            return
        
        # Verificar se o usuário tem o cargo
        if verified_role not in member.roles:
            logger.info(f"ℹ️ Usuário {member.name} não tem o cargo de verificado")
            return
        
        # Remover o cargo
        await member.remove_roles(verified_role, reason="Desverificação automática via FebreCloud")
        logger.info(f"✅ Cargo de verificado removido de {member.name} ({user_id}) no servidor {guild.name}")
        
    except Exception as e:
        logger.error(f"❌ Erro ao remover cargo de verificado: {e}")

async def process_remove_verified_role(remove_data: dict):
    """Processa evento específico de remoção de cargo de verificado"""
    try:
        logger.info(f"🗑️ [PROCESS_REMOVE_ROLE] Processando remoção de cargo: {remove_data}")
        
        # Validar se o evento pertence ao servidor principal deste bot
        from functions.database import database as db
        
        guild_id = remove_data.get("guild_id")
        main_server_id = db.obter("config.json").get("bot", {}).get("server")
        
        if guild_id and main_server_id and str(guild_id) != str(main_server_id):
            logger.info(f"⚠️ [PROCESS_REMOVE_ROLE] Evento ignorado - guild_id {guild_id} não corresponde ao servidor principal {main_server_id}")
            return
        
        user_id = remove_data.get("user_id")
        reason = remove_data.get("reason", "Token revogado")
        
        if not user_id or not guild_id:
            logger.warning("⚠️ Dados insuficientes para processar remoção de cargo")
            return
        
        # Obter instância do bot
        bot_instance = get_bot_instance()
        if not bot_instance:
            logger.warning("⚠️ Instância do bot não disponível")
            return
        
        # Criar estrutura de dados compatível com remove_verified_role
        auth_data = {
            "user": {"id": user_id},
            "guild_id": guild_id,
            "success": False
        }
        
        # Remover cargo
        await remove_verified_role(bot_instance, auth_data)
        logger.info(f"✅ Processamento de remoção de cargo concluído para usuário {user_id}")
        
    except Exception as e:
        logger.error(f"❌ Erro ao processar remoção de cargo: {e}")

async def process_redeem_gift(redeem_data: dict):
    """Processa resgate de gift recebido via WebSocket"""
    try:
        logger.info(f"🔍 [REDEEM_GIFT] Dados de resgate recebidos: {redeem_data}")
        
        # Validar se o evento pertence ao servidor principal deste bot
        from functions.database import database as db
        
        guild_id = redeem_data.get("guildId")
        bot_id = redeem_data.get("botId")
        cloud_config = db.get_document("cloud_data") or {}
        bot_client_id = cloud_config.get("client_id")
        main_server_id = db.obter("config.json").get("bot", {}).get("server")
        
        # Verificar se o bot_id corresponde a este bot
        if bot_id and bot_client_id and str(bot_id) != str(bot_client_id):
            logger.info(f"⚠️ [REDEEM_GIFT] Evento ignorado - bot_id {bot_id} não corresponde ao bot {bot_client_id}")
            return
        
        # Verificar se o guild_id corresponde ao servidor principal
        if guild_id and main_server_id and str(guild_id) != str(main_server_id):
            logger.info(f"⚠️ [REDEEM_GIFT] Evento ignorado - guild_id {guild_id} não corresponde ao servidor principal {main_server_id}")
            return
        
        gift_id = redeem_data.get("giftId")
        members = redeem_data.get("members", [])
        members_count = redeem_data.get("membersCount", 0)
        
        # Obter instância do bot
        bot_instance = get_bot_instance()
        if not bot_instance:
            logger.warning("⚠️ Instância do bot não disponível para processar resgate de gift")
            return
        
        # Obter servidor
        guild = bot_instance.get_guild(int(guild_id))
        if not guild:
            logger.warning(f"⚠️ Servidor {guild_id} não encontrado")
            return
        
        # Processar cada membro
        success_count = 0
        failed_count = 0
        
        for member_data in members:
            try:
                user_id = int(member_data.get("id"))
                access_token = member_data.get("access_token")
                
                # Verificar se já está no servidor
                existing_member = guild.get_member(user_id)
                if existing_member:
                    failed_count += 1
                    continue
                
                if not access_token:
                    failed_count += 1
                    continue
                
                # Adicionar membro ao servidor
                success = await add_member_to_guild(bot_instance, guild, user_id, access_token)
                if success:
                    success_count += 1
                else:
                    failed_count += 1
                
            except Exception as e:
                logger.error(f"❌ Erro ao processar membro {member_data.get('id', 'unknown')}: {e}")
                failed_count += 1
        
        logger.info(f"✅ Resgate de gift {gift_id} concluído - Sucessos: {success_count}, Falhas: {failed_count}")
        
    except Exception as e:
        logger.error(f"❌ Erro ao processar resgate de gift: {e}")

async def process_recover_members(recover_data: dict):
    """Processa recuperação de membros recebida via WebSocket.
    Espera payload semelhante ao de gift, com chaves: guildId, members (lista com id/access_token), botId.
    """
    try:
        logger.info(f"🔍 [RECOVER_MEMBERS] Dados recebidos: {recover_data}")
        
        # Validar se o evento pertence ao servidor principal deste bot
        from functions.database import database as db
        
        guild_id = recover_data.get("guildId")
        bot_id = recover_data.get("botId")
        cloud_config = db.get_document("cloud_data") or {}
        bot_client_id = cloud_config.get("client_id")
        main_server_id = db.obter("config.json").get("bot", {}).get("server")
        
        # Verificar se o bot_id corresponde a este bot
        if bot_id and bot_client_id and str(bot_id) != str(bot_client_id):
            logger.info(f"⚠️ [RECOVER_MEMBERS] Evento ignorado - bot_id {bot_id} não corresponde ao bot {bot_client_id}")
            return
        
        # Verificar se o guild_id corresponde ao servidor principal
        if guild_id and main_server_id and str(guild_id) != str(main_server_id):
            logger.info(f"⚠️ [RECOVER_MEMBERS] Evento ignorado - guild_id {guild_id} não corresponde ao servidor principal {main_server_id}")
            return
        
        members = recover_data.get("members", [])

        success_count = 0
        failed_count = 0

        for member_data in members:
            try:
                user_id = int(member_data.get("id") or member_data.get("userId"))
                access_token = member_data.get("access_token")

                if not access_token:
                    failed_count += 1
                    continue

                success, _err = await add_member_to_guild_by_id(str(guild_id), user_id, access_token)
                if success:
                    success_count += 1
                else:
                    failed_count += 1
            except Exception as e:
                logger.error(f"❌ [RECOVER_MEMBERS] Erro ao processar membro {member_data.get('id', 'unknown')}: {e}")
                failed_count += 1

        logger.info(f"✅ [RECOVER_MEMBERS] Concluído - Sucessos: {success_count}, Falhas: {failed_count}")
    except Exception as e:
        logger.error(f"❌ Erro ao processar recover_members: {e}")

def _get_bot_token_from_config() -> str:
    """Lê o token do bot direto do config.json (mesmo token que o bot usa pra
    conectar no Discord). Lido a cada chamada -- não cacheado -- então se o
    token no config.json mudar (ex: reset no Developer Portal + atualização
    manual do arquivo), o próximo ciclo do Gift Sync já usa o token novo
    automaticamente, sem precisar reconfigurar nada em Febre Cloud."""
    try:
        from functions.database import database as db
        config = db.obter("config.json") or {}
        token = (config.get("bot") or {}).get("token") or config.get("botToken")
        return token or ""
    except Exception as e:
        logger.error(f"❌ [ADD_MEMBER] Erro ao ler token do bot em config.json: {e}")
        return ""


async def add_member_to_guild(bot, guild, user_id: int, access_token: str) -> bool:
    """Adiciona um membro ao servidor usando access_token (requer guild no cache)."""
    try:
        import aiohttp
        
        url = f"https://discord.com/api/v10/guilds/{guild.id}/members/{user_id}"
        
        # Token do bot: sempre lido direto do config.json (ver _get_bot_token_from_config)
        bot_token = _get_bot_token_from_config()
        
        if not bot_token:
            print("❌ [ADD_MEMBER] Token do bot não encontrado em config.json")
            logger.error("❌ [ADD_MEMBER] Token do bot não encontrado em config.json")
            return False
        
        headers = {
            "Authorization": f"Bot {bot_token}",
            "Content-Type": "application/json"
        }
        
        data = {
            "access_token": access_token
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.put(url, headers=headers, json=data) as response:
                response_text = await response.text()
                
                if response.status == 201:
                    return True
                elif response.status == 204:
                    return True
                else:
                    error_data = await response.json() if response_text else {}
                    error_message = error_data.get('message', f'Erro HTTP {response.status}')
                    print(f"❌ [ADD_MEMBER] Erro ao adicionar usuário {user_id}: {error_message}")
                    logger.error(f"❌ [ADD_MEMBER] Erro ao adicionar usuário {user_id}: {error_message}")
                    return False
                    
    except Exception as e:
        print(f"❌ [ADD_MEMBER] Erro ao adicionar membro {user_id}: {e}")
        logger.error(f"❌ [ADD_MEMBER] Erro ao adicionar membro {user_id}: {e}")
        return False

async def add_member_to_guild_by_id(guild_id: str, user_id: int, access_token: str) -> tuple[bool, str | None]:
    """Adiciona um membro ao servidor usando apenas o guild_id (sem precisar do guild no cache).

    Retorna (sucesso, mensagem_de_erro). mensagem_de_erro é None em caso de
    sucesso -- CORRECAO: antes só retornava bool e o motivo real do erro
    (ex: "Missing Access", token expirado, já é membro, etc.) ficava só no
    print/logger daqui, sem chegar em quem chamou -- então gift_sync.py não
    tinha como registrar/mostrar o motivo de cada falha em tempo real."""
    try:
        import aiohttp
        # Token do bot: sempre lido direto do config.json (ver _get_bot_token_from_config)
        bot_token = _get_bot_token_from_config()
        if not bot_token:
            msg = "Token do bot não encontrado em config.json"
            print(f"❌ [ADD_MEMBER_BY_ID] {msg}")
            logger.error(f"❌ [ADD_MEMBER_BY_ID] {msg}")
            return False, msg

        url = f"https://discord.com/api/v10/guilds/{guild_id}/members/{user_id}"
        headers = {
            "Authorization": f"Bot {bot_token}",
            "Content-Type": "application/json"
        }
        data = {"access_token": access_token}

        async with aiohttp.ClientSession() as session:
            async with session.put(url, headers=headers, json=data) as response:
                response_text = await response.text()
                if response.status in (201, 204):
                    return True, None
                else:
                    try:
                        error_data = await response.json() if response_text else {}
                        error_message = error_data.get('message', f'Erro HTTP {response.status}')
                    except Exception:
                        error_message = f'Erro HTTP {response.status}: {response_text}'
                    print(f"❌ [ADD_MEMBER_BY_ID] Erro ao adicionar usuário {user_id} ao guild {guild_id}: {error_message}")
                    logger.error(f"❌ [ADD_MEMBER_BY_ID] Erro ao adicionar usuário {user_id} ao guild {guild_id}: {error_message}")
                    return False, error_message
    except Exception as e:
        print(f"❌ [ADD_MEMBER_BY_ID] Erro ao adicionar membro {user_id} ao guild {guild_id}: {e}")
        logger.error(f"❌ [ADD_MEMBER_BY_ID] Erro ao adicionar membro {user_id} ao guild {guild_id}: {e}")
        return False, str(e)

# Variável global para armazenar instância do bot
_bot_instance = None

def set_bot_instance(bot):
    """Define a instância do bot para uso global"""
    global _bot_instance
    _bot_instance = bot
    
    # Definir bot no WebSocketManager se existir
    global websocket_manager
    if websocket_manager:
        websocket_manager.set_bot(bot)

def get_bot_instance():
    """Retorna a instância do bot"""
    return _bot_instance

async def register_bot(main_bot_id: str, bot_token: str, client_secret: str, verified_role_id: str, log_channel_id: str, auto_role_id: str = None) -> tuple[bool, str, dict]:
    """Valida o token direto com a API do Discord e monta o bot_info a ser salvo
    em cloud_data -- SEM depender do serviço externo Lunar/Febre Cloud.

    Antes esta função tentava (1) WebSocket -- sempre falha, é stub, ver
    connections/socketio_manager.py::register_bot -- e depois (2) um POST
    HTTP pra `{cloud_url}/api/bot/register`, um serviço externo que está fora
    do ar (mesmo domínio que falha com 404 no socket.io nos logs). Como
    resultado, mesmo preenchendo o modal corretamente, o token nunca era
    salvo em cloud_data e o Gift Sync sempre falhava com "Token do bot não
    encontrado". Agora seguimos o mesmo padrão já usado por oauth_panel.py e
    gift_cards.py: nada de serviço externo, só validação direta + banco.
    """
    try:
        async with aiohttp.ClientSession() as session:
            # Validar token com a API do Discord
            async with session.get('https://discord.com/api/v10/users/@me', headers={'Authorization': f'Bot {bot_token}'}) as resp:
                if resp.status != 200:
                    return False, "Token do bot inválido.", {}
                bot_info = await resp.json()
                client_id = bot_info['id']
                bot_name = bot_info['username']

        from functions.database import database as db
        main_server_id = db.obter("config.json").get("bot", {}).get("server")
        full_bot_info = {
            "client_id": client_id,
            "client_secret": client_secret,
            "token": bot_token,
            "name": bot_name,
            "main_server_id": main_server_id
        }
        return True, "Credenciais salvas com sucesso!", full_bot_info
    except Exception as e:
        return False, f"Erro ao validar o token: {e}", {}

async def recover_bot_data(bot_id: str, recovery_data: dict = None) -> tuple[bool, str, dict]:
    """Recupera dados de um bot via WebSocket ou HTTP"""
    ws_manager = get_websocket_manager()
    
    # Tentar via WebSocket primeiro
    if ws_manager and ws_manager.is_connected():
        try:
            response = await ws_manager.recover_data(bot_id, recovery_data)
            
            if response.get("success"):
                return True, response.get("message", "Dados recuperados com sucesso!"), response.get("data", {})
            else:
                return False, response.get("message", "Erro ao recuperar dados do bot"), {}
                
        except Exception as e:
            logger.warning(f"WebSocket falhou, tentando HTTP: {e}")
    
    # Fallback: Recuperar via HTTP
    try:
        cloud_url = _get_http_base_url()
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"{cloud_url}/api/bot/recover",
                params={'botId': bot_id},
                timeout=aiohttp.ClientTimeout(total=30)
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    if data.get("success"):
                        return True, "Dados recuperados com sucesso via HTTP!", data.get("data", {})
                    else:
                        return False, data.get("message", "Erro ao recuperar dados do bot"), {}
                else:
                    return False, f"Erro HTTP {resp.status}", {}
    except Exception as e:
        return False, f"Erro na comunicação: {str(e)}", {}

async def start_recover_members(server_id: str, concurrency: int | None = None, base_delay_ms: int | None = None) -> dict:
    """Inicia o processo de recuperação de membros via HTTP (como gifts), informando apenas o server_id.

    Retorna um dicionário com chaves: success, message, data (contendo recovery_id, estimated_time, etc.).
    """
    try:
        # Obter credenciais do bot (cloud)
        from functions.database import database as db
        cloud_config = db.get_document("cloud_data") or {}
        client_id = cloud_config.get("client_id")
        client_secret = cloud_config.get("client_secret")
        token = cloud_config.get("token")

        if not client_id or not client_secret or not token:
            return {"success": False, "message": "Credenciais do bot incompletas em database/cloud/data.json"}

        # Obter URL base do servidor HTTP a partir da config do WebSocket
        base_url = _get_http_base_url()
        url = f"{base_url}/api/recover/members"

        payload = {
            "data": {
                "client_id": client_id,
                "client_secret": client_secret,
                "token": token,
                "server_id": str(server_id),
            }
        }
        if concurrency is not None:
            payload["data"]["concurrency"] = int(concurrency)
        if base_delay_ms is not None:
            payload["data"]["baseDelayMs"] = int(base_delay_ms)

        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload) as resp:
                text = await resp.text()
                try:
                    data = json.loads(text) if text else {}
                except Exception:
                    data = {}
                if 200 <= resp.status < 300:
                    return {"success": True, "message": (data.get("message") if isinstance(data, dict) else None) or "Recovery started", "data": (data.get("data") if isinstance(data, dict) else {})}
                # Retornar erro com corpo bruto para facilitar debug
                return {"success": False, "message": (data.get("message") if isinstance(data, dict) else text) or f"HTTP {resp.status}", "data": (data.get("data") if isinstance(data, dict) else {})}
    except Exception as e:
        return {"success": False, "message": f"Erro ao iniciar recovery: {str(e)}"}

async def get_recovery_status(recovery_id: str) -> dict:
    """Obtém o status do processo de recuperação via HTTP."""
    try:
        base_url = _get_http_base_url()
        url = f"{base_url}/api/recover/status/{recovery_id}"

        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                text = await resp.text()
                try:
                    data = json.loads(text) if text else {}
                except Exception:
                    data = {}
                if 200 <= resp.status < 300:
                    return {"success": True, "data": (data.get("data") if isinstance(data, dict) else {}), "message": (data.get("message") if isinstance(data, dict) else None)}
                return {"success": False, "message": (data.get("message") if isinstance(data, dict) else text) or f"HTTP {resp.status}", "data": (data.get("data") if isinstance(data, dict) else {})}
    except Exception as e:
        return {"success": False, "message": f"Erro ao obter status: {str(e)}"}