"""
Painel Discord do sistema NOVO de Gift Cards de membros.
Segue o mesmo padrão visual (Container/Embed) usado no resto do bot.
Ver modules/cloud/gift_cards.py para o porquê dessa implementação ser
totalmente nova e não usar nada do sistema antigo.
"""
import io
import datetime
import disnake
from functions.database import database as db
from functions.emoji import emoji
from . import gift_cards

# URL padrão do site de resgate -- usada quando o admin ainda não configurou
# uma própria em "Configurar Site de Resgate". Ver também gift_cards.py
# (get_redemption_url), que usa esse mesmo valor como fallback.
_DEFAULT_GIFT_SITE_URL = "https://eliteapplications.shardweb.app/resgatar"


def _container_kwargs() -> dict:
    primary_color_hex = (db.get_document("custom_colors") or {}).get("primary")
    if primary_color_hex:
        try:
            return {"accent_colour": disnake.Colour(int(str(primary_color_hex).replace("#", ""), 16))}
        except Exception:
            pass
    return {}


def _apply_embed_color(embed: disnake.Embed):
    primary_color_hex = (db.get_document("custom_colors") or {}).get("primary")
    if primary_color_hex:
        try:
            embed.color = disnake.Colour(int(str(primary_color_hex).replace("#", ""), 16))
        except Exception:
            pass


_STATUS_LABELS = {
    "active": "Ativo",
    "redeemed": "Resgatado (processando)",
    "fulfilled": "Concluído",
    "cancelled": "Cancelado",
}


def _status_label(status: str) -> str:
    return _STATUS_LABELS.get(status, status or "?")


def _format_card_line(card: dict) -> str:
    line = f"`{card.get('code')}` — {card.get('members_count')} membro(s) — {_status_label(card.get('status'))}"
    if card.get("status") == "fulfilled":
        line += f" (`{card.get('fulfilled_count', 0)}` adicionados)"
    return line


def _counts(cards: list[dict]) -> tuple[int, int, int]:
    active = sum(1 for c in cards if c.get("status") == "active")
    redeemed = sum(1 for c in cards if c.get("status") == "redeemed")
    fulfilled = sum(1 for c in cards if c.get("status") == "fulfilled")
    return active, redeemed, fulfilled


# --------------------------------------------------------------------------- #
#  Menu principal                                                             #
# --------------------------------------------------------------------------- #

def GiftCardsMenu_components(inter: disnake.Interaction) -> list:
    cards = gift_cards.get_all_gift_cards()
    active, redeemed, fulfilled = _counts(cards)
    site_url = (db.get_document("cloud_data") or {}).get("gift_site_url") or f"`{_DEFAULT_GIFT_SITE_URL}` (padrão)"

    container = disnake.ui.Container(
        disnake.ui.TextDisplay(
            f"## \n-# Painel > FebreCloud > **Gift Cards de Membros**"
        ),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.TextDisplay(
            "Crie códigos de gift card resgatáveis no site externo para adicionar "
            "membros verificados a um servidor.\n\n"
            f"**Site de Resgate:** {site_url}\n"
            f"-# **Ativos:** `{active}` • **Aguardando processamento:** `{redeemed}` • **Concluídos:** `{fulfilled}`"
        ),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.ActionRow(
            disnake.ui.Button(label="Criar Gift Card", style=disnake.ButtonStyle.green, emoji=emoji.plus, custom_id="CloudGiftCards_Create"),
            disnake.ui.Button(label="Listar Gift Cards", style=disnake.ButtonStyle.grey, emoji=emoji.settings2, custom_id="CloudGiftCards_List"),
        ),
        disnake.ui.ActionRow(
            disnake.ui.Button(label="Configurar Site de Resgate", style=disnake.ButtonStyle.blurple, emoji=emoji.edit, custom_id="CloudGiftCards_SetSiteUrl"),
            disnake.ui.Button(label="Ver Logs de um Código", style=disnake.ButtonStyle.blurple, emoji=emoji.clock, custom_id="CloudGiftCards_ViewLogs"),
        ),
        disnake.ui.ActionRow(
            disnake.ui.Button(label="Excluir por Código", style=disnake.ButtonStyle.grey, emoji=emoji.wrong, custom_id="CloudGiftCards_DeleteByCode"),
            disnake.ui.Button(label="Excluir Todos", style=disnake.ButtonStyle.red, emoji=emoji.delete, custom_id="CloudGiftCards_DeleteAll"),
        ),
        **_container_kwargs()
    )
    back_row = disnake.ui.ActionRow(
        disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="Cloud_Back")
    )
    return [container, back_row]


def GiftCardsMenu_embed(inter: disnake.Interaction):
    cards = gift_cards.get_all_gift_cards()
    active, redeemed, fulfilled = _counts(cards)
    site_url = (db.get_document("cloud_data") or {}).get("gift_site_url") or f"{_DEFAULT_GIFT_SITE_URL} (padrão)"

    embed = disnake.Embed(
        title="Gift Cards de Membros",
        description=(
            "Crie códigos de gift card resgatáveis no site externo para adicionar "
            "membros verificados a um servidor.\n\n"
            f"**Site de Resgate:** `{site_url}`\n"
            f"**Ativos:** `{active}` • **Aguardando processamento:** `{redeemed}` • **Concluídos:** `{fulfilled}`"
        )
    )
    _apply_embed_color(embed)

    components = [
        disnake.ui.ActionRow(
            disnake.ui.Button(label="Criar Gift Card", style=disnake.ButtonStyle.green, emoji=emoji.plus, custom_id="CloudGiftCards_Create"),
            disnake.ui.Button(label="Listar Gift Cards", style=disnake.ButtonStyle.grey, emoji=emoji.settings2, custom_id="CloudGiftCards_List"),
        ),
        disnake.ui.ActionRow(
            disnake.ui.Button(label="Configurar Site de Resgate", style=disnake.ButtonStyle.blurple, emoji=emoji.edit, custom_id="CloudGiftCards_SetSiteUrl"),
            disnake.ui.Button(label="Ver Logs de um Código", style=disnake.ButtonStyle.blurple, emoji=emoji.clock, custom_id="CloudGiftCards_ViewLogs"),
        ),
        disnake.ui.ActionRow(
            disnake.ui.Button(label="Excluir por Código", style=disnake.ButtonStyle.grey, emoji=emoji.wrong, custom_id="CloudGiftCards_DeleteByCode"),
            disnake.ui.Button(label="Excluir Todos", style=disnake.ButtonStyle.red, emoji=emoji.delete, custom_id="CloudGiftCards_DeleteAll"),
        ),
        disnake.ui.ActionRow(
            disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="Cloud_Back")
        )
    ]
    return embed, components


# --------------------------------------------------------------------------- #
#  Listagem                                                                   #
# --------------------------------------------------------------------------- #

def GiftCardsList_components(inter: disnake.Interaction) -> list:
    cards = gift_cards.get_all_gift_cards()
    cards_sorted = sorted(cards, key=lambda c: c.get("created_at") or "", reverse=True)[:20]
    lines = "\n".join(_format_card_line(c) for c in cards_sorted) or "Nenhum gift card criado ainda."

    container = disnake.ui.Container(
        disnake.ui.TextDisplay(
            f"## \n-# Painel > FebreCloud > Gift Cards > **Listar**"
        ),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.TextDisplay(f"Mostrando os {len(cards_sorted)} mais recentes de `{len(cards)}` total.\n\n{lines}"),
        **_container_kwargs()
    )
    back_row = disnake.ui.ActionRow(
        disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="CloudGiftCards_Menu")
    )
    return [container, back_row]


def GiftCardsList_embed(inter: disnake.Interaction):
    cards = gift_cards.get_all_gift_cards()
    cards_sorted = sorted(cards, key=lambda c: c.get("created_at") or "", reverse=True)[:20]
    lines = "\n".join(_format_card_line(c) for c in cards_sorted) or "Nenhum gift card criado ainda."

    embed = disnake.Embed(
        title="Gift Cards Criados",
        description=f"Mostrando os {len(cards_sorted)} mais recentes de `{len(cards)}` total.\n\n{lines}"
    )
    _apply_embed_color(embed)

    components = [
        disnake.ui.ActionRow(
            disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="CloudGiftCards_Menu")
        )
    ]
    return embed, components


# --------------------------------------------------------------------------- #
#  Modais                                                                     #
# --------------------------------------------------------------------------- #

class CreateGiftCardModal(disnake.ui.Modal):
    def __init__(self):
        components = [
            disnake.ui.TextInput(
                label="Quantidade de Membros por Gift",
                placeholder="Ex: 50",
                custom_id="members_count",
                style=disnake.TextInputStyle.short,
                required=True,
                max_length=6
            ),
            disnake.ui.TextInput(
                label="Quantidade de Gifts (opcional)",
                placeholder="Padrão: 1 — máximo: 50",
                custom_id="quantity",
                style=disnake.TextInputStyle.short,
                required=False,
                max_length=3
            ),
        ]
        super().__init__(title="Criar Gift Card de Membros", custom_id="CloudGiftCards_CreateModal", components=components)

    async def callback(self, inter: disnake.ModalInteraction):
        members_count_raw = inter.text_values.get("members_count", "").strip()
        quantity_raw = inter.text_values.get("quantity", "").strip()

        if not members_count_raw.isdigit() or int(members_count_raw) <= 0:
            await inter.response.send_message(f"{emoji.wrong} Digite um número válido de membros (maior que zero).", ephemeral=True)
            return

        quantity = int(quantity_raw) if quantity_raw.isdigit() and int(quantity_raw) > 0 else 1
        if quantity > 50:
            await inter.response.send_message(f"{emoji.wrong} Máximo de 50 gift cards por vez.", ephemeral=True)
            return

        await inter.response.defer(ephemeral=True)

        try:
            codes = gift_cards.create_gift_cards(
                members_count=int(members_count_raw),
                created_by_id=str(inter.user.id),
                created_by_name=inter.user.display_name,
                quantity=quantity
            )
        except Exception as e:
            await inter.followup.send(f"{emoji.wrong} Erro ao criar gift card(s): {e}", ephemeral=True)
            return

        links = [gift_cards.get_redemption_url(code) for code in codes]

        if len(codes) == 1:
            await inter.followup.send(
                f"{emoji.correct} **Gift card criado com sucesso!**\n\n"
                f"**Código:** `{codes[0]}`\n"
                f"**Membros:** `{members_count_raw}`\n"
                f"**Link de resgate:** {links[0]}",
                ephemeral=True
            )
        else:
            content = "\n".join(f"{c} -> {l}" for c, l in zip(codes, links))
            file = disnake.File(io.BytesIO(content.encode("utf-8")), filename="gift_cards.txt")
            await inter.followup.send(
                f"{emoji.correct} **{len(codes)} gift cards criados!** Links de resgate no arquivo anexado.",
                file=file,
                ephemeral=True
            )


class DeleteGiftCardModal(disnake.ui.Modal):
    def __init__(self):
        components = [
            disnake.ui.TextInput(
                label="Código do Gift Card",
                placeholder="Ex: A1B2C3D4E5",
                custom_id="code",
                style=disnake.TextInputStyle.short,
                required=True,
                max_length=20
            ),
        ]
        super().__init__(title="Excluir Gift Card", custom_id="CloudGiftCards_DeleteModal", components=components)

    async def callback(self, inter: disnake.ModalInteraction):
        code = inter.text_values.get("code", "").strip().upper()
        await inter.response.defer(ephemeral=True)
        if gift_cards.delete_gift_card(code):
            await inter.followup.send(f"{emoji.correct} Gift card `{code}` excluído.", ephemeral=True)
        else:
            await inter.followup.send(f"{emoji.wrong} Gift card `{code}` não encontrado.", ephemeral=True)


class ConfirmDeleteAllGiftCardsModal(disnake.ui.Modal):
    def __init__(self):
        components = [
            disnake.ui.TextInput(
                label='Digite "CONFIRMAR" para excluir tudo',
                placeholder="CONFIRMAR",
                custom_id="confirm",
                style=disnake.TextInputStyle.short,
                required=True,
                max_length=20
            ),
        ]
        super().__init__(title="Excluir TODOS os Gift Cards", custom_id="CloudGiftCards_DeleteAllModal", components=components)

    async def callback(self, inter: disnake.ModalInteraction):
        confirm = inter.text_values.get("confirm", "").strip().upper()
        if confirm != "CONFIRMAR":
            await inter.response.send_message(f"{emoji.wrong} Confirmação incorreta. Nada foi excluído.", ephemeral=True)
            return
        await inter.response.defer(ephemeral=True)
        count = gift_cards.delete_all_gift_cards()
        await inter.followup.send(f"{emoji.correct} `{count}` gift card(s) excluído(s).", ephemeral=True)


class ViewGiftLogsModal(disnake.ui.Modal):
    def __init__(self):
        components = [
            disnake.ui.TextInput(
                label="Código do Gift Card",
                placeholder="Ex: A1B2C3D4E5",
                custom_id="code",
                style=disnake.TextInputStyle.short,
                required=True,
                max_length=20
            ),
        ]
        super().__init__(title="Ver Logs de um Gift Card", custom_id="CloudGiftCards_ViewLogsModal", components=components)

    async def callback(self, inter: disnake.ModalInteraction):
        code = inter.text_values.get("code", "").strip().upper()
        await inter.response.defer(ephemeral=True)

        card = gift_cards.get_gift_card(code)
        if not card:
            await inter.followup.send(f"{emoji.wrong} Gift card `{code}` não encontrado.", ephemeral=True)
            return

        logs = card.get("logs", [])
        embed = _build_gift_logs_embed(code, card, logs)
        await inter.followup.send(embed=embed, ephemeral=True)


_LEVEL_ICON = {"success": "🟢", "error": "🔴", "info": "🔵"}


def _build_gift_logs_embed(code: str, card: dict, logs: list[dict]) -> disnake.Embed:
    embed = disnake.Embed(
        title=f"Logs — Gift Card {code}",
        description=(
            f"**Status:** {_status_label(card.get('status'))}\n"
            f"**Membros:** `{card.get('fulfilled_count', 0)}/{card.get('members_count')}`"
        ),
    )
    _apply_embed_color(embed)

    if not logs:
        embed.add_field(
            name="Histórico",
            value="Nenhum log registrado ainda (o gift ainda não foi resgatado/processado).",
            inline=False
        )
        return embed

    # Mostra os mais recentes primeiro, limitado ao que cabe num embed
    recent = list(reversed(logs))[:25]
    lines = []
    for entry in recent:
        icon = _LEVEL_ICON.get(entry.get("level"), "⚪")
        ts = entry.get("ts", "")
        try:
            ts_fmt = datetime.datetime.fromisoformat(ts.replace("Z", "+00:00")).strftime("%d/%m %H:%M:%S")
        except Exception:
            ts_fmt = ts
        lines.append(f"{icon} `{ts_fmt}` — {entry.get('message', '')}")

    text = "\n".join(lines)
    # Embeds têm limite de 1024 por campo -- quebra em múltiplos campos se precisar
    chunk = ""
    field_num = 1
    for line in lines:
        if len(chunk) + len(line) + 1 > 1024:
            embed.add_field(name=f"Histórico (mais recentes primeiro) {'' if field_num == 1 else f'({field_num})'}", value=chunk, inline=False)
            chunk = ""
            field_num += 1
        chunk += line + "\n"
    if chunk:
        embed.add_field(name=f"Histórico (mais recentes primeiro) {'' if field_num == 1 else f'({field_num})'}", value=chunk, inline=False)

    if len(logs) > 25:
        embed.set_footer(text=f"Mostrando os 25 mais recentes de {len(logs)} log(s) total.")

    return embed


class SetGiftSiteUrlModal(disnake.ui.Modal):
    def __init__(self):
        cloud_config = db.get_document("cloud_data") or {}
        current = cloud_config.get("gift_site_url", "")
        components = [
            disnake.ui.TextInput(
                label="URL do Site de Resgate",
                placeholder="https://seusite.com/resgatar",
                custom_id="site_url",
                style=disnake.TextInputStyle.short,
                required=True,
                max_length=200,
                value=current or None
            ),
        ]
        super().__init__(title="Configurar Site de Resgate", custom_id="CloudGiftCards_SetSiteUrlModal", components=components)

    async def callback(self, inter: disnake.ModalInteraction):
        site_url = inter.text_values.get("site_url", "").strip()
        await inter.response.defer(ephemeral=True)

        cloud_config = db.get_document("cloud_data") or {}
        cloud_config["gift_site_url"] = site_url
        db.save_document("cloud_data", cloud_config)

        await inter.followup.send(f"{emoji.correct} URL do site de resgate atualizada para: {site_url}", ephemeral=True)