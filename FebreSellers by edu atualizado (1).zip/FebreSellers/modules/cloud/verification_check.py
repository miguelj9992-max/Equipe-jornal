"""
Módulo central de integração com a Febre Cloud para o sistema de verificação.

"Estar verificado" siginifica ter concluído o fluxo OAuth2 com a Febre Cloud.
Este bot NÃO mantém uma base própria de usuários verificados: a lista de
verificados é obtida diretamente da Febre Cloud (banco remoto compartilhado
com o site de verificação, via `oauth_panel.get_oauth_verified_users_async`),
com o cargo de verificado -- sincronizado em tempo real pela própria Lunar
Cloud via WebSocket (eventos `auth_log` / `remove_verified_role`, ver
`modules/cloud/update_api.py`) -- como sinal auxiliar.

`get_verification_status()` é a ÚNICA função deste bot que efetivamente
consulta a Febre Cloud para saber se um usuário está verificado. Todo o
restante do sistema de verificação (painel de "Funcionalidades Protegidas"
em `modules/verification`, a checagem legada "Requerer Verificação OAuth2"
aqui neste módulo, etc.) passa por ela -- evitando duplicar a lógica de
consulta em cada lugar que precisa checar verificação.
"""
import asyncio
import time

import disnake
from functions.database import database as db

# --------------------------------------------------------------------------- #
# Status possíveis de uma checagem de verificação na Febre Cloud
# --------------------------------------------------------------------------- #
VERIFIED = "verified"            # Usuário verificado na Febre Cloud
UNVERIFIED = "unverified"        # Usuário consultado com sucesso e NÃO está verificado
UNAVAILABLE = "unavailable"      # Não foi possível consultar a Febre Cloud agora (erro/timeout)
NOT_CONFIGURED = "not_configured"  # Febre Cloud (OAuth2) não configurada neste servidor

# --------------------------------------------------------------------------- #
# Cache curtíssimo por usuário, apenas para evitar consultar a Febre Cloud
# mais de uma vez para a mesma ação quando mais de um ponto do fluxo checa a
# verificação em sequência (ex: a checagem legada "Requerer Verificação
# OAuth2" e o painel de "Funcionalidades Protegidas" rodando um atrás do
# outro para a mesma interação de compra).
# --------------------------------------------------------------------------- #
_STATUS_CACHE_TTL = 5.0  # segundos
_status_cache: dict[int, tuple[float, str]] = {}


def _cache_get(user_id: int) -> "str | None":
    entry = _status_cache.get(user_id)
    if not entry:
        return None
    fetched_at, status = entry
    if (time.monotonic() - fetched_at) > _STATUS_CACHE_TTL:
        _status_cache.pop(user_id, None)
        return None
    return status


def _cache_set(user_id: int, status: str) -> None:
    _status_cache[user_id] = (time.monotonic(), status)
    if len(_status_cache) > 1000:
        now = time.monotonic()
        for uid, (fetched_at, _) in list(_status_cache.items()):
            if (now - fetched_at) > _STATUS_CACHE_TTL:
                _status_cache.pop(uid, None)


async def get_verification_status(member: disnake.Member) -> str:
    """
    Função central: consulta a Febre Cloud para saber se `member` está
    verificado e retorna um dos status acima (VERIFIED / UNVERIFIED /
    UNAVAILABLE / NOT_CONFIGURED).

    Args:
        member: Membro do Discord a checar.

    Returns:
        str: um dos status acima.
    """
    cached = _cache_get(member.id)
    if cached is not None:
        return cached

    status = await _fetch_verification_status(member)
    _cache_set(member.id, status)
    return status


async def _fetch_verification_status(member: disnake.Member) -> str:
    cloud_config = db.get_document("cloud_data") or {}
    if not cloud_config.get("client_id"):
        # Febre Cloud não configurada neste servidor -- não há o que checar.
        return NOT_CONFIGURED

    try:
        from .oauth_panel import get_oauth_verified_users_async, get_oauth_verified_role

        # Consulta a Febre Cloud (banco remoto compartilhado com o site de
        # verificação -- ver docstring de get_oauth_verified_users) com um
        # timeout para não travar a ação do usuário caso ela esteja
        # temporariamente indisponível/lenta.
        verified_users = await asyncio.wait_for(get_oauth_verified_users_async(), timeout=10.0)
        verified_ids = {str(u.get("id")) for u in verified_users if u.get("id")}

        if str(member.id) in verified_ids:
            return VERIFIED

        # Sinal auxiliar: cargo de verificado, mantido em tempo real pela
        # própria Febre Cloud via WebSocket. Cobre o caso raro do registro
        # remoto ainda não ter propagado mas o cargo já ter sido concedido.
        verified_role_id = get_oauth_verified_role()
        if verified_role_id and getattr(member, "guild", None):
            role = member.guild.get_role(int(verified_role_id))
            if role and role in member.roles:
                return VERIFIED

        return UNVERIFIED

    except asyncio.TimeoutError:
        print(f"[FebreCloud] Timeout ao consultar verificação do usuário {member.id} na Febre Cloud.")
        return UNAVAILABLE
    except Exception as e:
        print(f"[FebreCloud] Erro ao consultar verificação do usuário {member.id} na Febre Cloud: {e}")
        import traceback
        traceback.print_exc()
        return UNAVAILABLE


async def is_user_verified(member: disnake.Member) -> bool:
    """
    Wrapper booleano de `get_verification_status`, mantido para os pontos do
    bot que só precisam de um booleano.

    Por segurança, retorna False tanto quando o usuário não está verificado
    quanto quando não foi possível confirmar o status (Febre Cloud
    indisponível) -- uma funcionalidade protegida não deve ser liberada
    quando a verificação não pôde ser validada. Para diferenciar os dois
    casos (e mostrar a mensagem correta ao usuário), use
    `get_verification_status` diretamente.

    Args:
        member: Membro do Discord

    Returns:
        bool: True se o usuário está verificado (ou se a Febre Cloud não
        está configurada neste servidor), False caso contrário.
    """
    status = await get_verification_status(member)
    return status in (VERIFIED, NOT_CONFIGURED)


def _build_verify_view(inter: "disnake.Interaction", client_id: str) -> "disnake.ui.View":
    # Reaproveita o mesmo gerador de link usado pelo painel OAuth2
    # (modules.cloud.oauth_panel), que é o único que monta o parâmetro
    # `state` no formato "bot_id:guild_id" esperado pelo site da Lunar
    # Cloud para localizar as credenciais no Mongo. Um `state` fora desse
    # formato (ex: "client_id-guild_id") faz o site responder "Credenciais
    # OAuth2 não configuradas" mesmo com tudo certo no painel do bot.
    from .oauth_panel import build_auth_url
    guild_id = inter.guild.id if inter.guild else ""
    bot_user = getattr(getattr(inter, "bot", None), "user", None)
    bot_id = str(bot_user.id) if bot_user else client_id
    auth_url = build_auth_url(client_id, guild_id=guild_id, bot_id=bot_id)

    view = disnake.ui.View(timeout=None)
    view.add_item(disnake.ui.Button(label="Verificar", style=disnake.ButtonStyle.link, url=auth_url))
    return view


def get_verification_message_and_view(
    inter: "disnake.Interaction", status: str = UNVERIFIED
) -> "tuple[str, disnake.ui.View] | tuple[None, None]":
    """
    Gera a mensagem (e a view com o botão de verificação, quando aplicável)
    a mostrar ao usuário bloqueado.

    Args:
        inter: Interação do Discord.
        status: UNVERIFIED (padrão) para a mensagem normal de "você precisa
            se verificar" com o botão de verificação, ou UNAVAILABLE para a
            mensagem de "não foi possível validar sua verificação agora"
            (sem botão, já que não sabemos se o usuário precisa ou não se
            verificar).

    Returns:
        tuple: (message_text, view) ou (None, None) se não for possível gerar
        (ex: Febre Cloud não configurada neste servidor).
    """
    try:
        cloud_config = db.get_document("cloud_data") or {}
        client_id = cloud_config.get("client_id")
        if not client_id:
            return None, None

        if status == UNAVAILABLE:
            message_text = (
                "Não foi possível validar sua verificação na Febre Cloud neste momento. "
                "Tente novamente em alguns instantes."
            )
            return message_text, disnake.ui.View(timeout=None)

        message_text = "Esse servidor requer que você seja verificado para usar algumas funcionalidades."
        view = _build_verify_view(inter, client_id)
        return message_text, view

    except Exception as e:
        print(f"Erro ao gerar mensagem de verificação: {e}")
        return None, None


def is_verification_required() -> bool:
    """
    Verifica se a opção 'Requerer Verificação OAuth2' está ativada nas preferências
    e se há client_id configurado (necessário para funcionar)
    
    Returns:
        bool: True se a verificação é obrigatória e está configurada, False caso contrário
    """
    try:
        cloud_config = db.get_document("cloud_data") or {}
        
        # Verificar se há client_id configurado (necessário para o checker funcionar)
        client_id = cloud_config.get("client_id")
        if not client_id:
            return False
        
        # Verificar se a opção está ativada
        definitions = cloud_config.get("definitions", {})
        return definitions.get("require_oauth2", {}).get("enabled", False)
        
    except Exception:
        return False


async def send_verification_required_message(inter: disnake.Interaction) -> bool:
    """
    Envia mensagem efêmera de verificação quando o usuário não está
    verificado na Febre Cloud, ou quando não foi possível confirmar o
    status (Febre Cloud indisponível no momento).
    
    Args:
        inter: Interação do Discord
        
    Returns:
        bool: True se a mensagem foi enviada, False caso contrário
    """
    try:
        # Verificar se a verificação é obrigatória
        if not is_verification_required():
            return False
        
        # Verificar se há client_id configurado (necessário para funcionar)
        cloud_config = db.get_document("cloud_data") or {}
        client_id = cloud_config.get("client_id")
        if not client_id:
            # Se não houver client_id, não enviar mensagem
            return False
        
        # Verificar se o usuário está verificado
        if isinstance(inter.user, disnake.Member):
            member = inter.user
        else:
            # Se não for Member, tentar obter do guild
            if inter.guild:
                member = inter.guild.get_member(inter.user.id)
                if not member:
                    # Se não conseguir obter o membro, não bloquear
                    return False
            else:
                return False
        
        # Consultar o status de verificação atualizado na Febre Cloud
        status = await get_verification_status(member)
        if status in (VERIFIED, NOT_CONFIGURED):
            return False

        message_text, view = get_verification_message_and_view(inter, status=status)
        if not message_text:
            return False

        if inter.response.is_done():
            await inter.followup.send(message_text, ephemeral=True, view=view)
        else:
            await inter.response.send_message(message_text, ephemeral=True, view=view)
        
        return True
        
    except Exception as e:
        print(f"Erro ao enviar mensagem de verificação obrigatória: {e}")
        import traceback
        traceback.print_exc()
        return False