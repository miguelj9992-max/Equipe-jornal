"""
Sistema de Gift Cards de membros.

IMPLEMENTAÇÃO NOVA, independente do sistema antigo (CreateGiftModal,
EditGiftModal, DeleteGiftModal e os botões "CloudGift_*" em cog.py). O
sistema antigo dependia do SocketIOManager/HTTPPollingManager para criar,
listar e resgatar gifts -- ambos foram desativados nesse projeto (ver
connections/socketio_manager.py e connections/http_polling.py, onde toda
chamada de API relacionada a gifts/membros virou um stub que sempre
retorna falha). Por isso o sistema antigo nunca vai funcionar de novo, e
esse módulo não usa nem importa nada dele.

Esse módulo fala DIRETO com o MongoDB, no mesmo padrão que a verificação
OAuth2 já usa com sucesso (modules/cloud/oauth_panel.py) -- reaproveitando
inclusive a mesma conexão (MongoClient singleton) para não abrir uma
conexão nova.

Fluxo:
  1. Um admin cria um gift card no Discord (`gift_cards.create_gift_cards`)
     -- vira um documento com status "active" e um link de resgate.
  2. A pessoa resgata o código no SITE EXTERNO (fora deste repositório),
     informando o ID do servidor de destino. O site grava esse resgate
     direto no mesmo documento do Mongo (status "redeemed").
  3. O loop `tasks/cloud/gift_sync.py` (rodando no bot) detecta gifts com
     status "redeemed", adiciona os membros verificados ao servidor via
     API do Discord, e marca como "fulfilled".
"""
import random
import string
from datetime import datetime, timezone

from .oauth_panel import _get_mongo_users_collection

_GIFT_DOC_ID = "gift_cards"


def _generate_gift_code(length: int = 10) -> str:
    alphabet = string.ascii_uppercase + string.digits
    return "".join(random.choices(alphabet, k=length))


def _get_gift_doc() -> dict:
    collection = _get_mongo_users_collection()
    if collection is None:
        return {}
    return collection.find_one({"_id": _GIFT_DOC_ID}) or {}


def create_gift_cards(members_count: int, created_by_id: str, created_by_name: str, quantity: int = 1) -> list[str]:
    """Cria `quantity` gift card(s), cada um valendo `members_count` membros.
    Retorna a lista de códigos gerados. Lança RuntimeError se o Mongo não
    estiver configurado/acessível."""
    collection = _get_mongo_users_collection()
    if collection is None:
        raise RuntimeError("MongoDB não configurado ou inacessível no momento (verifique as credenciais do FProCloud).")

    existing_codes = {c.get("code") for c in _get_gift_doc().get("cards", [])}
    now = datetime.now(timezone.utc).isoformat()
    codes = []

    for _ in range(quantity):
        code = _generate_gift_code()
        while code in existing_codes:
            code = _generate_gift_code()
        existing_codes.add(code)

        card = {
            "code": code,
            "members_count": int(members_count),
            "status": "active",  # active -> redeemed -> fulfilled | cancelled
            "created_by": {"id": str(created_by_id), "name": created_by_name},
            "created_at": now,
            "redeemed_at": None,
            "redeemed_by_guild": None,
            "fulfilled_at": None,
            "fulfilled_count": 0,
            "logs": [],  # ver append_gift_log() -- histórico detalhado de tentativas/erros
        }

        collection.update_one(
            {"_id": _GIFT_DOC_ID},
            {"$push": {"cards": card}},
            upsert=True,
        )
        codes.append(code)

    return codes


def append_gift_log(code: str, entries: list[dict]) -> None:
    """Adiciona entradas de log detalhado ao histórico de um gift card
    (tentativas de adicionar membro, erros da API do Discord, etc.).

    Usa $push atômico (igual ao resto do módulo, ver comentário em
    oauth_panel.py sobre por que evitar find_one + $set do array inteiro)
    -- assim varios ciclos gravando logs ao mesmo tempo (gifts diferentes)
    nunca se pisam. Mantém só as últimas 200 entradas por código via
    $slice, pra não deixar o documento crescer sem limite.

    Cada entrada: {"ts": iso, "level": "info"|"error"|"success", "message": str}
    """
    collection = _get_mongo_users_collection()
    if collection is None or not entries:
        return
    now = datetime.now(timezone.utc).isoformat()
    for e in entries:
        e.setdefault("ts", now)
    collection.update_one(
        {"_id": _GIFT_DOC_ID, "cards.code": code},
        {"$push": {"cards.$.logs": {"$each": entries, "$slice": -200}}},
    )


def get_gift_card_logs(code: str) -> list[dict]:
    card = get_gift_card(code)
    if not card:
        return []
    return card.get("logs", [])


def get_all_gift_cards() -> list[dict]:
    return _get_gift_doc().get("cards", [])


def get_gift_card(code: str) -> dict | None:
    code = (code or "").strip().upper()
    for card in get_all_gift_cards():
        if str(card.get("code", "")).upper() == code:
            return card
    return None


def get_pending_fulfillment_cards() -> list[dict]:
    """Gifts resgatados no site externo, mas que o bot ainda não processou."""
    return [c for c in get_all_gift_cards() if c.get("status") == "redeemed"]


def mark_gift_fulfilled(code: str, fulfilled_count: int) -> bool:
    collection = _get_mongo_users_collection()
    if collection is None:
        return False
    now = datetime.now(timezone.utc).isoformat()
    result = collection.update_one(
        {"_id": _GIFT_DOC_ID, "cards.code": code},
        {"$set": {
            "cards.$.status": "fulfilled",
            "cards.$.fulfilled_at": now,
            "cards.$.fulfilled_count": int(fulfilled_count),
        }},
    )
    return result.modified_count > 0


def delete_gift_card(code: str) -> bool:
    collection = _get_mongo_users_collection()
    if collection is None:
        return False
    code = (code or "").strip().upper()
    result = collection.update_one(
        {"_id": _GIFT_DOC_ID},
        {"$pull": {"cards": {"code": code}}},
    )
    return result.modified_count > 0


def delete_all_gift_cards() -> int:
    collection = _get_mongo_users_collection()
    if collection is None:
        return 0
    count = len(get_all_gift_cards())
    collection.update_one(
        {"_id": _GIFT_DOC_ID},
        {"$set": {"cards": []}},
        upsert=True,
    )
    return count


def get_redemption_url(code: str) -> str:
    """Monta a URL de resgate no site externo. Configurável em
    database/cloud_data -> gift_site_url (ver Preferências > Gift Cards).
    Inclui o bot_id na querystring -- o site de resgate precisa dele para
    saber em qual coleção do Mongo procurar o gift card (mesmo padrão da
    verificação OAuth2)."""
    from functions.database import database as db
    from .oauth_panel import _get_verification_bot_id_and_mongo_url

    try:
        bot_id, _, _ = _get_verification_bot_id_and_mongo_url()
    except Exception:
        bot_id = None

    cloud_config = db.get_document("cloud_data") or {}
    base = (cloud_config.get("gift_site_url") or "").rstrip("/")
    if not base:
        base = "https://eliteapplications.shardweb.app/resgatar"

    url = f"{base}?codigo={code}"
    if bot_id:
        url += f"&bot_id={bot_id}"
    return url