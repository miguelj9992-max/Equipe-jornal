"""
Verificação de VPN / Proxy / Datacenter para o sistema de verificação OAuth2.

Usa a API gratuita ip-api.com (sem necessidade de chave) para checar se um
IP pertence a um provedor de VPN/proxy ou a um datacenter/hosting (sinal
forte de VPN comercial, já que provedores residenciais normais não usam
IPs de datacenter).

Se quiser mais precisão (ex: detectar Tor, IPs residenciais de VPN "premium"
etc.), é possível trocar por um provedor pago (ipinfo.io, ipapi.co,
vpnapi.io, IPQualityScore...) mudando apenas o corpo da função check_ip(),
sem precisar tocar em nenhum outro arquivo do bot.
"""
import aiohttp
import logging

logger = logging.getLogger(__name__)

_IP_API_URL = "http://ip-api.com/json/{ip}"
_IP_API_FIELDS = "status,message,proxy,hosting,query"

# Cache simples em memória para não bater na API de novo para o mesmo IP
# em pouco tempo (ex: reconexões de WebSocket reenviando o mesmo evento).
_cache: dict[str, tuple[bool, str]] = {}
_CACHE_MAX_SIZE = 500


async def check_ip(ip: str) -> tuple[bool, str]:
    """
    Verifica se um IP é de VPN, Proxy ou Datacenter/Hosting.

    Retorna (is_vpn, motivo).

    Em caso de erro/timeout na API externa, retorna (False, motivo_do_erro)
    para NÃO bloquear o usuário por falha de um serviço de terceiros
    (fail-open — evita bloquear gente legítima por instabilidade da API).
    """
    if not ip or ip in ("Desconhecido", "N/A", "0.0.0.0"):
        return False, "IP não disponível"

    if ip in _cache:
        return _cache[ip]

    try:
        url = _IP_API_URL.format(ip=ip)
        async with aiohttp.ClientSession() as session:
            async with session.get(
                url,
                params={"fields": _IP_API_FIELDS},
                timeout=aiohttp.ClientTimeout(total=6),
            ) as resp:
                if resp.status != 200:
                    return False, f"erro HTTP {resp.status} ao consultar API de IP"
                data = await resp.json()

        if data.get("status") != "success":
            return False, data.get("message", "erro desconhecido na API de IP")

        is_proxy = bool(data.get("proxy"))
        is_hosting = bool(data.get("hosting"))
        is_vpn = is_proxy or is_hosting

        if is_proxy and is_hosting:
            motivo = "VPN/Proxy + IP de Datacenter detectado"
        elif is_proxy:
            motivo = "VPN/Proxy detectado"
        elif is_hosting:
            motivo = "IP de Datacenter/Hosting detectado"
        else:
            motivo = "IP residencial (sem sinais de VPN/Proxy)"

        result = (is_vpn, motivo)

        if len(_cache) >= _CACHE_MAX_SIZE:
            _cache.clear()
        _cache[ip] = result

        return result

    except Exception as e:
        logger.warning(f"[VPN_CHECK] Erro ao verificar IP {ip}: {e}")
        return False, f"erro ao verificar IP: {e}"