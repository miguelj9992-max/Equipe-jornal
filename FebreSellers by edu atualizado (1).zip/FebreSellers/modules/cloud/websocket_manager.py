class WebSocketManager:
    def __init__(self, *args, **kwargs):
        pass

    async def start(self):
        pass

    async def stop(self):
        pass

    def set_callbacks(self, *args, **kwargs):
        pass

    def set_bot(self, *args, **kwargs):
        pass

    def is_connected(self):
        return False

    def get_connection_info(self):
        return {
            "connected": False,
            "connecting": False,
            "server_url": None
        }
