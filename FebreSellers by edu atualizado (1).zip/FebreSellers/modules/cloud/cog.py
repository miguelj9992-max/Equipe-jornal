import disnake
from disnake.ext import commands
import aiohttp

from functions.emoji import emoji
from functions.database import database as db
from functions.message import message, embed_message
from functions.utils import utils
from . import helpers
from . import config_credenciais
from . import config_mensagem
from . import auth_logs
from . import update_api
from . import oauth_panel as oauth
from .config_definicoes import DefinicoesView_components, DefinicoesView_embed
from .manage_tasks import ManageTasksView_components, ManageTasksView_embed, ManageTasksSelectView_components, TaskDetailsView_components, ManageTasksSelectView_embed, TaskDetailsView_embed
from .create_task_modal import CreateTaskModal
from . import gift_cards_panel


class Cloud(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        # Definir instância do bot para uso global no WebSocket
        update_api.set_bot_instance(bot)
        # Garantir callbacks do WebSocket registrados mesmo se conexão já estiver ativa
        try:
            update_api.register_websocket_callbacks()
        except Exception as e:
            print(f"[Cloud Cog] Falha ao registrar callbacks do WebSocket: {e}")

    async def _definir_preferencias(self, inter: disnake.MessageInteraction):
        await inter.response.send_message("Lógica para definir preferências a ser implementada.", ephemeral=True)

    async def _gerenciar_gift(self, inter: disnake.MessageInteraction):
        """Mostra container ou embed com opções de gerenciamento de gifts"""
        try:
            mode = db.get_document("custom_mode").get("mode")

            if mode == "embed":
                primary_color_hex = db.get_document("custom_colors").get("primary")
                embed = disnake.Embed(
                    title=f"Painel > FProCloud > Gerenciar Gifts",
                    description="Use os botões abaixo para gerenciar os gifts.",
                )
                if primary_color_hex:
                    embed.color = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))

                components = [
                    disnake.ui.ActionRow(
                        disnake.ui.Button(label="Criar Gift", style=disnake.ButtonStyle.green, emoji=emoji.plus, custom_id="CloudGift_Create"),
                        disnake.ui.Button(label="Gerenciar Gifts", style=disnake.ButtonStyle.grey, emoji=emoji.settings, custom_id="CloudGift_Manage"),
                        disnake.ui.Button(label="Excluir Gifts", style=disnake.ButtonStyle.red, emoji=emoji.wrong, custom_id="CloudGift_Delete"),
                    ),
                    disnake.ui.ActionRow(
                        disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="Cloud_Back")
                    )
                ]
                await inter.edit_original_response(content=None, embed=embed, components=components)
            else:
                primary_color_hex = db.get_document("custom_colors").get("primary")
                container_kwargs = {}
                if primary_color_hex:
                    container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))

                container = disnake.ui.Container(
                    disnake.ui.TextDisplay(f"## \n-# Painel > FProCloud > **Gerenciar Gifts**"),
                    disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                    disnake.ui.ActionRow(
                        disnake.ui.Button(label="Criar Gift", style=disnake.ButtonStyle.green, emoji=emoji.plus, custom_id="CloudGift_Create"),
                        disnake.ui.Button(label="Gerenciar Gifts", style=disnake.ButtonStyle.grey, emoji=emoji.settings, custom_id="CloudGift_Manage"),
                        disnake.ui.Button(label="Excluir Gifts", style=disnake.ButtonStyle.red, emoji=emoji.wrong, custom_id="CloudGift_Delete"),
                    ),
                    **container_kwargs
                )
                
                buttons = disnake.ui.ActionRow(
                    disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="Cloud_Back")
                )
                
                await inter.edit_original_response(content=None, components=[container, buttons])
            
        except Exception as e:
            print(f"Erro ao mostrar gerenciamento de gifts: {e}")
            try:
                if not inter.response.is_done():
                    await inter.response.send_message("Erro ao carregar gerenciamento de gifts.", ephemeral=True)
                else:
                    await inter.edit_original_response("Erro ao carregar gerenciamento de gifts.")
            except:
                await inter.followup.send("Erro ao carregar gerenciamento de gifts.", ephemeral=True)

    async def _show_delete_options(self, inter: disnake.MessageInteraction):
        """Mostra as opções de deleção de gifts"""
        try:
            mode = db.get_document("custom_mode").get("mode")
            primary_color_hex = db.get_document("custom_colors").get("primary")
            
            buttons = disnake.ui.ActionRow(
                disnake.ui.Button(label="Excluir da Lista", style=disnake.ButtonStyle.grey, emoji=emoji.embed, custom_id="CloudGift_DeleteFromList"),
                disnake.ui.Button(label="Excluir por Código", style=disnake.ButtonStyle.grey, emoji=emoji.search, custom_id="CloudGift_DeleteByCode"),
                disnake.ui.Button(label="Excluir Todos", style=disnake.ButtonStyle.red, emoji=emoji.delete, custom_id="CloudGift_DeleteAll"),
            )
            back_button = disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="CloudGift_Back")
            )

            if mode == "embed":
                embed = disnake.Embed(
                    title=f"Painel > FProCloud > Excluir Gifts",
                    description="Selecione um método para excluir os gifts.",
                )
                if primary_color_hex:
                    embed.color = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))
                
                await inter.edit_original_response(content=None, embed=embed, components=[buttons, back_button])
            else:
                container_kwargs = {}
                if primary_color_hex:
                    container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))

                container = disnake.ui.Container(
                    disnake.ui.TextDisplay(f"## \n-# Painel > FProCloud > **Excluir Gifts**"),
                    disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                    disnake.ui.TextDisplay("Selecione um método para excluir os gifts."),
                    buttons,
                    **container_kwargs
                )
                
                await inter.edit_original_response(content=None, components=[container, back_button])
            
        except Exception as e:
            print(f"Erro ao mostrar opções de deleção de gifts: {e}")
            try:
                if not inter.response.is_done():
                    await inter.response.send_message("Erro ao carregar opções de deleção.", ephemeral=True)
                else:
                    await inter.edit_original_response("Erro ao carregar opções de deleção.")
            except:
                await inter.followup.send("Erro ao carregar opções de deleção.", ephemeral=True)

    async def _create_gift_modal(self, inter: disnake.MessageInteraction):
        """Mostra modal para criar gift"""
        try:
            from .create_gift_modal import CreateGiftModal
            modal = CreateGiftModal(self.bot)
            await inter.response.send_modal(modal)
        except Exception as e:
            print(f"Erro ao mostrar modal de criar gift: {e}")
            await inter.response.send_message("Erro ao carregar modal de criar gift.", ephemeral=True)

    async def _manage_gifts_select(self, inter: disnake.MessageInteraction):
        """Mostra select menu para gerenciar gifts"""
        try:
            mode = db.get_document("custom_mode").get("mode")
            
            await self._load_gifts_for_manage(inter)
        except Exception as e:
            print(f"Erro ao mostrar select de gerenciar gifts: {e}")
            try:
                if not inter.response.is_done():
                    await inter.response.send_message("Erro ao carregar gerenciamento de gifts.", ephemeral=True)
                else:
                    await inter.edit_original_response("Erro ao carregar gerenciamento de gifts.")
            except:
                await inter.followup.send("Erro ao carregar gerenciamento de gifts.", ephemeral=True)

    async def _handle_manage_gift_select(self, inter: disnake.MessageInteraction):
        """Handler para seleção de gift para gerenciar"""
        try:
            selected_value = inter.values[0]
            # Modais precisam ser enviados diretamente na resposta, sem defer
            await self._manage_gift_modal(inter, selected_value)
                
        except disnake.errors.HTTPException as e:
            if "already been acknowledged" in str(e):
                # Se já foi reconhecido, tentar enviar via followup
                try:
                    await inter.followup.send("Por favor, selecione novamente.", ephemeral=True)
                except:
                    pass
            else:
                print(f"Erro ao processar seleção de gift para gerenciar: {e}")
                try:
                    await inter.followup.send("Erro ao processar seleção.", ephemeral=True)
                except:
                    pass
        except Exception as e:
            print(f"Erro ao processar seleção de gift para gerenciar: {e}")
            try:
                if not inter.response.is_done():
                    await inter.response.send_message("Erro ao processar seleção.", ephemeral=True)
                else:
                    await inter.followup.send("Erro ao processar seleção.", ephemeral=True)
            except:
                pass

    async def _handle_delete_gift_select(self, inter: disnake.MessageInteraction):
        """Handler para seleção de gift para deletar"""
        try:
            selected_value = inter.values[0]
            # Modais precisam ser enviados diretamente na resposta, sem defer
            await self._delete_gift_modal(inter, selected_value)
                
        except disnake.errors.HTTPException as e:
            if "already been acknowledged" in str(e):
                # Se já foi reconhecido, tentar enviar via followup
                try:
                    await inter.followup.send("Por favor, selecione novamente.", ephemeral=True)
                except:
                    pass
            else:
                print(f"Erro ao processar seleção de gift para deletar: {e}")
                try:
                    await inter.followup.send("Erro ao processar seleção.", ephemeral=True)
                except:
                    pass
        except Exception as e:
            print(f"Erro ao processar seleção de gift para deletar: {e}")
            try:
                if not inter.response.is_done():
                    await inter.response.send_message("Erro ao processar seleção.", ephemeral=True)
                else:
                    await inter.followup.send("Erro ao processar seleção.", ephemeral=True)
            except:
                pass

    async def _load_gifts_for_manage(self, inter: disnake.MessageInteraction):
        """Carrega gifts para gerenciar"""
        try:
            mode = db.get_document("custom_mode").get("mode")
            primary_color_hex = db.get_document("custom_colors").get("primary")

            # Obter configuração do cloud
            cloud_config = db.get_document("cloud_data") or {}
            bot_id = cloud_config.get("client_id")
            
            if not bot_id:
                if mode == "embed":
                    embed = disnake.Embed(
                        title=f"{emoji.wrong} Erro",
                        description="Bot não configurado.",
                        color=utils.get_color("danger")
                    )
                    await inter.edit_original_response(embed=embed)
                else:
                    container = disnake.ui.Container(
                        disnake.ui.TextDisplay(f"# {emoji.wrong}\n-# **Erro**"),
                        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                        disnake.ui.TextDisplay("Bot não configurado."),
                    )
                    await inter.edit_original_response(components=[container])
                return
            
            # Fazer requisição para obter gifts (funciona via WS ou HTTP fallback)
            from .update_api import get_websocket_manager
            ws_manager = get_websocket_manager()
            
            response = await ws_manager.get_gifts(bot_id)
            
            if not response.get("success"):
                error_message = f"Erro ao carregar gifts: {response.get('message', 'Erro desconhecido')}"
                if mode == "embed":
                    embed = disnake.Embed(
                        title=f"{emoji.wrong} Erro",
                        description=error_message,
                        color=utils.get_color("danger")
                    )
                    await inter.edit_original_response(embed=embed)
                else:
                    container = disnake.ui.Container(
                        disnake.ui.TextDisplay(f"# {emoji.wrong}\n-# **Erro**"),
                        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                        disnake.ui.TextDisplay(error_message),
                    )
                    await inter.edit_original_response(components=[container])
                return
            
            gifts = response.get("data", {}).get("gifts", [])
            
            if not gifts:
                back_button = disnake.ui.Button(
                    label="Voltar",
                    style=disnake.ButtonStyle.grey,
                    emoji=emoji.back,
                    custom_id="CloudGift_Back"
                )
                if mode == "embed":
                    embed = disnake.Embed(
                        title=f"Painel > FProCloud > Gerenciamento de Gifts",
                        description="Nenhum gift encontrado para este bot.",
                    )
                    if primary_color_hex:
                        embed.color = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))
                    await inter.edit_original_response(embed=embed, components=[disnake.ui.ActionRow(back_button)])
                else:
                    container = disnake.ui.Container(
                        disnake.ui.TextDisplay(f"## \n-# Painel > FProCloud > **Gerenciamento de Gifts**"),
                        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                        disnake.ui.TextDisplay("Nenhum gift encontrado para este bot."),
                    )
                    await inter.edit_original_response(components=[container, disnake.ui.ActionRow(back_button)])
                return
            
            gifts_to_display = gifts[:125]
            
            gift_chunks = [gifts_to_display[i:i + 25] for i in range(0, len(gifts_to_display), 25)]
            
            selects_components = []
            for i, chunk in enumerate(gift_chunks):
                select = disnake.ui.StringSelect(
                    placeholder=f"Selecione um gift para gerenciar ({i*25 + 1}-{i*25 + len(chunk)})...",
                    custom_id=f"manage_gift_select_{i}",
                    min_values=1,
                    max_values=1
                )
                for gift in chunk:
                    status_emoji = "✅" if gift.get("status") == "active" else "❌"
                    select.add_option(
                        label=f"{status_emoji} {gift.get('id', 'Unknown')[:8]}...",
                        value=gift.get("id"),
                        description=f"{gift.get('members_count', 0)} membros - {gift.get('status', 'unknown')}"
                    )
                selects_components.append(disnake.ui.ActionRow(select))

            back_button = disnake.ui.Button(
                label="Voltar",
                style=disnake.ButtonStyle.grey,
                emoji=emoji.back,
                custom_id="CloudGift_Back"
            )

            if mode == "embed":
                embed = disnake.Embed(
                    title=f"Painel > FProCloud > Gerenciamento de Gifts",
                    description="Selecione um gift da lista abaixo para gerenciar.",
                )
                if primary_color_hex:
                    embed.color = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))
                
                components = selects_components + [disnake.ui.ActionRow(back_button)]
                await inter.edit_original_response(embed=embed, components=components)
            else:
                container_kwargs = {}
                if primary_color_hex:
                    container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))

                container_children = [
                    disnake.ui.TextDisplay(f"## \n-# Painel > FProCloud > **Gerenciamento de Gifts**"),
                    disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                ]
                container_children.extend(selects_components)
                container = disnake.ui.Container(*container_children, **container_kwargs)
                
                await inter.edit_original_response(components=[container, disnake.ui.ActionRow(back_button)])
            
        except Exception as e:
            print(f"Erro ao carregar gifts para gerenciar: {e}")
            try:
                error_message = f"Erro ao carregar gifts: {str(e)}"
                if db.get_document("custom_mode").get("mode") == "embed":
                    embed = disnake.Embed(title=f"{emoji.wrong} Erro", description=error_message, color=utils.get_color("danger"))
                    await inter.edit_original_response(embed=embed)
                else:
                    container = disnake.ui.Container(
                        disnake.ui.TextDisplay(f"# {emoji.wrong}\n-# **Erro**"),
                        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                        disnake.ui.TextDisplay(error_message),
                    )
                    await inter.edit_original_response(components=[container])
            except:
                await inter.followup.send(f"{emoji.wrong} Erro ao carregar gifts: {str(e)}", ephemeral=True)

    async def _delete_gifts_select(self, inter: disnake.MessageInteraction):
        """Mostra select menu para deletar gifts"""
        try:
            await self._load_gifts_for_delete(inter)
        except Exception as e:
            print(f"Erro ao mostrar select de deletar gifts: {e}")
            try:
                if not inter.response.is_done():
                    await inter.response.send_message("Erro ao carregar seleção de gifts para deletar.", ephemeral=True)
                else:
                    await inter.edit_original_response("Erro ao carregar seleção de gifts para deletar.")
            except:
                await inter.followup.send("Erro ao carregar seleção de gifts para deletar.", ephemeral=True)

    async def _load_gifts_for_delete(self, inter: disnake.MessageInteraction):
        """Carrega gifts para deletar"""
        try:
            mode = db.get_document("custom_mode").get("mode")
            primary_color_hex = db.get_document("custom_colors").get("primary")

            cloud_config = db.get_document("cloud_data") or {}
            bot_id = cloud_config.get("client_id")
            
            if not bot_id:
                if mode == "embed":
                    embed = disnake.Embed(title=f"{emoji.wrong} Erro", description="Bot não configurado.", color=utils.get_color("danger"))
                    await inter.edit_original_response(embed=embed)
                else:
                    container = disnake.ui.Container(
                        disnake.ui.TextDisplay(f"# {emoji.wrong}\n-# **Erro**"),
                        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                        disnake.ui.TextDisplay("Bot não configurado."),
                    )
                    await inter.edit_original_response(components=[container])
                return
            
            from .update_api import get_websocket_manager
            ws_manager = get_websocket_manager()
            # Funciona via WS ou HTTP fallback automaticamente
            
            response = await ws_manager.get_gifts(bot_id)
            
            if not response.get("success"):
                error_message = f"Erro ao carregar gifts: {response.get('message', 'Erro desconhecido')}"
                if mode == "embed":
                    embed = disnake.Embed(title=f"{emoji.wrong} Erro", description=error_message, color=utils.get_color("danger"))
                    await inter.edit_original_response(embed=embed)
                else:
                    container = disnake.ui.Container(
                        disnake.ui.TextDisplay(f"# {emoji.wrong}\n-# **Erro**"),
                        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                        disnake.ui.TextDisplay(error_message),
                    )
                    await inter.edit_original_response(components=[container])
                return
            
            gifts = response.get("data", {}).get("gifts", [])
            
            if not gifts:
                back_button = disnake.ui.Button(
                    label="Voltar",
                    style=disnake.ButtonStyle.grey,
                    emoji=emoji.back,
                    custom_id="CloudGift_Back"
                )
                if mode == "embed":
                    embed = disnake.Embed(
                        title=f"Painel > FProCloud > Deletar Gifts",
                        description="Nenhum gift encontrado para este bot."
                    )
                    if primary_color_hex:
                        embed.color = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))
                    await inter.edit_original_response(embed=embed, components=[disnake.ui.ActionRow(back_button)])
                else:
                    container = disnake.ui.Container(
                        disnake.ui.TextDisplay(f"## \n-# Painel > FProCloud > **Deletar Gifts**"),
                        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                        disnake.ui.TextDisplay("Nenhum gift encontrado para este bot."),
                    )
                    await inter.edit_original_response(components=[container, disnake.ui.ActionRow(back_button)])
                return
            
            gifts_to_display = gifts[:125]
            
            gift_chunks = [gifts_to_display[i:i + 25] for i in range(0, len(gifts_to_display), 25)]
            
            selects_components = []
            for i, chunk in enumerate(gift_chunks):
                select = disnake.ui.StringSelect(
                    placeholder=f"Selecione um gift para deletar ({i*25 + 1}-{i*25 + len(chunk)})...",
                    custom_id=f"delete_gift_select_{i}",
                    min_values=1,
                    max_values=1
                )
                for gift in chunk:
                    status_emoji = "✅" if gift.get("status") == "active" else "❌"
                    select.add_option(
                        label=f"{status_emoji} {gift.get('id', 'Unknown')[:8]}...",
                        value=gift.get("id"),
                        description=f"{gift.get('members_count', 0)} membros - {gift.get('status', 'unknown')}"
                    )
                selects_components.append(disnake.ui.ActionRow(select))

            back_button = disnake.ui.Button(
                label="Voltar",
                style=disnake.ButtonStyle.grey,
                emoji=emoji.back,
                custom_id="CloudGift_Back"
            )
            
            if mode == "embed":
                embed = disnake.Embed(
                    title=f"Painel > FProCloud > Deletar Gifts",
                    description="Selecione um gift da lista abaixo para deletar."
                )
                if primary_color_hex:
                    embed.color = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))
                
                components = selects_components + [disnake.ui.ActionRow(back_button)]
                await inter.edit_original_response(embed=embed, components=components)
            else:
                container_kwargs = {}
                if primary_color_hex:
                    container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))

                container_children = [
                    disnake.ui.TextDisplay(f"## \n-# Painel > FProCloud > **Deletar Gifts**"),
                    disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                ]
                container_children.extend(selects_components)
                container = disnake.ui.Container(*container_children, **container_kwargs)
                
                await inter.edit_original_response(components=[container, disnake.ui.ActionRow(back_button)])
            
        except Exception as e:
            print(f"Erro ao carregar gifts para deletar: {e}")
            try:
                error_message = f"Erro ao carregar gifts: {str(e)}"
                if db.get_document("custom_mode").get("mode") == "embed":
                    embed = disnake.Embed(title=f"{emoji.wrong} Erro", description=error_message, color=utils.get_color("danger"))
                    await inter.edit_original_response(embed=embed)
                else:
                    container = disnake.ui.Container(
                        disnake.ui.TextDisplay(f"# {emoji.wrong}\n-# **Erro**"),
                        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                        disnake.ui.TextDisplay(error_message),
                    )
                    await inter.edit_original_response(components=[container])
            except:
                await inter.followup.send(f"{emoji.wrong} Erro ao carregar gifts: {str(e)}", ephemeral=True)

    async def _manage_gift_modal(self, inter: disnake.MessageInteraction, gift_id: str):
        """Mostra modal para editar gift"""
        try:
            from .edit_gift_modal import EditGiftModal
            modal = EditGiftModal(self.bot, gift_id)
            await inter.response.send_modal(modal)
            
        except Exception as e:
            print(f"Erro ao mostrar modal de editar gift: {e}")
            await inter.response.send_message("Erro ao abrir modal de edição.", ephemeral=True)

    async def _delete_gift_modal(self, inter: disnake.MessageInteraction, gift_id: str):
        """Mostra modal para confirmar deleção de gift"""
        try:
            from .delete_gift_modal import DeleteGiftModal
            modal = DeleteGiftModal(self.bot, gift_id)
            await inter.response.send_modal(modal)
            
        except Exception as e:
            print(f"Erro ao mostrar modal de deletar gift: {e}")
            await inter.response.send_message("Erro ao abrir modal de confirmação.", ephemeral=True)

    async def process_log_channel(self, inter: disnake.ModalInteraction, channel_id_str: str):
        try:
            channel_id = int(channel_id_str)
            channel = self.bot.get_channel(channel_id)
            
            if not channel:
                if not inter.response.is_done():
                    await inter.response.send_message(f"{emoji.wrong} Canal não encontrado. ID: {channel_id}\n\n**Verifique se:**\n• O canal existe\n• O bot tem acesso ao canal\n• O ID está correto", ephemeral=True)
                return
                
            if not isinstance(channel, disnake.TextChannel):
                if not inter.response.is_done():
                    await inter.response.send_message(f"{emoji.wrong} O canal encontrado não é um canal de texto. Tipo: {type(channel).__name__}", ephemeral=True)
                return
                
        except (ValueError, TypeError):
            if not inter.response.is_done():
                await inter.response.send_message(f"{emoji.wrong} ID do canal inválido. Use apenas números.", ephemeral=True)
            return

        # Salvar configuração
        cloud_config = db.get_document("cloud_data") or {}
        cloud_config["log_channel_id"] = channel_id
        db.save_document("cloud_data", cloud_config)

        # Atualizar o painel principal diretamente
        await self.display_cloud_panel(inter)


    def CloudComponents(self, inter: disnake.MessageInteraction, status_text: str) -> list[disnake.ui.Container]:
        colors = db.get_document("custom_colors")
        primary_color_hex = colors.get("primary")

        container_kwargs = {}
        if primary_color_hex:
            primary_color = int(primary_color_hex.replace("#", ""), 16)
            container_kwargs["accent_colour"] = disnake.Colour(primary_color)

        cloud_conf = db.get_document("cloud_data") or {}
        is_configured = bool(cloud_conf.get("client_id"))
        # Credentials can only be configured if verified role and logs are set
        verified_role_id = (db.get_document("cargos") or {}).get("cargo_verificado")
        has_verified_role = bool(verified_role_id)
        has_log_channel = bool(cloud_conf.get("log_channel_id"))
        can_configure_credentials = True  # Credenciais sempre configuráveis

        return [
            disnake.ui.Container(
                disnake.ui.TextDisplay(
                    f"## \n-# Painel > **Febre Cloud**"
                ),

                disnake.ui.Separator(
                    spacing=disnake.SeparatorSpacing.small
                ),

                disnake.ui.ActionRow(
                    disnake.ui.Button(
                        label="Configurar Verificação OAuth2",
                        style=disnake.ButtonStyle.blurple,
                        emoji=emoji.verified,
                        custom_id="Cloud_OAuthPanel"
                    ),
                ),

                disnake.ui.ActionRow(
                    disnake.ui.Button(
                        label="Gift Cards de Membros",
                        style=disnake.ButtonStyle.blurple,
                        emoji=emoji.gift,
                        custom_id="CloudGiftCards_Menu",
                        disabled=not is_configured
                    ),
                ),

                **container_kwargs,
            ),

            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Voltar",
                    style=disnake.ButtonStyle.grey,
                    emoji=emoji.back,
                    custom_id="PainelInicial"
                ),
            )
        ]

    def CloudEmbed(self, inter: disnake.Interaction, status_text: str):
        colors = db.get_document("custom_colors")
        primary_color_hex = colors.get("primary")

        embed = disnake.Embed(
            title=f"FProCloud",
            description=status_text,
        )
        if primary_color_hex:
            primary_color = int(primary_color_hex.replace("#", ""), 16)
            embed.color = primary_color
        
        cloud_conf = db.get_document("cloud_data") or {}
        is_configured = bool(cloud_conf.get("client_id"))
        # Credentials can only be configured if verified role and logs are set
        verified_role_id = (db.get_document("cargos") or {}).get("cargo_verificado")
        has_verified_role = bool(verified_role_id)
        has_log_channel = bool(cloud_conf.get("log_channel_id"))
        can_configure_credentials = True  # Credenciais sempre configuráveis

        components = [
            #disnake.ui.ActionRow(
                #disnake.ui.Button(label="Gerenciar Tarefas", style=disnake.ButtonStyle.green, emoji=emoji.reload, custom_id="Cloud_ManageTasks", disabled=not is_configured),
                #disnake.ui.Button(label="Editar Credenciais", style=disnake.ButtonStyle.grey, custom_id="Cloud_ConfigurarCredenciais", disabled=not can_configure_credentials),
                #disnake.ui.Button(label="Preferencias", style=disnake.ButtonStyle.grey, emoji=emoji.settings2, custom_id="Cloud_Definicoes", disabled=not is_configured),
            #),
            #disnake.ui.ActionRow(
                #disnake.ui.Button(label="Gerenciar Mensagens", style=disnake.ButtonStyle.grey, emoji=emoji.embed, custom_id="Cloud_DefinirMensagens", disabled=not is_configured),
                #disnake.ui.Button(label="Gerenciar Gifts", style=disnake.ButtonStyle.grey, emoji=emoji.gift, custom_id="Cloud_GerenciarGift", disabled=not is_configured),
                #disnake.ui.Button(label="Definir Logs", style=disnake.ButtonStyle.grey, emoji=emoji.textc, custom_id="Cloud_DefinirLogs"),
            #),
            #disnake.ui.ActionRow(
                #disnake.ui.Button(label="Configurar Verificação OAuth2", style=disnake.ButtonStyle.blurple, emoji=emoji.verified, custom_id="Cloud_OAuthPanel"),
            #),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Gift Cards de Membros", style=disnake.ButtonStyle.blurple, emoji=emoji.gift, custom_id="CloudGiftCards_Menu", disabled=not is_configured),
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="PainelInicial"),
            )
        ]
        return embed, components

    async def display_cloud_panel(self, inter):
        try:
            mode = db.get_document("custom_mode").get("mode")
            print(f"[Cloud] display_cloud_panel chamado | mode={mode} | response_done={inter.response.is_done()}")

            # Responder imediatamente para evitar timeout do Discord (3s)
            if not inter.response.is_done():
                try:
                    await inter.response.defer(with_message=False)
                except Exception:
                    pass

            # Mostrar "Carregando..." enquanto busca os dados
            if mode == "embed":
                await embed_message.wait(inter)
            else:
                await message.wait(inter)

            status_text = await helpers.get_status_text(inter)
            print(f"[Cloud] status_text obtido")

            if mode == "embed":
                embed, components = self.CloudEmbed(inter, status_text)
                print("[Cloud] editando mensagem (embed mode)")
                await inter.edit_original_message(content=None, embed=embed, components=components)
            else:
                components = self.CloudComponents(inter, status_text)
                print(f"[Cloud] editando mensagem (components mode) | components={components}")
                await inter.edit_original_message(content=None, embed=None, components=components)

            print("[Cloud] display_cloud_panel concluído com sucesso")

        except Exception as e:
            import traceback
            print(f"[Cloud] ERRO em display_cloud_panel: {e}")
            traceback.print_exc()
            try:
                await inter.followup.send(f"Erro ao abrir painel cloud: {e}", ephemeral=True)
            except Exception:
                pass

    @commands.Cog.listener("on_button_click")
    async def on_button_click(self, inter: disnake.MessageInteraction):
        if not inter.component.custom_id.startswith("Cloud"):
            return
        
        # Responder a interação imediatamente para evitar "Esta interação falhou".
        # with_message=False significa que não altera a mensagem original — só reconhece a interação.
        # O message.wait() chamado depois vai editar a mensagem com o loading e depois com o conteúdo final.
        # Botões que abrem modal NÃO devem receber defer aqui, pois send_modal é a própria resposta.
        modal_buttons = {
            "CloudTasks_Create",
            "Cloud_SetCredentialsModal",
            "Cloud_DefinirLogs",
            "CloudGift_Create",
            "CloudGift_DeleteByCode",
            "CloudGift_DeleteAll",
            "CloudMsgEdit_EditButton",
            "CloudMsgEdit_EditContent",
            "CloudSend_External",
            "OAuthPanel_PullVerified",
            "OAuthPanel_SetVerifiedRole",
            "OAuthPanel_SetClientID",
            "OAuthPanel_SetClientSecret",
            "OAuthPanel_SetButton",
            "OAuthPanel_Preview",
            "OAuthPanel_PostMessage",
            "CloudGiftCards_Create",
            "CloudGiftCards_DeleteByCode",
            "CloudGiftCards_DeleteAll",
            "CloudGiftCards_SetSiteUrl",
            "CloudGiftCards_ViewLogs",
        }

        if inter.component.custom_id not in modal_buttons and not inter.response.is_done():
            try:
                await inter.response.defer(with_message=False)
            except disnake.errors.InteractionResponded:
                pass
            
        match inter.component.custom_id:
            case "Cloud_ManageTasks":
                cloud_conf = db.get_document("cloud_data") or {}
                if not bool(cloud_conf.get("client_id")):
                    await inter.followup.send(f"{emoji.off} FProCloud não está configurado. Use 'Editar Credenciais' primeiro.", ephemeral=True)
                    return
                mode = db.get_document("custom_mode").get("mode")
                if mode == "embed":
                    await embed_message.wait(inter)
                    embed, components = ManageTasksView_embed(inter)
                    await inter.edit_original_message(content=None, embed=embed, components=components)
                else:
                    await message.wait(inter)
                    components = await ManageTasksView_components(inter)
                    await inter.edit_original_message(content=None, components=components)
            case "CloudTasks_Create":
                await inter.response.send_modal(CreateTaskModal(self.bot))
            case "CloudTasks_Manage":
                mode = db.get_document("custom_mode").get("mode")
                if mode == "embed":
                    await embed_message.wait(inter)
                    embed, components = ManageTasksSelectView_embed(inter)
                    await inter.edit_original_message(content=None, embed=embed, components=components)
                else:
                    await message.wait(inter)
                    components = ManageTasksSelectView_components(inter)
                    await inter.edit_original_message(content=None, components=components)
            case "CloudTasks_Back":
                mode = db.get_document("custom_mode").get("mode")
                if mode == "embed":
                    await embed_message.wait(inter)
                    embed, components = ManageTasksView_embed(inter)
                    await inter.edit_original_message(content=None, embed=embed, components=components)
                else:
                    await message.wait(inter)
                    components = await ManageTasksView_components(inter)
                    await inter.edit_original_message(components=components)
            case "Cloud_ConfigurarCredenciais":
                mode = db.get_document("custom_mode").get("mode")
                if mode == "embed":
                    await embed_message.wait(inter)
                else:
                    await message.wait(inter)
                await config_credenciais.show_panel(inter)
            case "Cloud_CopyAuthURL":
                from .cloud_config import get_auth_callback_url
                auth_url = get_auth_callback_url()
                await inter.followup.send(f"{auth_url}", ephemeral=True)
            case "Cloud_SetCredentialsModal":
                cloud_config = db.get_document("cloud_data") or {}
                bot_token = cloud_config.get("token", "")
                client_secret = cloud_config.get("client_secret", "")
                await inter.response.send_modal(config_credenciais.CredentialModal(self.bot, bot_token=bot_token, client_secret=client_secret))
            case "Cloud_OAuthPanel":
                mode = db.get_document("custom_mode").get("mode")
                if mode == "embed":
                    await embed_message.wait(inter)
                else:
                    await message.wait(inter)
                await oauth.panel_oauth(inter, self.bot)
            case "Cloud_MainPanel":
                await self.display_cloud_panel(inter)
            case "Cloud_Back":
                await self.display_cloud_panel(inter)
            case "Cloud_Definicoes":
                mode = db.get_document("custom_mode").get("mode")
                if mode == "embed":
                    await embed_message.wait(inter)
                    embed, components = DefinicoesView_embed(inter)
                    await inter.edit_original_message(embed=embed, components=components)
                else:
                    await message.wait(inter)
                    components = DefinicoesView_components(inter)
                    await inter.edit_original_message(components=components)
            case "Cloud_Preferencias":
                cloud_conf = db.get_document("cloud_data") or {}
                if not bool(cloud_conf.get("client_id")):
                    await inter.followup.send(f"{emoji.off} FProCloud não está configurado. Use 'Editar Credenciais' primeiro.", ephemeral=True)
                    return
                mode = db.get_document("custom_mode").get("mode")
                if mode == "embed":
                    await embed_message.wait(inter)
                else:
                    await message.wait(inter)
                await self._definir_preferencias(inter)
            case "Cloud_DefinirMensagens":
                cloud_conf = db.get_document("cloud_data") or {}
                if not bool(cloud_conf.get("client_id")):
                    await inter.followup.send(f"{emoji.off} FProCloud não está configurado. Use 'Editar Credenciais' primeiro.", ephemeral=True)
                    return
                mode = db.get_document("custom_mode").get("mode")
                if mode == "embed":
                    await embed_message.wait(inter)
                else:
                    await message.wait(inter)
                await config_mensagem.show_panel(inter)
            case "Cloud_DefinirLogs":
                cloud_config = db.get_document("cloud_data") or {}
                current_log_channel_id = str(cloud_config.get("log_channel_id", ""))
                
                modal = helpers.LogChannelModal(self.bot, current_channel_id=current_log_channel_id)
                await inter.response.send_modal(modal)
            case "Cloud_GerenciarGift":
                cloud_conf = db.get_document("cloud_data") or {}
                if not bool(cloud_conf.get("client_id")):
                    await inter.followup.send(f"{emoji.off} FProCloud não está configurado. Use 'Editar Credenciais' primeiro.", ephemeral=True)
                    return
                mode = db.get_document("custom_mode").get("mode")
                if mode == "embed":
                    await embed_message.wait(inter)
                else:
                    await message.wait(inter)
                await self._gerenciar_gift(inter)
            case "CloudGift_Create":
                await self._create_gift_modal(inter)
            case "CloudGift_Manage":
                mode = db.get_document("custom_mode").get("mode")
                if mode == "embed":
                    await embed_message.wait(inter)
                else:
                    await message.wait(inter)
                await self._manage_gifts_select(inter)
            case "CloudGift_Delete":
                mode = db.get_document("custom_mode").get("mode")
                if mode == "embed":
                    await embed_message.wait(inter)
                else:
                    await message.wait(inter)
                await self._show_delete_options(inter)
            case "CloudGift_DeleteFromList":
                mode = db.get_document("custom_mode").get("mode")
                if mode == "embed":
                    await embed_message.wait(inter)
                else:
                    await message.wait(inter)
                await self._delete_gifts_select(inter)
            case "CloudGift_DeleteByCode":
                from .delete_gift_modal import DeleteGiftByCodeModal
                await inter.response.send_modal(DeleteGiftByCodeModal(self.bot))
            case "CloudGift_DeleteAll":
                from .delete_gift_modal import DeleteAllGiftsModal
                await inter.response.send_modal(DeleteAllGiftsModal(self.bot))
            case "CloudGift_Back":
                mode = db.get_document("custom_mode").get("mode")
                if mode == "embed":
                    await embed_message.wait(inter)
                else:
                    await message.wait(inter)
                await self._gerenciar_gift(inter)

            # --- Gift Cards de Membros (implementação nova, ver gift_cards.py) ---
            case "CloudGiftCards_Menu":
                mode = db.get_document("custom_mode").get("mode")
                if mode == "embed":
                    await embed_message.wait(inter)
                    embed, components = gift_cards_panel.GiftCardsMenu_embed(inter)
                    await inter.edit_original_message(content=None, embed=embed, components=components)
                else:
                    await message.wait(inter)
                    components = gift_cards_panel.GiftCardsMenu_components(inter)
                    await inter.edit_original_message(content=None, components=components)
            case "CloudGiftCards_List":
                mode = db.get_document("custom_mode").get("mode")
                if mode == "embed":
                    await embed_message.wait(inter)
                    embed, components = gift_cards_panel.GiftCardsList_embed(inter)
                    await inter.edit_original_message(content=None, embed=embed, components=components)
                else:
                    await message.wait(inter)
                    components = gift_cards_panel.GiftCardsList_components(inter)
                    await inter.edit_original_message(content=None, components=components)
            case "CloudGiftCards_Create":
                await inter.response.send_modal(gift_cards_panel.CreateGiftCardModal())
            case "CloudGiftCards_DeleteByCode":
                await inter.response.send_modal(gift_cards_panel.DeleteGiftCardModal())
            case "CloudGiftCards_DeleteAll":
                await inter.response.send_modal(gift_cards_panel.ConfirmDeleteAllGiftCardsModal())
            case "CloudGiftCards_SetSiteUrl":
                await inter.response.send_modal(gift_cards_panel.SetGiftSiteUrlModal())
            case "CloudGiftCards_ViewLogs":
                await inter.response.send_modal(gift_cards_panel.ViewGiftLogsModal())
            case "Cloud_GetAuthLink":
                cloud_config = db.get_document("cloud_data") or {}
                client_id = cloud_config.get("client_id")

                if not client_id:
                    await inter.followup.send("O bot da cloud não foi configurado.", ephemeral=True)
                    return

                # Usa o mesmo gerador de link do painel OAuth2 (state no
                # formato "bot_id:guild_id" esperado pelo site da Lunar
                # Cloud) - ver nota em modules/cloud/verification_check.py.
                from .oauth_panel import build_auth_url
                bot_user = getattr(getattr(inter, "bot", None), "user", None)
                bot_id = str(bot_user.id) if bot_user else client_id
                auth_url = build_auth_url(client_id, guild_id=inter.guild.id, bot_id=bot_id)

                view = disnake.ui.View()
                view.add_item(disnake.ui.Button(label="Verificar", style=disnake.ButtonStyle.link, url=auth_url))
                await inter.followup.send(
                        "Clique no botão abaixo para ser verificado:",
                        view=view,
                        ephemeral=True
                    )
            case "CloudMsgEdit_CycleStyle":
                mode = db.get_document("custom_mode").get("mode")
                if mode == "embed":
                    await embed_message.wait(inter)
                else:
                    await message.wait(inter)
                cloud_config = db.get_document("cloud_data") or {}
                message_config = cloud_config.setdefault("message_verify", {})
                
                styles = ["embed", "content", "container"]
                current_style = message_config.get("message_style", "embed")
                try:
                    current_index = styles.index(current_style)
                    new_style = styles[(current_index + 1) % len(styles)]
                except ValueError:
                    new_style = "embed"
                
                message_config["message_style"] = new_style
                db.save_document("cloud_data", cloud_config)
                await config_mensagem.show_panel(inter)

            case "CloudMsgEdit_EditButton":
                cloud_config = db.get_document("cloud_data") or {}
                button_data = cloud_config.get("message_verify", {}).get("button", {})
                await inter.response.send_modal(config_mensagem.EditButtonModal(data=button_data))

            case "CloudMsgEdit_EditContent":
                cloud_config = db.get_document("cloud_data") or {}
                message_config = cloud_config.get("message_verify", {})
                style = message_config.get("message_style", "embed")

                try:
                    if style == "embed":
                        embed_data = message_config.get("embed", {})
                        await inter.response.send_modal(config_mensagem.EditEmbedModal(data=embed_data))
                    elif style == "content":
                        content_data = message_config.get("content", {})
                        await inter.response.send_modal(config_mensagem.EditContentModal(data=content_data))
                    else:  # container
                        container_data = message_config.get("container", {})
                        await inter.response.send_modal(config_mensagem.EditContainerModal(data=container_data))
                except disnake.errors.NotFound:
                    try:
                        await inter.followup.send("A interação expirou. Clique novamente no botão.", ephemeral=True)
                    except Exception:
                        pass
                    return

            case "CloudMsgEdit_Send":
                mode = db.get_document("custom_mode").get("mode")
                if mode == "embed":
                    await embed_message.wait(inter)
                else:
                    await message.wait(inter)
                await config_mensagem.show_send_panel(inter, self.bot)

            case "CloudMsgEdit_Preview":
                # Sends an ephemeral preview message — does not edit the original
                cloud_config = db.get_document("cloud_data") or {}
                message_config = cloud_config.get("message_verify", {})
                style = message_config.get("message_style", "embed")
                
                send_kwargs = {}
                
                if style == "embed":
                    embed_data = message_config.get("embed", {})
                    if not embed_data:
                        embed_data = {"title": "Título de Exemplo", "description": "Descrição de exemplo."}
                    normalized_data = utils.normalize_embed_data(embed_data)
                    embed = disnake.Embed.from_dict(normalized_data)
                    send_kwargs["embed"] = embed
                elif style == "content": # content
                    content_data = message_config.get("content", {})
                    send_kwargs["content"] = content_data.get("content", "Conteúdo de exemplo.")
                    # Previewing with imag69e might be complex, skipping for now.
                elif style == "container":
                    data = message_config.get("container", {})
                    container = config_mensagem.ContainerUtils.montar_container(
                        conteudo=data.get("content"), 
                        imagem_url=data.get("image_url"), 
                        cor_hex=data.get("color"),
                        thumbnail_url=data.get("thumbnail_url")
                    )
                    send_kwargs["components"] = [container]
                    send_kwargs["flags"] = disnake.MessageFlags(is_components_v2=True)


                button_data = message_config.get("button", {})
                style_map = {"green": disnake.ButtonStyle.green, "grey": disnake.ButtonStyle.grey, "red": disnake.ButtonStyle.red, "blue": disnake.ButtonStyle.primary}
                button = disnake.ui.Button(
                    label=button_data.get("label", "Verificar"),
                    style=style_map.get(button_data.get("style", "green")),
                    emoji=config_mensagem.get_validated_emoji(button_data.get("emoji")),
                    custom_id="do_nothing"
                )
                
                view = disnake.ui.View()
                view.add_item(button)

                if style != "container":
                    send_kwargs["view"] = view
                else:
                    if "components" not in send_kwargs:
                        send_kwargs["components"] = []
                    send_kwargs["components"].append(disnake.ui.ActionRow(button))
                
                if style == "container":
                    await inter.followup.send(**send_kwargs, ephemeral=True)
                else:
                    await inter.followup.send(**send_kwargs, ephemeral=True)
            case "CloudSend_External":
                await inter.response.send_modal(config_mensagem.ExternalSendModal(self.bot))
            
            # Handler para botão de localização
            # case _ if inter.component.custom_id.startswith("auth_location_"):
            #     await auth_logs.handle_location_button(inter)




    @commands.Cog.listener("on_button_click")
    async def on_oauth_button_click(self, inter: disnake.MessageInteraction):
        cid = inter.component.custom_id
        if not cid.startswith("OAuthPanel") and not cid.startswith("OAuthModal"):
            return
        # Botões que abrem modal, ou que precisam controlar a própria resposta
        # (ex: editar a mensagem diretamente), não devem receber defer automático
        no_defer_buttons = {
            "OAuthPanel_PullVerified",
            "OAuthPanel_SetClientID",
            "OAuthPanel_SetClientSecret",
            "OAuthPanel_SetButton",
            "OAuthPanel_Preview",
        }
        needs_manual_response = cid in no_defer_buttons or cid.startswith("OAuthPanel_ChartPeriod_")
        if not needs_manual_response and not inter.response.is_done():
            try:
                await inter.response.defer()
            except disnake.errors.InteractionResponded:
                pass
        await oauth.dispatch(inter, self.bot)

    @commands.Cog.listener("on_dropdown")
    async def on_oauth_dropdown(self, inter: disnake.MessageInteraction):
        cid = inter.component.custom_id
        if not cid.startswith("OAuthPanel") and not cid.startswith("OAuthModal"):
            return
        # Selects que abrem modal não devem receber defer
        no_defer_selects = {"OAuthPanel_PermsMenu", "OAuthPanel_BlacklistIPMenu", "OAuthPanel_BlacklistUserMenu"}
        # MessageMenu pode ter "import" que abre modal - nao defer para segurança
        if cid == "OAuthPanel_MessageMenu":
            # não faz defer pois pode abrir modal
            pass
        elif cid not in no_defer_selects and not inter.response.is_done():
            try:
                await inter.response.defer()
            except disnake.errors.InteractionResponded:
                pass
        await oauth.dispatch(inter, self.bot)

    @commands.Cog.listener("on_modal_submit")
    async def on_oauth_modal_submit(self, inter: disnake.ModalInteraction):
        cid = inter.custom_id
        if not cid.startswith("OAuthModal"):
            return
        # Não faz defer aqui - os callbacks dos modais e o dispatch cuidam disso
        await oauth.dispatch(inter, self.bot)

    @commands.Cog.listener("on_dropdown")
    async def on_dropdown(self, inter: disnake.MessageInteraction):
        if not inter.component.custom_id.startswith("Cloud") and \
           not inter.component.custom_id.startswith("manage_gift_select") and \
           not inter.component.custom_id.startswith("delete_gift_select"):
            return

        custom_id = inter.component.custom_id

        # Selects que abrem modal não devem receber defer global
        modal_selects = {"OAuthPanel_PermsMenu", "OAuthPanel_BlacklistIPMenu", "OAuthPanel_BlacklistUserMenu", "OAuthPanel_MessageMenu"}
        if custom_id not in modal_selects and not inter.response.is_done():
            try:
                await inter.response.defer(with_message=False)
            except disnake.errors.InteractionResponded:
                pass

        mode = db.get_document("custom_mode").get("mode")

        if custom_id == "CloudTasks_Select":
            try:
                if not inter.values:
                    await inter.followup.send("Nenhuma task selecionada.", ephemeral=True)
                    return
                task_id = inter.values[0]
                if mode == "embed":
                    await embed_message.wait(inter)
                    embed, components = TaskDetailsView_embed(inter, task_id)
                    await inter.edit_original_message(content=None, embed=embed, components=components)
                else:
                    await message.wait(inter)
                    components = TaskDetailsView_components(inter, task_id)
                    await inter.edit_original_message(components=components)
            except Exception as e:
                print(f"Erro no handler CloudTasks_Select: {e}")
                await inter.followup.send(f"Erro ao processar seleção: {str(e)}", ephemeral=True)

        elif custom_id.startswith("manage_gift_select"):
            await self._handle_manage_gift_select(inter)

        elif custom_id.startswith("delete_gift_select"):
            await self._handle_delete_gift_select(inter)

        elif custom_id == "CloudDefinicoes_Select":
            if mode == "embed":
                await embed_message.wait(inter)
            else:
                await message.wait(inter)

            setting_key = inter.values[0]
            cloud_config = db.get_document("cloud_data") or {}
            definitions = cloud_config.setdefault("definitions", {})
            setting = definitions.setdefault(setting_key, {})
            setting["enabled"] = not setting.get("enabled", False)
            db.save_document("cloud_data", cloud_config)

            from .update_api import get_websocket_manager
            ws_manager = get_websocket_manager()
            try:
                if ws_manager.is_connected():
                    await ws_manager.update_definitions(definitions)
            except Exception as e:
                print(f"[Cloud Cog] Erro ao enviar definições: {e}")

            if mode == "embed":
                embed, components = DefinicoesView_embed(inter)
                await inter.edit_original_message(content=None, embed=embed, components=components)
            else:
                components = DefinicoesView_components(inter)
                await inter.edit_original_message(components=components)

        elif custom_id == "CloudSend_ChannelSelect":
            if mode == "embed":
                await embed_message.wait(inter)
            else:
                await message.wait(inter)

            try:
                channel_id = int(inter.values[0])
                channel = self.bot.get_channel(channel_id)
            except (ValueError, IndexError):
                channel = None

            if not channel:
                if mode == "embed":
                    await inter.edit_original_message(content=f"{emoji.wrong} Canal não encontrado.", embed=None, components=[])
                else:
                    container = disnake.ui.Container(
                        disnake.ui.TextDisplay(f"# {emoji.wrong}\n-# **Erro**"),
                        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                        disnake.ui.TextDisplay("Canal não encontrado."),
                    )
                    await inter.edit_original_message(components=[container])
                return

            cloud_config = db.get_document("cloud_data") or {}
            message_config = cloud_config.get("message_verify", {})
            success, error_message = await config_mensagem._send_verification_message(channel, message_config)

            if success:
                if mode == "embed":
                    await inter.edit_original_message(content=f"{emoji.correct} Mensagem de verificação enviada para {channel.mention}.", embed=None, components=[])
                else:
                    container = disnake.ui.Container(
                        disnake.ui.TextDisplay(f"{emoji.correct} Mensagem de verificação enviada para {channel.mention}."),
                    )
                    await inter.edit_original_message(components=[container])
            else:
                if mode == "embed":
                    await inter.edit_original_message(content=f"{emoji.wrong} {error_message}", embed=None, components=[])
                else:
                    container = disnake.ui.Container(
                        disnake.ui.TextDisplay(f"{emoji.wrong} {error_message}"),
                    )
                    await inter.edit_original_message(components=[container])


def setup(bot: commands.Bot):

    bot.add_cog(Cloud(bot))