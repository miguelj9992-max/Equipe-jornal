import disnake
from functions.emoji import emoji
from functions.database import database as db
from functions.message import message, embed_message
from disnake.ext import commands


class PermsInternas(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    PERMS_OPCOES = [
        ("perms_gerar_pagamento", "Quem pode usar /gerar_pagamento", emoji.card, "Define quem pode gerar pagamentos pelo bot."),
        ("perms_entregar",        "Quem pode usar /entregar",         emoji.truck, "Define quem pode entregar produtos ou assinaturas."),
        ("perms_anunciar",        "Quem pode usar /anunciar",         emoji.announcement, "Define quem pode criar e enviar anúncios pelo bot."),
        ("perms_backup",          "Quem pode usar /backup",           emoji.save, "Define quem pode gerar backups do servidor."),
        ("perms_painel",          "Quem pode usar /painel",           emoji.config, "Define quem pode abrir o painel de configurações do bot."),
        ("perms_limpar",          "Quem pode usar /limpar",           emoji.delete, "Define quem pode limpar mensagens de um canal."),
        ("perms_lock",            "Quem pode usar /lock",             emoji.lock, "Define quem pode trancar canais do servidor."),
        ("perms_unlock",          "Quem pode usar /unlock",           emoji.unlock, "Define quem pode destrancar canais do servidor."),
        ("perms_falar",           "Quem pode usar /falar",            emoji.speech, "Define quem pode fazer o bot falar em um canal."),
        ("perms_enviar_dm",       "Quem pode usar /enviar_dm",        emoji.mail2, "Define quem pode enviar DMs em massa pelo bot."),
        ("perms_conectar",        "Quem pode usar /conectar",         emoji.voice, "Define quem pode conectar o bot em canais de voz."),
        ("perms_cargos",          "Quem pode usar /cargo",            emoji.group, "Define quem pode adicionar ou remover cargos em massa."),
        ("perms_boost",           "Quem pode usar /boost",            emoji.boost, "Define quem pode usar o sistema de boost do servidor."),
    ]

    # ─── helpers ──────────────────────────────────────────────────────────────

    @staticmethod
    def _accent(container_kwargs: dict):
        colors = db.get_document("custom_colors") or {}
        primary = colors.get("primary")
        if primary:
            container_kwargs["accent_colour"] = disnake.Colour(int(primary.replace("#", ""), 16))

    @staticmethod
    def _get_roles(perms_key: str) -> list[int]:
        """Retorna lista de IDs de cargos salvos para a permissão."""
        doc = db.get_document("perms_internas") or {}
        return doc.get(perms_key, [])

    @staticmethod
    def _save_roles(perms_key: str, role_ids: list[int]):
        """Salva lista de IDs de cargos para a permissão."""
        doc = db.get_document("perms_internas") or {}
        doc[perms_key] = role_ids
        db.save_document("perms_internas", doc)

    @staticmethod
    def _role_mentions(guild: disnake.Guild, role_ids: list[int]) -> str:
        mentions = []
        for rid in role_ids:
            role = guild.get_role(rid)
            mentions.append(role.mention if role else f"`{rid}` *(removido)*")
        return ", ".join(mentions) if mentions else "*Nenhum cargo configurado*"

    @staticmethod
    async def _show_loading(inter: disnake.MessageInteraction):
        mode = (db.get_document("custom_mode") or {}).get("mode", "embed")
        msg_handler = embed_message if mode == "embed" else message
        await msg_handler.wait(inter, send=False)

    # ─── painel principal ─────────────────────────────────────────────────────

    async def display_panel(self, inter: disnake.MessageInteraction):
        mode = (db.get_document("custom_mode") or {}).get("mode", "embed")

        await self._show_loading(inter)

        if mode == "embed":
            embed, components = self._build_main_embed(inter)
            await inter.edit_original_message(content=None, embed=embed, components=components)
        else:
            await inter.edit_original_message(content=None, embed=None, components=self._build_main_components(inter))

    def _build_main_components(self, inter):
        options = [
            disnake.SelectOption(label=label, value=key, emoji=e, description=desc)
            for key, label, e, desc in self.PERMS_OPCOES
        ]
        ck = {}
        self._accent(ck)
        return [
            disnake.ui.Container(
                disnake.ui.TextDisplay(
                    f"##  \n"
                    f"-# Painel > Proteção > Permissões Internas"
                ),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(
                    "Gerencie quem pode usar comandos internos do bot.\n"
                    "Selecione uma opção abaixo para configurar:"
                ),
                disnake.ui.Separator(),
                disnake.ui.ActionRow(
                    disnake.ui.StringSelect(
                        placeholder="Escolha o comando para configurar",
                        options=options,
                        custom_id="PermsInternasSelectMenu"
                    )
                ),
                **ck
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Voltar",
                    style=disnake.ButtonStyle.grey,
                    emoji=emoji.back,
                    custom_id="Protection"
                ),
            )
        ]

    def _build_main_embed(self, inter):
        options = [
            disnake.SelectOption(label=label, value=key, emoji=e, description=desc)
            for key, label, e, desc in self.PERMS_OPCOES
        ]
        colors = db.get_document("custom_colors") or {}
        primary = colors.get("primary")
        embed = disnake.Embed(
            title="Painel de Permissões Internas",
            description="Gerencie quem pode usar comandos internos do bot.\nSelecione uma opção abaixo para configurar:"
        )
        if primary:
            embed.color = int(primary.replace("#", ""), 16)
        components = [
            disnake.ui.ActionRow(
                disnake.ui.StringSelect(
                    placeholder="Escolha o comando para configurar",
                    options=options,
                    custom_id="PermsInternasSelectMenu"
                )
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey,
                                  emoji=emoji.back, custom_id="Protection"),
            )
        ]
        return embed, components

    # ─── sub-painel de um comando ─────────────────────────────────────────────

    def _build_perm_components(self, inter: disnake.MessageInteraction, perms_key: str):
        label = next((l for k, l, *_ in self.PERMS_OPCOES if k == perms_key), perms_key)
        role_ids = self._get_roles(perms_key)
        roles_txt = self._role_mentions(inter.guild, role_ids)

        ck = {}
        self._accent(ck)

        return [
            disnake.ui.Container(
                disnake.ui.TextDisplay(
                    f"##  \n"
                    f"-# Painel > Proteção > Permissões Internas > {label}"
                ),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(
                    f"**Cargos permitidos:** {roles_txt}\n\n"
                    f"Use os botões abaixo para adicionar ou remover cargos."
                ),
                disnake.ui.Separator(),
                disnake.ui.ActionRow(
                    disnake.ui.Button(
                        label="Adicionar Cargo",
                        style=disnake.ButtonStyle.green,
                        emoji=emoji.plus if hasattr(emoji, "plus") else None,
                        custom_id=f"perms_add_{perms_key}"
                    ),
                    disnake.ui.Button(
                        label="Remover Cargo",
                        style=disnake.ButtonStyle.red,
                        emoji=emoji.minus if hasattr(emoji, "minus") else None,
                        custom_id=f"perms_remove_{perms_key}"
                    )
                ),
                **ck
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Voltar",
                    style=disnake.ButtonStyle.grey,
                    emoji=emoji.back,
                    custom_id="PermsInternasBack"
                ),
            )
        ]

    # ─── listeners ────────────────────────────────────────────────────────────

    @commands.Cog.listener("on_message_interaction")
    async def on_select_menu(self, inter: disnake.MessageInteraction):
        if not inter.data or inter.data.custom_id != "PermsInternasSelectMenu":
            return
        perms_key = inter.values[0]
        await self._show_loading(inter)
        await inter.edit_original_message(
            components=self._build_perm_components(inter, perms_key)
        )

    @commands.Cog.listener("on_button_click")
    async def on_perms_buttons(self, inter: disnake.MessageInteraction):
        custom_id = inter.component.custom_id

        # Botão Voltar → retorna ao painel principal
        if custom_id == "PermsInternasBack":
            await self.display_panel(inter)
            return

        # Botão Voltar → retorna ao painel de Proteção
        if custom_id == "Protection":
            cog = self.bot.get_cog("ProtectionCog")
            if cog:
                await cog.display_protection_panel(inter)
            return

        # Adicionar cargo
        if custom_id.startswith("perms_add_"):
            perms_key = custom_id[len("perms_add_"):]
            label = next((l for k, l, *_ in self.PERMS_OPCOES if k == perms_key), perms_key)

            # Abre um modal com RoleSelect via componente (disnake suporta RoleSelect em modais v2)
            # Como disnake não tem RoleSelect em Modal, usamos ActionRow com RoleSelect na mensagem
            await self._show_loading(inter)

            role_ids = self._get_roles(perms_key)
            ck = {}
            self._accent(ck)

            await inter.edit_original_message(
                components=[
                    disnake.ui.Container(
                        disnake.ui.TextDisplay(
                            f"##  \n"
                            f"-# Permissões Internas > {label} > Adicionar Cargo"
                        ),
                        disnake.ui.Separator(),
                        disnake.ui.TextDisplay(
                            "Selecione o cargo que deseja **adicionar** à lista de permissão:"
                        ),
                        disnake.ui.Separator(),
                        disnake.ui.ActionRow(
                            disnake.ui.RoleSelect(
                                custom_id=f"perms_role_add_select_{perms_key}",
                                placeholder="Selecione um cargo",
                                min_values=1,
                                max_values=1
                            )
                        ),
                        **ck
                    ),
                    disnake.ui.ActionRow(
                        disnake.ui.Button(
                            label="Cancelar",
                            style=disnake.ButtonStyle.grey,
                            emoji=emoji.back,
                            custom_id=f"perms_cancel_{perms_key}"
                        )
                    )
                ]
            )
            return

        # Remover cargo
        if custom_id.startswith("perms_remove_"):
            perms_key = custom_id[len("perms_remove_"):]
            label = next((l for k, l, *_ in self.PERMS_OPCOES if k == perms_key), perms_key)
            role_ids = self._get_roles(perms_key)

            if not inter.response.is_done():
                await inter.response.defer()

            if not role_ids:
                await inter.followup.send(
                    f"{emoji.wrong} Não há cargos configurados para remover.",
                    ephemeral=True
                )
                return

            await self._show_loading(inter)

            ck = {}
            self._accent(ck)

            # Monta opções apenas com cargos já cadastrados
            options = []
            for rid in role_ids:
                role = inter.guild.get_role(rid)
                name = role.name if role else f"ID {rid}"
                options.append(disnake.SelectOption(label=name, value=str(rid)))

            await inter.edit_original_message(
                components=[
                    disnake.ui.Container(
                        disnake.ui.TextDisplay(
                            f"##  \n"
                            f"-# Permissões Internas > {label} > Remover Cargo"
                        ),
                        disnake.ui.Separator(),
                        disnake.ui.TextDisplay(
                            "Selecione o cargo que deseja **remover** da lista de permissão:"
                        ),
                        disnake.ui.Separator(),
                        disnake.ui.ActionRow(
                            disnake.ui.StringSelect(
                                custom_id=f"perms_role_remove_select_{perms_key}",
                                placeholder="Selecione um cargo para remover",
                                options=options,
                                min_values=1,
                                max_values=1
                            )
                        ),
                        **ck
                    ),
                    disnake.ui.ActionRow(
                        disnake.ui.Button(
                            label="Cancelar",
                            style=disnake.ButtonStyle.grey,
                            emoji=emoji.back,
                            custom_id=f"perms_cancel_{perms_key}"
                        )
                    )
                ]
            )
            return

        # Cancelar → volta ao sub-painel da permissão
        if custom_id.startswith("perms_cancel_"):
            perms_key = custom_id[len("perms_cancel_"):]
            await self._show_loading(inter)
            await inter.edit_original_message(
                components=self._build_perm_components(inter, perms_key)
            )
            return

    # ─── listener de selects (adicionar / remover) ────────────────────────────

    @commands.Cog.listener("on_message_interaction")
    async def on_role_selects(self, inter: disnake.MessageInteraction):
        if not inter.data:
            return

        custom_id = inter.data.custom_id

        # RoleSelect → adicionar
        if custom_id.startswith("perms_role_add_select_"):
            perms_key = custom_id[len("perms_role_add_select_"):]
            label = next((l for k, l, *_ in self.PERMS_OPCOES if k == perms_key), perms_key)

            role_id = int(inter.values[0])
            role_ids = self._get_roles(perms_key)

            if not inter.response.is_done():
                await inter.response.defer()

            if role_id in role_ids:
                await inter.followup.send(
                    f"{emoji.wrong} Esse cargo já está na lista.",
                    ephemeral=True
                )
            else:
                role_ids.append(role_id)
                self._save_roles(perms_key, role_ids)
                role = inter.guild.get_role(role_id)
                await inter.followup.send(
                    f"{emoji.correct} Cargo **{role.name if role else role_id}** adicionado à permissão **{label}**.",
                    ephemeral=True
                )

            await self._show_loading(inter)
            await inter.edit_original_message(
                components=self._build_perm_components(inter, perms_key)
            )
            return

        # StringSelect → remover
        if custom_id.startswith("perms_role_remove_select_"):
            perms_key = custom_id[len("perms_role_remove_select_"):]
            label = next((l for k, l, *_ in self.PERMS_OPCOES if k == perms_key), perms_key)

            role_id = int(inter.values[0])
            role_ids = self._get_roles(perms_key)

            if not inter.response.is_done():
                await inter.response.defer()

            if role_id in role_ids:
                role_ids.remove(role_id)
                self._save_roles(perms_key, role_ids)
                role = inter.guild.get_role(role_id)
                await inter.followup.send(
                    f"{emoji.correct} Cargo **{role.name if role else role_id}** removido da permissão **{label}**.",
                    ephemeral=True
                )
            else:
                await inter.followup.send(
                    f"{emoji.wrong} Cargo não encontrado na lista.",
                    ephemeral=True
                )

            await self._show_loading(inter)
            await inter.edit_original_message(
                components=self._build_perm_components(inter, perms_key)
            )
            return


def setup(bot: commands.Bot):
    bot.add_cog(PermsInternas(bot))