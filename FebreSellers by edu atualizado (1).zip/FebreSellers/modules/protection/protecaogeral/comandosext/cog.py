import disnake
from disnake.ext import commands
from functions.emoji import emoji
from functions.database import database as db
from functions.message import message, embed_message

from . import helpers
from . import interactions

class ComandosExtCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    def _get_advanced_select_descriptions(self, inter: disnake.Interaction, avancado: dict) -> tuple:
        punicao_atual = avancado.get("punicao", "kick")
        desc_punicao = f"Atual: {helpers.formatar_punicao(punicao_atual)}"

        bots_permitidos = avancado.get("bots_permitidos", [])
        desc_bots = f"Atual: {len(bots_permitidos)} bots permitidos"

        canal_logs_id = avancado.get("canal_logs")
        canal = inter.guild.get_channel(canal_logs_id) if canal_logs_id else None
        select_logs = f"Atual: {canal.name}" if canal else "Atual: Nenhum"
        
        return desc_punicao, desc_bots, select_logs

    @staticmethod
    def _get_punishment_options(punicao_atual: str) -> list[disnake.SelectOption]:
        return [
            disnake.SelectOption(label="Banimento", value="ban", default=punicao_atual == 'ban'),
            disnake.SelectOption(label="Expulsão", value="kick", default=punicao_atual == 'kick'),
            disnake.SelectOption(label="Castigo de 30 dias", value="timeout_30d", default=punicao_atual == 'timeout_30d'),
            disnake.SelectOption(label="Remoção dos Cargos", value="remover_cargos", default=punicao_atual == 'remover_cargos'),
            disnake.SelectOption(label="Nenhuma", value="none", default=punicao_atual == 'none'),
        ]

    async def display_panel(self, inter: disnake.MessageInteraction):
        mode = db.get_document("custom_mode").get("mode")
        msg_handler = embed_message if mode == "embed" else message
        await msg_handler.wait(inter, send=False)

        if mode == "embed":
            embed, components = self.PainelEmbed(inter)
            await inter.edit_original_message(content=None, embed=embed, components=components)
        else:
            components = self.PainelComponents(inter)
            await inter.edit_original_message(content=None, embed=None, components=components)

    async def display_punishment_panel(self, inter: disnake.MessageInteraction):
        mode = db.get_document("custom_mode").get("mode")
        msg_handler = embed_message if mode == "embed" else message
        await msg_handler.wait(inter, send=False)

        if mode == "embed":
            embed, components = self.PunishmentPanelEmbed(inter)
            await inter.edit_original_message(content=None, embed=embed, components=components)
        else:
            components = self.PunishmentPanelComponents(inter)
            await inter.edit_original_message(content=None, embed=None, components=components)

    async def display_log_channel_panel(self, inter: disnake.MessageInteraction):
        mode = db.get_document("custom_mode").get("mode")
        msg_handler = embed_message if mode == "embed" else message
        await msg_handler.wait(inter, send=False)

        if mode == "embed":
            embed, components = self.LogChannelPanelEmbed(inter)
            await inter.edit_original_message(content=None, embed=embed, components=components)
        else:
            components = self.LogChannelPanelComponents(inter)
            await inter.edit_original_message(content=None, embed=None, components=components)

    def PunishmentPanelEmbed(self, inter: disnake.MessageInteraction):
        config = helpers.carregar_config()
        avancado = config.get("comandosext_avancado", {})
        punicao_atual = avancado.get("punicao", "kick")
        
        colors = db.get_document("custom_colors")
        primary_color = int(colors.get("primary").replace("#", ""), 16) if colors.get("primary") else None

        embed = disnake.Embed(
            title=f"Configurar Punição",
            description="Escolha a punição para quem usar comandos de bots não permitidos.",
            color=primary_color
        )

        options = self._get_punishment_options(punicao_atual)
        components = [
            disnake.ui.ActionRow(disnake.ui.Select(options=options, custom_id="ProtComandosExtPunishmentSelect")),
            disnake.ui.ActionRow(disnake.ui.Button(label="Voltar", emoji=emoji.back, custom_id="ProtComandosExt_Back"))
        ]
        return embed, components

    def PunishmentPanelComponents(self, inter: disnake.MessageInteraction) -> list:
        config = helpers.carregar_config()
        avancado = config.get("comandosext_avancado", {})
        punicao_atual = avancado.get("punicao", "kick")
        options = self._get_punishment_options(punicao_atual)
        
        colors = db.get_document("custom_colors")
        primary_color_hex = colors.get("primary")
        container_kwargs = {}
        if primary_color_hex:
            container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))

        return [
            disnake.ui.Container(
                disnake.ui.TextDisplay(f"## \n-# Painel > Proteção > Comandos Externos > **Punição**"),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay("Escolha a punição para o infrator."),
                disnake.ui.ActionRow(disnake.ui.Select(options=options, custom_id="ProtComandosExtPunishmentSelect")),
                **container_kwargs
            ),
            disnake.ui.ActionRow(disnake.ui.Button(label="Voltar", emoji=emoji.back, custom_id="ProtComandosExt_Back"))
        ]

    def LogChannelPanelEmbed(self, inter: disnake.MessageInteraction):
        config = helpers.carregar_config()
        avancado = config.get("comandosext_avancado", {})
        canal_logs_id = avancado.get("canal_logs")
        
        colors = db.get_document("custom_colors")
        primary_color = int(colors.get("primary").replace("#", ""), 16) if colors.get("primary") else None

        embed = disnake.Embed(
            title=f"Configurar Canal de Logs",
            description="Selecione o canal para os logs da proteção.",
            color=primary_color
        )

        canal_str = f"<#{canal_logs_id}>" if canal_logs_id else "Nenhum"
        embed.add_field(name="Canal de Logs Atual", value=canal_str)
        components = [
            disnake.ui.ActionRow(disnake.ui.ChannelSelect(custom_id="ProtComandosExtLogChannelSelect", channel_types=[disnake.ChannelType.text])),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", emoji=emoji.back, custom_id="ProtComandosExt_Back"),
                disnake.ui.Button(label="Remover", emoji=emoji.delete, style=disnake.ButtonStyle.red, custom_id="ProtComandosExtLogChannelClear", disabled=not canal_logs_id),
                disnake.ui.Button(label="Criar para mim", style=disnake.ButtonStyle.blurple, emoji=emoji.wand, custom_id="ProtComandosExtLogChannelCreate"),
            )
        ]
        return embed, components

    def LogChannelPanelComponents(self, inter: disnake.MessageInteraction) -> list:
        config = helpers.carregar_config()
        avancado = config.get("comandosext_avancado", {})
        canal_logs_id = avancado.get("canal_logs")
        canal_str = f"<#{canal_logs_id}>" if canal_logs_id else "Nenhum"
        
        colors = db.get_document("custom_colors")
        primary_color_hex = colors.get("primary")
        container_kwargs = {}
        if primary_color_hex:
            container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))

        return [
            disnake.ui.Container(
                disnake.ui.TextDisplay(f"## \n-# Painel > Proteção > Comandos Externos > **Logs**"),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(f"Canal Atual: {canal_str}"),
                disnake.ui.ActionRow(disnake.ui.ChannelSelect(custom_id="ProtComandosExtLogChannelSelect", channel_types=[disnake.ChannelType.text])),
                **container_kwargs
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", emoji=emoji.back, custom_id="ProtComandosExt_Back"),
                disnake.ui.Button(label="Remover", emoji=emoji.delete, style=disnake.ButtonStyle.red, custom_id="ProtComandosExtLogChannelClear", disabled=not canal_logs_id),
                disnake.ui.Button(label="Criar para mim", style=disnake.ButtonStyle.blurple, emoji=emoji.wand, custom_id="ProtComandosExtLogChannelCreate"),
            )
        ]

    def PainelEmbed(self, inter: disnake.MessageInteraction):
        config = helpers.carregar_config()
        dados = config.get(helpers.CHAVE, {})
        avancado = config.get("comandosext_avancado", {})
        
        colors = db.get_document("custom_colors")
        primary_color = int(colors.get("primary").replace("#", ""), 16) if colors.get("primary") else None

        embed = disnake.Embed(
            title=f"Proteção de Comandos Externos",
            color=primary_color
        )

        status_emoji = emoji.on if dados.get('ativado', False) else emoji.off
        embed.description = (
            f"{status_emoji} **Status:** `{'Ativado' if dados.get('ativado') else 'Desativado'}`\n"
            f"{emoji.chart} **Limite atual:** `{dados.get('limite', 0)}`\n"
            f"{emoji.clock} **Intervalo atual:** `{dados.get('intervalo', 0)}s`"
        )
        
        desc_punicao, desc_bots, select_logs = self._get_advanced_select_descriptions(inter, avancado)

        components = [
            disnake.ui.ActionRow(
                disnake.ui.Select(
                    placeholder="Configurar Proteção",
                    options=[
                        disnake.SelectOption(label="Desativar" if dados.get('ativado') else "Ativar", value="toggle", emoji=emoji.power),
                        disnake.SelectOption(label="Definir Limite", value="limite", emoji=emoji.chart, description=f"Limite de ações por intervalo"),
                        disnake.SelectOption(label="Definir Intervalo", value="intervalo", emoji=emoji.clock, description=f"Intervalo de tempo para a punição"),
                    ],
                    custom_id="ProtComandosExtConfigSelect"
                ),
            ),
            disnake.ui.ActionRow(
                disnake.ui.Select(
                    placeholder="Configurações Avançadas",
                    options=[
                        disnake.SelectOption(label="Configurar Punição", value="punicao", emoji=emoji.ban, description=desc_punicao),
                        disnake.SelectOption(label="Configurar Bots Permitidos", value="bots_permitidos", description=desc_bots),
                        disnake.SelectOption(label="Configurar Canal de Logs", value="canal_logs", emoji=emoji.textc, description=select_logs),
                    ],
                    custom_id="ProtComandosExtConfigSelectAvancado"
                ),
            ),
            disnake.ui.ActionRow(disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="Protecao_Geral"))
        ]
        return embed, components

    def PainelComponents(self, inter: disnake.MessageInteraction) -> list:
        config = helpers.carregar_config()
        dados = config.get(helpers.CHAVE, {})
        avancado = config.get("comandosext_avancado", {})
        desc_punicao, desc_bots, select_logs = self._get_advanced_select_descriptions(inter, avancado)
        status_emoji = emoji.on if dados.get('ativado', False) else emoji.off
        
        colors = db.get_document("custom_colors")
        primary_color_hex = colors.get("primary")
        container_kwargs = {}
        if primary_color_hex:
            container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))

        return [
            disnake.ui.Container(
                disnake.ui.TextDisplay(f"## \n-# Painel > Proteção > **Comandos Externos**"),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(
                    f"{status_emoji} **Status:** `{'Ativado' if dados.get('ativado') else 'Desativado'}`\n"
                    f"{emoji.chart} **Limite:** `{dados.get('limite', 0)}`\n"
                    f"{emoji.clock} **Intervalo:** `{dados.get('intervalo', 0)}s`"
                ),
                disnake.ui.Separator(),
                disnake.ui.ActionRow(
                    disnake.ui.Select(
                        placeholder="Configurar Proteção",
                        options=[
                            disnake.SelectOption(label="Desativar" if dados.get('ativado') else "Ativar", value="toggle", emoji=emoji.power),
                            disnake.SelectOption(label="Definir Limite", value="limite", emoji=emoji.chart, description=f"Limite de ações por intervalo"),
                            disnake.SelectOption(label="Definir Intervalo", value="intervalo", emoji=emoji.clock, description=f"Intervalo de tempo para a punição"),
                        ],
                        custom_id="ProtComandosExtConfigSelect"
                    ),
                ),
                disnake.ui.ActionRow(
                    disnake.ui.Select(
                        placeholder="Configurações Avançadas",
                        options=[
                            disnake.SelectOption(label="Configurar Punição", value="punicao", emoji=emoji.ban, description=desc_punicao),
                            disnake.SelectOption(label="Configurar Bots Permitidos", value="bots_permitidos", description=desc_bots),
                            disnake.SelectOption(label="Configurar Canal de Logs", value="canal_logs", emoji=emoji.textc, description=select_logs),
                        ],
                        custom_id="ProtComandosExtConfigSelectAvancado"
                    ),
                ),
                **container_kwargs
            ),
            disnake.ui.ActionRow(disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="Protecao_Geral"))
        ]

    @commands.Cog.listener("on_dropdown")
    async def comandosext_dropdown_listener(self, inter: disnake.MessageInteraction):
        custom_id = inter.component.custom_id
        if "ProtComandosExt" not in custom_id:
            return
        
        if custom_id == "ProtComandosExtPunishmentSelect":
            await interactions.handle_punishment_select(self, inter)
            return
        if custom_id == "ProtComandosExtLogChannelSelect":
            await interactions.handle_log_channel_select(self, inter)
            return

        value = inter.values[0]
        action_map = {
            "toggle": interactions.handle_toggle,
            "limite": interactions.handle_set_limit,
            "intervalo": interactions.handle_set_interval,
            "punicao": interactions.handle_set_punishment,
            "bots_permitidos": interactions.handle_set_allowed_bots,
            "canal_logs": interactions.handle_set_log_channel,
        }
        handler = action_map.get(value)
        if handler:
            await handler(self, inter)

    @commands.Cog.listener("on_button_click")
    async def comandosext_button_listener(self, inter: disnake.MessageInteraction):
        custom_id = inter.component.custom_id
        if "ProtComandosExt" not in custom_id:
            return

        action_map = {
            "ProtComandosExt_Back": self.display_panel,
            "ProtComandosExtLogChannelClear": interactions.handle_log_channel_clear,
            "ProtComandosExtLogChannelCreate": interactions.handle_log_channel_create,
        }
        handler = action_map.get(custom_id)
        if handler:
            if custom_id == "ProtComandosExt_Back":
                await handler(inter)
            else:
                await handler(self, inter)

def setup(bot: commands.Bot):
    bot.add_cog(ComandosExtCog(bot))
