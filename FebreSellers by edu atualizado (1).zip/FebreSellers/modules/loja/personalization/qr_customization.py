"""
Sistema de personalização de QR Code
"""
import disnake
from disnake.ext import commands
from functions.database import database as db
from functions.emoji import emoji
from functions.utils import utils
import aiohttp
import io
import json
import qrcode
from PIL import Image, ImageDraw


class QRCustomizationModal(disnake.ui.Modal):
    def __init__(self):
        data = db.get_document("loja_qr_customization")
        
        components = [
            disnake.ui.TextInput(
                label="Cor do QR Code (Hex)",
                custom_id="color",
                value=data.get("color", "#000000"),
                placeholder="Ex: #000000 para preto",
                max_length=7,
                required=True
            ),
            disnake.ui.TextInput(
                label="Cor de Fundo (Hex)",
                custom_id="background_color",
                value=data.get("background_color", "#FFFFFF"),
                placeholder="Ex: #FFFFFF para branco",
                max_length=7,
                required=True
            ),
            disnake.ui.TextInput(
                label="URL do Logo (opcional)",
                custom_id="logo_url",
                value=data.get("logo_url", ""),
                placeholder="URL da imagem do logo (PNG/JPG)",
                required=False
            ),
            disnake.ui.TextInput(
                label="Tamanho do Logo (0.1 a 0.22)",
                custom_id="logo_size",
                value=str(data.get("logo_size", 0.2)),
                placeholder="0.2 = 20% do tamanho do QR",
                max_length=4,
                required=False
            ),
            disnake.ui.TextInput(
                label="Estilo dos Cantos",
                custom_id="corner_style",
                value=data.get("corner_style", "square"),
                placeholder="square, rounded ou dots",
                max_length=10,
                required=True
            )
        ]
        
        super().__init__(title="Personalizar QR Code", components=components)
    
    async def callback(self, inter: disnake.ModalInteraction):
        await inter.response.defer(ephemeral=True)
        
        # Validar cores hex
        color = inter.text_values["color"]
        bg_color = inter.text_values["background_color"]
        
        if not color.startswith("#") or len(color) != 7:
            await inter.followup.send(
                f"{emoji.wrong} Cor do QR inválida! Use formato hex: #000000",
                ephemeral=True
            )
            return
        
        if not bg_color.startswith("#") or len(bg_color) != 7:
            await inter.followup.send(
                f"{emoji.wrong} Cor de fundo inválida! Use formato hex: #FFFFFF",
                ephemeral=True
            )
            return
        
        # Validar tamanho do logo
        try:
            logo_size = float(inter.text_values.get("logo_size", 0.2))
            if logo_size < 0.1 or logo_size > 0.22:
                raise ValueError
        except ValueError:
            await inter.followup.send(
                f"{emoji.wrong} Tamanho do logo inválido! Use valores entre 0.1 e 0.22 "
                f"(acima disso o QR Code pode ficar ilegível para escanear).",
                ephemeral=True
            )
            return
        
        # Validar estilo dos cantos
        corner_style = inter.text_values["corner_style"].lower()
        if corner_style not in ["square", "rounded", "dots"]:
            await inter.followup.send(
                f"{emoji.wrong} Estilo de cantos inválido! Use: square, rounded ou dots",
                ephemeral=True
            )
            return
        
        # Salvar configurações
        data = db.get_document("loja_qr_customization")
        data["color"] = color
        data["background_color"] = bg_color
        data["logo_url"] = inter.text_values.get("logo_url", "")
        data["logo_size"] = logo_size
        data["corner_style"] = corner_style
        data["enabled"] = True
        
        db.save_document("loja_qr_customization", data)
        
        # Gerar preview
        await inter.followup.send(
            f"{emoji.correct} Personalização de QR Code salva com sucesso!\n"
            f"As novas configurações serão aplicadas aos próximos QR Codes gerados.",
            ephemeral=True
        )


class QRCodeGenerator:
    """Gerador de QR Code personalizado"""
    
    @staticmethod
    async def generate_custom_qr(data: str) -> bytes:
        """
        Gera um QR Code personalizado 100% local, aplicando cores e,
        se configurada, a logo no centro (igual à imagem de referência).
        """
        config = db.get_document("loja_qr_customization")
        
        if not config.get("enabled"):
            # Se não estiver habilitado, usar QR simples
            return await QRCodeGenerator.generate_simple_qr(data)
        
        # Gerar QR localmente com as cores configuradas
        try:
            qr_bytes = QRCodeGenerator._generate_local_qr(
                data,
                fill_color=config.get("color", "#000000"),
                back_color=config.get("background_color", "#FFFFFF"),
                corner_style=config.get("corner_style", "square")
            )
        except Exception as e:
            print(f"[QRCodeGenerator] Erro ao gerar QR personalizado local: {e}")
            return await QRCodeGenerator.generate_simple_qr(data)
        
        # Colar a logo no centro, se configurada
        logo_url = config.get("logo_url")
        if logo_url:
            try:
                logo_size = float(config.get("logo_size", 0.2))
            except (TypeError, ValueError):
                logo_size = 0.2
            
            qr_bytes = await QRCodeGenerator._apply_logo(qr_bytes, logo_url, logo_size)
        
        return qr_bytes
    
    @staticmethod
    async def _apply_logo(qr_bytes: bytes, logo_url: str, logo_size: float) -> bytes:
        """
        Baixa a imagem do logo_url e a cola centralizada por cima do QR Code,
        com um fundo branco circular atrás para manter o contraste e a leitura.
        Se qualquer etapa falhar, retorna o QR original sem logo (nunca quebra o pagamento).
        """
        try:
            timeout = aiohttp.ClientTimeout(total=8)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(logo_url) as resp:
                    if resp.status != 200:
                        print(f"[QRCodeGenerator] Logo retornou status {resp.status}: {logo_url}")
                        return qr_bytes
                    logo_data = await resp.read()
            
            return QRCodeGenerator._compose_logo(qr_bytes, logo_data, logo_size)
        except Exception as e:
            print(f"[QRCodeGenerator] Erro ao aplicar logo no QR Code: {e}")
            return qr_bytes
    
    @staticmethod
    def _compose_logo(qr_bytes: bytes, logo_data: bytes, logo_size: float) -> bytes:
        """Composição em si (síncrona/CPU-bound) usando Pillow.
        A logo é sempre recortada em círculo (cover-fit, preenchendo de ponta a ponta),
        não importa se a imagem original é quadrada, retangular etc — assim o resultado
        fica sempre como um "selo" circular limpo, igual ao padrão de referência."""
        qr_img = Image.open(io.BytesIO(qr_bytes)).convert("RGBA")
        logo_img = Image.open(io.BytesIO(logo_data)).convert("RGBA")
        
        qr_width, qr_height = qr_img.size
        
        # Limita entre 10% e 22% do tamanho do QR — testado com centenas de payloads Pix
        # de tamanhos variados: acima de ~22% a correção de erro (ERROR_CORRECT_H) não é
        # suficiente e o QR passa a falhar na leitura em muitos scanners.
        ratio = max(0.1, min(logo_size, 0.22))
        circle_size = int(min(qr_width, qr_height) * ratio)
        
        # Cover-fit: recorta a imagem original em um quadrado central (sem distorcer)
        lw, lh = logo_img.size
        side = min(lw, lh)
        left = (lw - side) // 2
        top = (lh - side) // 2
        logo_square = logo_img.crop((left, top, left + side, top + side))
        logo_square = logo_square.resize((circle_size, circle_size), Image.LANCZOS)
        
        # Aplica máscara circular, preenchendo o círculo de ponta a ponta
        mask = Image.new("L", (circle_size, circle_size), 0)
        ImageDraw.Draw(mask).ellipse((0, 0, circle_size, circle_size), fill=255)
        logo_circular = Image.new("RGBA", (circle_size, circle_size), (0, 0, 0, 0))
        logo_circular.paste(logo_square, (0, 0), mask)
        
        # Anel branco fino atrás da logo, para destacar do QR
        border = max(3, int(circle_size * 0.06))
        backdrop_size = circle_size + border * 2
        backdrop = Image.new("RGBA", (backdrop_size, backdrop_size), (0, 0, 0, 0))
        ImageDraw.Draw(backdrop).ellipse((0, 0, backdrop_size, backdrop_size), fill=(255, 255, 255, 255))
        
        backdrop_pos = (
            (qr_width - backdrop_size) // 2,
            (qr_height - backdrop_size) // 2
        )
        qr_img.alpha_composite(backdrop, dest=backdrop_pos)
        
        logo_pos = (
            (qr_width - circle_size) // 2,
            (qr_height - circle_size) // 2
        )
        qr_img.alpha_composite(logo_circular, dest=logo_pos)
        
        buffer = io.BytesIO()
        qr_img.convert("RGB").save(buffer, format="PNG")
        return buffer.getvalue()
    
    @staticmethod
    async def generate_simple_qr(data: str) -> bytes:
        """
        Gera um QR Code 100% local, sem depender de nenhuma API externa.
        Igual ao sistema usado pelo riquinho store.
        """
        try:
            return QRCodeGenerator._generate_local_qr(data)
        except Exception as e:
            print(f"[QRCodeGenerator] ERRO ao gerar QR Code local: {e}")
            return None

    @staticmethod
    def _generate_local_qr(
        data: str,
        fill_color: str = "#000000",
        back_color: str = "#FFFFFF",
        corner_style: str = "square"
    ) -> bytes:
        """Gera um QR Code 100% local (sem internet) usando a biblioteca qrcode.
        Mesmo sistema usado pelo riquinho store — sem dependência de APIs externas.

        corner_style controla o desenho dos módulos do QR:
        - "square"  -> módulos quadrados normais (comportamento original, inalterado)
        - "rounded" -> módulos com cantos arredondados
        - "dots"    -> módulos circulares (igual ao padrão de referência)

        Mantemos error_correction=ERROR_CORRECT_H (o mais alto, ~30% de tolerância
        a dano/oclusão) em todos os estilos — é o que garante que o QR continue
        lendo normalmente mesmo com a logo colada em cima depois."""
        qr = qrcode.QRCode(
            version=None,
            error_correction=qrcode.constants.ERROR_CORRECT_H,
            box_size=10,
            border=4,
        )
        qr.add_data(data)
        qr.make(fit=True)

        style = str(corner_style or "square").strip().lower()

        if style in ("rounded", "dots"):
            try:
                img = QRCodeGenerator._make_styled_image(qr, style, fill_color, back_color)
            except Exception as e:
                # Qualquer problema ao montar o estilo (import diferente entre
                # versões da lib, cor inválida, etc.) NUNCA pode derrubar a
                # geração do QR de pagamento — cai pro quadrado normal, que é
                # o formato já testado e usado por padrão.
                print(f"[QRCodeGenerator] Erro ao aplicar estilo '{style}', usando 'square': {e}")
                img = qr.make_image(fill_color=fill_color, back_color=back_color)
        else:
            img = qr.make_image(fill_color=fill_color, back_color=back_color)

        buffer = io.BytesIO()
        img.save(buffer, format="PNG")
        return buffer.getvalue()

    @staticmethod
    def _make_styled_image(qr, style: str, fill_color: str, back_color: str):
        """Monta a imagem estilizada (cantos arredondados ou pontilhados) usando
        qrcode.image.styledpil. Isolado em função própria só pra facilitar o
        fallback de import entre versões da lib (ver comentário abaixo)."""
        from qrcode.image.styledpil import StyledPilImage
        from qrcode.image.styles.colormasks import SolidFillColorMask

        try:
            # qrcode >= 7.x expõe os drawers em qrcode.image.styles.moduledrawers.pil
            from qrcode.image.styles.moduledrawers.pil import (
                RoundedModuleDrawer,
                CircleModuleDrawer,
            )
        except ImportError:
            # Versões mais antigas (6.x) expõem direto em .moduledrawers
            from qrcode.image.styles.moduledrawers import (
                RoundedModuleDrawer,
                CircleModuleDrawer,
            )

        module_drawer = CircleModuleDrawer() if style == "dots" else RoundedModuleDrawer()

        return qr.make_image(
            image_factory=StyledPilImage,
            module_drawer=module_drawer,
            color_mask=SolidFillColorMask(
                front_color=QRCodeGenerator._hex_to_rgb(fill_color),
                back_color=QRCodeGenerator._hex_to_rgb(back_color),
            ),
        )

    @staticmethod
    def _hex_to_rgb(hex_color: str) -> tuple:
        """Converte '#RRGGBB' em (R, G, B). Cai para preto/branco-seguro se vier
        um valor inesperado, em vez de quebrar a geração do QR."""
        try:
            h = str(hex_color).lstrip("#")
            if len(h) != 6:
                raise ValueError("hex color precisa ter 6 dígitos")
            return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
        except Exception:
            return (0, 0, 0)
    
    @staticmethod
    def panel(inter: disnake.Interaction) -> dict:
        """Painel de personalização de QR Code"""
        mode = db.get_document("custom_mode").get("mode")
        if mode == "components":
            return QRCodeGenerator._panel_components(inter)
        return QRCodeGenerator._panel_embed(inter)
    
    @staticmethod
    def _panel_components(inter: disnake.Interaction) -> dict:
        data = db.get_document("loja_qr_customization")
        
        color_data = db.get_document("custom_colors")
        primary_color_hex = color_data.get("primary")
        
        container_kwargs = {}
        if primary_color_hex:
            container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))
        
        # Status
        status = f"{emoji.on} Ativado" if data.get("enabled") else f"{emoji.off} Desativado"
        
        config_text = (
            f"**Status:** {status}\n"
            f"**Cor Principal:** {data.get('color', '#000000')}\n"
            f"**Cor de Fundo:** {data.get('background_color', '#FFFFFF')}\n"
            f"**Estilo dos Cantos:** {data.get('corner_style', 'square')}\n"
            f"**Logo:** {'Configurado' if data.get('logo_url') else 'Não configurado'}"
        )
        
        return {"components": [
            disnake.ui.Container(
                disnake.ui.TextDisplay(f"## \n-# Loja > Personalizar > **QR Code**"),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(
                    "Personalize a aparência dos QR Codes de pagamento.\n"
                    "Adicione cores, logo e estilos personalizados."
                ),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(config_text),
                disnake.ui.Separator(),
                disnake.ui.ActionRow(
                    disnake.ui.Button(
                        label="Configurar",
                        style=disnake.ButtonStyle.blurple,
                        emoji=emoji.config,
                        custom_id="Loja_QRCode_Config"
                    ),
                    disnake.ui.Button(
                        label="Ativar" if not data.get("enabled") else "Desativar",
                        style=disnake.ButtonStyle.green if not data.get("enabled") else disnake.ButtonStyle.red,
                        emoji=emoji.on if not data.get("enabled") else emoji.off,
                        custom_id="Loja_QRCode_Toggle"
                    ),
                    disnake.ui.Button(
                        label="Testar",
                        style=disnake.ButtonStyle.grey,
                        emoji=emoji.science,
                        custom_id="Loja_QRCode_Test"
                    )
                ),
                **container_kwargs
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Voltar",
                    style=disnake.ButtonStyle.grey,
                    emoji=emoji.back,
                    custom_id="Loja_Personalizar"
                )
            )
        ]}
    
    @staticmethod
    def _panel_embed(inter: disnake.Interaction):
        data = db.get_document("loja_qr_customization")
        
        embed = disnake.Embed(
            title=f"##  Personalização de QR Code",
            description="Configure a aparência dos QR Codes",
            color=utils.get_color("primary")
        )
        
        embed.add_field(
            name="Status",
            value=f"{emoji.on if data.get('enabled') else emoji.off} {'Ativado' if data.get('enabled') else 'Desativado'}",
            inline=True
        )
        
        embed.add_field(
            name="Cores",
            value=f"Principal: {data.get('color', '#000000')}\nFundo: {data.get('background_color', '#FFFFFF')}",
            inline=True
        )
        
        embed.add_field(
            name="Estilo",
            value=data.get("corner_style", "square"),
            inline=True
        )
        
        components = [
            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Configurar",
                    style=disnake.ButtonStyle.blurple,
                    emoji=emoji.config,
                    custom_id="Loja_QRCode_Config"
                ),
                disnake.ui.Button(
                    label="Ativar" if not data.get("enabled") else "Desativar",
                    style=disnake.ButtonStyle.green if not data.get("enabled") else disnake.ButtonStyle.red,
                    emoji=emoji.on if not data.get("enabled") else emoji.off,
                    custom_id="Loja_QRCode_Toggle"
                ),
                disnake.ui.Button(
                    label="Testar",
                    style=disnake.ButtonStyle.grey,
                    emoji=emoji.science,
                    custom_id="Loja_QRCode_Test"
                )
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Voltar",
                    style=disnake.ButtonStyle.grey,
                    emoji=emoji.back,
                    custom_id="Loja_Personalizar"
                )
            )
        ]
        
        return embed, components