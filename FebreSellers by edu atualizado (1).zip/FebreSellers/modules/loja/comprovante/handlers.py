"""
Sistema de Comprovantes — handlers do Discord.

Fluxo:
    1. Cliente clica em "Enviar Comprovante" (botão só aparece quando o
       pagamento exige aprovação manual — mesma condição do botão
       "Aprovar Pagamento" já existente).
    2. Bot pede a imagem e espera o cliente enviar (timeout de 5 min).
    3. Roda o pipeline de analysis.py.
    4. Aprovado automaticamente -> reaproveita _handle_payment_approved
       (mesma função usada pela aprovação manual) para entregar o produto.
    5. Suspeito / inconclusivo -> nunca entrega sozinho; avisa o cliente que
       está em análise e notifica a staff com botões de Aprovar/Recusar.

O botão "Aprovar Pagamento" já existente continua funcionando exatamente
como antes — esse módulo só soma uma camada de pré-validação antes dele.
"""

import asyncio
from datetime import datetime

import disnake
from disnake.ext import commands

from functions.database import database as db
from functions.emoji import emoji
from functions.utils import utils

from . import store
from .analysis import analyze_receipt, download_image

RECEIPT_TIMEOUT_SECONDS = 300  # 5 minutos para o cliente enviar a imagem
VALID_IMAGE_EXTENSIONS = (".png", ".jpg", ".jpeg", ".webp")


def _is_admin(member: disnake.Member) -> bool:
    cargos_data = db.get_document("cargos")
    cargo_admin_id = cargos_data.get("cargo_admin")
    is_admin = member.guild_permissions.administrator
    has_admin_role = False
    if cargo_admin_id:
        has_admin_role = any(role.id == int(cargo_admin_id) for role in member.roles)
    return is_admin or has_admin_role


def _find_cart(loja_data: dict, thread_id: str):
    """Mesma lógica de busca usada em cancel.py — thread_id pode estar salvo como str ou int."""
    carts = loja_data.get("carts", {})
    cart_id = str(thread_id)
    cart = carts.get(cart_id)
    if not cart:
        cart = carts.get(thread_id)
        if cart:
            cart_id = thread_id
    if not cart:
        for cart_key, cart_value in carts.items():
            if cart_value.get("thread_id") == int(thread_id):
                cart = cart_value
                cart_id = cart_key
                break
    return cart_id, cart


def _expected_amount(cart: dict) -> float:
    payment_data = cart.get("payment_data") or {}
    metadata = payment_data.get("metadata") or {}
    return metadata.get("amount") or cart.get("total_price") or 0


def _expected_method(cart: dict) -> str:
    payment_data = cart.get("payment_data") or {}
    provider = payment_data.get("provider") or {}
    return provider.get("name") or cart.get("payment_method") or "pix"


def _get_review_channel(guild: disnake.Guild):
    canais = db.get_document("canais") or {}
    channel_id = canais.get("canal_de_analise_comprovantes") or canais.get("canal_de_logs_de_pedidos")
    if not channel_id:
        return None
    return guild.get_channel(int(channel_id))


class ComprovanteHandlers(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ------------------------------------------------------------------
    # Botão "Enviar Comprovante"
    # ------------------------------------------------------------------

    @commands.Cog.listener("on_button_click")
    async def on_send_receipt_button(self, inter: disnake.MessageInteraction):
        custom_id = inter.component.custom_id
        if not custom_id.startswith("send_receipt:"):
            return

        thread_id = custom_id.split(":", 1)[1]
        loja_data = db.get_document("loja_data")
        cart_id, cart = _find_cart(loja_data, thread_id)

        if not cart:
            await inter.response.send_message(f"{emoji.wrong} Carrinho não encontrado!", ephemeral=True)
            return

        if cart.get("status") == "approved":
            await inter.response.send_message(f"{emoji.wrong} Este pagamento já foi aprovado!", ephemeral=True)
            return

        if not store.is_reading_enabled():
            await inter.response.send_message(
                f"{emoji.wrong} A leitura automática de comprovantes está desativada no momento. "
                f"Aguarde um administrador aprovar seu pagamento manualmente.",
                ephemeral=True
            )
            return

        # Só o próprio cliente do pedido envia o comprovante dele
        if inter.author.id != cart.get("user_id"):
            await inter.response.send_message(
                f"{emoji.wrong} Só quem fez esse pedido pode enviar o comprovante dele.",
                ephemeral=True
            )
            return

        # Se já existe uma análise em andamento pra esse carrinho, evita duplicar
        existing = store.get_by_cart(cart_id)
        if existing and existing.get("status") == store.STATUS_ANALISANDO:
            await inter.response.send_message(
                f"{emoji.clock} Já estou analisando um comprovante enviado por você. Aguarde só um instante.",
                ephemeral=True
            )
            return

        comprovante = store.create(
            cart_id=cart_id,
            thread_id=inter.channel.id,
            guild_id=inter.guild.id,
            user_id=inter.author.id,
            expected_amount=_expected_amount(cart),
            expected_method=_expected_method(cart),
        )

        await inter.response.send_message(
            f"{emoji.clock} Envie a **imagem** do comprovante de pagamento aqui nesta thread "
            f"nos próximos {RECEIPT_TIMEOUT_SECONDS // 60} minutos.",
            ephemeral=True
        )

        def check(m: disnake.Message) -> bool:
            return (
                m.channel.id == inter.channel.id
                and m.author.id == inter.author.id
                and len(m.attachments) > 0
            )

        try:
            message = await self.bot.wait_for("message", check=check, timeout=RECEIPT_TIMEOUT_SECONDS)
        except asyncio.TimeoutError:
            store.log_attempt(comprovante["id"], None, "timeout", "Cliente não enviou a imagem a tempo.")
            try:
                await inter.channel.send(
                    f"{emoji.wrong} {inter.author.mention}, o tempo para enviar o comprovante acabou. "
                    f"Clique em **Enviar Comprovante** de novo quando estiver pronto."
                )
            except Exception:
                pass
            return

        await self._process_receipt_message(message, cart_id, cart, comprovante)

    async def _process_receipt_message(self, message: disnake.Message, cart_id: str, cart: dict, comprovante: dict):
        attachment = next(
            (a for a in message.attachments if (a.content_type or "").startswith("image/")
             or a.filename.lower().endswith(VALID_IMAGE_EXTENSIONS)),
            None
        )

        if not attachment:
            store.log_attempt(comprovante["id"], None, "invalid_file", "Arquivo enviado não é uma imagem.")
            await message.channel.send(
                f"{emoji.wrong} {message.author.mention} isso não parece uma imagem válida. "
                f"Envie um print/foto do comprovante em PNG, JPG ou WEBP."
            )
            return

        processing_msg = await message.channel.send(f"{emoji.clock} Analisando o comprovante enviado...")

        image_bytes = await download_image(attachment.url)
        if not image_bytes:
            store.log_attempt(comprovante["id"], None, "download_failed", "Falha ao baixar a imagem enviada.")
            await processing_msg.edit(
                content=f"{emoji.wrong} Não consegui baixar a imagem enviada. Tente enviar de novo."
            )
            return

        comprovante["status"] = store.STATUS_ANALISANDO
        store.save(comprovante)

        try:
            result = await analyze_receipt(
                image_bytes=image_bytes,
                expected_amount=comprovante["expected_amount"],
                expected_method=comprovante["expected_method"],
                cart_id=cart_id,
            )
        except Exception as e:
            print(f"[Comprovante] Erro no pipeline de análise: {e}")
            import traceback
            traceback.print_exc()
            store.log_attempt(comprovante["id"], None, "analysis_error", str(e))
            await processing_msg.edit(
                content=f"{emoji.wrong} Ocorreu um erro ao analisar o comprovante. "
                        f"A equipe foi avisada para revisar manualmente."
            )
            store.update_analysis_result(
                comprovante["id"], store.STATUS_ANALISE_MANUAL, {}, {}, [f"Erro técnico na análise: {e}"], 0, None
            )
            await self._notify_staff_review(cart_id, cart, store.get(comprovante["id"]))
            return

        print(
            f"[Comprovante] Resultado: status={result['status']} | confiança={result['confidence']} | "
            f"valor_esperado={comprovante['expected_amount']} | extraido={result['extracted']} | "
            f"checks={result['checks']} | motivos={result['reasons']}"
        )

        store.update_analysis_result(
            comprovante["id"], result["status"], result["extracted"], result["checks"],
            result["reasons"], result["confidence"], result["image_hash"],
        )
        if result["image_hash"]:
            store.register_hash(result["image_hash"], comprovante["id"])
        store.log_attempt(comprovante["id"], result["image_hash"], result["status"])

        comprovante = store.get(comprovante["id"])

        if result["status"] == store.STATUS_APROVADO:
            await processing_msg.edit(
                content=f"{emoji.correct} Comprovante validado! Aprovando seu pagamento e liberando o produto..."
            )
            await self._auto_approve_cart(cart_id, message.guild)
        else:
            label = "sinais que precisam de revisão" if result["status"] == store.STATUS_SUSPEITO else "algumas pendências"
            await processing_msg.edit(
                content=f"{emoji.clock} Recebi o comprovante, mas a análise automática encontrou {label} e "
                        f"não pode aprovar sozinha por segurança. Um administrador vai revisar em breve."
            )
            await self._notify_staff_review(cart_id, cart, comprovante)

    # ------------------------------------------------------------------
    # Aprovação automática (reaproveita o mesmo fluxo do botão manual)
    # ------------------------------------------------------------------

    async def _auto_approve_cart(self, cart_id: str, guild: disnake.Guild):
        loja_data = db.get_document("loja_data")
        cart = loja_data.get("carts", {}).get(cart_id)
        if not cart or cart.get("status") == "approved":
            return

        cart["status"] = "approved"
        cart["approved_at"] = int(datetime.utcnow().timestamp())
        cart["approved_by"] = self.bot.user.id
        cart["approved_via"] = "comprovante_auto"
        cart["updated_at"] = int(datetime.utcnow().timestamp())
        loja_data["carts"][cart_id] = cart
        db.save_document("loja_data", loja_data)

        thread = guild.get_thread(cart.get("thread_id")) if cart.get("thread_id") else None
        if thread:
            try:
                approval_msg = await thread.send(
                    f"{emoji.correct} **Pagamento aprovado automaticamente via análise de comprovante!**"
                )
                cart["manual_approval_message_id"] = approval_msg.id
                loja_data = db.get_document("loja_data")
                loja_data["carts"][cart_id] = cart
                db.save_document("loja_data", loja_data)
            except Exception:
                pass

        from ..cart.checkout import _handle_payment_approved
        await _handle_payment_approved(cart_id, self.bot)

    # ------------------------------------------------------------------
    # Notificação da staff quando a análise automática não conclui sozinha
    # ------------------------------------------------------------------

    async def _notify_staff_review(self, cart_id: str, cart: dict, comprovante: dict):
        guild = self.bot.get_guild(comprovante["guild_id"])
        if not guild:
            return
        channel = _get_review_channel(guild)
        if not channel:
            print("[Comprovante] Nenhum canal configurado para análise de comprovantes "
                  "('canal_de_analise_comprovantes' ou 'canal_de_logs_de_pedidos').")
            return

        extracted = comprovante.get("extracted", {})
        reasons = comprovante.get("reasons", [])
        status_label = "🚨 Suspeito" if comprovante["status"] == store.STATUS_SUSPEITO else "🔎 Análise Manual"

        embed = disnake.Embed(
            title=f"{status_label} — Comprovante pendente de revisão",
            description=(
                f"Cliente: <@{comprovante['user_id']}>\n"
                f"Carrinho: `{cart_id}`\n"
                f"Thread: <#{comprovante['thread_id']}>\n\n"
                f"**Valor esperado:** R$ {float(comprovante.get('expected_amount') or 0):.2f}\n"
                f"**Valor identificado:** {extracted.get('valor', 'não identificado')}\n"
                f"**Data/Hora no comprovante:** {extracted.get('data') or '-'} {extracted.get('hora') or ''}\n"
                f"**ID da transação:** {extracted.get('transacao_id') or 'não identificado'}\n\n"
                f"**Motivo(s):**\n" + "\n".join(f"- {r}" for r in reasons[:6])
            ),
            color=utils.get_color("warning") if comprovante["status"] == store.STATUS_ANALISE_MANUAL else utils.get_color("danger"),
        )
        embed.set_footer(text=f"ID do comprovante: {comprovante['id']}")
        embed.timestamp = datetime.utcnow()

        components = [
            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Aprovar Pagamento",
                    style=disnake.ButtonStyle.success,
                    emoji=emoji.correct if hasattr(emoji, "correct") else "✅",
                    custom_id=f"comprovante_aprovar:{comprovante['id']}"
                ),
                disnake.ui.Button(
                    label="Recusar",
                    style=disnake.ButtonStyle.danger,
                    emoji=emoji.wrong if hasattr(emoji, "wrong") else "❌",
                    custom_id=f"comprovante_recusar:{comprovante['id']}"
                ),
            )
        ]

        try:
            await channel.send(embed=embed, components=components)
        except Exception as e:
            print(f"[Comprovante] Erro ao notificar canal de análise: {e}")

    # ------------------------------------------------------------------
    # Ações da staff nos comprovantes suspeitos/em análise manual
    # ------------------------------------------------------------------

    @commands.Cog.listener("on_button_click")
    async def on_comprovante_aprovar(self, inter: disnake.MessageInteraction):
        if not inter.component.custom_id.startswith("comprovante_aprovar:"):
            return
        if not _is_admin(inter.author):
            await inter.response.send_message(f"{emoji.wrong} Você não tem permissão para revisar comprovantes!", ephemeral=True)
            return

        comprovante_id = inter.component.custom_id.split(":", 1)[1]
        comprovante = store.get(comprovante_id)
        if not comprovante:
            await inter.response.send_message(f"{emoji.wrong} Comprovante não encontrado!", ephemeral=True)
            return

        await inter.response.defer(ephemeral=True)

        store.set_manual_review(comprovante_id, store.STATUS_APROVADO, inter.author.id)
        await self._auto_approve_cart(comprovante["cart_id"], inter.guild)

        try:
            original_embed = inter.message.embeds[0] if inter.message.embeds else None
            if original_embed:
                original_embed.color = utils.get_color("success") if hasattr(utils, "get_color") else original_embed.color
                original_embed.add_field(name="Revisado por", value=f"{inter.author.mention} — ✅ Aprovado", inline=False)
            await inter.message.edit(embed=original_embed, components=[])
        except Exception:
            pass

        await inter.followup.send(f"{emoji.correct} Pagamento aprovado e produto liberado.", ephemeral=True)

    @commands.Cog.listener("on_button_click")
    async def on_comprovante_recusar(self, inter: disnake.MessageInteraction):
        if not inter.component.custom_id.startswith("comprovante_recusar:"):
            return
        if not _is_admin(inter.author):
            await inter.response.send_message(f"{emoji.wrong} Você não tem permissão para revisar comprovantes!", ephemeral=True)
            return

        comprovante_id = inter.component.custom_id.split(":", 1)[1]
        await inter.response.send_modal(RejeitarComprovanteModal(comprovante_id))


class RejeitarComprovanteModal(disnake.ui.Modal):
    def __init__(self, comprovante_id: str):
        self.comprovante_id = comprovante_id
        components = [
            disnake.ui.TextInput(
                label="Motivo da recusa",
                custom_id="motivo",
                style=disnake.TextInputStyle.paragraph,
                placeholder="Ex: valor não confere, comprovante ilegível, comprovante duplicado...",
                max_length=300,
                required=True,
            )
        ]
        super().__init__(title="Recusar Comprovante", components=components, custom_id=f"comprovante_recusar_modal:{comprovante_id}")

    async def callback(self, inter: disnake.ModalInteraction):
        motivo = inter.text_values.get("motivo", "").strip()
        comprovante = store.get(self.comprovante_id)
        if not comprovante:
            await inter.response.send_message(f"{emoji.wrong} Comprovante não encontrado!", ephemeral=True)
            return

        store.set_manual_review(self.comprovante_id, store.STATUS_REPROVADO, inter.author.id, reject_reason=motivo)

        thread = inter.guild.get_thread(comprovante.get("thread_id")) if comprovante.get("thread_id") else None
        if thread:
            try:
                await thread.send(
                    f"{emoji.wrong} <@{comprovante['user_id']}>, seu comprovante foi recusado por "
                    f"{inter.author.mention}.\n**Motivo:** {motivo}\n\n"
                    f"Se você acredita que isso é um engano, entre em contato com a equipe."
                )
            except Exception:
                pass

        try:
            original_embed = inter.message.embeds[0] if inter.message.embeds else None
            if original_embed:
                original_embed.add_field(name="Revisado por", value=f"{inter.author.mention} — ❌ Recusado\nMotivo: {motivo}", inline=False)
            await inter.message.edit(embed=original_embed, components=[])
        except Exception:
            pass

        await inter.response.send_message(f"{emoji.correct} Comprovante recusado.", ephemeral=True)


def setup(bot: commands.Bot):
    bot.add_cog(ComprovanteHandlers(bot))