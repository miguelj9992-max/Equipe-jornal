"""
Sistema de Comprovantes — camada de dados.

Guarda os comprovantes enviados pelos clientes e o índice de hashes usado
para detectar reuso do mesmo comprovante em pedidos diferentes.

Segue o mesmo padrão de armazenamento do resto do projeto: documentos
simples via functions.database (db.get_document / db.save_document),
sem criar um banco separado.

Documentos usados:
    - "loja_comprovantes"        -> { comprovante_id: {...} }
    - "loja_comprovantes_hashes" -> { image_sha256: comprovante_id }
"""

from datetime import datetime
from typing import Optional, Dict, Any, List
import uuid

from functions.database import database as db

# ---------------------------------------------------------------------------
# Toggle global do sistema (ligado/desligado em /painel > Configurações >
# Leitura de Comprovante). Guardado junto das preferências da loja, como o
# resto das configs desse módulo (cart_duration_minutes, cart_inactivity...).
# ---------------------------------------------------------------------------

def is_reading_enabled() -> bool:
    """
    Se False: nenhum botão 'Enviar Comprovante' aparece, e a aprovação de
    pagamentos manuais (PIX Manual) depende 100% de um admin clicando em
    'Aprovar Pagamento' — sem nenhuma leitura automática.
    """
    prefs = db.get_document("loja_preferences") or {}
    return bool(prefs.get("comprovante_reading_enabled", False))


def set_reading_enabled(enabled: bool):
    prefs = db.get_document("loja_preferences") or {}
    if not isinstance(prefs, dict):
        prefs = {}
    prefs["comprovante_reading_enabled"] = enabled
    db.save_document("loja_preferences", prefs)

# ---------------------------------------------------------------------------
# Estados possíveis de um comprovante
# ---------------------------------------------------------------------------
STATUS_AGUARDANDO = "aguardando_comprovante"   # botão clicado, esperando o cliente enviar a imagem
STATUS_ANALISANDO = "analisando"               # imagem recebida, pipeline rodando
STATUS_APROVADO = "aprovado"                   # aprovado (automático ou manual)
STATUS_REPROVADO = "reprovado"                 # recusado (sempre por um admin)
STATUS_SUSPEITO = "suspeito"                   # sinais de fraude/duplicidade — fila prioritária de análise manual
STATUS_ANALISE_MANUAL = "analise_manual"       # inconclusivo — precisa de um admin decidir

ALL_STATUSES = (
    STATUS_AGUARDANDO, STATUS_ANALISANDO, STATUS_APROVADO,
    STATUS_REPROVADO, STATUS_SUSPEITO, STATUS_ANALISE_MANUAL,
)

# Estados que ainda dependem de uma decisão (aparecem na fila do painel)
PENDING_REVIEW_STATUSES = (STATUS_SUSPEITO, STATUS_ANALISE_MANUAL)


def _now() -> int:
    return int(datetime.utcnow().timestamp())


# ---------------------------------------------------------------------------
# CRUD básico
# ---------------------------------------------------------------------------

def get_all() -> Dict[str, Any]:
    return db.get_document("loja_comprovantes") or {}


def get(comprovante_id: str) -> Optional[Dict[str, Any]]:
    return get_all().get(comprovante_id)


def get_by_cart(cart_id: str) -> Optional[Dict[str, Any]]:
    """Retorna o comprovante mais recente associado a um carrinho, se houver."""
    comprovantes = get_all()
    candidatos = [c for c in comprovantes.values() if c.get("cart_id") == cart_id]
    if not candidatos:
        return None
    candidatos.sort(key=lambda c: c.get("created_at", 0), reverse=True)
    return candidatos[0]


def save(comprovante: Dict[str, Any]):
    comprovantes = get_all()
    comprovantes[comprovante["id"]] = comprovante
    db.save_document("loja_comprovantes", comprovantes)


def create(cart_id: str, thread_id: int, guild_id: int, user_id: int,
           expected_amount: float, expected_method: str) -> Dict[str, Any]:
    comprovante = {
        "id": str(uuid.uuid4()),
        "cart_id": cart_id,
        "thread_id": thread_id,
        "guild_id": guild_id,
        "user_id": user_id,
        "expected_amount": expected_amount,
        "expected_method": expected_method,
        "status": STATUS_AGUARDANDO,
        "image_hash": None,
        "extracted": {},
        "checks": {},
        "reasons": [],
        "confidence": 0,
        "attempts": [],
        "reviewed_by": None,
        "reviewed_at": None,
        "reject_reason": None,
        "created_at": _now(),
        "updated_at": _now(),
    }
    save(comprovante)
    return comprovante


def log_attempt(comprovante_id: str, image_hash: Optional[str], result_status: str, note: str = ""):
    """Registra cada tentativa de envio de comprovante (mesmo as que falharam)."""
    comprovante = get(comprovante_id)
    if not comprovante:
        return
    comprovante.setdefault("attempts", []).append({
        "at": _now(),
        "image_hash": image_hash,
        "result": result_status,
        "note": note,
    })
    comprovante["updated_at"] = _now()
    save(comprovante)


def update_analysis_result(comprovante_id: str, status: str, extracted: dict,
                            checks: dict, reasons: List[str], confidence: int,
                            image_hash: Optional[str]):
    comprovante = get(comprovante_id)
    if not comprovante:
        return None
    comprovante["status"] = status
    comprovante["extracted"] = extracted
    comprovante["checks"] = checks
    comprovante["reasons"] = reasons
    comprovante["confidence"] = confidence
    comprovante["image_hash"] = image_hash
    comprovante["updated_at"] = _now()
    save(comprovante)
    return comprovante


def set_manual_review(comprovante_id: str, status: str, reviewer_id: int, reject_reason: Optional[str] = None):
    comprovante = get(comprovante_id)
    if not comprovante:
        return None
    comprovante["status"] = status
    comprovante["reviewed_by"] = reviewer_id
    comprovante["reviewed_at"] = _now()
    comprovante["updated_at"] = _now()
    if reject_reason:
        comprovante["reject_reason"] = reject_reason
    save(comprovante)
    return comprovante


# ---------------------------------------------------------------------------
# Índice de hashes — detecta o mesmo comprovante sendo usado em pedidos diferentes
# ---------------------------------------------------------------------------

def find_duplicate(image_hash: str, current_cart_id: str) -> Optional[str]:
    """
    Retorna o cart_id de um OUTRO pedido que já usou esse mesmo comprovante
    (mesmo hash de imagem), se existir. Reenvio do mesmo comprovante para o
    MESMO pedido não conta como duplicidade.
    """
    if not image_hash:
        return None
    index = db.get_document("loja_comprovantes_hashes") or {}
    existing_comprovante_id = index.get(image_hash)
    if not existing_comprovante_id:
        return None
    existing = get(existing_comprovante_id)
    if not existing:
        return None
    if existing.get("cart_id") == current_cart_id:
        return None
    return existing.get("cart_id")


def register_hash(image_hash: str, comprovante_id: str):
    if not image_hash:
        return
    index = db.get_document("loja_comprovantes_hashes") or {}
    # Não sobrescrever o registro original de um hash já indexado — o
    # primeiro pedido a usar aquele comprovante continua sendo a referência
    # para a checagem de duplicidade.
    if image_hash not in index:
        index[image_hash] = comprovante_id
        db.save_document("loja_comprovantes_hashes", index)


# ---------------------------------------------------------------------------
# Estatísticas para o painel administrativo
# ---------------------------------------------------------------------------

def get_stats() -> Dict[str, int]:
    comprovantes = get_all()
    stats = {status: 0 for status in ALL_STATUSES}
    for c in comprovantes.values():
        status = c.get("status")
        if status in stats:
            stats[status] += 1
    stats["total"] = len(comprovantes)
    return stats


def get_pending_review(guild_id: Optional[int] = None) -> List[Dict[str, Any]]:
    comprovantes = list(get_all().values())
    pending = [c for c in comprovantes if c.get("status") in PENDING_REVIEW_STATUSES]
    if guild_id:
        pending = [c for c in pending if c.get("guild_id") == guild_id]
    pending.sort(key=lambda c: c.get("updated_at", 0))
    return pending


def get_history(guild_id: Optional[int] = None, limit: int = 25) -> List[Dict[str, Any]]:
    comprovantes = list(get_all().values())
    if guild_id:
        comprovantes = [c for c in comprovantes if c.get("guild_id") == guild_id]
    comprovantes = [c for c in comprovantes if c.get("reviewed_at") or c.get("status") == STATUS_APROVADO]
    comprovantes.sort(key=lambda c: c.get("updated_at", 0), reverse=True)
    return comprovantes[:limit]