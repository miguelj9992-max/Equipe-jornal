"""
Sistema de Comprovantes — pipeline de análise automática de imagem.

Baixa a imagem enviada pelo cliente, pede pra um modelo de IA com visão
extrair os dados visíveis no comprovante (valor, data, hora, ID da
transação) e cruza com o que era esperado pra decidir se aprova sozinho,
marca como suspeito (ex: comprovante repetido) ou manda pra revisão manual.

Regra de ouro: na dúvida, NUNCA aprova sozinho. Qualquer falha de leitura,
inconsistência de valor ou comprovante repetido cai em análise manual, e
quem decide é sempre um admin.
"""

import base64
import hashlib
import json
import re
from typing import Optional

import aiohttp

from functions.ai_api import GROQ_API_KEYS, _get_next_groq_key

from . import store

# Modelos multimodais (com suporte a imagem) da Groq, em ordem de preferência
GROQ_VISION_URL = "https://api.groq.com/openai/v1/chat/completions"
GROQ_VISION_MODELS = [
    "qwen/qwen3.6-27b",
    "meta-llama/llama-4-maverick-17b-128e-instruct",
]

# Confiança mínima (0-100) pra aprovar automaticamente sem intervenção humana
MIN_CONFIDENCE_AUTO_APPROVE = 75
# Tolerância no valor (em R$) — arredondamentos de centavos ainda passam
AMOUNT_TOLERANCE = 0.05


# ---------------------------------------------------------------------------
# Download da imagem
# ---------------------------------------------------------------------------

async def download_image(url: str) -> Optional[bytes]:
    """Baixa os bytes da imagem do comprovante enviado no Discord."""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=20)) as resp:
                if resp.status != 200:
                    return None
                data = await resp.read()
                return data or None
    except Exception as e:
        print(f"[Comprovante] Erro ao baixar imagem: {e}")
        return None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _hash_image(image_bytes: bytes) -> str:
    return hashlib.sha256(image_bytes).hexdigest()


def _guess_mime(image_bytes: bytes) -> str:
    if image_bytes[:8] == b"\x89PNG\r\n\x1a\n":
        return "image/png"
    if image_bytes[:3] == b"\xff\xd8\xff":
        return "image/jpeg"
    if image_bytes[:4] == b"RIFF" and image_bytes[8:12] == b"WEBP":
        return "image/webp"
    return "image/png"


def _parse_valor(raw) -> Optional[float]:
    if raw is None:
        return None
    if isinstance(raw, (int, float)):
        return float(raw)
    texto = re.sub(r"[^\d,.\-]", "", str(raw))
    if not texto:
        return None
    if "," in texto and "." in texto:
        texto = texto.replace(".", "").replace(",", ".")
    elif "," in texto:
        texto = texto.replace(",", ".")
    try:
        return float(texto)
    except ValueError:
        return None


def _extract_json(text: str) -> dict:
    text = re.sub(r"^```(json)?|```$", "", text.strip(), flags=re.MULTILINE).strip()
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if not match:
        return {}
    try:
        return json.loads(match.group(0))
    except Exception:
        return {}


async def _call_vision_model(image_b64: str, mime: str, prompt: str) -> str:
    """Chama um modelo multimodal da Groq, com fallback entre modelos e chaves."""
    for model in GROQ_VISION_MODELS:
        for _ in range(len(GROQ_API_KEYS)):
            api_key = _get_next_groq_key()
            try:
                async with aiohttp.ClientSession() as session:
                    payload = {
                        "model": model,
                        "messages": [
                            {
                                "role": "user",
                                "content": [
                                    {"type": "text", "text": prompt},
                                    {"type": "image_url", "image_url": {"url": f"data:{mime};base64,{image_b64}"}},
                                ],
                            }
                        ],
                        "temperature": 0,
                        "max_tokens": 500,
                    }
                    headers = {
                        "Authorization": f"Bearer {api_key}",
                        "Content-Type": "application/json",
                    }
                    async with session.post(
                        GROQ_VISION_URL, json=payload, headers=headers,
                        timeout=aiohttp.ClientTimeout(total=30)
                    ) as resp:
                        if resp.status == 200:
                            data = await resp.json()
                            content = data.get("choices", [{}])[0].get("message", {}).get("content", "")
                            if content:
                                return content.strip()
                            print(f"[Comprovante] Groq vision ({model}): status 200 mas sem conteúdo na resposta: {data}")
                        else:
                            error_text = await resp.text()
                            print(f"[Comprovante] Groq vision ({model}): status {resp.status} - {error_text[:500]}")
                        # 401/403/429/5xx etc -> tenta próxima chave/modelo
            except Exception as e:
                print(f"[Comprovante] Erro na chamada de visão ({model}): {type(e).__name__}: {e}")
    return ""


# ---------------------------------------------------------------------------
# Pipeline principal
# ---------------------------------------------------------------------------

async def analyze_receipt(image_bytes: bytes, expected_amount: float, expected_method: str, cart_id: str) -> dict:
    """
    Roda o pipeline completo sobre a imagem de um comprovante e devolve:
        {
            "status": store.STATUS_APROVADO | STATUS_SUSPEITO | STATUS_ANALISE_MANUAL,
            "extracted": {"valor": ..., "data": ..., "hora": ..., "transacao_id": ...},
            "checks": {"valor_confere": bool, "duplicado": bool, "extraido_com_sucesso": bool},
            "reasons": [str, ...],
            "confidence": int (0-100),
            "image_hash": str,
        }
    """
    image_hash = _hash_image(image_bytes)
    mime = _guess_mime(image_bytes)
    image_b64 = base64.b64encode(image_bytes).decode("ascii")

    reasons: list[str] = []
    checks: dict = {}

    # 1) Duplicidade — mesmo comprovante já usado em outro pedido
    duplicate_cart = store.find_duplicate(image_hash, cart_id)
    checks["duplicado"] = bool(duplicate_cart)
    if duplicate_cart:
        reasons.append(f"Esse comprovante já foi usado em outro pedido (`{duplicate_cart}`).")

    # 2) Extração dos dados via IA com visão
    prompt = (
        "Você está analisando a imagem de um comprovante de pagamento brasileiro "
        "(Pix, transferência ou boleto). Extraia SOMENTE os dados abaixo e responda "
        "em JSON puro, sem nenhum texto antes ou depois:\n"
        "{\n"
        '  "valor": <número, valor pago em reais, ex: 49.90>,\n'
        '  "data": "<data do pagamento, formato DD/MM/AAAA, ou null>",\n'
        '  "hora": "<hora do pagamento, formato HH:MM, ou null>",\n'
        '  "transacao_id": "<ID/código da transação/autenticação, ou null>",\n'
        '  "metodo": "<pix, ted, doc, boleto ou outro>",\n'
        '  "parece_comprovante_valido": <true ou false>\n'
        "}\n"
        "Se a imagem não for um comprovante de pagamento, retorne "
        '"parece_comprovante_valido": false e os outros campos null.'
    )

    raw_response = await _call_vision_model(image_b64, mime, prompt)
    parsed = _extract_json(raw_response) if raw_response else {}

    extracted = {
        "valor": parsed.get("valor"),
        "data": parsed.get("data"),
        "hora": parsed.get("hora"),
        "transacao_id": parsed.get("transacao_id"),
    }

    extraido_com_sucesso = bool(parsed) and parsed.get("parece_comprovante_valido") is not False
    checks["extraido_com_sucesso"] = extraido_com_sucesso

    if not raw_response:
        reasons.append("Não foi possível rodar a análise automática da imagem (serviço de IA indisponível).")
    elif not parsed:
        reasons.append("A análise automática não conseguiu interpretar os dados do comprovante.")
    elif parsed.get("parece_comprovante_valido") is False:
        reasons.append("A imagem enviada não parece ser um comprovante de pagamento válido.")

    # 3) Confere o valor
    valor_extraido = _parse_valor(extracted.get("valor"))
    valor_esperado = _parse_valor(expected_amount)
    valor_confere = False
    if valor_extraido is not None and valor_esperado is not None:
        valor_confere = abs(valor_extraido - valor_esperado) <= AMOUNT_TOLERANCE
        if not valor_confere:
            reasons.append(
                f"Valor identificado (R$ {valor_extraido:.2f}) não confere com o valor esperado "
                f"(R$ {valor_esperado:.2f})."
            )
    else:
        reasons.append("Não foi possível identificar o valor pago no comprovante.")
    checks["valor_confere"] = valor_confere

    # 4) Confiança e decisão final
    confidence = 0
    if extraido_com_sucesso:
        confidence += 40
    if valor_confere:
        confidence += 40
    if extracted.get("transacao_id"):
        confidence += 10
    if extracted.get("data"):
        confidence += 10
    if checks["duplicado"]:
        confidence = min(confidence, 20)

    if checks["duplicado"]:
        status = store.STATUS_SUSPEITO
    elif extraido_com_sucesso and valor_confere and confidence >= MIN_CONFIDENCE_AUTO_APPROVE:
        status = store.STATUS_APROVADO
    elif extraido_com_sucesso and not valor_confere:
        status = store.STATUS_SUSPEITO
    else:
        status = store.STATUS_ANALISE_MANUAL

    return {
        "status": status,
        "extracted": extracted,
        "checks": checks,
        "reasons": reasons or ["Nenhuma pendência identificada."],
        "confidence": confidence,
        "image_hash": image_hash,
    }