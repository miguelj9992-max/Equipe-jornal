"""
Handlers para botões do carrinho de compras
"""
import disnake
import asyncio
import io
from disnake.ext import commands
from datetime import datetime
from typing import Optional, Dict, Any
from functions.database import database as db
from functions.emoji import emoji
from functions.utils import utils
from .checkout import _build_cart_message, _add_item_to_cart, _create_payment, _extract_urls, _extract_qr_image, _extract_payment_ids, _http_get_bytes, _api_base_root, _delete_old_checkout_messages
from .coupon_validator import CouponValidator
from .buy_modal import get_available_payment_methods, ensure_emoji
from .stock_manager import StockManager


def _reserve_unique_payment_amount(loja_data: dict, current_cart_id: str, base_amount: float) -> float:
    """Reserva um valor único considerando somente carrinhos ainda abertos.

    Carrinhos com status aprovado, concluído, entregue, cancelado, expirado
    ou qualquer outro status fechado não ocupam mais o valor e nunca causam
    acréscimo de centavos em um novo checkout.
    """
    occupied = set()
    carts = (loja_data or {}).get("carts", {}) or {}
    open_statuses = {"cart", "pending"}
    for other_id, other_cart in carts.items():
        if str(other_id) == str(current_cart_id):
            continue
        if not isinstance(other_cart, dict) or other_cart.get("status") not in open_statuses:
            continue

        payment_amount = other_cart.get("payment_amount")
        if payment_amount is None:
            pdata = other_cart.get("payment_data") or {}
            metadata = pdata.get("metadata") or {}
            provider = pdata.get("provider") or {}
            raw = provider.get("raw_response") or pdata.get("raw") or {}
            payment_amount = (
                metadata.get("amount") or provider.get("amount")
                or raw.get("amount")
            )
        if payment_amount is None:
            try:
                payment_amount = (
                    float(other_cart.get("total_price", 0) or 0)
                    - float(other_cart.get("discount_amount", 0) or 0)
                    - float(other_cart.get("balance_applied", 0) or 0)
                )
            except (TypeError, ValueError):
                payment_amount = None
        try:
            occupied.add(round(float(payment_amount), 2))
        except (TypeError, ValueError):
            continue

    try:
        base = round(float(base_amount), 2)
    except (TypeError, ValueError):
        return base_amount

    increment = 0
    while round(base + increment * 0.01, 2) in occupied:
        increment += 1
    return round(base + increment * 0.01, 2)


class CartPaymentMethodModal(disnake.ui.Modal):
    """Modal para seleção do método de pagamento do carrinho."""
    
    def __init__(self, cart_id: str):
        self.cart_id = str(cart_id)
        
        available_methods = get_available_payment_methods()
        components = []
        
        if available_methods:
            options = []
            for method_key, method_info in available_methods.items():
                payment_emoji = ensure_emoji(method_info["emoji"])
                options.append(
                    disnake.SelectOption(
                        label=method_info["label"],
                        value=method_key,
                        description=method_info["description"],
                        emoji=payment_emoji,
                    )
                )
            
            components.append(
                disnake.ui.Label(
                    text="Método de Pagamento",
                    component=disnake.ui.StringSelect(
                        placeholder="Selecione o método de pagamento",
                        custom_id="payment_method",
                        options=options,
                        required=True,
                    ),
                    description="Escolha como deseja pagar o carrinho",
                )
            )
        
        super().__init__(
            title="Escolher Forma de Pagamento",
            components=components,
            custom_id=f"cart_payment_modal:{self.cart_id}",
        )
    
    async def callback(self, inter: disnake.ModalInteraction):
        """Atualiza o método de pagamento do carrinho."""
        # Evitar timeout: defer logo no início
        if not inter.response.is_done():
            await inter.response.defer(ephemeral=True)

        custom_id = inter.custom_id or ""
        parts = custom_id.split(":")
        cart_id = parts[1] if len(parts) >= 2 else None
        if not cart_id:
            await inter.followup.send(
                f"{emoji.wrong} Carrinho não encontrado.",
                ephemeral=True,
            )
            return
        
        valores = inter.resolved_values
        payment_value = valores.get("payment_method")
        
        if isinstance(payment_value, (list, tuple)):
            payment_method = payment_value[0] if payment_value else None
        else:
            payment_method = payment_value or None
        
        if not payment_method:
            await inter.followup.send(
                f"{emoji.wrong} Selecione um método de pagamento válido.",
                ephemeral=True,
            )
            return
        
        # Carregar carrinho
        loja_data = db.get_document("loja_data")
        cart = loja_data.get("carts", {}).get(cart_id)
        
        if not cart:
            await inter.followup.send(
                f"{emoji.wrong} Carrinho não encontrado!",
                ephemeral=True,
            )
            return
        
        if cart.get("user_id") != inter.user.id:
            await inter.followup.send(
                f"{emoji.wrong} Este não é o seu carrinho!",
                ephemeral=True,
            )
            return
        
        # Atualizar método de pagamento
        cart["payment_method"] = payment_method
        cart["updated_at"] = int(datetime.utcnow().timestamp())
        
        loja_data["carts"][cart_id] = cart
        db.save_document("loja_data", loja_data)
        
        # Atualizar mensagem do carrinho
        thread_id = cart.get("thread_id")
        thread = inter.guild.get_thread(thread_id) if thread_id else None
        if thread:
            mode = db.get_document("custom_mode").get("mode", "embed")
            cart_msg_id = cart.get("cart_message_id")
            if cart_msg_id:
                try:
                    cart_msg = await thread.fetch_message(cart_msg_id)
                    new_cart_msg = await _build_cart_message(cart, thread, mode)
                    await cart_msg.delete()
                    cart["cart_message_id"] = new_cart_msg.id
                    loja_data["carts"][cart_id] = cart
                    db.save_document("loja_data", loja_data)
                except Exception:
                    pass
        
        method_names = {"pix": "PIX", "pix_direto": "PIX Direto", "card": "Cartão de Crédito", "crypto": "Criptomoeda"}
        pretty_name = method_names.get(payment_method, payment_method.upper())
        
        await inter.followup.send(
            f"{emoji.correct} Método de pagamento atualizado para `{pretty_name}`!",
            ephemeral=True,
        )


class CartButtonHandlers(commands.Cog):
    """Handlers para botões do carrinho"""
    
    def __init__(self, bot: commands.Bot):
        self.bot = bot
    
    @commands.Cog.listener("on_button_click")
    async def on_cart_button_click(self, inter: disnake.MessageInteraction):
        custom_id = inter.component.custom_id
        
        # Handler para alterar método de pagamento do carrinho
        if custom_id.startswith("cart_change_payment:"):
            thread_id = int(custom_id.split(":")[1])
            cart_id = str(thread_id)
            
            # Verificar métodos disponíveis primeiro (operação rápida)
            available_methods = get_available_payment_methods()
            if not available_methods:
                try:
                    if not inter.response.is_done():
                        await inter.response.send_message(
                            f"{emoji.wrong} Nenhum método de pagamento está disponível no momento. Entre em contato com um administrador.",
                            ephemeral=True
                        )
                    else:
                        await inter.followup.send(
                            f"{emoji.wrong} Nenhum método de pagamento está disponível no momento. Entre em contato com um administrador.",
                            ephemeral=True
                        )
                except:
                    pass
                return
            
            # Criar modal (operação rápida)
            modal = CartPaymentMethodModal(cart_id)
            
            # Tentar abrir modal imediatamente
            try:
                if not inter.response.is_done():
                    await inter.response.send_modal(modal)
                else:
                    # Se já foi respondida, não podemos enviar modal
                    await inter.followup.send(
                        f"{emoji.wrong} Não foi possível abrir o modal. Tente novamente.",
                        ephemeral=True
                    )
            except disnake.errors.NotFound:
                # Interação expirou - tentar enviar mensagem de erro
                try:
                    if not inter.response.is_done():
                        await inter.response.send_message(
                            f"{emoji.wrong} A interação expirou. Por favor, tente novamente.",
                            ephemeral=True
                        )
                    else:
                        await inter.followup.send(
                            f"{emoji.wrong} A interação expirou. Por favor, tente novamente.",
                            ephemeral=True
                        )
                except:
                    pass
            except Exception as e:
                # Outro erro - tentar enviar mensagem de erro
                try:
                    if not inter.response.is_done():
                        await inter.response.send_message(
                            f"{emoji.wrong} Erro ao abrir modal: {str(e)}",
                            ephemeral=True
                        )
                    else:
                        await inter.followup.send(
                            f"{emoji.wrong} Erro ao abrir modal: {str(e)}",
                            ephemeral=True
                        )
                except:
                    pass
            return
        
        # Handler para aceitar os termos, separado do fluxo de pagamento.
        # Isso permite fazer defer imediatamente no `cart_continue` sem tentar
        # abrir um modal depois que a interação já foi confirmada.
        if custom_id.startswith("cart_accept_terms:"):
            cart_id = custom_id.split(":", 1)[1]
            try:
                from modules.loja.cart.terms_modal import TermsAcceptanceModal
                await inter.response.send_modal(TermsAcceptanceModal(cart_id))
            except disnake.errors.NotFound:
                return
            except Exception as error:
                try:
                    if not inter.response.is_done():
                        await inter.response.send_message(
                            f"{emoji.wrong} Não foi possível abrir os termos: {error}",
                            ephemeral=True,
                        )
                except Exception:
                    pass
            return

        # Handler para continuar com o carrinho (criar pagamento)
        if custom_id.startswith("cart_continue:"):
            thread_id = int(custom_id.split(":")[1])
            cart_id = str(thread_id)

            # Confirmar a interação antes de qualquer acesso ao banco, estoque
            # ou gateway. Essas operações podem ultrapassar o limite do Discord.
            try:
                if not inter.response.is_done():
                    await inter.response.defer()
            except disnake.errors.NotFound:
                return

            # Carregar carrinho (recarregar do banco para garantir dados atualizados)
            loja_data = db.get_document("loja_data")
            carts_available = list(loja_data.get("carts", {}).keys())
            
            cart = loja_data.get("carts", {}).get(cart_id)
            
            # Se não encontrou, tentar migrar se necessário
            if not cart:
                # Tentar buscar por thread_id como int também
                cart = loja_data.get("carts", {}).get(str(thread_id))
                if not cart:
                    # Tentar buscar por thread_id como int
                    for key, value in loja_data.get("carts", {}).items():
                        if value.get("thread_id") == thread_id:
                            cart = value
                            cart_id = key  # Atualizar cart_id para a chave correta
                            break
            
            if not cart:
                await inter.response.send_message(
                    f"{emoji.wrong} Carrinho não encontrado!",
                    ephemeral=True
                )
                return
            
            # Migrar carrinho se necessário
            from .checkout import _migrate_cart_to_items
            cart = _migrate_cart_to_items(cart)
            
            # Salvar carrinho migrado se necessário
            if cart_id not in loja_data.get("carts", {}):
                loja_data["carts"][cart_id] = cart
                db.save_document("loja_data", loja_data)
            
            
            # Verificar se é o dono do carrinho
            if cart.get("user_id") != inter.user.id:
                await inter.response.send_message(
                    f"{emoji.wrong} Este não é o seu carrinho!",
                    ephemeral=True
                )
                return
            
            # Verificar se já está em pagamento
            if cart.get("status") != "cart":
                await inter.response.send_message(
                    f"{emoji.wrong} Este carrinho já está em processo de pagamento!",
                    ephemeral=True
                )
                return
            
            items = cart.get("items", [])
            if not items:
                await inter.response.send_message(
                    f"{emoji.wrong} Carrinho vazio!",
                    ephemeral=True
                )
                return
            
            # Verificar termos depois que a interação já foi confirmada.
            from modules.loja.preferences.utils import get_terms
            terms_enabled, terms_text = get_terms()
            if terms_enabled and not cart.get("terms_accepted", False):
                terms_preview = (terms_text or "Leia e aceite os termos da loja para prosseguir.")[:1800]
                await inter.followup.send(
                    f"**Termos da Loja**\n\n{terms_preview}\n\n"
                    f"Clique no botão abaixo para aceitar e continuar.",
                    components=[disnake.ui.ActionRow(
                        disnake.ui.Button(
                            label="Aceitar Termos",
                            style=disnake.ButtonStyle.success,
                            custom_id=f"cart_accept_terms:{cart_id}",
                        )
                    )],
                    ephemeral=True,
                )
                return

            cart["status"] = "processing"
            loja_data.setdefault("carts", {})[cart_id] = cart
            db.save_document("loja_data", loja_data)
            
            # Verificar estoque ANTES de criar pagamento
            products = db.get_document("loja_products")
            stock_errors = []
            no_stock_items = []  # Itens completamente sem estoque (para botões de notificação)
            
            for item in items:
                product_id = item.get("product_id")
                campo_id = item.get("campo_id")
                quantity = item.get("quantity", 1)
                
                if not product_id or not campo_id:
                    continue
                
                product = products.get(product_id, {})
                if not product:
                    continue
                
                campos = product.get("campos", {})
                campo = campos.get(campo_id, {})
                if not campo:
                    continue
                
                info = product.get("info", {})
                delivery_type = info.get("delivery_type", "automatic")
                
                # Verificar se é estoque infinito
                infinite_stock = campo.get("infinite_stock", {})
                is_infinite = infinite_stock.get("enabled", False)
                
                if not is_infinite and delivery_type == "automatic":
                    # Verificar estoque disponível
                    stock_count = StockManager.get_available_stock(product_id, campo_id)
                    
                    if stock_count < quantity:
                        product_name = product.get("name", "Produto")
                        campo_name = campo.get("name", "Campo")
                        
                        if stock_count <= 0:
                            # Sem estoque - adicionar para mostrar botão de notificação
                            no_stock_items.append({
                                "product_id": product_id,
                                "campo_id": campo_id,
                                "product_name": product_name,
                                "campo_name": campo_name
                            })
                            stock_errors.append(f"**{product_name}** - `{campo_name}`: Sem estoque disponível")
                        else:
                            stock_errors.append(f"**{product_name}** - `{campo_name}`: Estoque insuficiente (disponível: {stock_count}, necessário: {quantity})")
            
            if stock_errors:
                error_msg = f"{emoji.wrong} **Estoque insuficiente para alguns produtos:**\n\n" + "\n".join(stock_errors)
                
                # Adicionar botões de notificação para produtos sem estoque
                components = []
                if no_stock_items:
                    # Limitar a 5 botões (máximo por ActionRow)
                    buttons = []
                    for no_stock_item in no_stock_items[:5]:
                        notify_emoji = ensure_emoji(emoji.warn)
                        buttons.append(
                            disnake.ui.Button(
                                emoji=notify_emoji,
                                label=f"Notificar: {no_stock_item['product_name']}",
                                style=disnake.ButtonStyle.grey,
                                custom_id=f"notify_stock:{no_stock_item['product_id']}:{no_stock_item['campo_id']}"
                            )
                        )
                    
                    if buttons:
                        components.append(disnake.ui.ActionRow(*buttons))
                
                cart["status"] = "cart"
                loja_data.setdefault("carts", {})[cart_id] = cart
                db.save_document("loja_data", loja_data)
                await inter.followup.send(
                    error_msg,
                    components=components if components else None,
                    ephemeral=True
                )
                return
            
            # Verificar se está em manutenção
            from modules.loja.preferences.utils import check_maintenance
            is_maintenance, maintenance_msg = check_maintenance(inter.user.id, inter.guild)
            if is_maintenance:
                cart["status"] = "cart"
                loja_data.setdefault("carts", {})[cart_id] = cart
                db.save_document("loja_data", loja_data)
                await inter.followup.send(
                    maintenance_msg or "🔧 Sistema em manutenção. Por favor, tente novamente mais tarde.",
                    ephemeral=True
                )
                return
            
            # Verificar horário de funcionamento
            from modules.loja.preferences.utils import check_store_hours
            is_open, hours_msg = check_store_hours()
            if not is_open:
                cart["status"] = "cart"
                loja_data.setdefault("carts", {})[cart_id] = cart
                db.save_document("loja_data", loja_data)
                await inter.followup.send(
                    hours_msg or "⏰ A loja está fora do horário de funcionamento.",
                    ephemeral=True
                )
                return
            
            # Calcular total
            total_price = sum(item.get("item_total", 0) for item in items)
            payment_method = cart.get("payment_method", "pix")
            
            # Obter cupom do carrinho (se aplicado)
            discount_amount = cart.get("discount_amount", 0) or 0
            coupon_applied = cart.get("coupon_code")
            coupon_type = cart.get("coupon_type")
            is_free_purchase = cart.get("is_free_purchase", False)
            
            balance_applied = cart.get("balance_applied", 0) or 0
            final_price = max(0, total_price - discount_amount - balance_applied)

            # Diferenciar somente carrinhos ainda abertos com o mesmo valor.
            # Carrinhos fechados não ocupam mais centavos.
            loja_data = db.get_document("loja_data") or {}
            charge_amount = _reserve_unique_payment_amount(loja_data, cart_id, final_price)
            cart["payment_amount"] = charge_amount
            loja_data.setdefault("carts", {})[cart_id] = cart
            db.save_document("loja_data", loja_data)
            
            # Validar valor mínimo para pagamento PIX
            if payment_method == "pix" and final_price < 0.01:
                cart["status"] = "cart"
                loja_data.setdefault("carts", {})[cart_id] = cart
                db.save_document("loja_data", loja_data)
                await inter.followup.send(
                    f"{emoji.wrong} O valor mínimo para pagamento via PIX é R$ 0,01.\n"
                    f"{emoji.arrow} Valor atual: R$ {final_price:.2f}\n\n"
                    f"Por favor, adicione mais itens ao carrinho ou remova o cupom.",
                    ephemeral=True
                )
                return
            
            # A interação já foi confirmada no início do fluxo.
            # Criar pagamento
            try:
                # Criar descrição
                products = db.get_document("loja_products")
                descriptions = []
                for item in items:
                    product = products.get(item.get("product_id"))
                    if product:
                        product_name = product.get("name", "Produto")
                        campos = product.get("campos", {})
                        campo = campos.get(item.get("campo_id"))
                        campo_name = campo.get("name", "") if campo else "Campo"
                        quantity = item.get("quantity", 1)
                        descriptions.append(f"{product_name} - {campo_name} x{quantity}")
                
                description = " | ".join(descriptions)
                
                # Efi Bank agora NÃO precisa de CPF e nome - API gera automaticamente
                # Criar pagamento diretamente
                
                print(f"[CART] Criando pagamento: method={payment_method}, amount={charge_amount}, description={description}")
                
                payment_data = await _create_payment(
                    payment_method=payment_method,
                    amount=charge_amount,
                    user=inter.user,
                    description=description,
                    cart_id=cart_id
                )
                
                print(f"[CART] Pagamento criado com sucesso: {payment_data.keys() if payment_data else 'None'}")
            except Exception as e:
                cart["status"] = "cart"
                loja_data.setdefault("carts", {})[cart_id] = cart
                db.save_document("loja_data", loja_data)
                print(f"[CART] Erro ao criar pagamento: {e}")
                import traceback
                traceback.print_exc()
                
                nice_names = {"pix": "PIX", "pix_direto": "PIX Direto", "card": "Cartão de Crédito", "crypto": "Criptomoeda"}
                method_pretty = nice_names.get(payment_method, payment_method.upper())
                
                erro_str = str(e).lower()
                if "valor mínimo" in erro_str or "valor minimo" in erro_str:
                    # Erro de valor abaixo do mínimo aceito pelo gateway/carteira
                    await inter.followup.send(
                        content=(
                            f"{emoji.wrong} O valor total desse pedido é menor que o mínimo permitido para pagamento via {method_pretty}.\n"
                            f"{emoji.arrow} {str(e)}\n"
                            f"{emoji.arrow} Aumente a quantidade ou escolha outro produto para continuar."
                        ),
                        ephemeral=True
                    )
                else:
                    await inter.followup.send(
                        content=(
                            f"{emoji.wrong} Não há nenhuma forma de pagamento configurada para {method_pretty}.\n"
                            f"{emoji.arrow} Por favor, contate um administrador."
                        ),
                        ephemeral=True
                    )
                return
            
            # Extrair informações do pagamento
            checkout_url, copy_code = _extract_urls(payment_data or {})
            qr_bytes, qr_url = _extract_qr_image(payment_data or {})
            
            if not qr_bytes and payment_data and payment_data.get("qr_code_bytes"):
                qr_bytes = payment_data.get("qr_code_bytes")
            
            if not copy_code and payment_data:
                copy_code = payment_data.get("pix_copia_cola") or payment_data.get("copy_paste") or payment_data.get("emv")
            
            # Fallback: alguns gateways (ex.: LofyPay/Febre Wallet) nem sempre devolvem
            # a imagem do QR (bytes, base64 ou URL) na resposta, mas sempre devolvem o
            # código copia-e-cola. Nesse caso, gerar o QR localmente a partir dele em
            # vez de deixar o cliente sem QR code para escanear.
            if not qr_bytes and not qr_url and copy_code:
                try:
                    from modules.loja.personalization.qr_customization import QRCodeGenerator
                    qr_bytes = await QRCodeGenerator.generate_custom_qr(copy_code)
                except Exception as e:
                    print(f"[CART] Erro ao gerar QR code localmente a partir do copia-e-cola: {e}")
            
            payment_ids = _extract_payment_ids(payment_data or {})
            requires_manual_approval = payment_data.get("requires_manual_approval", False) if payment_data else False
            payment_provider = payment_data.get("_provider") if payment_data else None
            
            # O valor efetivamente cobrado pode ser ajustado pelo provedor
            # em relação ao que foi calculado aqui (ex.: taxas embutidas).
            # O que importa é o valor realmente codificado
            # no PIX gerado (payment_data["amount"]), então ele sempre tem
            # prioridade sobre o valor calculado antes da criação do pagamento;
            # exibir um valor diferente do que está no PIX confundiria o
            # cliente e quebraria a reserva de valor único entre carrinhos.
            display_amount = charge_amount
            if payment_data and payment_data.get("amount"):
                try:
                    real_amount = round(float(payment_data.get("amount")), 2)
                    if real_amount > 0:
                        display_amount = real_amount
                except (TypeError, ValueError):
                    pass
            
            # Se tiver URL do QR Code, tentar baixar apenas se for path relativo da API
            # URLs externas (imgur, etc.) são usadas diretamente no embed via set_image
            if qr_url:
                full_url = str(qr_url)
                if full_url.startswith("/"):
                    # Path relativo da API — montar URL completa e baixar
                    base_root = _api_base_root()
                    full_url = base_root + full_url
                    fetched = await _http_get_bytes(full_url)
                    if fetched:
                        qr_bytes = fetched
                        qr_url = None
                # URLs absolutas externas (http/https) são mantidas em qr_url
                # para serem usadas diretamente como set_image/MediaGallery
            
            # Obter thread
            thread = inter.guild.get_thread(thread_id)
            if not thread:
                cart["status"] = "cart"
                loja_data.setdefault("carts", {})[cart_id] = cart
                db.save_document("loja_data", loja_data)
                await inter.followup.send(
                    f"{emoji.wrong} Thread não encontrada!",
                    ephemeral=True
                )
                return
            
            # Formatar preços
            if discount_amount > 0:
                original_price_str = f"R$ {total_price:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
                final_price_str = f"R$ {display_amount:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
                discount_str = f"R$ {discount_amount:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
                price_display = f"~~{original_price_str}~~ → **{final_price_str}**\nDesconto: {discount_str}"
                if coupon_applied:
                    price_display += f"\n{emoji.coupon} Cupom: `{coupon_applied}`"
            else:
                price_display = f"R$ {display_amount:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
            
            # Método de pagamento
            method_names = {
                "pix": "PIX",
                "pix_direto": "PIX Direto",
                "card": "Cartão de Crédito",
                "crypto": "Criptomoeda"
            }
            payment_method_display = method_names.get(payment_method, payment_method.upper())
            
            # Preparar componentes
            components = []
            main_row = []
            
            # Botão Copiar Código PIX
            if copy_code:
                main_row.append(
                    disnake.ui.Button(
                        label="PIX Cópia e Cola",
                        emoji=emoji.pix if hasattr(emoji, 'pix') else "💳",
                        style=disnake.ButtonStyle.grey,
                        custom_id=f"copy_pix:{thread_id}"
                    )
                )
            
            # Botão Cancelar na mesma linha
            main_row.append(
                disnake.ui.Button(
                    label="Cancelar",
                    emoji=emoji.delete,
                    style=disnake.ButtonStyle.danger,
                    custom_id=f"cancel_checkout:{thread_id}"
                )
            )
            
            # Adicionar linha principal
            if main_row:
                components.append(disnake.ui.ActionRow(*main_row))
            
            # Botão de Aprovar Pagamento (se necessário) em linha separada
            if requires_manual_approval:
                from modules.loja.comprovante import store as comprovante_store
                manual_buttons = []
                if comprovante_store.is_reading_enabled():
                    manual_buttons.append(
                        disnake.ui.Button(
                            label="Enviar Comprovante",
                            emoji=emoji.receipt if hasattr(emoji, 'receipt') else "🧾",
                            style=disnake.ButtonStyle.blurple,
                            custom_id=f"send_receipt:{thread_id}"
                        )
                    )
                manual_buttons.append(
                    disnake.ui.Button(
                        label="Aprovar Pagamento",
                        emoji=emoji.double_check if hasattr(emoji, 'double_check') else "✅",
                        style=disnake.ButtonStyle.success,
                        custom_id=f"approve_manual_pix:{thread_id}"
                    )
                )
                components.append(disnake.ui.ActionRow(*manual_buttons))
            
            # Preparar arquivos (QR Code)
            files = []
            qr_attachment_url = None
            
            if qr_bytes:
                file = disnake.File(io.BytesIO(qr_bytes), filename="qrcode.png")
                files.append(file)
                qr_attachment_url = "attachment://qrcode.png"
            elif qr_url:
                qr_attachment_url = qr_url
            
            # Obter cor do produto
            product_color = None
            if items:
                first_item = items[0]
                product = products.get(first_item.get("product_id"))
                if product and product.get("color"):
                    try:
                        product_color_hex = product.get("color")
                        if product_color_hex.startswith("#"):
                            product_color = disnake.Colour(int(product_color_hex.replace("#", ""), 16))
                        else:
                            product_color = disnake.Colour(int(product_color_hex, 16))
                    except:
                        pass
            
            # Enviar mensagem de pagamento
            mode = db.get_document("custom_mode").get("mode", "embed")
            
            if mode == "components":
                container_components = []
                container_components.append(
                    disnake.ui.TextDisplay(f"## \n-# Checkout")
                )
                container_components.append(disnake.ui.Separator())
                
                # Listar produtos
                for item in items:
                    product = products.get(item.get("product_id"))
                    if not product:
                        continue
                    product_name = product.get("name", "Produto")
                    campos = product.get("campos", {})
                    campo = campos.get(item.get("campo_id"))
                    campo_name = campo.get("name", "") if campo else "Campo"
                    quantity = item.get("quantity", 1)
                    
                    container_components.append(
                        disnake.ui.TextDisplay(
                            f"-# Produto: `{product_name}`\n"
                            f"-# Campo: `{campo_name}` • Quantidade: `{quantity}`"
                        )
                    )
                    container_components.append(disnake.ui.Separator())
                
                # Informações de pagamento
                payment_info = f"-# Valor: `{price_display}` • Método: `{payment_method_display}`"
                container_components.append(disnake.ui.TextDisplay(payment_info))
                
                # Imagem QR Code
                if qr_attachment_url:
                    container_components.append(disnake.ui.Separator())
                    container_components.append(
                        disnake.ui.MediaGallery(
                            disnake.MediaGalleryItem(media=qr_attachment_url)
                        )
                    )
                
                container_kwargs = {}
                if product_color:
                    container_kwargs["accent_colour"] = product_color
                
                payment_container = disnake.ui.Container(*container_components, **container_kwargs)
                
                # Enviar mensagem de pagamento
                payment_msg = await thread.send(
                    components=[payment_container] + components,
                    files=files if files else None,
                    flags=disnake.MessageFlags(is_components_v2=True)
                )
            else:
                # Modo Embed
                embed_color = product_color if product_color else utils.get_color("primary")
                embed = disnake.Embed(
                    title=f"{emoji.cart} Checkout",
                    color=embed_color
                )
                
                # Adicionar produtos
                for item in items:
                    product = products.get(item.get("product_id"))
                    if not product:
                        continue
                    product_name = product.get("name", "Produto")
                    campos = product.get("campos", {})
                    campo = campos.get(item.get("campo_id"))
                    campo_name = campo.get("name", "") if campo else "Campo"
                    quantity = item.get("quantity", 1)
                    
                    embed.add_field(
                        name=f"{emoji.bag} {product_name} (x{quantity})",
                        value=f"Campo: `{campo_name}`",
                        inline=False
                    )
                
                # Informações de pagamento
                embed.add_field(
                    name=f"{emoji.dollar} Pagamento",
                    value=f"Valor: `{price_display}` • Método: `{payment_method_display}`",
                    inline=False
                )
                
                # Adicionar imagem QR Code
                if qr_attachment_url:
                    embed.set_image(url=qr_attachment_url)
                
                embed.timestamp = datetime.utcnow()
                
                payment_msg = await thread.send(
                    embed=embed,
                    components=components,
                    files=files if files else None
                )
            
            # A nova mensagem já existe; apagar em paralelo todos os painéis e
            # mensagens antigas, preservando somente o checkout recém-criado.
            await _delete_old_checkout_messages(thread, preserve_ids={payment_msg.id})

            # Atualizar carrinho com dados do pagamento
            cart["status"] = "pending"
            cart["message_id"] = payment_msg.id
            # Manter total_price bruto; desconto e saldo são campos separados e
            # serão aplicados uma única vez no processamento da aprovação.
            cart["total_price"] = total_price
            cart["payment_amount"] = display_amount
            cart["discount_amount"] = discount_amount
            cart["coupon_code"] = coupon_applied
            cart["coupon_type"] = coupon_type
            cart["is_free_purchase"] = is_free_purchase
            
            # Nova estrutura organizada de payment_data
            cart["payment_data"] = {
                "local": {
                    "copy_code": copy_code,
                    "qr_url": qr_url,
                    "qr_bytes": qr_bytes if qr_bytes else None,
                    "requires_manual_approval": requires_manual_approval
                },
                "provider": {
                    "name": payment_provider,
                    "payment_id": payment_ids.get("payment_id") or payment_ids.get("paymentId"),
                    "correlation_id": payment_ids.get("correlationID") or payment_ids.get("correlation_id"),
                    "charge_id": payment_ids.get("charge_id") or payment_ids.get("id"),
                    "txid": payment_ids.get("txid"),
                    "raw_response": payment_data
                },
                "metadata": {
                    "created_at": int(datetime.utcnow().timestamp()),
                    "payment_method": payment_method,
                    "amount": display_amount,
                    "currency": "BRL"
                }
            }
            cart["updated_at"] = int(datetime.utcnow().timestamp())
            
            loja_data["carts"][cart_id] = cart
            db.save_document("loja_data", loja_data)
            
                        # Iniciar monitoramento por gateway. O polling local continua sendo
            # obrigatório; o WebSocket é apenas uma aceleração quando disponível.
            from .checkout import _monitor_payment
            if not is_free_purchase:
                asyncio.create_task(_monitor_payment(cart_id, payment_method, payment_ids, payment_provider, self.bot))
                try:
                    from functions.payments.websocket_client import get_ws_client
                    ws_client = get_ws_client()
                    if ws_client and ws_client.is_connected():
                        normalized_ids = set(payment_ids.values())
                        for payment_id in normalized_ids:
                            if payment_id:
                                asyncio.create_task(ws_client.watch_payment(str(payment_id)))
                except Exception as ws_error:
                    print(f"[CART] WebSocket indisponível; mantendo polling: {ws_error}")
            
            await inter.followup.send(
                f"{emoji.correct} Pagamento criado! Verifique a mensagem acima.",
                ephemeral=True
            )
            return
        
        # Handler para editar quantidade
        if custom_id.startswith("cart_edit_quantity:"):
            parts = custom_id.split(":")
            thread_id = int(parts[1])
            item_idx = int(parts[2])
            cart_id = str(thread_id)
            
            # Carregar carrinho
            loja_data = db.get_document("loja_data")
            cart = loja_data.get("carts", {}).get(cart_id)
            
            if not cart:
                await inter.response.send_message(
                    f"{emoji.wrong} Carrinho não encontrado!",
                    ephemeral=True
                )
                return
            
            if cart.get("user_id") != inter.user.id:
                await inter.response.send_message(
                    f"{emoji.wrong} Este não é o seu carrinho!",
                    ephemeral=True
                )
                return
            
            items = cart.get("items", [])
            if item_idx >= len(items):
                await inter.response.send_message(
                    f"{emoji.wrong} Item não encontrado!",
                    ephemeral=True
                )
                return
            
            # Abrir modal para editar quantidade
            item = items[item_idx]
            current_quantity = item.get("quantity", 1)
            
            modal = disnake.ui.Modal(
                title="Editar Quantidade",
                custom_id=f"cart_edit_quantity_modal:{thread_id}:{item_idx}",
                components=[
                    disnake.ui.TextInput(
                        label="Nova Quantidade",
                        placeholder="Digite a nova quantidade",
                        custom_id="new_quantity",
                        style=disnake.TextInputStyle.short,
                        required=True,
                        max_length=10,
                        value=str(current_quantity)
                    )
                ]
            )
            
            # Enviar modal com tratamento de erro
            try:
                if not inter.response.is_done():
                    await inter.response.send_modal(modal)
                else:
                    await inter.followup.send(
                        f"{emoji.wrong} Não foi possível abrir o modal. Tente novamente.",
                        ephemeral=True
                    )
            except disnake.errors.NotFound:
                # Interação expirou durante a criação do modal
                if not inter.response.is_done():
                    try:
                        await inter.response.send_message(
                            f"{emoji.wrong} A interação expirou. Por favor, tente novamente.",
                            ephemeral=True
                        )
                    except:
                        pass
                else:
                    try:
                        await inter.followup.send(
                            f"{emoji.wrong} A interação expirou. Por favor, tente novamente.",
                            ephemeral=True
                        )
                    except:
                        pass
            except Exception as e:
                # Outro erro inesperado
                if not inter.response.is_done():
                    try:
                        await inter.response.send_message(
                            f"{emoji.wrong} Ocorreu um erro inesperado: {e}",
                            ephemeral=True
                        )
                    except:
                        pass
                else:
                    try:
                        await inter.followup.send(
                            f"{emoji.wrong} Ocorreu um erro inesperado: {e}",
                            ephemeral=True
                        )
                    except:
                        pass
            return
        
        # Handler para remover item
        if custom_id.startswith("cart_remove_item:"):
            parts = custom_id.split(":")
            thread_id = int(parts[1])
            item_idx = int(parts[2])
            cart_id = str(thread_id)
            
            # Carregar carrinho
            loja_data = db.get_document("loja_data")
            cart = loja_data.get("carts", {}).get(cart_id)
            
            if not cart:
                await inter.response.send_message(
                    f"{emoji.wrong} Carrinho não encontrado!",
                    ephemeral=True
                )
                return
            
            if cart.get("user_id") != inter.user.id:
                await inter.response.send_message(
                    f"{emoji.wrong} Este não é o seu carrinho!",
                    ephemeral=True
                )
                return
            
            items = cart.get("items", [])
            if item_idx >= len(items):
                await inter.response.send_message(
                    f"{emoji.wrong} Item não encontrado!",
                    ephemeral=True
                )
                return
            
            # Remover item
            items.pop(item_idx)
            
            if not items:
                # Carrinho vazio - deletar
                await inter.response.send_message(
                    f"{emoji.correct} Último item removido! O carrinho será deletado em breve.",
                    ephemeral=True
                )
                # Gerar e enviar transcript se habilitado (antes de deletar)
                try:
                    from modules.loja.preferences.generate_transcript import generate_cart_transcript, send_cart_transcript_to_channel
                    prefs = db.get_document("loja_preferences") or {}
                    if prefs.get("transcript_enabled", False):
                        transcript_channel_id = prefs.get("transcript_channel_id")
                        if transcript_channel_id:
                            thread = inter.guild.get_thread(thread_id)
                            if thread:
                                transcript_file = await generate_cart_transcript(thread, self.bot, cart)
                                if transcript_file:
                                    await send_cart_transcript_to_channel(self.bot, transcript_file, int(transcript_channel_id), cart)
                except Exception as e:
                    print(f"Erro ao gerar transcript: {e}")
                
                # Deletar thread e carrinho
                try:
                    thread = inter.guild.get_thread(thread_id)
                    if thread:
                        await thread.delete()
                except:
                    pass
                del loja_data["carts"][cart_id]
                db.save_document("loja_data", loja_data)
                return
            
            # Atualizar carrinho
            cart["items"] = items
            cart["total_price"] = sum(item.get("item_total", 0) for item in items)
            cart["updated_at"] = int(datetime.utcnow().timestamp())
            
            loja_data["carts"][cart_id] = cart
            db.save_document("loja_data", loja_data)
            
            # Atualizar mensagem do carrinho
            thread = inter.guild.get_thread(thread_id)
            if thread:
                mode = db.get_document("custom_mode").get("mode", "embed")
                cart_msg_id = cart.get("cart_message_id")
                if cart_msg_id:
                    try:
                        cart_msg = await thread.fetch_message(cart_msg_id)
                        # Reconstruir mensagem
                        new_cart_msg = await _build_cart_message(cart, thread, mode)
                        await cart_msg.delete()
                        cart["cart_message_id"] = new_cart_msg.id
                        loja_data["carts"][cart_id] = cart
                        db.save_document("loja_data", loja_data)
                    except:
                        pass
            
            await inter.response.send_message(
                f"{emoji.correct} Item removido do carrinho com sucesso!",
                ephemeral=True
            )
            return
    
    @commands.Cog.listener("on_modal_submit")
    async def on_edit_quantity_modal(self, inter: disnake.ModalInteraction):
        custom_id = inter.custom_id
        
        if not custom_id or not custom_id.startswith("cart_edit_quantity_modal:"):
            return
        
        # Fazer defer imediatamente para evitar timeout
        if not inter.response.is_done():
            await inter.response.defer(ephemeral=True)
        
        parts = custom_id.split(":")
        thread_id = int(parts[1])
        item_idx = int(parts[2])
        cart_id = str(thread_id)
        
        # Obter nova quantidade
        valores = inter.resolved_values
        new_quantity_str = valores.get("new_quantity", "1")
        
        try:
            new_quantity = int(new_quantity_str)
            if new_quantity < 1:
                new_quantity = 1
        except:
            await inter.followup.send(
                f"{emoji.wrong} Quantidade inválida!",
                ephemeral=True
            )
            return
        
        # Carregar carrinho
        loja_data = db.get_document("loja_data")
        cart = loja_data.get("carts", {}).get(cart_id)
        
        if not cart:
            await inter.followup.send(
                f"{emoji.wrong} Carrinho não encontrado!",
                ephemeral=True
            )
            return
        
        if cart.get("user_id") != inter.user.id:
            await inter.followup.send(
                f"{emoji.wrong} Este não é o seu carrinho!",
                ephemeral=True
            )
            return
        
        items = cart.get("items", [])
        if item_idx >= len(items):
            await inter.followup.send(
                f"{emoji.wrong} Item não encontrado!",
                ephemeral=True
            )
            return
        
        # Atualizar quantidade - validar estoque primeiro
        item = items[item_idx]
        product_id = item.get("product_id")
        campo_id = item.get("campo_id")
        
        # Validar estoque disponível
        from .stock_manager import StockManager
        products = db.get_document("loja_products")
        product = products.get(product_id, {})
        campo = product.get("campos", {}).get(campo_id, {})
        
        # Verificar se é estoque infinito
        infinite_stock = campo.get("infinite_stock", {})
        is_infinite = infinite_stock.get("enabled", False)
        
        if not is_infinite:
            # Verificar estoque disponível
            stock_count = StockManager.get_available_stock(product_id, campo_id)
            
            # Calcular quantidade total já no carrinho (excluindo o item atual)
            total_quantity_in_cart = sum(
                it.get("quantity", 0) for idx, it in enumerate(items) 
                if idx != item_idx and it.get("product_id") == product_id and it.get("campo_id") == campo_id
            )
            
            # Estoque disponível considerando outros itens no carrinho
            available_stock = stock_count - total_quantity_in_cart
            
            if new_quantity > available_stock:
                await inter.followup.send(
                    f"{emoji.wrong} Quantidade inválida! Estoque disponível: `{available_stock}`",
                    ephemeral=True
                )
                return
        
        # Atualizar quantidade
        item["quantity"] = new_quantity
        item["item_total"] = item.get("price_per_unit", 0) * new_quantity
        
        cart["items"] = items
        cart["total_price"] = sum(item.get("item_total", 0) for item in items)
        cart["updated_at"] = int(datetime.utcnow().timestamp())
        
        loja_data["carts"][cart_id] = cart
        db.save_document("loja_data", loja_data)
        
        # Atualizar mensagem do carrinho
        thread = inter.guild.get_thread(thread_id)
        if thread:
            mode = db.get_document("custom_mode").get("mode", "embed")
            cart_msg_id = cart.get("cart_message_id")
            if cart_msg_id:
                try:
                    cart_msg = await thread.fetch_message(cart_msg_id)
                    # Reconstruir mensagem
                    new_cart_msg = await _build_cart_message(cart, thread, mode)
                    await cart_msg.delete()
                    cart["cart_message_id"] = new_cart_msg.id
                    loja_data["carts"][cart_id] = cart
                    db.save_document("loja_data", loja_data)
                except:
                    pass
        
        await inter.followup.send(
            f"{emoji.correct} Quantidade atualizada com sucesso!",
            ephemeral=True
        )
    
    @commands.Cog.listener("on_button_click")
    async def on_coupon_button_click(self, inter: disnake.MessageInteraction):
        custom_id = inter.component.custom_id
        
        # Handler para aplicar cupom
        if custom_id.startswith("cart_apply_coupon:"):
            thread_id = int(custom_id.split(":")[1])
            cart_id = str(thread_id)
            
            # Criar modal primeiro (operação rápida)
            modal = disnake.ui.Modal(
                title="Aplicar Cupom",
                custom_id=f"cart_coupon_modal:{thread_id}",
                components=[
                    disnake.ui.TextInput(
                        label="Código do Cupom",
                        placeholder="Digite o código do cupom",
                        custom_id="coupon_code",
                        style=disnake.TextInputStyle.short,
                        required=True,
                        max_length=30
                    )
                ]
            )
            
            # Tentar abrir modal imediatamente
            try:
                if not inter.response.is_done():
                    await inter.response.send_modal(modal)
                else:
                    # Se já foi respondida, não podemos enviar modal
                    await inter.followup.send(
                        f"{emoji.wrong} Não foi possível abrir o modal. Tente novamente.",
                        ephemeral=True
                    )
            except disnake.errors.NotFound:
                # Interação expirou - tentar enviar mensagem de erro
                try:
                    if not inter.response.is_done():
                        await inter.response.send_message(
                            f"{emoji.wrong} A interação expirou. Por favor, tente novamente.",
                            ephemeral=True
                        )
                    else:
                        await inter.followup.send(
                            f"{emoji.wrong} A interação expirou. Por favor, tente novamente.",
                            ephemeral=True
                        )
                except:
                    pass
            except Exception as e:
                # Outro erro - tentar enviar mensagem de erro
                try:
                    if not inter.response.is_done():
                        await inter.response.send_message(
                            f"{emoji.wrong} Erro ao abrir modal: {str(e)}",
                            ephemeral=True
                        )
                    else:
                        await inter.followup.send(
                            f"{emoji.wrong} Erro ao abrir modal: {str(e)}",
                            ephemeral=True
                        )
                except:
                    pass
            return
        
        # Handler para remover cupom
        if custom_id.startswith("cart_remove_coupon:"):
            thread_id = int(custom_id.split(":")[1])
            cart_id = str(thread_id)
            
            # Carregar carrinho
            loja_data = db.get_document("loja_data")
            cart = loja_data.get("carts", {}).get(cart_id)
            
            if not cart:
                await inter.response.send_message(
                    f"{emoji.wrong} Carrinho não encontrado!",
                    ephemeral=True
                )
                return
            
            if cart.get("user_id") != inter.user.id:
                await inter.response.send_message(
                    f"{emoji.wrong} Este não é o seu carrinho!",
                    ephemeral=True
                )
                return
            
            # Remover cupom
            cart["coupon_code"] = None
            cart["coupon_type"] = None
            cart["discount_amount"] = 0
            cart["is_free_purchase"] = False
            cart["updated_at"] = int(datetime.utcnow().timestamp())
            
            loja_data["carts"][cart_id] = cart
            db.save_document("loja_data", loja_data)
            
            # Atualizar mensagem do carrinho
            thread = inter.guild.get_thread(thread_id)
            if thread:
                mode = db.get_document("custom_mode").get("mode", "embed")
                cart_msg_id = cart.get("cart_message_id")
                if cart_msg_id:
                    try:
                        cart_msg = await thread.fetch_message(cart_msg_id)
                        # Reconstruir mensagem
                        new_cart_msg = await _build_cart_message(cart, thread, mode)
                        await cart_msg.delete()
                        cart["cart_message_id"] = new_cart_msg.id
                        loja_data["carts"][cart_id] = cart
                        db.save_document("loja_data", loja_data)
                    except:
                        pass
            
            await inter.response.send_message(
                f"{emoji.correct} Cupom removido com sucesso!",
                ephemeral=True
            )
            return
    
    @commands.Cog.listener("on_modal_submit")
    async def on_coupon_modal(self, inter: disnake.ModalInteraction):
        custom_id = inter.custom_id
        
        if not custom_id or not custom_id.startswith("cart_coupon_modal:"):
            return
        
        # Fazer defer imediatamente para evitar timeout
        if not inter.response.is_done():
            await inter.response.defer(ephemeral=True)

        # Verificar se a verificação própria do bot é obrigatória para resgatar cupons
        from modules.verification import service as verification_service
        if not await verification_service.require_verification(inter, "coupons"):
            return

        thread_id = int(custom_id.split(":")[1])
        cart_id = str(thread_id)
        
        # Obter código do cupom
        valores = inter.resolved_values
        coupon_code = valores.get("coupon_code", "").strip().upper()
        
        if not coupon_code:
            await inter.followup.send(
                f"{emoji.wrong} Código do cupom não pode estar vazio!",
                ephemeral=True
            )
            return
        
        # Carregar carrinho
        loja_data = db.get_document("loja_data")
        cart = loja_data.get("carts", {}).get(cart_id)
        
        if not cart:
            await inter.followup.send(
                f"{emoji.wrong} Carrinho não encontrado!",
                ephemeral=True
            )
            return
        
        if cart.get("user_id") != inter.user.id:
            await inter.followup.send(
                f"{emoji.wrong} Este não é o seu carrinho!",
                ephemeral=True
            )
            return
        
        items = cart.get("items", [])
        if not items:
            await inter.followup.send(
                f"{emoji.wrong} Carrinho vazio!",
                ephemeral=True
            )
            return
        
        # Calcular total do carrinho
        total_price = sum(item.get("item_total", 0) for item in items)
        
        # Validar cupom (tentar com o primeiro produto do carrinho)
        products = db.get_document("loja_products")
        first_item = items[0]
        first_product_id = first_item.get("product_id")
        
        is_valid, error_msg, discount, ctype, coupon_data = CouponValidator.validate_coupon(
            coupon_code,
            first_product_id,
            inter.user.id,
            total_price,
            inter.guild
        )
        
        if not is_valid:
            await inter.followup.send(
                f"{emoji.wrong} Cupom inválido: {error_msg}",
                ephemeral=True
            )
            return
        
        # Aplicar cupom
        cart["coupon_code"] = coupon_code
        cart["coupon_type"] = ctype
        cart["discount_amount"] = discount
        cart["is_free_purchase"] = CouponValidator.is_free_coupon(discount, total_price)
        cart["updated_at"] = int(datetime.utcnow().timestamp())
        
        loja_data["carts"][cart_id] = cart
        db.save_document("loja_data", loja_data)
        
        # Atualizar mensagem do carrinho
        thread = inter.guild.get_thread(thread_id)
        if thread:
            mode = db.get_document("custom_mode").get("mode", "embed")
            cart_msg_id = cart.get("cart_message_id")
            if cart_msg_id:
                try:
                    cart_msg = await thread.fetch_message(cart_msg_id)
                    # Reconstruir mensagem
                    new_cart_msg = await _build_cart_message(cart, thread, mode)
                    await cart_msg.delete()
                    cart["cart_message_id"] = new_cart_msg.id
                    loja_data["carts"][cart_id] = cart
                    db.save_document("loja_data", loja_data)
                except:
                    pass
        
        discount_str = f"R$ {discount:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
        await inter.followup.send(
            f"{emoji.correct} Cupom `{coupon_code}` aplicado com sucesso! Desconto: `{discount_str}`",
            ephemeral=True
        )
    
    @commands.Cog.listener("on_button_click")
    async def on_balance_button_click(self, inter: disnake.MessageInteraction):
        custom_id = inter.component.custom_id
        
        # Handler para usar saldo no carrinho
        if custom_id.startswith("cart_use_balance:"):
            thread_id = int(custom_id.split(":")[1])
            cart_id = str(thread_id)
            
            # Verificar se sistema de saldo está habilitado
            saldo_config = db.get_document("loja_saldo_config") or {}
            if not saldo_config.get("enabled", False):
                await inter.response.send_message(
                    f"{emoji.wrong} O sistema de saldo está desabilitado.",
                    ephemeral=True
                )
                return
            
            # Obter saldo do usuário
            from modules.loja.saldo.balance_manager import BalanceManager
            user_balance = BalanceManager.get_user_balance(inter.user.id)
            
            if user_balance <= 0:
                await inter.response.send_message(
                    f"{emoji.wrong} Você não possui saldo disponível.",
                    ephemeral=True
                )
                return
            
            # Carregar carrinho
            loja_data = db.get_document("loja_data")
            cart = loja_data.get("carts", {}).get(cart_id)
            
            if not cart:
                await inter.response.send_message(
                    f"{emoji.wrong} Carrinho não encontrado!",
                    ephemeral=True
                )
                return
            
            if cart.get("user_id") != inter.user.id:
                await inter.response.send_message(
                    f"{emoji.wrong} Este não é o seu carrinho!",
                    ephemeral=True
                )
                return
            
            # Calcular total do carrinho
            items = cart.get("items", [])
            total_price = sum(item.get("item_total", 0) for item in items)
            discount_amount = cart.get("discount_amount", 0) or 0
            balance_applied = cart.get("balance_applied", 0) or 0
            final_price = max(0, total_price - discount_amount - balance_applied)
            
            # Criar select menu com opções
            await inter.response.send_message(
                f"{emoji.wallet} **Seu saldo:** R$ {user_balance:.2f}\n"
                f"{emoji.cart} **Valor do carrinho:** R$ {final_price:.2f}\n\n"
                f"Selecione como deseja usar o saldo:",
                components=[
                    disnake.ui.ActionRow(
                        disnake.ui.StringSelect(
                            placeholder="Escolha uma opção",
                            custom_id=f"balance_action:{cart_id}",
                            options=[
                                disnake.SelectOption(
                                    label="Pagar totalmente com saldo",
                                    value="pay_full",
                                    description=f"Usar R$ {min(user_balance, final_price):.2f} do saldo",
                                    emoji=emoji.dollar if hasattr(emoji, "dollar") else "💵"
                                ),
                                disnake.SelectOption(
                                    label="Usar saldo parcialmente",
                                    value="pay_partial",
                                    description="Escolher quanto usar do saldo",
                                    emoji=emoji.wallet if hasattr(emoji, "wallet") else "💰"
                                )
                            ]
                        )
                    )
                ],
                ephemeral=True
            )
    
    @commands.Cog.listener("on_dropdown")
    async def on_balance_dropdown(self, inter: disnake.MessageInteraction):
        custom_id = inter.component.custom_id
        
        # Handler para ações de saldo
        if custom_id.startswith("balance_action:"):
            cart_id = custom_id.split(":")[1]
            
            if not inter.values:
                await inter.response.send_message(
                    f"{emoji.wrong} Nenhuma opção selecionada.",
                    ephemeral=True
                )
                return
            
            action = inter.values[0]
            
            # Carregar carrinho
            loja_data = db.get_document("loja_data")
            cart = loja_data.get("carts", {}).get(cart_id)
            
            if not cart:
                await inter.response.send_message(
                    f"{emoji.wrong} Carrinho não encontrado!",
                    ephemeral=True
                )
                return
            
            if cart.get("user_id") != inter.user.id:
                await inter.response.send_message(
                    f"{emoji.wrong} Este não é o seu carrinho!",
                    ephemeral=True
                )
                return
            
            # Obter saldo do usuário
            from modules.loja.saldo.balance_manager import BalanceManager
            user_balance = BalanceManager.get_user_balance(inter.user.id)
            
            # Calcular total do carrinho
            items = cart.get("items", [])
            total_price = sum(item.get("item_total", 0) for item in items)
            discount_amount = cart.get("discount_amount", 0) or 0
            balance_applied = cart.get("balance_applied", 0) or 0
            final_price = max(0, total_price - discount_amount - balance_applied)
            
            # Pagar totalmente com saldo
            if action == "pay_full":
                if user_balance < final_price:
                    await inter.response.send_message(
                        f"{emoji.wrong} Saldo insuficiente! Necessário: R$ {final_price:.2f}, Disponível: R$ {user_balance:.2f}",
                        ephemeral=True
                    )
                    return
                
                # Usar saldo
                success, message = BalanceManager.use_balance(
                    inter.user.id,
                    final_price,
                    reference_id=cart_id,
                    description="Pagamento de carrinho com saldo"
                )
                
                if not success:
                    await inter.response.send_message(
                        f"{emoji.wrong} Erro ao usar saldo: {message}",
                        ephemeral=True
                    )
                    return
                
                # Marcar carrinho como pago com saldo
                cart["status"] = "paid_with_balance"
                cart["balance_applied"] = final_price
                cart["payment_method"] = "balance"
                cart["total_price"] = 0
                loja_data["carts"][cart_id] = cart
                db.save_document("loja_data", loja_data)
                
                # Defer para processar a entrega
                await inter.response.defer(ephemeral=True)
                
                # Deletar mensagem do carrinho
                thread_id = cart.get("thread_id")
                thread = inter.guild.get_thread(thread_id) if thread_id else None
                if thread:
                    cart_msg_id = cart.get("cart_message_id")
                    if cart_msg_id:
                        try:
                            cart_msg = await thread.fetch_message(cart_msg_id)
                            await cart_msg.delete()
                        except Exception:
                            pass
                
                # Processar entrega de produtos
                from .delivery import process_automatic_delivery
                
                # Entregar cada item do carrinho
                items = cart.get("items", [])
                products = db.get_document("loja_products")
                
                for item in items:
                    product_id = item.get("product_id")
                    campo_id = item.get("campo_id")
                    quantity = item.get("quantity", 1)
                    
                    product = products.get(product_id, {})
                    product_name = product.get("name", "Produto")
                    campos = product.get("campos", {})
                    campo = campos.get(campo_id, {})
                    campo_name = campo.get("name", "Campo")
                    
                    # Entregar produto
                    await process_automatic_delivery(
                        inter.user,
                        product_id,
                        campo_id,
                        product_name,
                        campo_name,
                        quantity,
                        thread=thread,
                        guild=inter.guild
                    )
                
                # Aplicar cashback ao saldo do usuário
                try:
                    from modules.loja.cashback.manager import CashbackManager
                    if CashbackManager.is_enabled():
                        # Calcular cashback baseado no valor pago com saldo
                        user_roles = []
                        if isinstance(inter.user, disnake.Member):
                            user_roles = [role.id for role in inter.user.roles]
                        
                        cashback_amount = CashbackManager.calculate_cashback(final_price, user_roles)
                        if cashback_amount > 0:
                            success, message = CashbackManager.apply_cashback(
                                inter.user.id,
                                cashback_amount,
                                purchase_ref=cart_id
                            )
                            if success:
                                print(f"[BALANCE_CHECKOUT] Cashback de R$ {cashback_amount:.2f} creditado ao usuário {inter.user.id}")
                except Exception as e:
                    print(f"[BALANCE_CHECKOUT] Erro ao processar cashback: {e}")
                
                # Deletar thread após entrega
                if thread:
                    try:
                        await thread.delete()
                        print(f"[BALANCE_CHECKOUT] Thread {thread_id} deletada após pagamento com saldo")
                    except Exception as e:
                        print(f"[BALANCE_CHECKOUT] Erro ao deletar thread: {e}")
                
                await inter.followup.send(
                    f"{emoji.correct} Pagamento realizado com saldo! Produtos entregues.",
                    ephemeral=True
                )
            
            # Usar saldo parcialmente
            elif action == "pay_partial":
                # Abrir modal para pedir valor
                modal = disnake.ui.Modal(
                    title="Usar Saldo Parcialmente",
                    custom_id=f"partial_balance_modal:{cart_id}",
                    components=[
                        disnake.ui.TextInput(
                            label=f"Quanto usar do saldo? (máx: R$ {min(user_balance, final_price):.2f})",
                            placeholder="Ex: 50.00",
                            custom_id="amount",
                            required=True,
                            max_length=10
                        )
                    ]
                )
                await inter.response.send_modal(modal)
    
    @commands.Cog.listener("on_modal_submit")
    async def on_partial_balance_modal(self, inter: disnake.ModalInteraction):
        custom_id = inter.custom_id
        
        # Modal de saldo parcial
        if custom_id.startswith("partial_balance_modal:"):
            cart_id = custom_id.split(":")[1]
            
            try:
                amount = float(inter.text_values["amount"].replace(",", "."))
                
                if amount <= 0:
                    await inter.response.send_message(
                        f"{emoji.wrong} O valor deve ser maior que zero.",
                        ephemeral=True
                    )
                    return
                
                # Carregar carrinho
                loja_data = db.get_document("loja_data")
                cart = loja_data.get("carts", {}).get(cart_id)
                
                if not cart:
                    await inter.response.send_message(
                        f"{emoji.wrong} Carrinho não encontrado!",
                        ephemeral=True
                    )
                    return
                
                # Obter saldo
                from modules.loja.saldo.balance_manager import BalanceManager
                user_balance = BalanceManager.get_user_balance(inter.user.id)
                
                # Calcular total
                items = cart.get("items", [])
                total_price = sum(item.get("item_total", 0) for item in items)
                discount_amount = cart.get("discount_amount", 0) or 0
                balance_applied = cart.get("balance_applied", 0) or 0
                final_price = max(0, total_price - discount_amount - balance_applied)
                
                # Validar valores
                if amount > user_balance:
                    await inter.response.send_message(
                        f"{emoji.wrong} Saldo insuficiente! Disponível: R$ {user_balance:.2f}",
                        ephemeral=True
                    )
                    return
                
                if amount > final_price:
                    await inter.response.send_message(
                        f"{emoji.wrong} Valor maior que o total do carrinho (R$ {final_price:.2f})!",
                        ephemeral=True
                    )
                    return
                
                # Registrar o saldo separadamente do cupom/desconto. O checkout
                # subtrai balance_applied do valor cobrado e o handler de aprovação
                # faz a dedução após a confirmação.
                cart["balance_applied"] = amount
                cart["balance_user_id"] = inter.user.id
                cart.pop("balance_to_use", None)
                loja_data["carts"][cart_id] = cart
                db.save_document("loja_data", loja_data)
                
                await inter.response.send_message(
                    f"{emoji.correct} R$ {amount:.2f} do saldo será usado no pagamento!",
                    ephemeral=True
                )
                
                # Atualizar mensagem do carrinho
                thread_id = cart.get("thread_id")
                thread = inter.guild.get_thread(thread_id) if thread_id else None
                if thread:
                    mode = db.get_document("custom_mode").get("mode", "embed")
                    from .checkout import _build_cart_message
                    cart_msg_id = cart.get("cart_message_id")
                    if cart_msg_id:
                        try:
                            cart_msg = await thread.fetch_message(cart_msg_id)
                            new_cart_msg = await _build_cart_message(cart, thread, mode)
                            await cart_msg.delete()
                            cart["cart_message_id"] = new_cart_msg.id
                            loja_data["carts"][cart_id] = cart
                            db.save_document("loja_data", loja_data)
                        except Exception:
                            pass
            except ValueError:
                await inter.response.send_message(
                    f"{emoji.wrong} Valor inválido. Use apenas números.",
                    ephemeral=True
                )
            except Exception as e:
                await inter.response.send_message(
                    f"{emoji.wrong} Erro: {str(e)}",
                    ephemeral=True
                )


def setup(bot: commands.Bot):
    bot.add_cog(CartButtonHandlers(bot))
