import disnake
from disnake.ext import commands
from functions.database import database as db
from functions.emoji import emoji
from functions.text_utils import wrap_text
from functions.utils import utils
from functions.loja_products import get_effective_interaction_type
from modules.loja.cart.stock_manager import StockManager
from modules.loja.products.product.configurar import ConfigurarProduto
from PIL import Image
from io import BytesIO
from typing import Optional
import requests
import requests.exceptions
import re


class SendProduct(commands.Cog):
    """Sistema simplificado de envio de produtos - Legacy e Container"""
    
    def __init__(self, bot: commands.Bot):
        self.bot = bot
    
    def _is_valid_image_url(self, url: str) -> bool:
        """Valida se a URL é uma URL de imagem válida e acessível"""
        if not url or not isinstance(url, str):
            return False
        
        # Verificar se é uma URL válida
        url_pattern = re.compile(
            r'^https?://'  # http:// ou https://
            r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,6}\.?|'  # domínio
            r'localhost|'  # localhost
            r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # IP
            r'(?::\d+)?'  # porta opcional
            r'(?:/?|[/?]\S+)$', re.IGNORECASE)
        
        if not url_pattern.match(url):
            return False
        
        # Verificar extensões de imagem comuns
        image_extensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp']
        url_lower = url.lower()
        if not any(url_lower.endswith(ext) or ext in url_lower.split('?')[0] for ext in image_extensions):
            # Pode ser uma URL sem extensão explícita, tentar validar via HEAD request
            try:
                resp = requests.head(url, timeout=5, allow_redirects=True)
                content_type = resp.headers.get('content-type', '').lower()
                if 'image' not in content_type:
                    return False
            except Exception:
                return False
        
        return True
    
    def _format_price(self, price: float) -> str:
        """Formata preço para padrão brasileiro"""
        return f"R$ {price:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    
    def _str_to_partial_emoji(self, emoji_str: str):
        """Converte qualquer string de emoji para PartialEmoji.
        Aceita: '<:nome:id>', '<a:nome:id>' (custom) ou emoji Unicode (ex: '🛒').
        Retorna PartialEmoji ou None se inválido.
        """
        if not emoji_str or not isinstance(emoji_str, str):
            return None
        emoji_str = emoji_str.strip()
        if emoji_str.startswith("<"):
            try:
                partial = disnake.PartialEmoji.from_str(emoji_str)
                if partial.id:
                    return partial
            except Exception:
                pass
            return None
        # Emoji Unicode — PartialEmoji aceita apenas o nome/char
        try:
            return disnake.PartialEmoji(name=emoji_str)
        except Exception:
            return None

    def _safe_get_emoji(self, emoji_str, fallback=emoji.cart):
        """Valida e retorna emoji seguro como PartialEmoji, usando fallback se inválido.
        Nunca retorna str pura, pois o disnake exige objeto PartialEmoji nos componentes.
        """
        # Resolver fallback: se for str, converter para PartialEmoji
        def _resolve_fallback(fb):
            if fb is None:
                return None
            if isinstance(fb, disnake.PartialEmoji):
                return fb
            if isinstance(fb, str):
                return self._str_to_partial_emoji(fb)
            return None

        if not emoji_str:
            return _resolve_fallback(fallback)

        if isinstance(emoji_str, str):
            result = self._str_to_partial_emoji(emoji_str)
            if result is not None:
                return result
            return _resolve_fallback(fallback)

        if isinstance(emoji_str, disnake.PartialEmoji):
            # Emoji Unicode do disnake não tem .id mas é válido
            if emoji_str.id or emoji_str.name:
                return emoji_str
            return _resolve_fallback(fallback)

        return _resolve_fallback(fallback)
    
    def _create_buy_button(self, product_id: str) -> list:
        """Cria botões de compra e dúvida (se configurado).
        Se interaction_type == 'buttons', gera um único botão personalizado de compra
        (label/emoji do Botão Compra); ao clicar, mostra select com os campos."""
        # Obter produto para pegar configuração do botão customizado
        products = db.get_document("loja_products")
        product = products.get(product_id) if product_id else {}
        
        info = product.get("info", {}) if product else {}
        button_config = info.get("buy_button", {})
        button_label = button_config.get("label", "Comprar")
        button_emoji_str = button_config.get("emoji", emoji.cart)
        
        # Verificar tipo de interação
        display_prefs = info.get("display_preferences", {})
        interaction_type = get_effective_interaction_type(product)
        
        # Verificar se o botão de dúvidas está habilitado
        doubt_config = db.get_document("loja_doubt_button")
        
        def make_doubt_button():
            if doubt_config.get("enabled") and doubt_config.get("channel_id"):
                doubt_emoji = doubt_config.get("button_emoji")
                if doubt_emoji and isinstance(doubt_emoji, str) and doubt_emoji.startswith("<"):
                    try:
                        doubt_emoji = disnake.PartialEmoji.from_str(doubt_emoji)
                    except:
                        doubt_emoji = "❓"
                elif not doubt_emoji:
                    doubt_emoji = "❓"
                return disnake.ui.Button(
                    label=doubt_config.get("button_label", "Dúvidas"),
                    emoji=doubt_emoji,
                    style=disnake.ButtonStyle.secondary,
                    custom_id="product_doubt_button"
                )
            return None
        
        # Verificar se há estoque disponível (considerando todos os campos)
        campos_all = product.get("campos", {}) if product else {}
        has_any_stock = False
        for cid, campo in campos_all.items():
            delivery_type_c = campo.get("delivery_type", "automatic")
            if delivery_type_c != "automatic":
                has_any_stock = True
                break
            sc = StockManager.get_available_stock(product_id, cid)
            if sc == 999999 or sc > 0:
                has_any_stock = True
                break

        # Modo: botão único personalizado (ao clicar, mostra select com os campos)
        if interaction_type == "buttons":
            btn_emoji = self._safe_get_emoji(button_emoji_str)
            btn_label = button_label if has_any_stock else "Sem estoque"
            buttons = [
                disnake.ui.Button(
                    label=btn_label,
                    emoji=btn_emoji,
                    style=disnake.ButtonStyle.grey,
                    custom_id=f"buy_product:{product_id}",
                    disabled=not has_any_stock
                )
            ]
            doubt_btn = make_doubt_button()
            if doubt_btn:
                buttons.append(doubt_btn)
            return [disnake.ui.ActionRow(*buttons)]
        
        # Modo select: select menu direto na mensagem
        if interaction_type == "select":
            return self._create_select_row(product_id)
        
        # Modo padrão legado (sem interaction_type configurado): botão único
        btn_emoji = self._safe_get_emoji(button_emoji_str)
        btn_label = button_label if has_any_stock else "Sem estoque"
        
        buttons = [
            disnake.ui.Button(
                label=btn_label,
                emoji=btn_emoji,
                style=disnake.ButtonStyle.grey,
                custom_id=f"buy_product:{product_id}",
                disabled=not has_any_stock
            )
        ]
        
        doubt_btn = make_doubt_button()
        if doubt_btn:
            buttons.append(doubt_btn)
        
        return [disnake.ui.ActionRow(*buttons)]
    
    def _create_select_action_row(self, product_id: str) -> Optional[disnake.ui.ActionRow]:
        """Cria apenas o ActionRow do StringSelect com os campos do produto (sem botão de dúvidas).
        Retorna None se o produto não tiver campos."""
        products = db.get_document("loja_products")
        product = products.get(product_id) if product_id else {}
        campos = product.get("campos", {}) if product else {}

        options = []
        for cid, campo in campos.items():
            campo_name = campo.get("name", "Campo")
            campo_price = campo.get("price", 0)
            price_str = f"R$ {campo_price:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
            # Obter estoque
            stock_count = StockManager.get_available_stock(product_id, cid)
            is_infinite = stock_count == 999999
            delivery_type = campo.get("delivery_type", "automatic")
            if delivery_type != "automatic":
                stock_str = "Estoque: infinito"
            elif is_infinite:
                stock_str = "Estoque: infinito"
            elif stock_count <= 0:
                stock_str = "Sem estoque"
            else:
                stock_str = f"Estoque: {stock_count}"
            campo_desc = f"{price_str} | {stock_str}"
            if len(campo_desc) > 97:
                campo_desc = campo_desc[:97] + "..."
            campo_emoji_raw = campo.get("emoji")
            campo_emoji = self._safe_get_emoji(campo_emoji_raw, fallback=None)
            opt = disnake.SelectOption(
                label=campo_name[:100],
                value=cid,
                description=campo_desc,
            )
            if campo_emoji:
                opt.emoji = campo_emoji
            options.append(opt)
        if not options:
            return None

        select = disnake.ui.StringSelect(
            placeholder="Selecione uma opção para comprar...",
            custom_id=f"buy_product_select_field:{product_id}",
            options=options[:25],
        )
        return disnake.ui.ActionRow(select)

    def _create_common_purchase_components(self, product_id: str) -> list:
        """Componentes de compra do Modo Comum (sempre fora da embed).
        Regra: produto com apenas 1 campo -> botão único de compra.
        Produto com 2 ou mais campos -> select menu com as opções.
        Essa regra é independente do interaction_type configurado no produto,
        pois é uma característica própria do Modo Comum."""
        products = db.get_document("loja_products")
        product = products.get(product_id) if product_id else {}
        campos = product.get("campos", {}) if product else {}

        if len(campos) >= 2:
            return self._create_select_row(product_id)

        # 0 ou 1 campo: botão único
        info = product.get("info", {}) if product else {}
        button_config = info.get("buy_button", {})
        button_label = button_config.get("label", "Comprar")
        button_emoji_str = button_config.get("emoji", emoji.cart)
        btn_emoji = self._safe_get_emoji(button_emoji_str)

        has_stock = False
        for cid, campo in campos.items():
            delivery_type_c = campo.get("delivery_type", "automatic")
            if delivery_type_c != "automatic":
                has_stock = True
                break
            sc = StockManager.get_available_stock(product_id, cid)
            if sc == 999999 or sc > 0:
                has_stock = True
                break

        btn_label = button_label if has_stock else "Sem estoque"
        buttons = [
            disnake.ui.Button(
                label=btn_label,
                emoji=btn_emoji,
                style=disnake.ButtonStyle.grey,
                custom_id=f"buy_product:{product_id}",
                disabled=not has_stock
            )
        ]

        doubt_config = db.get_document("loja_doubt_button")
        if doubt_config.get("enabled") and doubt_config.get("channel_id"):
            doubt_emoji = doubt_config.get("button_emoji")
            if doubt_emoji and isinstance(doubt_emoji, str) and doubt_emoji.startswith("<"):
                try:
                    doubt_emoji = disnake.PartialEmoji.from_str(doubt_emoji)
                except Exception:
                    doubt_emoji = "❓"
            elif not doubt_emoji:
                doubt_emoji = "❓"
            buttons.append(
                disnake.ui.Button(
                    label=doubt_config.get("button_label", "Dúvidas"),
                    emoji=doubt_emoji,
                    style=disnake.ButtonStyle.secondary,
                    custom_id="product_doubt_button"
                )
            )

        return [disnake.ui.ActionRow(*buttons)]

    def _create_select_row(self, product_id: str) -> list:
        """Cria um StringSelect com os campos do produto para exibir diretamente no painel.
        Retorna lista de ActionRow(s) com o select (e botão de dúvidas se configurado)."""
        rows = []
        select_row = self._create_select_action_row(product_id)
        if select_row:
            rows.append(select_row)

        # Botão de dúvidas se habilitado
        doubt_config = db.get_document("loja_doubt_button")
        if doubt_config.get("enabled") and doubt_config.get("channel_id"):
            doubt_emoji = doubt_config.get("button_emoji")
            if doubt_emoji and isinstance(doubt_emoji, str) and doubt_emoji.startswith("<"):
                try:
                    doubt_emoji = disnake.PartialEmoji.from_str(doubt_emoji)
                except:
                    doubt_emoji = "❓"
            elif not doubt_emoji:
                doubt_emoji = "❓"
            rows.append(disnake.ui.ActionRow(
                disnake.ui.Button(
                    label=doubt_config.get("button_label", "Dúvidas"),
                    emoji=doubt_emoji,
                    style=disnake.ButtonStyle.secondary,
                    custom_id="product_doubt_button"
                )
            ))
        return rows


        """Constrói embed no modo Legacy com footer do servidor
        formatted_desc=True -> descrição completa com quebras de linha
        formatted_desc=False -> descrição padrão Discord (sem formatação especial)
        """
        product_name = product.get("name", "Produto")
        description = product.get("info", {}).get("description", "")
        hex_color = product.get("info", {}).get("hex_color")
        banner = product.get("info", {}).get("banner")
        campos = product.get("campos", {})
        
        # Calcular preços
        prices = [campo.get("price", 0) for campo in campos.values()]
        min_price = min(prices) if prices else 0
        max_price = max(prices) if prices else 0
        
        if min_price == max_price:
            price_text = self._format_price(min_price)
        else:
            price_text = f"{self._format_price(min_price)} - {self._format_price(max_price)}"
        
        # Criar embed
        embed_kwargs = {}
        if hex_color:
            try:
                embed_kwargs["color"] = disnake.Color(int(hex_color.replace("#", ""), 16))
            except:
                pass
        
        # Aplicar quebra de linha se formatada
        if formatted_desc and description:
            description = wrap_text(description, max_line_length=50)
        
        embed = disnake.Embed(
            title=product_name,
            description=description if description else "Produto disponível para compra",
            **embed_kwargs
        )
        
        # Adicionar informações
        embed.add_field(
            name=f"{emoji.dollar} Preço",
            value=f"`{price_text}`",
            inline=True
        )
        
        # Obter preferências de exibição
        info = product.get("info", {})
        display_prefs = info.get("display_preferences", {})
        show_options = display_prefs.get("show_options", True)
        show_sales = display_prefs.get("show_sales", True)
        
        # Adicionar opções primeiro (se habilitado)
        if show_options:
            embed.add_field(
                name=f"{emoji.embed} Opções",
                value=f"`{len(campos)} disponível`" if len(campos) == 1 else f"`{len(campos)} disponíveis`",
                inline=True
            )
        
        # Adicionar vendas depois (se habilitado)
        if show_sales:
            purchases_count = len(info.get("purchasesIds", []))
            if purchases_count > 0:
                embed.add_field(
                    name=f"{emoji.dollar} Vendas",
                    value=f"`{purchases_count} {'venda realizada' if purchases_count == 1 else 'vendas realizadas'}`",
                    inline=True
                )
        
        # Banner - validar URL antes de usar
        if banner and self._is_valid_image_url(banner):
            embed.set_image(url=banner)
        
        # Footer com informações do servidor
        icon_url = guild.icon.url if guild.icon else None
        embed.set_footer(text=guild.name, icon_url=icon_url)
        embed.timestamp = disnake.utils.utcnow()
        
        return embed
    
    def _build_container(self, product: dict, image_inside: bool = False, product_id: str = "", formatted_desc: bool = True, banner_gallery: disnake.ui.MediaGallery | None = None, wrap_len: int | None = None, force_emoji_cart: bool = False) -> list:
        """Constrói container moderno com MediaGallery
        image_inside=True -> imagem dentro do container
        image_inside=False -> imagem fora (acima) do container
        formatted_desc=True -> descrição completa com quebras de linha
        formatted_desc=False -> descrição padrão Discord (sem formatação especial)
        """
        product_name = product.get("name", "Produto")
        description = product.get("info", {}).get("description", "")
        hex_color = product.get("info", {}).get("hex_color")
        banner = product.get("info", {}).get("banner")
        campos = product.get("campos", {})
        
        # Calcular preços
        prices = [campo.get("price", 0) for campo in campos.values()]
        min_price = min(prices) if prices else 0
        max_price = max(prices) if prices else 0
        
        if min_price == max_price:
            price_text = self._format_price(min_price)
        else:
            price_text = f"{self._format_price(min_price)} - {self._format_price(max_price)}"
        
        # Componentes
        components = []
        # Container principal
        container_kwargs = {}
        if hex_color:
            try:
                container_kwargs["accent_colour"] = disnake.Colour(int(hex_color.replace("#", ""), 16))
            except:
                pass
        
        # Textos com formatação baseada em formatted_desc
        title_text = f"**{product_name}**"
        # Sempre adicionar descrição se existir
        if description:
            if formatted_desc:
                description = wrap_text(description, max_line_length=wrap_len or 50)
            title_text += f"\n{description}"
        
        # Obter preferências de exibição
        info = product.get("info", {})
        display_prefs = info.get("display_preferences", {})
        show_options = display_prefs.get("show_options", True)
        show_sales = display_prefs.get("show_sales", True)
        
        # Construir informações de preço
        price_info_parts = [f"**{price_text}**"]
        
        # Adicionar opções primeiro (se habilitado)
        if show_options:
            # Calcular estoque total disponível
            total_stock = 0
            all_infinite = False
            has_manual = False
            for cid, campo in campos.items():
                dt = campo.get("delivery_type", "automatic")
                if dt != "automatic":
                    has_manual = True
                    continue
                sc = StockManager.get_available_stock(product_id, cid)
                if sc == 999999:
                    all_infinite = True
                else:
                    total_stock += sc
            if has_manual or all_infinite:
                stock_label = "∞"
            else:
                stock_label = str(total_stock)
            price_info_parts.append(f"-# {len(campos)} {'opção' if len(campos) == 1 else 'opções'} | Estoque: {stock_label}")
        
        # Adicionar vendas depois (se habilitado)
        if show_sales:
            purchases_count = len(info.get("purchasesIds", []))
            if purchases_count > 0:
                price_info_parts.append(f"-# {purchases_count} {'venda realizada' if purchases_count == 1 else 'vendas realizadas'}")

        price_info_text = "\n".join(price_info_parts)
        
        # Obter configuração do botão customizado
        button_config = info.get("buy_button", {})
        button_label = button_config.get("label", "Comprar")
        
        # Se force_emoji_cart for True, usar emoji.cart diretamente
        if force_emoji_cart:
            btn_emoji_preview = emoji.cart
        else:
            button_emoji_str = button_config.get("emoji", emoji.cart)
            # Preparar emoji do botão usando função segura
            btn_emoji_preview = self._safe_get_emoji(button_emoji_str)

        # Verificar tipo de interação
        interaction_type = get_effective_interaction_type(product)

        # Montar elementos internos do container
        inner_items = []
        if image_inside and banner:
            # Só adicionar se tiver banner_gallery processado ou URL válida
            if banner_gallery is not None:
                inner_items.append(banner_gallery)
            elif self._is_valid_image_url(banner):
                inner_items.append(
                    disnake.ui.MediaGallery(
                        disnake.MediaGalleryItem(media=banner)
                    )
                )
        inner_items.append(disnake.ui.TextDisplay(title_text))
        inner_items.append(disnake.ui.Separator())

        if interaction_type == "buttons":
            # Botão único personalizado (ao clicar, mostra select com os campos)
            inner_items.append(
                disnake.ui.Section(
                    disnake.ui.TextDisplay(price_info_text),
                    accessory=disnake.ui.Button(
                        label=button_label,
                        emoji=btn_emoji_preview,
                        style=disnake.ButtonStyle.grey,
                        custom_id=f"buy_product:{product_id}"
                    )
                )
            )
        elif interaction_type == "select":
            # Preço sem acessório; select fica DENTRO do container, junto do resto do conteúdo
            inner_items.append(disnake.ui.TextDisplay(price_info_text))
            select_action_row = self._create_select_action_row(product_id)
            if select_action_row:
                inner_items.append(select_action_row)
        else:
            inner_items.append(
                disnake.ui.Section(
                    disnake.ui.TextDisplay(price_info_text),
                    accessory=disnake.ui.Button(
                        label=button_label,
                        emoji=btn_emoji_preview,
                        style=disnake.ButtonStyle.grey,
                        custom_id=f"buy_product:{product_id}"
                    )
                )
            )

        container = disnake.ui.Container(
            *inner_items,
            **container_kwargs
        )

        # Se imagem for fora, adiciona acima do container
        if (not image_inside) and banner:
            # Só adicionar se tiver banner_gallery processado ou URL válida
            if banner_gallery is not None:
                components.append(banner_gallery)
            elif self._is_valid_image_url(banner):
                components.append(
                    disnake.ui.MediaGallery(
                        disnake.MediaGalleryItem(media=banner)
                    )
                )
        components.append(container)

        # No modo select, o select agora fica dentro do container (acima).
        # Aqui só precisamos adicionar o botão de dúvidas (se habilitado), fora do container.
        if interaction_type == "select":
            doubt_config = db.get_document("loja_doubt_button")
            if doubt_config.get("enabled") and doubt_config.get("channel_id"):
                doubt_emoji = doubt_config.get("button_emoji")
                if doubt_emoji and isinstance(doubt_emoji, str) and doubt_emoji.startswith("<"):
                    try:
                        doubt_emoji = disnake.PartialEmoji.from_str(doubt_emoji)
                    except:
                        doubt_emoji = "❓"
                elif not doubt_emoji:
                    doubt_emoji = "❓"
                components.append(disnake.ui.ActionRow(
                    disnake.ui.Button(
                        label=doubt_config.get("button_label", "Dúvidas"),
                        emoji=doubt_emoji,
                        style=disnake.ButtonStyle.secondary,
                        custom_id="product_doubt_button"
                    )
                ))

        return components
    
    def _build_channel_selector(self, product_id: str, guild: disnake.Guild) -> disnake.ui.Container:
        """Constrói seletor de canal onde a mensagem será enviada"""
        colors = db.get_document("custom_colors")
        primary_color_hex = colors.get("primary") if isinstance(colors, dict) else None
        container_kwargs = {}
        if primary_color_hex:
            container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))
        
        return disnake.ui.Container(
            disnake.ui.TextDisplay(f"## \n-# Publicar Produto > **Selecionar Canal**"),
            disnake.ui.Separator(),
            disnake.ui.TextDisplay(
                "Escolha o canal onde deseja publicar a mensagem do produto:\n"
                "-# Selecione um canal de texto do servidor"
            ),
            disnake.ui.ActionRow(
                disnake.ui.ChannelSelect(
                    placeholder="Selecione o canal",
                    custom_id=f"select_channel:{product_id}",
                    channel_types=[disnake.ChannelType.text]
                )
            ),
            **container_kwargs
        )
    
    def _build_mode_selector(self, product_id: str, channel_id: str) -> disnake.ui.Container:
        """Constrói seletor de modo (Legacy/Container)"""
        colors = db.get_document("custom_colors")
        primary_color_hex = colors.get("primary") if isinstance(colors, dict) else None
        container_kwargs = {}
        if primary_color_hex:
            container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))
        
        return disnake.ui.Container(
            disnake.ui.TextDisplay(f"## \n-# Publicar Produto > **Escolher Modo**"),
            disnake.ui.Separator(),
            disnake.ui.TextDisplay(
                "**Modo Legacy**\n"
                "-# Embed tradicional com informações do produto\n"
                "**Modo Comum**\n"
                "-# Embed clássica enxuta: título, descrição e imagem dentro da embed. "
                "Compra fora da embed: botão único se houver 1 campo, select se houver 2 ou mais\n"
                "**Modo Container**\n"
                "-# Escolha o posicionamento da imagem: dentro ou fora do container"
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Modo Legacy",
                    emoji=emoji.embed,
                    style=disnake.ButtonStyle.grey,
                    custom_id=f"send_select_size:legacy:{product_id}:{channel_id}"
                ),
                disnake.ui.Button(
                    label="Modo Comum",
                    emoji=emoji.embed,
                    style=disnake.ButtonStyle.grey,
                    custom_id=f"send_select_size:common:{product_id}:{channel_id}"
                )
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Container (Imagem Fora)",
                    emoji=emoji.image if hasattr(emoji, 'image') else None,
                    style=disnake.ButtonStyle.blurple,
                    custom_id=f"send_select_size:container_outside:{product_id}:{channel_id}"
                ),
                disnake.ui.Button(
                    label="Container (Imagem Dentro)",
                    emoji=emoji.image if hasattr(emoji, 'image') else None,
                    style=disnake.ButtonStyle.blurple,
                    custom_id=f"send_select_size:container_inside:{product_id}:{channel_id}"
                )
            ),
            **container_kwargs
        )

    def _build_size_selector(self, product_id: str, channel_id: str, mode: str) -> disnake.ui.Container:
        colors = db.get_document("custom_colors")
        primary_color_hex = colors.get("primary") if isinstance(colors, dict) else None
        container_kwargs = {}
        if primary_color_hex:
            container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))

        return disnake.ui.Container(
            disnake.ui.TextDisplay(f"## \n-# Publicar Produto > **Escolher Tamanho da Imagem**"),
            disnake.ui.Separator(),
            disnake.ui.TextDisplay(
                "Selecione o tamanho do banner que será usado na mensagem:\n"
                "-# Small: menor largura (ideal para compactar)\n"
                "-# Medium: largura média (ex. 512px)\n"
                "-# Normal: tamanho original"
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Small",
                    emoji=emoji.image if hasattr(emoji, 'image') else None,
                    style=disnake.ButtonStyle.grey,
                    custom_id=f"send_select_desc_format:{mode}:small:{product_id}:{channel_id}"
                ),
                disnake.ui.Button(
                    label="Medium",
                    emoji=emoji.image if hasattr(emoji, 'image') else None,
                    style=disnake.ButtonStyle.blurple,
                    custom_id=f"send_select_desc_format:{mode}:medium:{product_id}:{channel_id}"
                ),
                disnake.ui.Button(
                    label="Normal",
                    emoji=emoji.image if hasattr(emoji, 'image') else None,
                    style=disnake.ButtonStyle.green,
                    custom_id=f"send_select_desc_format:{mode}:normal:{product_id}:{channel_id}"
                )
            ),
            **container_kwargs
        )

    def _build_banner_gallery(self, banner_url: str, size: str) -> tuple[disnake.ui.MediaGallery | None, list[disnake.File]]:
        """Constrói MediaGallery com banner processado. Retorna None se houver erro."""
        if not banner_url or not self._is_valid_image_url(banner_url):
            return None, []
        
        try:
            resp = requests.get(banner_url, timeout=10)
            resp.raise_for_status()
            
            # Verificar content-type
            content_type = resp.headers.get('content-type', '').lower()
            if 'image' not in content_type:
                return None, []
            
            buf_in = BytesIO(resp.content)
            im = Image.open(buf_in)
            
            # Validar que é uma imagem válida
            im.verify()
            im = Image.open(buf_in)  # Reabrir após verify
            
            w, h = im.size
            filename = "banner.png"
            target_w = None
            if size == "small":
                target_w = 320
                filename = "banner_small.png"
            elif size == "medium":
                filename = "banner_medium.png"
                if w > 512:
                    target_w = 512
                elif w > 320:
                    target_w = 400
                else:
                    target_w = None
            else:
                filename = "banner.png"

            if target_w is not None and w > target_w:
                new_h = int(h * (target_w / w))
                im = im.resize((target_w, new_h), Image.LANCZOS)

            out = BytesIO()
            im.save(out, format="PNG")
            out.seek(0)
            file = disnake.File(out, filename=filename)
            gallery = disnake.ui.MediaGallery(
                disnake.MediaGalleryItem(media=f"attachment://{filename}", description="Banner")
            )
            return gallery, [file]
        except requests.exceptions.HTTPError as e:
            # Se for 404 (imagem não encontrada), apenas retornar None silenciosamente
            if e.response and e.response.status_code == 404:
                return None, []
            # Para outros erros HTTP, logar mas não quebrar
            print(f"Erro HTTP ao processar banner {banner_url}: {e.response.status_code if e.response else 'Unknown'}")
            return None, []
        except Exception as e:
            # Outros erros (timeout, conexão, etc) - logar mas não quebrar
            # Não logar erros comuns como 404 para não poluir o console
            error_msg = str(e).lower()
            if "404" not in error_msg and "not found" not in error_msg:
                print(f"Erro ao processar banner {banner_url}: {e}")
            return None, []

    @commands.Cog.listener("on_button_click")
    async def on_button_click(self, inter: disnake.MessageInteraction):
        custom_id = inter.component.custom_id
        print(f"[SEND][on_button_click] custom_id={custom_id!r}")
        try:
            await self._on_button_click_inner(inter, custom_id)
        except Exception as e:
            import traceback
            print(f"[SEND][ERRO] custom_id={custom_id!r} | {e}")
            traceback.print_exc()

    async def _on_button_click_inner(self, inter: disnake.MessageInteraction, custom_id: str):
        # Handler para publicar produto (entrada principal)
        if custom_id.startswith("Loja_PublicarProduto:"):
            product_id = custom_id.split(":", 1)[1]
            
            # Mostrar seletor de canal primeiro
            await inter.response.defer(ephemeral=True)
            container = self._build_channel_selector(product_id, inter.guild)
            await inter.followup.send(
                components=[container],
                ephemeral=True,
                flags=disnake.MessageFlags(is_components_v2=True)
            )
            return
        
        # Handler para seleção de tamanho após modo
        if custom_id.startswith("send_select_size:"):
            parts = custom_id.split(":")
            mode = parts[1]
            product_id = parts[2]
            channel_id = parts[3]
            print(f"[SEND][send_select_size] mode={mode!r} product_id={product_id!r} channel_id={channel_id!r}")
            await inter.response.defer(ephemeral=True)
            # Se não for container, pular etapa de tamanho (legacy e common usam embed com imagem via URL, sem attachment redimensionado)
            if mode in ("legacy", "common"):
                colors = db.get_document("custom_colors")
                primary_color_hex = colors.get("primary") if isinstance(colors, dict) else None
                container_kwargs = {}
                if primary_color_hex:
                    container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))
                container = disnake.ui.Container(
                    disnake.ui.TextDisplay(f"## \n-# Publicar Produto > **Formatação da Descrição**"),
                    disnake.ui.Separator(),
                    disnake.ui.TextDisplay(
                        "**Descrição Formatada**\n"
                        "-# Exibe a descrição completa com todas as quebras de linha\n"
                        "**Descrição Normal**\n"
                        "-# Segue o padrão do Discord (texto corrido)"
                    ),
                    disnake.ui.ActionRow(
                        disnake.ui.Button(
                            label="Formatada",
                            emoji=emoji.correct,
                            style=disnake.ButtonStyle.green,
                            custom_id=f"send_mode_{mode}:formatted:normal:{product_id}:{channel_id}"
                        ),
                        disnake.ui.Button(
                            label="Normal",
                            emoji=emoji.information,
                            style=disnake.ButtonStyle.grey,
                            custom_id=f"send_mode_{mode}:normal:normal:{product_id}:{channel_id}"
                        )
                    ),
                    **container_kwargs
                )
                await inter.edit_original_message(
                    components=[container],
                    flags=disnake.MessageFlags(is_components_v2=True)
                )
                return

            # Para container: só mostrar etapa de tamanho se houver banner
            products = db.get_document("loja_products")
            product = products.get(product_id)
            banner_url = product.get("info", {}).get("banner") if product else None
            if not banner_url:
                # Ir direto para formatação com tamanho normal
                colors = db.get_document("custom_colors")
                primary_color_hex = colors.get("primary") if isinstance(colors, dict) else None
                container_kwargs = {}
                if primary_color_hex:
                    container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))
                container = disnake.ui.Container(
                    disnake.ui.TextDisplay(f"## \n-# Publicar Produto > **Formatação da Descrição**"),
                    disnake.ui.Separator(),
                    disnake.ui.TextDisplay(
                        "**Descrição Formatada**\n"
                        "-# Exibe a descrição completa com todas as quebras de linha\n"
                        "**Descrição Normal**\n"
                        "-# Segue o padrão do Discord (texto corrido)"
                    ),
                    disnake.ui.ActionRow(
                        disnake.ui.Button(
                            label="Formatada",
                            emoji=emoji.correct,
                            style=disnake.ButtonStyle.green,
                            custom_id=f"send_mode_{mode}:formatted:normal:{product_id}:{channel_id}"
                        ),
                        disnake.ui.Button(
                            label="Normal",
                            emoji=emoji.information,
                            style=disnake.ButtonStyle.grey,
                            custom_id=f"send_mode_{mode}:normal:normal:{product_id}:{channel_id}"
                        )
                    ),
                    **container_kwargs
                )
                await inter.edit_original_message(
                    components=[container],
                    flags=disnake.MessageFlags(is_components_v2=True)
                )
                return

            # Banner existe: mostrar seletor de tamanho
            container = self._build_size_selector(product_id, channel_id, mode)
            await inter.edit_original_message(
                components=[container],
                flags=disnake.MessageFlags(is_components_v2=True)
            )
            return

        # Handler para seleção de formatação de descrição
        if custom_id.startswith("send_select_desc_format:"):
            parts = custom_id.split(":")
            mode = parts[1]  # legacy, container_outside, container_inside
            # Suporta chamadas com ou sem parâmetro de tamanho
            if len(parts) >= 5:
                size = parts[2]  # small, medium, normal
                product_id = parts[3]
                channel_id = int(parts[4]) if len(parts) > 4 else None
            else:
                size = "normal"
                product_id = parts[2]
                channel_id = int(parts[3]) if len(parts) > 3 else None
            
            # Mostrar seletor de formatação
            colors = db.get_document("custom_colors")
            primary_color_hex = colors.get("primary") if isinstance(colors, dict) else None
            container_kwargs = {}
            if primary_color_hex:
                container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))
            
            await inter.response.defer(ephemeral=True)
            container = disnake.ui.Container(
                disnake.ui.TextDisplay(f"## \n-# Publicar Produto > **Formatação da Descrição**"),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(
                    "**Descrição Formatada**\n"
                    "-# Exibe a descrição completa com todas as quebras de linha\n"
                    "**Descrição Normal**\n"
                    "-# Segue o padrão do Discord (texto corrido)"
                ),
                disnake.ui.ActionRow(
                    disnake.ui.Button(
                        label="Formatada",
                        emoji=emoji.correct,
                        style=disnake.ButtonStyle.green,
                        custom_id=f"send_mode_{mode}:formatted:{size}:{product_id}:{channel_id}"
                    ),
                    disnake.ui.Button(
                        label="Normal",
                        emoji=emoji.information,
                        style=disnake.ButtonStyle.grey,
                        custom_id=f"send_mode_{mode}:normal:{size}:{product_id}:{channel_id}"
                    )
                ),
                **container_kwargs
            )
            await inter.edit_original_message(
                components=[container],
                flags=disnake.MessageFlags(is_components_v2=True)
            )
            return
        
        # Handler para modo Legacy
        print(f"[SEND] Verificando send_mode_legacy: {custom_id.startswith('send_mode_legacy:')!r} custom_id={custom_id!r}")
        if custom_id.startswith("send_mode_legacy:"):
            parts = custom_id.split(":")
            desc_format = parts[1]  # formatted ou normal
            size = parts[2]
            product_id = parts[3]
            channel_id = int(parts[4]) if len(parts) > 4 else None
            formatted_desc = (desc_format == "formatted")
            
            # Carregar produto
            products = db.get_document("loja_products")
            product = products.get(product_id)
            
            if not product:
                await inter.response.defer(ephemeral=True)
                await inter.edit_original_message(
                    content=f"{emoji.wrong} Produto não encontrado!",
                    components=[]
                )
                return
            
            # Obter canal
            channel = inter.guild.get_channel(channel_id) if channel_id else inter.channel
            if not channel:
                await inter.response.defer(ephemeral=True)
                await inter.edit_original_message(
                    content=f"{emoji.wrong} Canal não encontrado!",
                    components=[]
                )
                return
            
            # Enviar no modo Legacy
            print(f"[SEND][Legacy] Enviando para canal {channel!r} produto={product_id!r}")
            await inter.response.defer(ephemeral=True)
            embed = ConfigurarProduto._build_legacy_embed(product, inter.guild, formatted_desc=formatted_desc)
            components = self._create_buy_button(product_id)
            
            try:
                msg = await channel.send(embed=embed, components=components)
            except disnake.HTTPException as e:
                # Se o erro for relacionado a emoji inválido, tentar novamente com emoji.cart
                if e.code == 50035 and "emoji" in str(e).lower():
                    # Recriar botões com emoji.cart como fallback
                    products = db.get_document("loja_products")
                    product = products.get(product_id)
                    info = product.get("info", {}) if product else {}
                    button_config = info.get("buy_button", {})
                    button_label = button_config.get("label", "Comprar")
                    
                    buttons = [
                        disnake.ui.Button(
                            label=button_label,
                            emoji=emoji.cart,
                            style=disnake.ButtonStyle.grey,
                            custom_id=f"buy_product:{product_id}"
                        )
                    ]
                    
                    # Adicionar botão de dúvidas se estiver habilitado
                    doubt_config = db.get_document("loja_doubt_button")
                    if doubt_config.get("enabled") and doubt_config.get("channel_id"):
                        buttons.append(
                            disnake.ui.Button(
                                label=doubt_config.get("button_label", "Dúvidas"),
                                emoji="❓",
                                style=disnake.ButtonStyle.secondary,
                                custom_id="product_doubt_button"
                            )
                        )
                    
                    components = [disnake.ui.ActionRow(*buttons)]
                    msg = await channel.send(embed=embed, components=components)
                else:
                    raise
            
            # Salvar mensagem enviada
            messages = product.get("messages", [])
            messages.append({
                "message_id": msg.id,
                "channel_id": channel.id,
                "guild_id": inter.guild.id,
                "mode": "legacy",
                "formatted_desc": formatted_desc,
                "image_size": size,
                "created_at": int(disnake.utils.utcnow().timestamp())
            })
            
            products[product_id]["messages"] = messages
            db.save_document("loja_products", products)
            
            # Confirmar envio
            colors = db.get_document("custom_colors")
            primary_color_hex = colors.get("primary") if isinstance(colors, dict) else None
            container_kwargs = {}
            if primary_color_hex:
                container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))
            
            container = disnake.ui.Container(
                disnake.ui.TextDisplay(f"# {emoji.correct}\n-# **Produto Publicado com Sucesso!**"),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(
                    f"**Modo:** Legacy\n"
                    f"**Canal:** {channel.mention}\n"
                    f"**ID da Mensagem:** `{msg.id}`"
                ),
                **container_kwargs
            )
            
            await inter.edit_original_message(
                components=[container],
                flags=disnake.MessageFlags(is_components_v2=True)
            )
            return

        # Handler para modo Comum (embed clássica + select menu fora da embed)
        if custom_id.startswith("send_mode_common:"):
            parts = custom_id.split(":")
            desc_format = parts[1]  # formatted ou normal
            size = parts[2]
            product_id = parts[3]
            channel_id = int(parts[4]) if len(parts) > 4 else None
            formatted_desc = (desc_format == "formatted")

            # Carregar produto
            products = db.get_document("loja_products")
            product = products.get(product_id)

            if not product:
                await inter.response.defer(ephemeral=True)
                await inter.edit_original_message(
                    content=f"{emoji.wrong} Produto não encontrado!",
                    components=[]
                )
                return

            # Obter canal
            channel = inter.guild.get_channel(channel_id) if channel_id else inter.channel
            if not channel:
                await inter.response.defer(ephemeral=True)
                await inter.edit_original_message(
                    content=f"{emoji.wrong} Canal não encontrado!",
                    components=[]
                )
                return

            # Enviar no modo Comum: embed clássica (título em cima, descrição, imagem
            # dentro da embed logo abaixo) + select menu de compra como componente
            # separado, fora da embed.
            print(f"[SEND][Comum] Enviando para canal {channel!r} produto={product_id!r}")
            await inter.response.defer(ephemeral=True)
            embed = ConfigurarProduto._build_common_embed(product, inter.guild, formatted_desc=formatted_desc)
            components = self._create_common_purchase_components(product_id)

            msg = await channel.send(embed=embed, components=components)

            # Salvar mensagem enviada
            messages = product.get("messages", [])
            messages.append({
                "message_id": msg.id,
                "channel_id": channel.id,
                "guild_id": inter.guild.id,
                "mode": "common",
                "formatted_desc": formatted_desc,
                "image_size": size,
                "created_at": int(disnake.utils.utcnow().timestamp())
            })

            products[product_id]["messages"] = messages
            db.save_document("loja_products", products)

            # Confirmar envio
            colors = db.get_document("custom_colors")
            primary_color_hex = colors.get("primary") if isinstance(colors, dict) else None
            container_kwargs = {}
            if primary_color_hex:
                container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))

            container = disnake.ui.Container(
                disnake.ui.TextDisplay(f"# {emoji.correct}\n-# **Produto Publicado com Sucesso!**"),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(
                    f"**Modo:** Comum\n"
                    f"**Canal:** {channel.mention}\n"
                    f"**ID da Mensagem:** `{msg.id}`"
                ),
                **container_kwargs
            )

            await inter.edit_original_message(
                components=[container],
                flags=disnake.MessageFlags(is_components_v2=True)
            )
            return

        # Handler para modo Container (Imagem Fora)
        if custom_id.startswith("send_mode_container_outside:"):
            parts = custom_id.split(":")
            desc_format = parts[1]  # formatted ou normal
            size = parts[2]
            product_id = parts[3]
            channel_id = int(parts[4]) if len(parts) > 4 else None
            formatted_desc = (desc_format == "formatted")
            
            # Carregar produto
            products = db.get_document("loja_products")
            product = products.get(product_id)
            
            if not product:
                await inter.response.defer(ephemeral=True)
                await inter.edit_original_message(
                    content=f"{emoji.wrong} Produto não encontrado!",
                    components=[]
                )
                return
            
            # Obter canal
            channel = inter.guild.get_channel(channel_id) if channel_id else inter.channel
            if not channel:
                await inter.response.defer(ephemeral=True)
                await inter.edit_original_message(
                    content=f"{emoji.wrong} Canal não encontrado!",
                    components=[]
                )
                return
            
            # Enviar no modo Container (imagem fora)
            await inter.response.defer(ephemeral=True)
            banner_url = product.get("info", {}).get("banner")
            gallery = None
            files = []
            if banner_url:
                gallery, files = self._build_banner_gallery(banner_url, size)
            wrap_len = None
            if formatted_desc:
                if size == "small":
                    wrap_len = 47
                elif size == "medium":
                    wrap_len = 64
                else:
                    wrap_len = 82
            container_components = self._build_container(product, image_inside=False, product_id=product_id, formatted_desc=formatted_desc, banner_gallery=gallery, wrap_len=wrap_len)
            
            try:
                msg = await channel.send(
                    components=container_components,
                    files=files,
                    flags=disnake.MessageFlags(is_components_v2=True)
                )
            except disnake.HTTPException as e:
                # Se o erro for relacionado a emoji inválido, tentar novamente com emoji.cart
                if e.code == 50035 and "emoji" in str(e).lower():
                    # Reconstruir container com emoji.cart como fallback
                    info = product.get("info", {})
                    button_config = info.get("buy_button", {})
                    button_label = button_config.get("label", "Comprar")
                    
                    # Reconstruir container com emoji seguro
                    container_components = self._build_container(
                        product, 
                        image_inside=False, 
                        product_id=product_id, 
                        formatted_desc=formatted_desc, 
                        banner_gallery=gallery, 
                        wrap_len=wrap_len,
                        force_emoji_cart=True
                    )
                    msg = await channel.send(
                        components=container_components,
                        files=files,
                        flags=disnake.MessageFlags(is_components_v2=True)
                    )
                else:
                    raise
            
            # Salvar mensagem enviada
            messages = product.get("messages", [])
            messages.append({
                "message_id": msg.id,
                "channel_id": channel.id,
                "guild_id": inter.guild.id,
                "mode": "container_outside",
                "formatted_desc": formatted_desc,
                "image_size": size,
                "created_at": int(disnake.utils.utcnow().timestamp())
            })
            
            products[product_id]["messages"] = messages
            db.save_document("loja_products", products)
            
            # Confirmar envio
            colors = db.get_document("custom_colors")
            primary_color_hex = colors.get("primary") if isinstance(colors, dict) else None
            container_kwargs = {}
            if primary_color_hex:
                container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))
            
            desc_format_text = "Formatada" if formatted_desc else "Normal"
            container = disnake.ui.Container(
                disnake.ui.TextDisplay(f"# {emoji.correct}\n-# **Produto Publicado com Sucesso!**"),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(
                    f"**Modo:** Container (Imagem Fora)\n"
                    f"**Descrição:** {desc_format_text}\n"
                    f"**Canal:** {channel.mention}\n"
                    f"**ID da Mensagem:** `{msg.id}`"
                ),
                **container_kwargs
            )
            
            await inter.edit_original_message(
                components=[container],
                flags=disnake.MessageFlags(is_components_v2=True)
            )
            return

        # Handler para modo Container (Imagem Dentro)
        if custom_id.startswith("send_mode_container_inside:"):
            parts = custom_id.split(":")
            desc_format = parts[1]  # formatted ou normal
            size = parts[2]
            product_id = parts[3]
            channel_id = int(parts[4]) if len(parts) > 4 else None
            formatted_desc = (desc_format == "formatted")
            
            # Carregar produto
            products = db.get_document("loja_products")
            product = products.get(product_id)
            
            if not product:
                await inter.response.defer(ephemeral=True)
                await inter.edit_original_message(
                    content=f"{emoji.wrong} Produto não encontrado!",
                    components=[]
                )
                return
            
            # Obter canal
            channel = inter.guild.get_channel(channel_id) if channel_id else inter.channel
            if not channel:
                await inter.response.defer(ephemeral=True)
                await inter.edit_original_message(
                    content=f"{emoji.wrong} Canal não encontrado!",
                    components=[]
                )
                return
            
            # Enviar no modo Container (imagem dentro)
            await inter.response.defer(ephemeral=True)
            banner_url = product.get("info", {}).get("banner")
            gallery = None
            files = []
            if banner_url:
                gallery, files = self._build_banner_gallery(banner_url, size)
            wrap_len = None
            if formatted_desc:
                if size == "small":
                    wrap_len = 47
                elif size == "medium":
                    wrap_len = 64
                else:
                    wrap_len = 82
            container_components = self._build_container(product, image_inside=True, product_id=product_id, formatted_desc=formatted_desc, banner_gallery=gallery, wrap_len=wrap_len)
            
            try:
                msg = await channel.send(
                    components=container_components,
                    files=files,
                    flags=disnake.MessageFlags(is_components_v2=True)
                )
            except disnake.HTTPException as e:
                # Se o erro for relacionado a emoji inválido, tentar novamente com emoji.cart
                if e.code == 50035 and "emoji" in str(e).lower():
                    # Reconstruir container com emoji.cart como fallback
                    info = product.get("info", {})
                    button_config = info.get("buy_button", {})
                    button_label = button_config.get("label", "Comprar")
                    
                    # Reconstruir container com emoji seguro
                    container_components = self._build_container(
                        product, 
                        image_inside=True, 
                        product_id=product_id, 
                        formatted_desc=formatted_desc, 
                        banner_gallery=gallery, 
                        wrap_len=wrap_len,
                        force_emoji_cart=True
                    )
                    msg = await channel.send(
                        components=container_components,
                        files=files,
                        flags=disnake.MessageFlags(is_components_v2=True)
                    )
                else:
                    raise
            
            # Salvar mensagem enviada
            messages = product.get("messages", [])
            messages.append({
                "message_id": msg.id,
                "channel_id": channel.id,
                "guild_id": inter.guild.id,
                "mode": "container_inside",
                "formatted_desc": formatted_desc,
                "image_size": size,
                "created_at": int(disnake.utils.utcnow().timestamp())
            })
            
            products[product_id]["messages"] = messages
            db.save_document("loja_products", products)
            
            # Confirmar envio
            colors = db.get_document("custom_colors")
            primary_color_hex = colors.get("primary") if isinstance(colors, dict) else None
            container_kwargs = {}
            if primary_color_hex:
                container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))
            
            desc_format_text = "Formatada" if formatted_desc else "Normal"
            container = disnake.ui.Container(
                disnake.ui.TextDisplay(f"# {emoji.correct}\n-# **Produto Publicado com Sucesso!**"),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(
                    f"**Modo:** Container (Imagem Dentro)\n"
                    f"**Descrição:** {desc_format_text}\n"
                    f"**Canal:** {channel.mention}\n"
                    f"**ID da Mensagem:** `{msg.id}`"
                ),
                **container_kwargs
            )
            
            await inter.edit_original_message(
                components=[container],
                flags=disnake.MessageFlags(is_components_v2=True)
            )
            return
    
    @commands.Cog.listener("on_dropdown")
    async def on_dropdown(self, inter: disnake.MessageInteraction):
        custom_id = inter.component.custom_id
        print(f"[SEND][on_dropdown] custom_id={custom_id!r} values={inter.values!r}")
        try:
            await self._on_dropdown_inner(inter, custom_id)
        except Exception as e:
            import traceback
            print(f"[SEND][ERRO dropdown] custom_id={custom_id!r} | {e}")
            traceback.print_exc()

    async def _on_dropdown_inner(self, inter: disnake.MessageInteraction, custom_id: str):
        # Handler para seleção de canal
        if custom_id.startswith("select_channel:"):
            product_id = custom_id.split(":", 1)[1]
            # ChannelSelect retorna IDs diretamente, não objetos
            channel_id = int(inter.values[0]) if inter.values else None
            
            if not channel_id:
                await inter.response.send_message(
                    f"{emoji.wrong} Selecione um canal válido!",
                    ephemeral=True
                )
                return
            
            # Mostrar seletor de modo
            await inter.response.defer(ephemeral=True)
            container = self._build_mode_selector(product_id, str(channel_id))
            await inter.edit_original_message(
                components=[container],
                flags=disnake.MessageFlags(is_components_v2=True)
            )
            return


def setup(bot: commands.Bot):
    bot.add_cog(SendProduct(bot))