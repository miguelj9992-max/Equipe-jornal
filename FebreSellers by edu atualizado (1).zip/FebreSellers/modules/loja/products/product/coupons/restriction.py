"""
Restrição de cupons por cargo.

Cada cupom pode ser:
- Público: qualquer usuário pode utilizar (comportamento padrão, já existente).
- Restrito por cargo: só quem possuir pelo menos um dos cargos selecionados
  em `allowed_roles` pode utilizar o cupom.

Dados salvos por cupom (dentro de loja_products[product_id]["cupons"][coupon_id]):
- restricted: bool
- allowed_roles: list[int]  (IDs dos cargos autorizados)

A validação em si (bloquear a compra quando o usuário não tem o cargo) fica
em modules/loja/cart/coupon_validator.py, reaproveitando o mesmo fluxo que já
valida cupom ativo/expirado/limite de usos/valor mínimo e máximo.
"""

import disnake

from disnake.ext import commands
from functions.database import database as db
from functions.emoji import emoji
from functions.message import message, embed_message
from functions.text_utils import safe_textdisplay
from functions.loja_products import container_kwargs_for_product, embed_kwargs_for_product

from .configurar import ConfigurarCupom


def _ensure_coupon_restriction_structure(coupon: dict) -> dict:
    """Garante que cupons antigos (criados antes dessa feature) tenham as
    chaves de restrição, sem quebrar nada que já exista."""
    coupon.setdefault("restricted", False)
    allowed_roles = coupon.get("allowed_roles")
    if not isinstance(allowed_roles, list):
        allowed_roles = []
    coupon["allowed_roles"] = allowed_roles
    return coupon


def _role_defaults(guild: disnake.Guild, role_ids: list) -> list:
    defaults = []
    if not guild:
        return defaults
    for rid in (role_ids or []):
        try:
            role = guild.get_role(int(rid))
            if role is None:
                continue
            defaults.append(disnake.SelectDefaultValue(id=role.id, type=disnake.SelectDefaultValueType.role))
        except Exception:
            continue
    return defaults


def _get_coupon(product_id: str, coupon_id: str):
    products = db.get_document("loja_products")
    product = (products or {}).get(product_id) or {}
    coupon = (product.get("cupons") or {}).get(coupon_id)
    return products, product, coupon


class ConfigurarRestricaoCupom(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @staticmethod
    def panel(inter: disnake.MessageInteraction, product_id: str, coupon_id: str) -> dict:
        mode = db.get_document("custom_mode").get("mode")
        if mode == "embed":
            return ConfigurarRestricaoCupom._panel_embed(inter, product_id, coupon_id)
        return ConfigurarRestricaoCupom._panel_components(inter, product_id, coupon_id)

    @staticmethod
    def _panel_components(inter: disnake.MessageInteraction, product_id: str, coupon_id: str) -> dict:
        products = db.get_document("loja_products")
        product = products.get(product_id) or {}
        coupon = (product.get("cupons") or {}).get(coupon_id) or {}
        coupon = _ensure_coupon_restriction_structure(coupon)

        restricted = coupon.get("restricted", False)
        allowed_roles = coupon.get("allowed_roles", [])

        coupon_name = safe_textdisplay(coupon.get("name", coupon_id), 50)
        header_text = safe_textdisplay(
            f"## \n"
            f"-# Painel > Loja > Produto > Cupom > **{coupon_name}** > Restrição por Cargo"
        )

        toggle_button = disnake.ui.Button(
            label="Restrito por Cargo" if restricted else "Público",
            emoji=emoji.lock if restricted else emoji.unlock,
            style=disnake.ButtonStyle.red if restricted else disnake.ButtonStyle.green,
            custom_id=f"Loja_ToggleRestricaoCupom:{product_id}:{coupon_id}",
        )

        role_select = disnake.ui.RoleSelect(
            placeholder="Selecione um ou mais cargos autorizados",
            custom_id=f"Loja_CupomCargosSelect:{product_id}:{coupon_id}",
            min_values=0,
            max_values=25,
            default_values=_role_defaults(inter.guild, allowed_roles) or None,
            disabled=not restricted,
        )

        status_text = (
            f"**Tipo atual:** `{'Restrito por Cargo' if restricted else 'Público'}`\n"
            f"**Cargos autorizados:** `{len(allowed_roles)}` selecionado(s)"
        )

        return {"components": [
            disnake.ui.Container(
                disnake.ui.TextDisplay(header_text),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(
                    "Defina se este cupom é público (qualquer usuário pode usar) ou "
                    "restrito a cargos específicos do servidor.\n\n"
                    "Se restrito, selecione abaixo quais cargos podem utilizá-lo. Basta o "
                    "usuário possuir **pelo menos um** dos cargos selecionados."
                ),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(safe_textdisplay(status_text)),
                disnake.ui.ActionRow(toggle_button),
                disnake.ui.ActionRow(role_select),
                **container_kwargs_for_product(product)
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Voltar",
                    style=disnake.ButtonStyle.grey,
                    emoji=emoji.back,
                    custom_id=f"Loja_CupomRestricaoVoltar:{product_id}:{coupon_id}",
                )
            ),
        ]}

    @staticmethod
    def _panel_embed(inter: disnake.MessageInteraction, product_id: str, coupon_id: str) -> dict:
        products = db.get_document("loja_products")
        product = products.get(product_id) or {}
        coupon = (product.get("cupons") or {}).get(coupon_id) or {}
        coupon = _ensure_coupon_restriction_structure(coupon)

        restricted = coupon.get("restricted", False)
        allowed_roles = coupon.get("allowed_roles", [])

        embed_description = (
            f"-# Painel > Loja > Produto > Cupom > **{coupon.get('name', coupon_id)}** > Restrição por Cargo\n\n"
            "Defina se este cupom é público ou restrito a cargos específicos.\n\n"
            f"**Tipo atual:** `{'Restrito por Cargo' if restricted else 'Público'}`\n"
            f"**Cargos autorizados:** `{len(allowed_roles)}` selecionado(s)\n"
        )

        embed = disnake.Embed(description=embed_description, **embed_kwargs_for_product(product))

        toggle_button = disnake.ui.Button(
            label="Restrito por Cargo" if restricted else "Público",
            emoji=emoji.lock if restricted else emoji.unlock,
            style=disnake.ButtonStyle.red if restricted else disnake.ButtonStyle.green,
            custom_id=f"Loja_ToggleRestricaoCupom:{product_id}:{coupon_id}",
        )

        components = [
            disnake.ui.ActionRow(toggle_button),
            disnake.ui.ActionRow(
                disnake.ui.RoleSelect(
                    placeholder="Selecione um ou mais cargos autorizados",
                    custom_id=f"Loja_CupomCargosSelect:{product_id}:{coupon_id}",
                    min_values=0,
                    max_values=25,
                    default_values=_role_defaults(inter.guild, allowed_roles) or None,
                    disabled=not restricted,
                )
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Voltar",
                    style=disnake.ButtonStyle.grey,
                    emoji=emoji.back,
                    custom_id=f"Loja_CupomRestricaoVoltar:{product_id}:{coupon_id}",
                )
            ),
        ]

        return {"embed": embed, "components": components}

    # --- Listeners ---

    @commands.Cog.listener("on_button_click")
    async def on_button_click(self, inter: disnake.MessageInteraction):
        custom_id = inter.component.custom_id or ""

        if custom_id.startswith("Loja_RestricaoCupom:"):
            _, product_id, coupon_id = custom_id.split(":", 2)
            mode = db.get_document("custom_mode").get("mode")
            await (embed_message if mode == "embed" else message).wait(inter, send=False)
            panel_data = ConfigurarRestricaoCupom.panel(inter, product_id, coupon_id)
            if mode == "embed":
                await inter.edit_original_message(content=None, **panel_data)
            else:
                await inter.edit_original_message(**panel_data)

        elif custom_id.startswith("Loja_ToggleRestricaoCupom:"):
            _, product_id, coupon_id = custom_id.split(":", 2)
            products, product, coupon = _get_coupon(product_id, coupon_id)
            if coupon is None:
                return

            coupon = _ensure_coupon_restriction_structure(coupon)
            coupon["restricted"] = not bool(coupon.get("restricted", False))
            coupon["updated_at"] = int(disnake.utils.utcnow().timestamp())

            product.setdefault("cupons", {})[coupon_id] = coupon
            products[product_id] = product
            db.save_document("loja_products", products)

            mode = db.get_document("custom_mode").get("mode")
            await (embed_message if mode == "embed" else message).wait(inter, send=False)
            panel_data = ConfigurarRestricaoCupom.panel(inter, product_id, coupon_id)
            if mode == "embed":
                await inter.edit_original_message(content=None, **panel_data)
            else:
                await inter.edit_original_message(**panel_data)

        elif custom_id.startswith("Loja_CupomRestricaoVoltar:"):
            _, product_id, coupon_id = custom_id.split(":", 2)
            mode = db.get_document("custom_mode").get("mode")
            await (embed_message if mode == "embed" else message).wait(inter, send=False)
            panel_data = ConfigurarCupom.panel(inter, product_id, coupon_id)
            if mode == "embed":
                await inter.edit_original_message(content=None, **panel_data)
            else:
                await inter.edit_original_message(**panel_data)

    @commands.Cog.listener("on_dropdown")
    async def on_dropdown(self, inter: disnake.MessageInteraction):
        custom_id = inter.component.custom_id or ""
        if not custom_id.startswith("Loja_CupomCargosSelect:"):
            return

        mode = db.get_document("custom_mode").get("mode")
        await (embed_message if mode == "embed" else message).wait(inter, send=False)

        _, product_id, coupon_id = custom_id.split(":", 2)
        products, product, coupon = _get_coupon(product_id, coupon_id)
        if coupon is None:
            return

        coupon = _ensure_coupon_restriction_structure(coupon)
        coupon["allowed_roles"] = [int(v) for v in (inter.values or [])]
        coupon["updated_at"] = int(disnake.utils.utcnow().timestamp())

        product.setdefault("cupons", {})[coupon_id] = coupon
        products[product_id] = product
        db.save_document("loja_products", products)

        panel_data = ConfigurarRestricaoCupom.panel(inter, product_id, coupon_id)
        if mode == "embed":
            await inter.edit_original_message(content=None, **panel_data)
        else:
            await inter.edit_original_message(**panel_data)


def setup(bot: commands.Bot):
    bot.add_cog(ConfigurarRestricaoCupom(bot))