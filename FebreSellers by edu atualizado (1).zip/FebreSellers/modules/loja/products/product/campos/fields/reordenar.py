import disnake

from disnake.ext import commands
from functions.database import database as db
from functions.emoji import emoji
from functions.utils import utils
from functions.message import message, embed_message
from functions.text_utils import safe_textdisplay, safe_select_option_label, safe_select_option_description
from functions.loja_products import get_products, save_products, container_kwargs_for_product, embed_kwargs_for_product


# Sessões temporárias de reordenação (não persistem no banco até o usuário
# clicar em "Salvar Alterações"). Chave: (product_id, user_id)
_sessions: dict[tuple[str, int], dict] = {}


def _session_key(product_id: str, user_id: int) -> tuple[str, int]:
    return (product_id, user_id)


def _start_session(product_id: str, user_id: int) -> dict:
    product = get_products().get(product_id) or {}
    order = list((product.get("campos") or {}).keys())
    session = {"order": order, "selected": None}
    _sessions[_session_key(product_id, user_id)] = session
    return session


def _get_session(product_id: str, user_id: int) -> dict:
    key = _session_key(product_id, user_id)
    if key not in _sessions:
        return _start_session(product_id, user_id)
    return _sessions[key]


def _clear_session(product_id: str, user_id: int) -> None:
    _sessions.pop(_session_key(product_id, user_id), None)


class ReordenarCampos(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ---------------- Painel ----------------
    @staticmethod
    def panel(inter: disnake.MessageInteraction, product_id: str, reset: bool = False) -> dict:
        if reset:
            _start_session(product_id, inter.user.id)
        mode = db.get_document("custom_mode").get("mode")
        if mode == "embed":
            return ReordenarCampos._panel_embed(inter, product_id)
        return ReordenarCampos._panel_components(inter, product_id)

    @staticmethod
    def _build_shared(inter: disnake.MessageInteraction, product_id: str) -> dict:
        products = get_products()
        product = products.get(product_id) or {}
        campos = product.get("campos") or {}

        session = _get_session(product_id, inter.user.id)
        # Remove da ordem campos que possam ter sido apagados enquanto a sessão estava aberta
        order = [field_id for field_id in session["order"] if field_id in campos]
        # Adiciona campos criados enquanto a sessão estava aberta
        for field_id in campos.keys():
            if field_id not in order:
                order.append(field_id)
        session["order"] = order

        selected = session.get("selected")
        if selected not in order:
            selected = None
            session["selected"] = None

        lines = []
        options = []
        for idx, field_id in enumerate(order, start=1):
            campo = campos.get(field_id) or {}
            name = campo.get("name") or field_id
            price = utils.format_price_brl(float(campo.get("price") or 0.0))
            is_selected = field_id == selected

            if is_selected:
                lines.append(f"**{emoji.arrow} {idx}. {name} - {price}**")
            else:
                lines.append(f"-# {idx}. {name} - {price}")

            options.append(disnake.SelectOption(
                label=safe_select_option_label(f"{idx}. {name}"),
                value=field_id,
                description=safe_select_option_description(price),
                default=is_selected,
            ))

        if not options:
            options.append(disnake.SelectOption(label="Nenhum campo encontrado", value="disabled"))

        select = disnake.ui.StringSelect(
            placeholder="Selecione um campo para mover",
            options=options,
            custom_id=f"Loja_ReordenarCampos_Select:{product_id}",
            disabled=not order,
        )

        selected_index = order.index(selected) if selected in order else -1
        pode_mover_cima = selected_index > 0
        pode_mover_baixo = 0 <= selected_index < len(order) - 1

        order_text = "\n".join(lines) if lines else "`Nenhum campo encontrado`"
        product_name = safe_textdisplay(product.get("name") or product_id, 50)

        return {
            "product": product,
            "product_name": product_name,
            "order_text": order_text,
            "select": select,
            "pode_mover_cima": pode_mover_cima,
            "pode_mover_baixo": pode_mover_baixo,
        }

    @staticmethod
    def _panel_components(inter: disnake.MessageInteraction, product_id: str) -> dict:
        data = ReordenarCampos._build_shared(inter, product_id)
        container_kwargs = container_kwargs_for_product(data["product"])

        header_text = safe_textdisplay(
            f"## \n-# Painel > Loja > {data['product_name']} > Campos > **Reordenar**"
        )

        return {"components": [
            disnake.ui.Container(
                disnake.ui.TextDisplay(header_text),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay("**Ordem Atual**"),
                disnake.ui.TextDisplay(safe_textdisplay(data["order_text"])),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay("-# Selecione um campo abaixo e use os botões para reordenar."),
                disnake.ui.ActionRow(data["select"]),
                disnake.ui.ActionRow(
                    disnake.ui.Button(label="Mover para cima", emoji=emoji.arrow_up, style=disnake.ButtonStyle.grey, custom_id=f"Loja_ReordenarMoverCima:{product_id}", disabled=not data["pode_mover_cima"]),
                    disnake.ui.Button(label="Mover para baixo", emoji=emoji.arrow_downward, style=disnake.ButtonStyle.grey, custom_id=f"Loja_ReordenarMoverBaixo:{product_id}", disabled=not data["pode_mover_baixo"]),
                ),
                disnake.ui.ActionRow(
                    disnake.ui.Button(label="Salvar Alterações", emoji=emoji.save, style=disnake.ButtonStyle.green, custom_id=f"Loja_ReordenarSalvar:{product_id}"),
                    disnake.ui.Button(label="Voltar", emoji=emoji.back, style=disnake.ButtonStyle.grey, custom_id=f"Loja_ReordenarVoltar:{product_id}"),
                ),
                **container_kwargs,
            ),
        ]}

    @staticmethod
    def _panel_embed(inter: disnake.MessageInteraction, product_id: str) -> dict:
        data = ReordenarCampos._build_shared(inter, product_id)
        embed_kwargs = embed_kwargs_for_product(data["product"])

        embed = disnake.Embed(
            description=(
                f"-# Painel > Loja > {data['product_name']} > **Campos > Reordenar**\n\n"
                f"**Ordem Atual**\n{data['order_text']}\n\n" 
                f"-# Selecione um campo abaixo e use os botões para reordenar."
            ),
            **embed_kwargs,
        )

        components = [
            disnake.ui.ActionRow(data["select"]),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Mover para cima", emoji=emoji.arrow_up, style=disnake.ButtonStyle.grey, custom_id=f"Loja_ReordenarMoverCima:{product_id}", disabled=not data["pode_mover_cima"]),
                disnake.ui.Button(label="Mover para baixo", emoji=emoji.arrow_downward, style=disnake.ButtonStyle.grey, custom_id=f"Loja_ReordenarMoverBaixo:{product_id}", disabled=not data["pode_mover_baixo"]),
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Salvar Alterações", emoji=emoji.save, style=disnake.ButtonStyle.green, custom_id=f"Loja_ReordenarSalvar:{product_id}"),
                disnake.ui.Button(label="Voltar", emoji=emoji.back, style=disnake.ButtonStyle.grey, custom_id=f"Loja_ReordenarVoltar:{product_id}"),
            ),
        ]
        return {"embed": embed, "components": components}

    # ---------------- Handlers ----------------
    async def _render(self, inter: disnake.MessageInteraction, product_id: str, reset: bool = False):
        mode = db.get_document("custom_mode").get("mode")
        await (embed_message if mode == "embed" else message).wait(inter, send=False)
        panel_data = ReordenarCampos.panel(inter, product_id, reset=reset)
        if "embed" in panel_data:
            await inter.edit_original_message(content=None, **panel_data)
        else:
            await inter.edit_original_message(**panel_data)

    @commands.Cog.listener("on_button_click")
    async def on_button_click(self, inter: disnake.MessageInteraction):
        custom_id = inter.component.custom_id or ""

        if custom_id.startswith("Loja_ReordenarCampos:"):
            product_id = custom_id.split(":", 1)[1]
            await self._render(inter, product_id, reset=True)
            return

        if custom_id.startswith("Loja_ReordenarMoverCima:") or custom_id.startswith("Loja_ReordenarMoverBaixo:"):
            direction = "up" if custom_id.startswith("Loja_ReordenarMoverCima:") else "down"
            product_id = custom_id.split(":", 1)[1]

            session = _get_session(product_id, inter.user.id)
            order = session["order"]
            selected = session.get("selected")
            if selected in order:
                idx = order.index(selected)
                target = idx - 1 if direction == "up" else idx + 1
                if 0 <= target < len(order):
                    order[idx], order[target] = order[target], order[idx]

            await self._render(inter, product_id)
            return

        if custom_id.startswith("Loja_ReordenarSalvar:"):
            product_id = custom_id.split(":", 1)[1]
            session = _get_session(product_id, inter.user.id)

            products = get_products()
            product = products.get(product_id) or {}
            campos = product.get("campos") or {}
            order = [field_id for field_id in session["order"] if field_id in campos]
            for field_id in campos.keys():
                if field_id not in order:
                    order.append(field_id)

            if order:
                product["campos"] = {field_id: campos[field_id] for field_id in order}
                products[product_id] = product
                save_products(products)

                from modules.loja.products.product.edit import sync_product_messages_silently
                await sync_product_messages_silently(inter.client, product_id)

            _clear_session(product_id, inter.user.id)

            mode = db.get_document("custom_mode").get("mode")
            await (embed_message if mode == "embed" else message).wait(inter, send=False)
            from ..cog import GerenciarCamposCategorias
            panel_data = GerenciarCamposCategorias(inter.bot).panel(inter, product_id)
            if "embed" in panel_data:
                await inter.edit_original_message(content=None, **panel_data)
            else:
                await inter.edit_original_message(**panel_data)
            return

        if custom_id.startswith("Loja_ReordenarVoltar:"):
            product_id = custom_id.split(":", 1)[1]
            _clear_session(product_id, inter.user.id)

            mode = db.get_document("custom_mode").get("mode")
            await (embed_message if mode == "embed" else message).wait(inter, send=False)
            from ..cog import GerenciarCamposCategorias
            panel_data = GerenciarCamposCategorias(inter.bot).panel(inter, product_id)
            if "embed" in panel_data:
                await inter.edit_original_message(content=None, **panel_data)
            else:
                await inter.edit_original_message(**panel_data)
            return

    @commands.Cog.listener("on_dropdown")
    async def on_dropdown(self, inter: disnake.MessageInteraction):
        custom_id = inter.component.custom_id or ""

        if custom_id.startswith("Loja_ReordenarCampos_Select:"):
            product_id = custom_id.split(":", 1)[1]
            field_id = inter.values[0]
            if field_id == "disabled":
                return

            session = _get_session(product_id, inter.user.id)
            session["selected"] = field_id

            await self._render(inter, product_id)
            return


def setup(bot: commands.Bot):
    bot.add_cog(ReordenarCampos(bot))