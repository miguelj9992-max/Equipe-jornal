import disnake

from disnake.ext import commands
from functions.database import database as db
from functions.emoji import emoji
from functions.message import message, embed_message
from functions.utils import utils
from functions.text_utils import safe_textdisplay, safe_select_option_label, safe_select_option_description
from functions.loja_products import get_product, container_kwargs_for_product, embed_kwargs_for_product, move_field


def _order_list_text(product: dict, field_ids: list[str], selected_field_id: str | None) -> str:
    """Monta o texto com a ordem atual dos campos (sem bloco de código)."""
    campos = product.get("campos") or {}
    if not field_ids:
        return "-# Nenhum campo cadastrado."

    lines = []
    for i, fid in enumerate(field_ids, 1):
        campo = campos.get(fid) or {}
        name = campo.get("name", fid)
        price = float(campo.get("price") or 0.0)
        marker = "➜ " if fid == selected_field_id else ""
        lines.append(f"{marker}{i}. {fid} - {name} - {utils.format_price_brl(price)}")
    return "\n".join(lines)


def _select_options(product: dict, field_ids: list[str], selected_field_id: str | None) -> list[disnake.SelectOption]:
    campos = product.get("campos") or {}
    options = []
    for fid in field_ids:
        campo = campos.get(fid) or {}
        name = campo.get("name") or fid
        label = safe_select_option_label(name)
        description = safe_select_option_description(f"ID: {fid}")
        options.append(
            disnake.SelectOption(
                label=label,
                value=fid,
                description=description,
                default=(fid == selected_field_id),
            )
        )
    if not options:
        options.append(disnake.SelectOption(label="Nenhum campo encontrado", value="disabled"))
    return options


def panel(inter: disnake.MessageInteraction, product_id: str, selected_field_id: str | None = None) -> dict:
    mode = db.get_document("custom_mode").get("mode")
    if mode == "embed":
        return _panel_embed(inter, product_id, selected_field_id)
    return _panel_components(inter, product_id, selected_field_id)


def _panel_components(inter: disnake.MessageInteraction, product_id: str, selected_field_id: str | None = None) -> dict:
    product = get_product(product_id)
    campos = product.get("campos") or {}
    field_ids = list(campos.keys())

    if selected_field_id and selected_field_id not in field_ids:
        selected_field_id = None

    product_name = safe_textdisplay(product.get("name") or product_id, 50)
    header_text = safe_textdisplay(f"## \n-# Painel > Loja > {product_name} > Campos > **Reordenar**")
    order_text = _order_list_text(product, field_ids, selected_field_id)

    select = disnake.ui.StringSelect(
        placeholder="Selecione um campo para reordenar",
        options=_select_options(product, field_ids, selected_field_id),
        custom_id=f"Loja_ReordenarCampos_Select:{product_id}",
        disabled=not field_ids,
    )

    index = field_ids.index(selected_field_id) if selected_field_id in field_ids else -1
    pode_mover_cima = index > 0
    pode_mover_baixo = 0 <= index < len(field_ids) - 1
    sel = selected_field_id or "none"

    components = [
        disnake.ui.Container(
            disnake.ui.TextDisplay(header_text),
            disnake.ui.Separator(),
            disnake.ui.TextDisplay(
                "Selecione um campo e use os botões para movê-lo para cima ou para baixo na ordem.\n"
                "-# As alterações são salvas automaticamente durante a reordenação."
            ),
            disnake.ui.Separator(),
            disnake.ui.TextDisplay(f"**Ordem Atual**\n{order_text}"),
            disnake.ui.Separator(),
            disnake.ui.ActionRow(select),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Mover para Cima", style=disnake.ButtonStyle.blurple, emoji=emoji.arrow_up, custom_id=f"Loja_ReordenarCampos_Cima:{product_id}:{sel}", disabled=not pode_mover_cima),
                disnake.ui.Button(label="Mover para Baixo", style=disnake.ButtonStyle.blurple, emoji=emoji.arrow_downward, custom_id=f"Loja_ReordenarCampos_Baixo:{product_id}:{sel}", disabled=not pode_mover_baixo),
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Salvar Ordem", style=disnake.ButtonStyle.green, emoji=emoji.correct, custom_id=f"Loja_ReordenarCampos_Salvar:{product_id}"),
                disnake.ui.Button(label="Cancelar", style=disnake.ButtonStyle.red, emoji=emoji.wrong, custom_id=f"Loja_ReordenarCampos_Cancelar:{product_id}"),
            ),
            **container_kwargs_for_product(product)
        ),
    ]
    return {"components": components}


def _panel_embed(inter: disnake.MessageInteraction, product_id: str, selected_field_id: str | None = None) -> dict:
    product = get_product(product_id)
    campos = product.get("campos") or {}
    field_ids = list(campos.keys())

    if selected_field_id and selected_field_id not in field_ids:
        selected_field_id = None

    product_name = product.get("name") or product_id
    order_text = _order_list_text(product, field_ids, selected_field_id)

    description = safe_textdisplay(
        f"-# Painel > Loja > {product_name} > Campos > **Reordenar**\n\n"
        f"Selecione um campo e use os botões para movê-lo para cima ou para baixo na ordem.\n"
        f"-# As alterações são salvas automaticamente durante a reordenação.\n\n"
        f"**Ordem Atual**\n{order_text}"
    )

    embed = disnake.Embed(description=description, **embed_kwargs_for_product(product))

    select = disnake.ui.StringSelect(
        placeholder="Selecione um campo para reordenar",
        options=_select_options(product, field_ids, selected_field_id),
        custom_id=f"Loja_ReordenarCampos_Select:{product_id}",
        disabled=not field_ids,
    )

    index = field_ids.index(selected_field_id) if selected_field_id in field_ids else -1
    pode_mover_cima = index > 0
    pode_mover_baixo = 0 <= index < len(field_ids) - 1
    sel = selected_field_id or "none"

    components = [
        disnake.ui.ActionRow(select),
        disnake.ui.ActionRow(
            disnake.ui.Button(label="Mover para Cima", style=disnake.ButtonStyle.blurple, emoji=emoji.arrow_up, custom_id=f"Loja_ReordenarCampos_Cima:{product_id}:{sel}", disabled=not pode_mover_cima),
            disnake.ui.Button(label="Mover para Baixo", style=disnake.ButtonStyle.blurple, emoji=emoji.arrow_downward, custom_id=f"Loja_ReordenarCampos_Baixo:{product_id}:{sel}", disabled=not pode_mover_baixo),
        ),
        disnake.ui.ActionRow(
            disnake.ui.Button(label="Salvar Ordem", style=disnake.ButtonStyle.green, emoji=emoji.correct, custom_id=f"Loja_ReordenarCampos_Salvar:{product_id}"),
            disnake.ui.Button(label="Cancelar", style=disnake.ButtonStyle.red, emoji=emoji.wrong, custom_id=f"Loja_ReordenarCampos_Cancelar:{product_id}"),
        ),
    ]
    return {"embed": embed, "components": components}


async def _voltar_para_campos(inter: disnake.MessageInteraction, product_id: str):
    """Volta para o painel principal de Campos do produto."""
    mode = db.get_document("custom_mode").get("mode")
    await (embed_message if mode == "embed" else message).wait(inter, send=False)

    from .cog import GerenciarCamposCategorias
    panel_data = GerenciarCamposCategorias(inter.bot).panel(inter, product_id)
    if "embed" in panel_data:
        await inter.edit_original_message(content=None, **panel_data)
    else:
        await inter.edit_original_message(**panel_data, flags=disnake.MessageFlags(is_components_v2=True))


class ReordenarCamposCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener("on_button_click")
    async def on_button_click(self, inter: disnake.MessageInteraction):
        custom_id = inter.component.custom_id or ""

        if custom_id.startswith("Loja_ReordenarCampos:"):
            _, product_id = custom_id.split(":", 1)
            mode = db.get_document("custom_mode").get("mode")
            await (embed_message if mode == "embed" else message).wait(inter, send=False)

            panel_data = panel(inter, product_id)
            if "embed" in panel_data:
                await inter.edit_original_message(content=None, **panel_data)
            else:
                await inter.edit_original_message(**panel_data, flags=disnake.MessageFlags(is_components_v2=True))
            return

        if custom_id.startswith("Loja_ReordenarCampos_Cima:") or custom_id.startswith("Loja_ReordenarCampos_Baixo:"):
            direction = "up" if custom_id.startswith("Loja_ReordenarCampos_Cima:") else "down"
            _, rest = custom_id.split(":", 1)
            product_id, field_id = rest.split(":", 1)

            mode = db.get_document("custom_mode").get("mode")
            await (embed_message if mode == "embed" else message).wait(inter, send=False)

            selected = None
            if field_id and field_id != "none":
                selected = field_id
                moved = move_field(product_id, field_id, direction)
                if moved:
                    # Sincronizar silenciosamente todas as mensagens do produto
                    from modules.loja.products.product.edit import sync_product_messages_silently
                    await sync_product_messages_silently(inter.client, product_id)

            panel_data = panel(inter, product_id, selected_field_id=selected)
            if "embed" in panel_data:
                await inter.edit_original_message(content=None, **panel_data)
            else:
                await inter.edit_original_message(**panel_data, flags=disnake.MessageFlags(is_components_v2=True))
            return

        if custom_id.startswith("Loja_ReordenarCampos_Salvar:") or custom_id.startswith("Loja_ReordenarCampos_Cancelar:"):
            _, product_id = custom_id.split(":", 1)
            await _voltar_para_campos(inter, product_id)
            return

    @commands.Cog.listener("on_dropdown")
    async def on_dropdown(self, inter: disnake.MessageInteraction):
        custom_id = inter.component.custom_id or ""
        if custom_id.startswith("Loja_ReordenarCampos_Select:"):
            _, product_id = custom_id.split(":", 1)
            field_id = inter.values[0] if inter.values else None
            if field_id == "disabled":
                field_id = None

            mode = db.get_document("custom_mode").get("mode")
            await (embed_message if mode == "embed" else message).wait(inter, send=False)

            panel_data = panel(inter, product_id, selected_field_id=field_id)
            if "embed" in panel_data:
                await inter.edit_original_message(content=None, **panel_data)
            else:
                await inter.edit_original_message(**panel_data, flags=disnake.MessageFlags(is_components_v2=True))
            return


def setup(bot: commands.Bot):
    bot.add_cog(ReordenarCamposCog(bot))