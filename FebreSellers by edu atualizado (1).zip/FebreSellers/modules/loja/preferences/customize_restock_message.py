"""
Sistema de personalização de mensagens de reestoque.

Permite que o usuário customize a mensagem que é enviada quando um produto
recebe novos itens de estoque.
"""

import disnake
from disnake.ext import commands

from functions.database import database as db
from functions.emoji import emoji
from functions.message import message, embed_message


class RestockMessageModal(disnake.ui.Modal):
    """Modal para personalizar a mensagem de reestoque"""

    def __init__(self, current_message: str = ""):
        components = [
            disnake.ui.TextInput(
                label="Título da Mensagem de Reestoque",
                placeholder="Ex: RESTOCK! O produto {product_name} chegou!",
                custom_id="restock_title",
                style=disnake.TextInputStyle.paragraph,
                max_length=1000,
                value=current_message or "RESTOCK! O produto {product_name} acabou de receber novos itens!",
            ),
        ]
        super().__init__(
            title="Personalizar Mensagem de Reestoque",
            components=components,
            custom_id="restock_message_modal"
        )

    async def callback(self, inter: disnake.ModalInteraction):
        try:
            message_text = inter.text_values.get("restock_title", "").strip()

            if not message_text:
                await inter.response.send_message(
                    f"{emoji.wrong} A mensagem não pode estar vazia!",
                    ephemeral=True
                )
                return

            # Validar se contém a variável {product_name}
            if "{product_name}" not in message_text:
                await inter.response.send_message(
                    f"{emoji.wrong} A mensagem deve conter `{{product_name}}` para inserir o nome do produto!",
                    ephemeral=True
                )
                return

            prefs = db.get_document("loja_preferences") or {}
            if not isinstance(prefs, dict):
                prefs = {}

            prefs["restock_custom_message"] = message_text
            db.save_document("loja_preferences", prefs)

            await inter.response.send_message(
                f"{emoji.correct} Mensagem de reestoque personalizada com sucesso!\n\n"
                f"**Prévia:** {message_text.replace('{product_name}', 'Exemplo Produto')}",
                ephemeral=True
            )

            try:
                from modules.loja.preferences.canal_reestoque import RestockPreferences
                mode = db.get_document("custom_mode").get("mode")
                await inter.response.defer()
                panel = RestockPreferences.panel(inter)
                if mode == "embed":
                    await inter.edit_original_message(content=None, **panel)
                else:
                    await inter.edit_original_message(**panel, flags=disnake.MessageFlags(is_components_v2=True))
            except:
                pass
        except Exception as e:
            if not inter.response.is_done():
                await inter.response.send_message(
                    f"{emoji.wrong} Erro ao processar modal: {str(e)}",
                    ephemeral=True
                )


class RestockMessageCustomization(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener("on_button_click")
    async def on_button_click(self, inter: disnake.MessageInteraction):
        if inter.component.custom_id == "Loja_Pref_Restock_CustomizeMessage":
            prefs = db.get_document("loja_preferences") or {}
            current_message = prefs.get(
                "restock_custom_message",
                "RESTOCK! O produto {product_name} acabou de receber novos itens!"
            )
            await inter.response.send_modal(RestockMessageModal(current_message))


def setup(bot: commands.Bot):
    bot.add_cog(RestockMessageCustomization(bot))