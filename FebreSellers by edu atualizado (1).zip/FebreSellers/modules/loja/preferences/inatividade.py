"""
Preferência: Fechamento automático de carrinhos por inatividade.

Permite ativar/desativar o sistema e definir o tempo (em minutos) sem
nenhuma interação do usuário no carrinho a partir do qual ele deve ser
fechado automaticamente. Segue o mesmo padrão de armazenamento das demais
preferências da loja (documento "loja_preferences"), igual ao usado em
temp_cart.py para "cart_duration_minutes".

A aplicação da configuração (o fechamento em si) é feita pela task
`close_inactive_carts` em modules/loja/cart/cleanup.py.
"""

import disnake
from disnake.ext import commands

from functions.database import database as db
from functions.emoji import emoji
from functions.message import message, embed_message

MINUTE_OPTIONS = (5, 10, 15, 20, 30, 45, 60, 90)
DEFAULT_MINUTES = 15


def _get_prefs():
    prefs = db.get_document("loja_preferences") or {}
    if not isinstance(prefs, dict):
        prefs = {}
    prefs.setdefault("cart_inactivity_enabled", False)
    prefs.setdefault("cart_inactivity_minutes", DEFAULT_MINUTES)
    return prefs


class CartInactivityPreferences(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @staticmethod
    def panel(inter: disnake.MessageInteraction) -> dict:
        mode = db.get_document("custom_mode").get("mode")
        return (
            CartInactivityPreferences._panel_embed(inter)
            if mode == "embed"
            else CartInactivityPreferences._panel_components(inter)
        )

    @staticmethod
    def _status_text(prefs: dict) -> str:
        enabled = prefs.get("cart_inactivity_enabled", False)
        minutes = int(prefs.get("cart_inactivity_minutes", DEFAULT_MINUTES))

        text = f"{emoji.on if enabled else emoji.off} **Status:** `{'Ativado' if enabled else 'Desativado'}`\n"
        if enabled:
            text += f"-# Carrinhos abertos sem nenhuma interação por `{minutes} minutos` serão fechados automaticamente.\n"
        else:
            text += "-# Carrinhos abertos não serão fechados automaticamente por inatividade.\n"
        return text

    @staticmethod
    def _panel_components(inter: disnake.MessageInteraction) -> dict:
        colors = db.get_document("custom_colors") or {}
        primary_color_hex = colors.get("primary")
        prefs = _get_prefs()
        enabled = prefs.get("cart_inactivity_enabled", False)
        minutes = int(prefs.get("cart_inactivity_minutes", DEFAULT_MINUTES))

        container_kwargs = {}
        if primary_color_hex:
            container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))

        options = [
            disnake.SelectOption(label=f"{m} minutos", value=str(m), default=(minutes == m))
            for m in MINUTE_OPTIONS
        ]

        return {"components": [
            disnake.ui.Container(
                disnake.ui.TextDisplay(
                    f"## \n"
                    "-# Painel > Loja > Preferências > **Fechamento por Inatividade**"
                ),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(
                    "Feche automaticamente carrinhos abertos (ainda montando o pedido, "
                    "antes de ir para pagamento) quando o cliente ficar um tempo sem "
                    "interagir com eles.\n\n" + CartInactivityPreferences._status_text(prefs)
                ),
                disnake.ui.Separator(),
                disnake.ui.ActionRow(
                    disnake.ui.Button(
                        label="Ativar" if not enabled else "Desativar",
                        emoji=emoji.power,
                        style=disnake.ButtonStyle.green if not enabled else disnake.ButtonStyle.red,
                        custom_id="Loja_Pref_Inactivity_Toggle"
                    )
                ),
                disnake.ui.ActionRow(
                    disnake.ui.StringSelect(
                        custom_id="Loja_Pref_Inactivity_Select",
                        placeholder="Selecione o tempo de inatividade",
                        options=options,
                        min_values=1,
                        max_values=1,
                        disabled=not enabled,
                    )
                ),
                **container_kwargs
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="Loja_Preferencias")
            )
        ]}

    @staticmethod
    def _panel_embed(inter: disnake.MessageInteraction) -> dict:
        colors = db.get_document("custom_colors") or {}
        primary_color_hex = colors.get("primary")
        prefs = _get_prefs()
        enabled = prefs.get("cart_inactivity_enabled", False)
        minutes = int(prefs.get("cart_inactivity_minutes", DEFAULT_MINUTES))

        embed = disnake.Embed(
            title="Fechamento por Inatividade",
            description=(
                "-# Painel > Loja > Preferências > **Fechamento por Inatividade**\n\n"
                "Feche automaticamente carrinhos abertos (ainda montando o pedido, "
                "antes de ir para pagamento) quando o cliente ficar um tempo sem "
                "interagir com eles.\n\n" + CartInactivityPreferences._status_text(prefs)
            )
        )
        if primary_color_hex:
            embed.color = int(primary_color_hex.replace("#", ""), 16)

        options = [
            disnake.SelectOption(label=f"{m} minutos", value=str(m), default=(minutes == m))
            for m in MINUTE_OPTIONS
        ]

        components = [
            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Ativar" if not enabled else "Desativar",
                    emoji=emoji.power,
                    style=disnake.ButtonStyle.green if not enabled else disnake.ButtonStyle.red,
                    custom_id="Loja_Pref_Inactivity_Toggle"
                )
            ),
            disnake.ui.ActionRow(
                disnake.ui.StringSelect(
                    custom_id="Loja_Pref_Inactivity_Select",
                    placeholder="Selecione o tempo de inatividade",
                    options=options,
                    min_values=1,
                    max_values=1,
                    disabled=not enabled,
                )
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="Loja_Preferencias")
            )
        ]
        return {"embed": embed, "components": components}

    async def _refresh(self, inter: disnake.MessageInteraction):
        mode = db.get_document("custom_mode").get("mode")
        await (embed_message if mode == "embed" else message).wait(inter, send=False)
        panel = CartInactivityPreferences.panel(inter)
        if mode == "embed":
            await inter.edit_original_message(content=None, **panel)
        else:
            await inter.edit_original_message(**panel, flags=disnake.MessageFlags(is_components_v2=True))

    @commands.Cog.listener("on_button_click")
    async def on_button_click(self, inter: disnake.MessageInteraction):
        if inter.component.custom_id == "Loja_Pref_Inactivity_Toggle":
            prefs = _get_prefs()
            prefs["cart_inactivity_enabled"] = not prefs.get("cart_inactivity_enabled", False)
            db.save_document("loja_preferences", prefs)
            await self._refresh(inter)

    @commands.Cog.listener("on_dropdown")
    async def on_dropdown(self, inter: disnake.MessageInteraction):
        if inter.component.custom_id == "Loja_Pref_Inactivity_Select":
            value = inter.values[0]
            try:
                minutes = int(value)
            except Exception:
                await inter.response.send_message("Valor inválido.", ephemeral=True)
                return

            prefs = _get_prefs()
            prefs["cart_inactivity_minutes"] = minutes
            db.save_document("loja_preferences", prefs)
            await self._refresh(inter)


def setup(bot: commands.Bot):
    bot.add_cog(CartInactivityPreferences(bot))