"""
Sistema de notificação de reestoque (RESTOCK).

Quando estoque é adicionado a um campo de produto, uma mensagem é enviada
automaticamente ao canal configurado aqui avisando que o produto recebeu
novos itens, com um botão para ir até a mensagem do produto.
"""

import disnake
from disnake.ext import commands

from functions.database import database as db
from functions.emoji import emoji
from functions.message import message, embed_message


def _get_mode() -> str:
    """Helper seguro para obter o modo de exibição (embed/components)."""
    doc = db.get_document("custom_mode") or {}
    if not isinstance(doc, dict):
        return "components"
    return doc.get("mode", "components")


class RestockChannelModal(disnake.ui.Modal):
    """Modal para selecionar o canal de reestoque"""

    def __init__(self, current_channel_id: str = ""):
        components = [
            disnake.ui.Label(
                text="Selecione o Canal de Reestoque",
                component=disnake.ui.ChannelSelect(
                    placeholder="Escolha um canal de texto",
                    custom_id="restock_channel_select",
                    channel_types=[disnake.ChannelType.text],
                    min_values=1,
                    max_values=1,
                ),
                description="Avisos de reestoque dos produtos serão enviados para este canal.",
            ),
        ]
        super().__init__(title="Configurar Canal de Reestoque", components=components, custom_id="restock_channel_modal")

    async def callback(self, inter: disnake.ModalInteraction):
        try:
            valores = inter.resolved_values
            selected = valores.get("restock_channel_select")

            if isinstance(selected, (list, tuple)):
                selected = selected[0] if selected else None
            if isinstance(selected, (str, int)):
                channel_id = int(selected)
            elif hasattr(selected, "id"):
                channel_id = int(selected.id)
            else:
                await inter.response.send_message(
                    f"{emoji.wrong} Canal inválido!",
                    ephemeral=True
                )
                return

            channel = inter.guild.get_channel(channel_id)
            if not channel:
                await inter.response.send_message(
                    f"{emoji.wrong} Canal não encontrado!",
                    ephemeral=True
                )
                return

            prefs = db.get_document("loja_preferences") or {}
            if not isinstance(prefs, dict):
                prefs = {}

            prefs["restock_channel_id"] = channel_id
            db.save_document("loja_preferences", prefs)

            # Responde a interação (única resposta permitida)
            await inter.response.send_message(
                f"{emoji.correct} Canal configurado: {channel.mention}\n"
                f"O painel de preferências foi atualizado.",
                ephemeral=True
            )

            # Atualiza a mensagem original do painel diretamente (não pela
            # resposta da interação, pois ela já foi usada acima).
            try:
                if inter.message is not None:
                    mode = _get_mode()
                    panel = RestockPreferences.panel(inter)
                    if mode == "embed":
                        await inter.message.edit(content=None, **panel)
                    else:
                        await inter.message.edit(**panel, flags=disnake.MessageFlags(is_components_v2=True))
            except Exception:
                pass
        except Exception as e:
            if not inter.response.is_done():
                await inter.response.send_message(
                    f"{emoji.wrong} Erro ao processar modal: {str(e)}",
                    ephemeral=True
                )


class RestockMessageModal(disnake.ui.Modal):
    """Modal para personalizar a mensagem de reestoque"""

    def __init__(self, current_message: str = ""):
        components = [
            disnake.ui.TextInput(
                label="Título da Mensagem de Reestoque",
                placeholder="Ex: RESTOCK! O produto {product_name} chegou!",
                custom_id="restock_title",
                style=disnake.TextInputStyle.paragraph,
                max_length=1000,
                value=current_message or "RESTOCK! O produto {product_name} acabou de receber novos itens!",
            ),
        ]
        super().__init__(
            title="Personalizar Mensagem de Reestoque",
            components=components,
            custom_id="restock_message_modal"
        )

    async def callback(self, modal_inter: disnake.ModalInteraction):
        try:
            message_text = modal_inter.text_values.get("restock_title", "").strip()

            if not message_text:
                await modal_inter.response.send_message(
                    f"{emoji.wrong} A mensagem não pode estar vazia!",
                    ephemeral=True
                )
                return

            if "{product_name}" not in message_text:
                await modal_inter.response.send_message(
                    f"{emoji.wrong} A mensagem deve conter `{{product_name}}` para inserir o nome do produto!",
                    ephemeral=True
                )
                return

            prefs = db.get_document("loja_preferences") or {}
            if not isinstance(prefs, dict):
                prefs = {}

            prefs["restock_custom_message"] = message_text
            db.save_document("loja_preferences", prefs)

            await modal_inter.response.send_message(
                f"{emoji.correct} Mensagem de reestoque personalizada com sucesso!\n\n"
                f"**Prévia:** {message_text.replace('{product_name}', 'Exemplo Produto')}",
                ephemeral=True
            )

            # Assim como no modal de canal: a resposta da interação já foi
            # usada, então editamos a mensagem original diretamente.
            try:
                if modal_inter.message is not None:
                    mode = _get_mode()
                    panel = RestockPreferences.panel(modal_inter)
                    if mode == "embed":
                        await modal_inter.message.edit(content=None, **panel)
                    else:
                        await modal_inter.message.edit(**panel, flags=disnake.MessageFlags(is_components_v2=True))
            except Exception:
                pass
        except Exception as e:
            if not modal_inter.response.is_done():
                await modal_inter.response.send_message(
                    f"{emoji.wrong} Erro ao processar modal: {str(e)}",
                    ephemeral=True
                )


class RestockPreferences(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @staticmethod
    def panel(inter: disnake.MessageInteraction) -> dict:
        mode = _get_mode()
        return RestockPreferences._panel_embed(inter) if mode == "embed" else RestockPreferences._panel_components(inter)

    @staticmethod
    def _status_text(inter: disnake.MessageInteraction) -> tuple[str, bool]:
        prefs = db.get_document("loja_preferences") or {}
        enabled = prefs.get("restock_notify_enabled", False)
        channel_id = prefs.get("restock_channel_id")

        status_text = f"{emoji.on if enabled else emoji.off} **Status:** `{'Ativado' if enabled else 'Desativado'}`\n"
        status_text += "-# Avisa automaticamente em um canal quando um produto recebe novos itens de estoque.\n"
        if enabled:
            if channel_id:
                channel = inter.guild.get_channel(int(channel_id)) if inter.guild else None
                channel_name = channel.name if channel else "Canal não encontrado"
                status_text += f"-# Canal: `#{channel_name}`\n"
            else:
                status_text += f"-# Canal: `Não configurado`\n"
        else:
            status_text += "-# Configure o canal e ative para enviar avisos de reestoque\n"

        status_text += "-# Variáveis disponíveis: `{product_name}`"

        return status_text, enabled

    @staticmethod
    def _panel_components(inter: disnake.MessageInteraction) -> dict:
        colors = db.get_document("custom_colors") or {}
        primary_color_hex = colors.get("primary")
        status_text, enabled = RestockPreferences._status_text(inter)

        container_kwargs = {}
        if primary_color_hex:
            container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))

        return {"components": [
            disnake.ui.Container(
                disnake.ui.TextDisplay(f"## \n-# Painel > Loja > Preferências > **Canal de Reestoque**"),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(status_text),
                disnake.ui.Separator(),
                disnake.ui.ActionRow(
                    disnake.ui.Button(
                        label="Ativar" if not enabled else "Desativar",
                        emoji=emoji.correct if not enabled else emoji.off,
                        style=disnake.ButtonStyle.green if not enabled else disnake.ButtonStyle.red,
                        custom_id="Loja_Pref_Restock_Toggle"
                    ),
                    disnake.ui.Button(
                        label="Configurar Canal",
                        emoji=emoji.edit,
                        style=disnake.ButtonStyle.blurple,
                        custom_id="Loja_Pref_Restock_Channel"
                    ),
                    disnake.ui.Button(
                        label="Personalizar Mensagem",
                        emoji=getattr(emoji, "message", "💬"),
                        style=disnake.ButtonStyle.blurple,
                        custom_id="Loja_Pref_Restock_CustomizeMessage"
                    )
                ),
                **container_kwargs
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="Loja_Preferencias")
            )
        ]}

    @staticmethod
    def _panel_embed(inter: disnake.MessageInteraction) -> dict:
        colors = db.get_document("custom_colors") or {}
        primary_color_hex = colors.get("primary")
        status_text, enabled = RestockPreferences._status_text(inter)

        embed = disnake.Embed(
            title="Canal de Reestoque",
            description=(
                "-# Painel > Loja > Preferências > **Canal de Reestoque**\n\n"
                f"{status_text}"
            )
        )
        if primary_color_hex:
            embed.color = int(primary_color_hex.replace("#", ""), 16)

        components = [
            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Ativar" if not enabled else "Desativar",
                    emoji=emoji.correct if not enabled else emoji.off,
                    style=disnake.ButtonStyle.green if not enabled else disnake.ButtonStyle.red,
                    custom_id="Loja_Pref_Restock_Toggle"
                ),
                disnake.ui.Button(
                    label="Configurar Canal",
                    emoji=emoji.edit,
                    style=disnake.ButtonStyle.blurple,
                    custom_id="Loja_Pref_Restock_Channel"
                ),
                disnake.ui.Button(
                    label="Personalizar Mensagem",
                    emoji=getattr(emoji, "message", "💬"),
                    style=disnake.ButtonStyle.blurple,
                    custom_id="Loja_Pref_Restock_CustomizeMessage"
                )
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="Loja_Preferencias")
            )
        ]
        return {"embed": embed, "components": components}

    @commands.Cog.listener("on_button_click")
    async def on_button_click(self, inter: disnake.MessageInteraction):
        if inter.component.custom_id == "Loja_Pref_Restock_Toggle":
            prefs = db.get_document("loja_preferences") or {}
            if not isinstance(prefs, dict):
                prefs = {}

            current = prefs.get("restock_notify_enabled", False)
            prefs["restock_notify_enabled"] = not current
            db.save_document("loja_preferences", prefs)

            mode = _get_mode()
            await inter.response.defer()
            panel = RestockPreferences.panel(inter)
            if mode == "embed":
                await inter.edit_original_message(content=None, **panel)
            else:
                await inter.edit_original_message(**panel, flags=disnake.MessageFlags(is_components_v2=True))

        elif inter.component.custom_id == "Loja_Pref_Restock_Channel":
            prefs = db.get_document("loja_preferences") or {}
            current_channel_id = str(prefs.get("restock_channel_id", ""))
            await inter.response.send_modal(RestockChannelModal(current_channel_id))

        elif inter.component.custom_id == "Loja_Pref_Restock_CustomizeMessage":
            prefs = db.get_document("loja_preferences") or {}
            current_message = prefs.get(
                "restock_custom_message",
                "RESTOCK! O produto {product_name} acabou de receber novos itens!"
            )
            await inter.response.send_modal(RestockMessageModal(current_message))

    @commands.Cog.listener("on_dropdown")
    async def on_dropdown(self, inter: disnake.MessageInteraction):
        pass


async def send_restock_notification(bot, product_id: str, field_id: str, added_count: int):
    """
    Envia o aviso de reestoque (RESTOCK!) no canal configurado nas preferências da loja.
    Chamado sempre que itens de estoque são adicionados a um campo de produto.
    """
    try:
        prefs = db.get_document("loja_preferences") or {}
        if not prefs.get("restock_notify_enabled", False):
            return

        channel_id = prefs.get("restock_channel_id")
        if not channel_id:
            return

        channel = bot.get_channel(int(channel_id))
        if channel is None:
            try:
                channel = await bot.fetch_channel(int(channel_id))
            except Exception:
                return
        if channel is None:
            return

        from modules.loja.cart.stock_manager import StockManager

        products = db.get_document("loja_products") or {}
        product = products.get(product_id) or {}
        if not product:
            return

        product_name = product.get("name", "Produto")
        campos = product.get("campos") or {}
        field = campos.get(field_id) or {}
        field_name = field.get("name", field_id)

        total_stock = StockManager.get_available_stock(product_id, field_id)
        total_text = "∞" if total_stock == 999999 else str(total_stock)

        timestamp = int(disnake.utils.utcnow().timestamp())

        # Tentar montar o link para a mensagem do produto
        product_link = None
        messages = product.get("messages") or []
        if messages:
            try:
                latest = max(messages, key=lambda m: m.get("created_at", 0))
                msg_id = latest.get("message_id")
                ch_id = latest.get("channel_id")
                gld_id = latest.get("guild_id")
                if msg_id and ch_id and gld_id:
                    product_link = f"https://discord.com/channels/{gld_id}/{ch_id}/{msg_id}"
            except Exception:
                product_link = None

        colors = db.get_document("custom_colors") or {}
        primary_color_hex = colors.get("primary")
        mode = _get_mode()

        # Obter mensagem personalizada ou usar padrão
        custom_message = prefs.get(
            "restock_custom_message",
            "RESTOCK! O produto {product_name} acabou de receber novos itens!"
        )
        title_message = custom_message.format(product_name=product_name)

        info_lines = (
            f"{emoji.flag} **Campo:** `{field_name}`\n"
            f"{emoji.cardbox} **Adicionados:** `{added_count}x`\n"
            f"{emoji.double_check} **Estoque total:** `{total_text}x`\n"
            f"{emoji.clock} **Data:** <t:{timestamp}:f> (<t:{timestamp}:R>)"
        )

        buttons = []
        if product_link:
            buttons.append(
                disnake.ui.Button(
                    label="Comprar Agora",
                    style=disnake.ButtonStyle.link,
                    url=product_link
                )
            )

        if mode == "embed":
            embed_kwargs = {}
            if primary_color_hex:
                embed_kwargs["color"] = int(primary_color_hex.replace("#", ""), 16)

            embed = disnake.Embed(
                title=title_message,
                description=info_lines,
                **embed_kwargs
            )

            kwargs = {"embed": embed}
            if buttons:
                kwargs["components"] = [disnake.ui.ActionRow(*buttons)]
            await channel.send(**kwargs)
        else:
            container_kwargs = {}
            if primary_color_hex:
                container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))

            warn_emoji = getattr(emoji, "warn", emoji.cardbox)
            container = disnake.ui.Container(
                disnake.ui.TextDisplay(f"### {warn_emoji} {title_message}"),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(info_lines),
                **container_kwargs
            )

            components = [container]
            if buttons:
                components.append(disnake.ui.ActionRow(*buttons))

            await channel.send(
                components=components,
                flags=disnake.MessageFlags(is_components_v2=True)
            )
    except Exception as e:
        print(f"[Reestoque] Falha ao enviar notificação de reestoque: {e}")


def setup(bot: commands.Bot):
    bot.add_cog(RestockPreferences(bot))