"""
Sistema de Configuração de Bancos (PIX, Inter, Nubank, LivePix)
Gerencia formas de pagamento e integrações bancárias
"""

import disnake
from disnake.ext import commands
import asyncio
import base64
import aiohttp

from functions.database import database as db
from functions.emoji import emoji
from functions.message import message, embed_message
from functions.utils import utils
from . import helpers
from .modals import PIXConfigModal, InterConfigModal, NubankConfigModal, LivePixConfigModal


class BankingCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @staticmethod
    def PainelEmbed(guild: disnake.Guild) -> tuple:
        """Retorna embed e componentes do painel de bancos"""
        mode = db.get_document("custom_mode", {}).get("mode", "components")
        if mode == "embed":
            return BankingCog._PainelEmbed_embed(guild)
        return BankingCog._PainelEmbed_components(guild)

    @staticmethod
    def _PainelEmbed_embed(guild: disnake.Guild) -> tuple:
        """Painel em modo embed (legado)"""
        embed = disnake.Embed(
            title=f"{emoji.bank} Configuração de Bancos",
            description="Gerencie suas integrações bancárias e formas de pagamento",
            color=utils.get_color("primary")
        )
        embed.set_thumbnail(url=guild.icon.url if guild.icon else "")
        
        banking_config = helpers.get_banking_config()
        enabled_banks = helpers.get_enabled_banks()
        
        # Status de cada banco
        banks_info = []
        for bank in ["pix", "inter", "nubank", "livepix"]:
            status = "✅ Ativado" if enabled_banks.get(bank, False) else "❌ Desativado"
            configured = "🔧" if banking_config.get(bank) else "❌"
            banks_info.append(f"**{bank.upper()}** {configured} - {status}")
        
        embed.add_field(
            name="Banks Status",
            value="\n".join(banks_info) if banks_info else "Nenhum banco configurado",
            inline=False
        )
        
        embed.set_footer(text=f"Guild: {guild.name}")
        
        # Componentes
        components = [
            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="PIX",
                    custom_id="Banking_PIX",
                    style=disnake.ButtonStyle.blurple,
                    emoji=emoji.credit_card
                ),
                disnake.ui.Button(
                    label="Inter",
                    custom_id="Banking_Inter",
                    style=disnake.ButtonStyle.blurple,
                    emoji=emoji.bank
                ),
                disnake.ui.Button(
                    label="Nubank",
                    custom_id="Banking_Nubank",
                    style=disnake.ButtonStyle.blurple,
                    emoji=emoji.credit_card
                ),
                disnake.ui.Button(
                    label="LivePix",
                    custom_id="Banking_LivePix",
                    style=disnake.ButtonStyle.blurple,
                    emoji=emoji.credit_card
                ),
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Voltar",
                    custom_id="Banking_VoltarPreferencias",
                    style=disnake.ButtonStyle.red,
                    emoji=emoji.back
                )
            )
        ]
        
        return embed, components

    @staticmethod
    def _PainelEmbed_components(guild: disnake.Guild) -> tuple:
        """Painel em modo components (novo)"""
        colors = db.get_document("custom_colors", {}) or {}
        primary_color_hex = colors.get("primary")
        
        container_kwargs = {}
        if primary_color_hex:
            try:
                container_kwargs["accent_colour"] = disnake.Colour(
                    int(primary_color_hex.replace("#", ""), 16)
                )
            except:
                pass

        banking_config = helpers.get_banking_config()
        enabled_banks = helpers.get_enabled_banks()
        
        # Status de cada banco
        banks_status = []
        for bank in ["pix", "inter", "nubank", "livepix"]:
            is_enabled = enabled_banks.get(bank, False)
            is_configured = bool(banking_config.get(bank))
            status = f"{'✅' if is_enabled else '❌'}"
            config_status = f"{'🔧' if is_configured else '❌'}"
            banks_status.append(f"**{bank.upper()}** {status} Config: {config_status}")

        components = {
            "components": [
                disnake.ui.Container(
                    disnake.ui.TextDisplay(f"## {emoji.bank} Bancos & Pagamentos\n-# Painel > Loja > **Bancos**"),
                    disnake.ui.Separator(),
                    disnake.ui.TextDisplay("Gerencie suas integrações bancárias e formas de pagamento."),
                    disnake.ui.TextDisplay(f"\n**Status das Integrações:**\n" + "\n".join(banks_status)),
                    disnake.ui.Separator(),
                    disnake.ui.ActionRow(
                        disnake.ui.Button(
                            label="🏦 PIX",
                            custom_id="Banking_PIX",
                            style=disnake.ButtonStyle.blurple,
                        ),
                        disnake.ui.Button(
                            label="🏦 Inter",
                            custom_id="Banking_Inter",
                            style=disnake.ButtonStyle.blurple,
                        ),
                        disnake.ui.Button(
                            label="🏦 Nubank",
                            custom_id="Banking_Nubank",
                            style=disnake.ButtonStyle.blurple,
                        ),
                        disnake.ui.Button(
                            label="🏦 LivePix",
                            custom_id="Banking_LivePix",
                            style=disnake.ButtonStyle.blurple,
                        ),
                    ),
                    disnake.ui.ActionRow(
                        disnake.ui.Button(
                            label="← Voltar",
                            custom_id="Banking_VoltarPreferencias",
                            style=disnake.ButtonStyle.red,
                        )
                    ),
                    **container_kwargs
                )
            ]
        }
        
        return components, None  # (dict_components, None) — preferências/cog.py trata esse padrão

    @commands.Cog.listener()
    async def on_ready(self):
        """Inicializa o cog quando o bot está pronto"""
        pass

    @commands.Cog.listener()
    async def on_button_click(self, inter: disnake.MessageInteraction):
        """Listener para botões do painel"""
        custom_id = inter.component.custom_id
        # Ignorar botões que não são deste cog
        if not custom_id.startswith("Banking_"):
            return

        if custom_id == "Banking_PIX":
            await self._show_pix_panel(inter)
        elif custom_id == "Banking_Inter":
            await self._show_inter_panel(inter)
        elif custom_id == "Banking_Nubank":
            await self._show_nubank_panel(inter)
        elif custom_id == "Banking_LivePix":
            await self._show_livepix_panel(inter)
        
        # Modais de configuração
        elif custom_id == "Banking_SetPIX":
            await inter.response.send_modal(PIXConfigModal())
        elif custom_id == "Banking_SetInter":
            await inter.response.send_modal(InterConfigModal())
        elif custom_id == "Banking_SetNubank":
            await inter.response.send_modal(NubankConfigModal())
        elif custom_id == "Banking_SetLivePix":
            await inter.response.send_modal(LivePixConfigModal())
        
        # Deletar configurações
        elif custom_id == "Banking_DeletePIX":
            await self._delete_pix_config(inter)
        elif custom_id == "Banking_SetPIXQR":
            await self._set_pix_qr(inter)
        elif custom_id == "Banking_DeletePIXQR":
            await self._delete_pix_qr(inter)
        elif custom_id == "Banking_DeleteInter":
            await self._delete_inter_config(inter)
        elif custom_id == "Banking_DeleteNubank":
            await self._delete_nubank_config(inter)
        elif custom_id == "Banking_DeleteLivePix":
            await self._delete_livepix_config(inter)
        
        # Toggle de ativação
        elif custom_id == "Banking_TogglePIX":
            await self._toggle_pix(inter)
        elif custom_id == "Banking_ToggleInter":
            await self._toggle_inter(inter)
        elif custom_id == "Banking_ToggleNubank":
            await self._toggle_nubank(inter)
        elif custom_id == "Banking_ToggleLivePix":
            await self._toggle_livepix(inter)
        
        # Voltar
        elif custom_id == "Banking_MainPanel":
            embed, components = BankingCog.PainelEmbed(inter.guild)
            if isinstance(components, dict):
                await inter.response.edit_message(**components)
            else:
                await inter.response.edit_message(embed=embed, components=components)

    async def _show_pix_panel(self, inter: disnake.MessageInteraction):
        """Mostra painel de configuração do PIX"""
        
        pix_config = helpers.get_bank_config("pix_manual")
        enabled_banks = helpers.get_enabled_banks()
        is_enabled = enabled_banks.get("pix_manual", False)
        
        embed = disnake.Embed(
            title=f"{emoji.credit_card} Configuração - PIX",
            description="Configure sua chave PIX para receber pagamentos",
            color=utils.get_color("primary")
        )
        
        if pix_config:
            pix_key = pix_config.get("pix_key", "Não configurada")
            pix_key_type = pix_config.get("pix_key_type", "Desconhecido")
            merchant_name = pix_config.get("merchant_name", "Não definido")
            merchant_city = pix_config.get("merchant_city", "Não definido")
            payment_mode = pix_config.get("payment_mode", "generate")
            payment_mode_label = "🔄 Gerar QR dinamicamente" if payment_mode == "generate" else "📨 Reenviar QR/chave estáticos"
            
            # Mascarar chave PIX (mostrar apenas últimos 4 dígitos)
            if len(str(pix_key)) > 4:
                pix_key_display = "*" * (len(str(pix_key)) - 4) + str(pix_key)[-4:]
            else:
                pix_key_display = pix_key
            
            embed.add_field(
                name="Chave PIX",
                value=f"`{pix_key_display}`",
                inline=False
            )
            embed.add_field(
                name="Tipo de Chave",
                value=f"`{pix_key_type}`",
                inline=True
            )
            embed.add_field(
                name="Razão Social",
                value=f"`{merchant_name}`",
                inline=True
            )
            embed.add_field(
                name="Cidade",
                value=f"`{merchant_city}`",
                inline=True
            )
            embed.add_field(
                name="Status",
                value=f"`{'✅ ATIVADO' if is_enabled else '❌ DESATIVADO'}`",
                inline=True
            )
            embed.add_field(
                name="Modo de Pagamento",
                value=f"`{payment_mode_label}`",
                inline=True
            )

            # Status do QR Code estático
            static_qr_b64 = pix_config.get("static_qr_base64")
            static_qr_url = pix_config.get("static_qr_url", "")
            qr_status = "✅ Cadastrado (upload)" if static_qr_b64 else ("✅ Cadastrado (URL)" if static_qr_url else "❌ Não cadastrado")
            embed.add_field(
                name="QR Code Estático",
                value=f"`{qr_status}`",
                inline=True
            )
            if payment_mode == "static" and not static_qr_b64 and not static_qr_url:
                embed.add_field(
                    name="⚠️ Atenção",
                    value="O modo **Reenviar** está ativo mas nenhum QR Code foi cadastrado. Configure em `/painel > Configurações > Formas de Pagamento > Pix Manual` ou faça upload abaixo.",
                    inline=False
                )
        else:
            embed.description = "**Nenhuma configuração de PIX encontrada**\n\nClique em **Configurar PIX** para adicionar sua chave."
        
        components = [
            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Configurar PIX",
                    custom_id="Banking_SetPIX",
                    style=disnake.ButtonStyle.green,
                    emoji=emoji.edit
                ),
                disnake.ui.Button(
                    label="Remover Configuração" if pix_config else "Voltar",
                    custom_id="Banking_DeletePIX" if pix_config else "Banking_MainPanel",
                    style=disnake.ButtonStyle.danger if pix_config else disnake.ButtonStyle.red,
                    emoji=emoji.delete if pix_config else emoji.back
                ),
                disnake.ui.Button(
                    label="✅ Ativar" if not is_enabled else "❌ Desativar",
                    custom_id="Banking_TogglePIX",
                    style=disnake.ButtonStyle.success if not is_enabled else disnake.ButtonStyle.danger,
                ),
            )
        ]

        if pix_config:
            qr_row_buttons = [
                disnake.ui.Button(
                    label="Cadastrar QR Code (upload)",
                    custom_id="Banking_SetPIXQR",
                    style=disnake.ButtonStyle.blurple,
                    emoji=emoji.image if hasattr(emoji, "image") else "🖼️"
                )
            ]
            if pix_config.get("static_qr_base64"):
                qr_row_buttons.append(
                    disnake.ui.Button(
                        label="Remover QR Code",
                        custom_id="Banking_DeletePIXQR",
                        style=disnake.ButtonStyle.danger,
                        emoji=emoji.delete
                    )
                )
            components.append(disnake.ui.ActionRow(*qr_row_buttons))
        
        components.append(
            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="← Voltar",
                    custom_id="Banking_MainPanel",
                    style=disnake.ButtonStyle.grey,
                    emoji=emoji.back
                )
            )
        )

        await inter.response.edit_message(embed=embed, components=components)

    async def _show_inter_panel(self, inter: disnake.MessageInteraction):
        """Mostra painel de configuração do Banco Inter"""
        
        inter_config = helpers.get_bank_config("inter")
        enabled_banks = helpers.get_enabled_banks()
        is_enabled = enabled_banks.get("inter", False)
        
        embed = disnake.Embed(
            title=f"{emoji.bank} Configuração - Banco Inter",
            description="Configure sua integração com o Banco Inter",
            color=utils.get_color("primary")
        )
        
        if inter_config:
            embed.add_field(
                name="Client ID",
                value=f"`{'*' * 20}...`",
                inline=False
            )
            embed.add_field(
                name="Número da Conta",
                value=f"`{inter_config.get('account_number', 'Não configurado')}`",
                inline=True
            )
            embed.add_field(
                name="Status",
                value=f"`{'✅ ATIVADO' if is_enabled else '❌ DESATIVADO'}`",
                inline=True
            )
        else:
            embed.description = "**Nenhuma configuração do Banco Inter encontrada**\n\nClique em **Configurar Inter** para adicionar suas credenciais."
        
        components = disnake.ui.ActionRow(
            disnake.ui.Button(
                label="Configurar Inter",
                custom_id="Banking_SetInter",
                style=disnake.ButtonStyle.green,
                emoji=emoji.edit
            ),
            disnake.ui.Button(
                label="Remover Configuração" if inter_config else "Voltar",
                custom_id="Banking_DeleteInter" if inter_config else "Banking_MainPanel",
                style=disnake.ButtonStyle.danger if inter_config else disnake.ButtonStyle.red,
                emoji=emoji.delete if inter_config else emoji.back
            ),
            disnake.ui.Button(
                label="✅ Ativar" if not is_enabled else "❌ Desativar",
                custom_id="Banking_ToggleInter",
                style=disnake.ButtonStyle.success if not is_enabled else disnake.ButtonStyle.danger,
            ),
        )
        
        await inter.response.edit_message(embed=embed, components=components)

    async def _show_nubank_panel(self, inter: disnake.MessageInteraction):
        """Mostra painel de configuração do Nubank"""
        
        nubank_config = helpers.get_bank_config("nubank_imap")
        enabled_banks = helpers.get_enabled_banks()
        is_enabled = enabled_banks.get("nubank_imap", False)
        
        embed = disnake.Embed(
            title=f"{emoji.credit_card} Configuração - Nubank",
            description="Configure sua integração com Nubank via IMAP",
            color=utils.get_color("primary")
        )
        
        if nubank_config:
            email = nubank_config.get("email", "Não configurado")
            pix_key = nubank_config.get("pix_key", "Não configurada")
            pix_key_type = nubank_config.get("pix_key_type", "Desconhecido")
            
            embed.add_field(
                name="Email Nubank",
                value=f"`{email}`",
                inline=False
            )
            embed.add_field(
                name="Chave PIX",
                value=f"`{'*' * (len(str(pix_key)) - 4) + str(pix_key)[-4:] if len(str(pix_key)) > 4 else pix_key}`",
                inline=True
            )
            embed.add_field(
                name="Tipo de Chave",
                value=f"`{pix_key_type}`",
                inline=True
            )
            embed.add_field(
                name="Status",
                value=f"`{'✅ ATIVADO' if is_enabled else '❌ DESATIVADO'}`",
                inline=True
            )
        else:
            embed.description = "**Nenhuma configuração do Nubank encontrada**\n\nClique em **Configurar Nubank** para adicionar suas credenciais."
        
        components = disnake.ui.ActionRow(
            disnake.ui.Button(
                label="Configurar Nubank",
                custom_id="Banking_SetNubank",
                style=disnake.ButtonStyle.green,
                emoji=emoji.edit
            ),
            disnake.ui.Button(
                label="Remover Configuração" if nubank_config else "Voltar",
                custom_id="Banking_DeleteNubank" if nubank_config else "Banking_MainPanel",
                style=disnake.ButtonStyle.danger if nubank_config else disnake.ButtonStyle.red,
                emoji=emoji.delete if nubank_config else emoji.back
            ),
            disnake.ui.Button(
                label="✅ Ativar" if not is_enabled else "❌ Desativar",
                custom_id="Banking_ToggleNubank",
                style=disnake.ButtonStyle.success if not is_enabled else disnake.ButtonStyle.danger,
            ),
        )
        
        await inter.response.edit_message(embed=embed, components=components)

    async def _show_livepix_panel(self, inter: disnake.MessageInteraction):
        """Mostra painel de configuração do LivePix"""
        
        livepix_config = helpers.get_bank_config("livepix")
        enabled_banks = helpers.get_enabled_banks()
        is_enabled = enabled_banks.get("livepix", False)
        
        embed = disnake.Embed(
            title=f"{emoji.credit_card} Configuração - LivePix",
            description="Configure sua integração com LivePix",
            color=utils.get_color("primary")
        )
        
        if livepix_config:
            embed.add_field(
                name="API Key",
                value=f"`{'*' * 20}...`",
                inline=False
            )
            embed.add_field(
                name="Token",
                value=f"`{'*' * 20}...`",
                inline=True
            )
            embed.add_field(
                name="Status",
                value=f"`{'✅ ATIVADO' if is_enabled else '❌ DESATIVADO'}`",
                inline=True
            )
        else:
            embed.description = "**Nenhuma configuração do LivePix encontrada**\n\nClique em **Configurar LivePix** para adicionar suas credenciais."
        
        components = disnake.ui.ActionRow(
            disnake.ui.Button(
                label="Configurar LivePix",
                custom_id="Banking_SetLivePix",
                style=disnake.ButtonStyle.green,
                emoji=emoji.edit
            ),
            disnake.ui.Button(
                label="Remover Configuração" if livepix_config else "Voltar",
                custom_id="Banking_DeleteLivePix" if livepix_config else "Banking_MainPanel",
                style=disnake.ButtonStyle.danger if livepix_config else disnake.ButtonStyle.red,
                emoji=emoji.delete if livepix_config else emoji.back
            ),
            disnake.ui.Button(
                label="✅ Ativar" if not is_enabled else "❌ Desativar",
                custom_id="Banking_ToggleLivePix",
                style=disnake.ButtonStyle.success if not is_enabled else disnake.ButtonStyle.danger,
            ),
        )
        
        await inter.response.edit_message(embed=embed, components=components)


    async def _delete_pix_config(self, inter: disnake.MessageInteraction):
        """Deleta configuração do PIX"""
        helpers.delete_bank_config("pix")
        await self._show_pix_panel(inter)

    async def _set_pix_qr(self, inter: disnake.MessageInteraction):
        """Solicita o upload de uma imagem para usar como QR Code do PIX Direto"""
        pix_config = helpers.get_bank_config("pix_manual")

        if not pix_config or not pix_config.get("pix_key"):
            await inter.response.send_message(
                f"{emoji.wrong} Configure a chave PIX antes de cadastrar o QR Code.",
                ephemeral=True
            )
            return

        await inter.response.send_message(
            f"{emoji.image if hasattr(emoji, 'image') else '🖼️'} Envie a imagem do QR Code do PIX neste canal "
            f"nos próximos 120 segundos. Ela será usada na opção **PIX Direto**.",
            ephemeral=True
        )

        def check(m: disnake.Message) -> bool:
            return (
                m.author.id == inter.author.id
                and m.channel.id == inter.channel.id
                and len(m.attachments) > 0
            )

        try:
            msg = await self.bot.wait_for("message", check=check, timeout=120)
        except asyncio.TimeoutError:
            await inter.followup.send(
                f"{emoji.wrong} Tempo esgotado. Nenhuma imagem foi recebida.",
                ephemeral=True
            )
            return

        attachment = msg.attachments[0]

        if not (attachment.content_type or "").startswith("image/"):
            await inter.followup.send(
                f"{emoji.wrong} O arquivo enviado não é uma imagem.",
                ephemeral=True
            )
            return

        try:
            connector = aiohttp.TCPConnector(ssl=False)
            async with aiohttp.ClientSession(connector=connector) as session:
                async with session.get(attachment.url) as resp:
                    if resp.status != 200:
                        raise RuntimeError(f"status {resp.status}")
                    image_bytes = await resp.read()
        except Exception as e:
            await inter.followup.send(
                f"{emoji.wrong} Não foi possível baixar a imagem enviada: {e}",
                ephemeral=True
            )
            return

        pix_config["static_qr_base64"] = base64.b64encode(image_bytes).decode("ascii")
        helpers.save_bank_config("pix_manual", pix_config)

        # Invalidar cache de métodos de pagamento
        try:
            from modules.loja.cart.buy_modal import invalidate_payment_methods_cache
            from modules.loja.cart.checkout import invalidate_checkout_payment_cache
            invalidate_payment_methods_cache()
            invalidate_checkout_payment_cache()
        except Exception:
            pass

        try:
            await msg.delete()
        except Exception:
            pass

        await inter.followup.send(
            f"{emoji.correct} QR Code cadastrado com sucesso! A opção **PIX Direto** já está disponível na loja "
            f"(desde que o PIX Manual esteja ativado).",
            ephemeral=True
        )

    async def _delete_pix_qr(self, inter: disnake.MessageInteraction):
        """Remove o QR Code estático do PIX Direto"""
        pix_config = helpers.get_bank_config("pix_manual")
        if pix_config and "static_qr_base64" in pix_config:
            del pix_config["static_qr_base64"]
            helpers.save_bank_config("pix_manual", pix_config)

        await self._show_pix_panel(inter)

    async def _delete_inter_config(self, inter: disnake.MessageInteraction):
        """Deleta configuração do Banco Inter"""
        helpers.delete_bank_config("inter")
        await self._show_inter_panel(inter)

    async def _delete_nubank_config(self, inter: disnake.MessageInteraction):
        """Deleta configuração do Nubank"""
        helpers.delete_bank_config("nubank_imap")
        await self._show_nubank_panel(inter)

    async def _delete_livepix_config(self, inter: disnake.MessageInteraction):
        """Deleta configuração do LivePix"""
        helpers.delete_bank_config("livepix")
        await self._show_livepix_panel(inter)

    async def _toggle_pix(self, inter: disnake.MessageInteraction):
        """Toggle de ativação do PIX"""
        enabled_banks = helpers.get_enabled_banks()
        is_enabled = enabled_banks.get("pix_manual", False)
        
        if is_enabled:
            helpers.disable_bank("pix_manual")
        else:
            helpers.enable_bank("pix_manual")
        
        await self._show_pix_panel(inter)

    async def _toggle_inter(self, inter: disnake.MessageInteraction):
        """Toggle de ativação do Banco Inter"""
        enabled_banks = helpers.get_enabled_banks()
        is_enabled = enabled_banks.get("inter", False)
        
        if is_enabled:
            helpers.disable_bank("inter")
        else:
            helpers.enable_bank("inter")
        
        await self._show_inter_panel(inter)

    async def _toggle_nubank(self, inter: disnake.MessageInteraction):
        """Toggle de ativação do Nubank"""
        enabled_banks = helpers.get_enabled_banks()
        is_enabled = enabled_banks.get("nubank_imap", False)
        
        if is_enabled:
            helpers.disable_bank("nubank_imap")
        else:
            helpers.enable_bank("nubank_imap")
        
        await self._show_nubank_panel(inter)

    async def _toggle_livepix(self, inter: disnake.MessageInteraction):
        """Toggle de ativação do LivePix"""
        enabled_banks = helpers.get_enabled_banks()
        is_enabled = enabled_banks.get("livepix", False)
        
        if is_enabled:
            helpers.disable_bank("livepix")
        else:
            helpers.enable_bank("livepix")
        
        await self._show_livepix_panel(inter)