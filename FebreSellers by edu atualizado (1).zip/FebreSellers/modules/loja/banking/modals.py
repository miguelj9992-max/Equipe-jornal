"""
Modals para configuração de bancos
"""

import disnake
from disnake.ext import commands
from . import helpers
from functions.message import message, embed_message


class PIXConfigModal(disnake.ui.Modal):
    def __init__(self):
        components = [
            disnake.ui.TextInput(
                label="Chave PIX",
                placeholder="CPF, CNPJ, Email, Telefone ou Chave Aleatória",
                custom_id="pix_key",
                min_length=3,
                max_length=100,
                required=True
            ),
            disnake.ui.TextInput(
                label="Tipo de Chave",
                placeholder="cpf, cnpj, email, telefone ou aleatoria",
                custom_id="pix_key_type",
                min_length=3,
                max_length=20,
                required=True
            ),
            disnake.ui.TextInput(
                label="Razão Social / Nome",
                placeholder="Seu nome completo ou razão social",
                custom_id="merchant_name",
                min_length=1,
                max_length=50,
                required=True
            ),
            disnake.ui.TextInput(
                label="Cidade",
                placeholder="Sua cidade",
                custom_id="merchant_city",
                min_length=1,
                max_length=30,
                required=True
            ),
        ]
        
        super().__init__(title="Configuração de PIX", components=components)
    
    async def callback(self, inter: disnake.ModalInteraction):
        try:
            await inter.response.defer(ephemeral=True)
            
            pix_key = inter.text_values.get("pix_key", "").strip()
            pix_key_type = inter.text_values.get("pix_key_type", "").strip().lower()
            merchant_name = inter.text_values.get("merchant_name", "").strip()
            merchant_city = inter.text_values.get("merchant_city", "").strip()
            
            # Validar
            is_valid, error_msg = helpers.validate_pix_config(pix_key, pix_key_type)
            if not is_valid:
                return await message.error(inter, error_msg, followup=True)
            
            # Salvar configuração
            config = {
                "pix_key": pix_key,
                "pix_key_type": pix_key_type,
                "merchant_name": merchant_name,
                "merchant_city": merchant_city
            }
            
            helpers.save_bank_config("pix_manual", config)
            
            return await message.success(
                inter, 
                f"✅ Configuração de PIX salva com sucesso!\n\n"
                f"**Tipo:** {pix_key_type}\n"
                f"**Razão Social:** {merchant_name}\n"
                f"**Cidade:** {merchant_city}",
                followup=True
            )
        
        except Exception as e:
            await message.error(inter, f"Erro ao configurar PIX: {str(e)}", followup=True)


class InterConfigModal(disnake.ui.Modal):
    def __init__(self):
        components = [
            disnake.ui.TextInput(
                label="Client ID",
                placeholder="ID do cliente do Banco Inter",
                custom_id="client_id",
                min_length=10,
                max_length=100,
                required=True
            ),
            disnake.ui.TextInput(
                label="Client Secret",
                placeholder="Secret do cliente do Banco Inter",
                custom_id="client_secret",
                min_length=10,
                max_length=100,
                required=True
            ),
            disnake.ui.TextInput(
                label="Número da Conta",
                placeholder="Seu número de conta no Banco Inter",
                custom_id="account_number",
                min_length=5,
                max_length=20,
                required=True
            ),
        ]
        
        super().__init__(title="Configuração - Banco Inter", components=components)
    
    async def callback(self, inter: disnake.ModalInteraction):
        try:
            await inter.response.defer(ephemeral=True)
            
            config = {
                "client_id": inter.text_values.get("client_id", "").strip(),
                "client_secret": inter.text_values.get("client_secret", "").strip(),
                "account_number": inter.text_values.get("account_number", "").strip(),
            }
            
            # Validar
            is_valid, error_msg = helpers.validate_inter_config(config)
            if not is_valid:
                return await message.error(inter, error_msg, followup=True)
            
            # Salvar configuração
            helpers.save_bank_config("inter", config)
            
            return await message.success(
                inter, 
                f"✅ Configuração do Banco Inter salva com sucesso!\n\n"
                f"**Conta:** {config['account_number']}",
                followup=True
            )
        
        except Exception as e:
            await message.error(inter, f"Erro ao configurar Banco Inter: {str(e)}", followup=True)


class NubankConfigModal(disnake.ui.Modal):
    def __init__(self):
        components = [
            disnake.ui.TextInput(
                label="Email do Nubank",
                placeholder="Seu email do Nubank",
                custom_id="email",
                min_length=5,
                max_length=100,
                required=True
            ),
            disnake.ui.TextInput(
                label="Senha do Nubank",
                placeholder="Sua senha do Nubank",
                custom_id="password",
                min_length=1,
                max_length=100,
                required=True
            ),
            disnake.ui.TextInput(
                label="Chave PIX",
                placeholder="CPF, Email ou outra chave PIX",
                custom_id="pix_key",
                min_length=3,
                max_length=100,
                required=True
            ),
            disnake.ui.TextInput(
                label="Tipo de Chave PIX",
                placeholder="cpf, email, aleatoria, etc",
                custom_id="pix_key_type",
                min_length=3,
                max_length=20,
                required=True
            ),
        ]
        
        super().__init__(title="Configuração - Nubank", components=components)
    
    async def callback(self, inter: disnake.ModalInteraction):
        try:
            await inter.response.defer(ephemeral=True)
            
            config = {
                "email": inter.text_values.get("email", "").strip(),
                "password": inter.text_values.get("password", "").strip(),
                "pix_key": inter.text_values.get("pix_key", "").strip(),
                "pix_key_type": inter.text_values.get("pix_key_type", "").strip().lower(),
                "enabled": True
            }
            
            # Validar
            is_valid, error_msg = helpers.validate_nubank_config(config)
            if not is_valid:
                return await message.error(inter, error_msg, followup=True)
            
            # Validar PIX também
            is_valid_pix, error_pix = helpers.validate_pix_config(config["pix_key"], config["pix_key_type"])
            if not is_valid_pix:
                return await message.error(inter, f"Erro na configuração da chave PIX: {error_pix}", followup=True)
            
            # Salvar configuração
            helpers.save_bank_config("nubank_imap", config)
            
            return await message.success(
                inter, 
                f"✅ Configuração do Nubank salva com sucesso!\n\n"
                f"**Email:** {config['email']}\n"
                f"**Chave PIX:** {config['pix_key_type']}\n\n"
                f"⚠️ **Nota:** A senha é armazenada no banco de dados. Use uma senha de aplicação se disponível.",
                followup=True
            )
        
        except Exception as e:
            await message.error(inter, f"Erro ao configurar Nubank: {str(e)}", followup=True)


class LivePixConfigModal(disnake.ui.Modal):
    def __init__(self):
        components = [
            disnake.ui.TextInput(
                label="API Key",
                placeholder="Sua API Key do LivePix",
                custom_id="api_key",
                min_length=10,
                max_length=200,
                required=True
            ),
            disnake.ui.TextInput(
                label="Token",
                placeholder="Seu Token do LivePix",
                custom_id="token",
                min_length=10,
                max_length=200,
                required=True
            ),
            disnake.ui.TextInput(
                label="Webhook URL (opcional)",
                placeholder="https://seu-dominio.com/webhook",
                custom_id="webhook_url",
                min_length=0,
                max_length=200,
                required=False
            ),
        ]
        
        super().__init__(title="Configuração - LivePix", components=components)
    
    async def callback(self, inter: disnake.ModalInteraction):
        try:
            await inter.response.defer(ephemeral=True)
            
            config = {
                "api_key": inter.text_values.get("api_key", "").strip(),
                "token": inter.text_values.get("token", "").strip(),
            }
            
            webhook_url = inter.text_values.get("webhook_url", "").strip()
            if webhook_url:
                config["webhook_url"] = webhook_url
            
            # Validar
            is_valid, error_msg = helpers.validate_livepix_config(config)
            if not is_valid:
                return await message.error(inter, error_msg, followup=True)
            
            # Salvar configuração
            helpers.save_bank_config("livepix", config)
            
            webhook_info = f"\n**Webhook:** {config.get('webhook_url', 'Não configurado')}" if webhook_url else ""
            
            return await message.success(
                inter, 
                f"✅ Configuração do LivePix salva com sucesso!{webhook_info}",
                followup=True
            )
        
        except Exception as e:
            await message.error(inter, f"Erro ao configurar LivePix: {str(e)}", followup=True)