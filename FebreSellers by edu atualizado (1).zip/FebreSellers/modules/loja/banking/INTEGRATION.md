"""
INSTRUÇÕES DE INTEGRAÇÃO DO MÓDULO DE BANKING

Este arquivo mostra como integrar o módulo de banking ao seu bot.
"""

# ============================================================
# OPÇÃO 1: Adicionar ao bot.py (Carregamento Manual)
# ============================================================

# No seu arquivo bot.py, adicione estas linhas:

# --- Na seção de imports ---
# (já deve estar presente)
from modules.loja.banking import setup as setup_banking

# --- Na função setup_bot() ou equivalente ---
def setup_bot(bot):
    # ... outras extensões ...
    
    # Carregar módulo de banking
    try:
        bot.load_extension("modules.loja.banking")
        print("✅ Módulo Banking carregado com sucesso")
    except Exception as e:
        print(f"❌ Erro ao carregar Banking: {e}")


# ============================================================
# OPÇÃO 2: Adicionar ao tasks/__init__.py (Carregamento Automático)
# ============================================================

# No arquivo tasks/__init__.py, adicione:

"""
# Após as outras extensões:
    
try:
    bot.load_extension("modules.loja.banking")
    logger.info("✅ Extensão Banking carregada")
except Exception as e:
    logger.error(f"Erro ao carregar Banking: {e}")
"""


# ============================================================
# OPÇÃO 3: Integração com Painel Existente
# ============================================================

# Se você tem um painel de loja/preferências, adicione o botão:

# Em modules/loja/preferences/cog.py:

"""
options = [
    # ... outras opções ...
    disnake.SelectOption(
        label="Bancos & Pagamentos",
        value="banking",
        emoji=emoji.bank,
        description="Configure suas integrações bancárias"
    ),
]

# No handler:
if selected_value == "banking":
    from modules.loja.banking import BankingCog
    embed, components = BankingCog.PainelEmbed(inter.guild)
    if isinstance(components, dict):
        await inter.edit_original_message(**components)
    else:
        await inter.edit_original_message(embed=embed, components=components)
"""


# ============================================================
# VERIFICAÇÃO DE INTEGRAÇÃO
# ============================================================

# Para verificar se o módulo foi carregado corretamente:

# 1. Iniciar o bot
# 2. Digitar /painel
# 3. Navegar para Loja
# 4. Procurar pela opção "Bancos & Pagamentos" ou o botão Banking
# 5. Clicar para abrir o painel


# ============================================================
# TESTE DOS FORMULÁRIOS
# ============================================================

# Para testar cada formulário:

# 1. PIX:
#    - Preencha com dados válidos (CPF ou Email)
#    - Clique em "Configurar PIX"
#    - Confirme que aparece "✅ Configuração de PIX salva"

# 2. Banco Inter:
#    - Use credenciais de teste
#    - Clique em "Configurar Inter"
#    - Confirme salvamento

# 3. Nubank:
#    - Use email e senha de teste
#    - Preencha chave PIX válida
#    - Confirme salvamento

# 4. LivePix:
#    - Use credenciais de teste
#    - Confirme salvamento
#    - (Webhook é opcional)


# ============================================================
# ESTRUTURA DO BANCO DE DADOS
# ============================================================

# O módulo criará os seguintes documentos no MongoDB:

# Document: payment_configs
# Armazena configurações de todos os bancos

# Document: pagamentos
# Armazena status (ativado/desativado) de cada banco


# ============================================================
# VARIÁVEIS DE AMBIENTE (OPCIONAL)
# ============================================================

# Se você quiser carregar configurações de variáveis de ambiente:

"""
import os

INTER_CLIENT_ID = os.getenv("INTER_CLIENT_ID")
INTER_CLIENT_SECRET = os.getenv("INTER_CLIENT_SECRET")

NUBANK_EMAIL = os.getenv("NUBANK_EMAIL")
NUBANK_PASSWORD = os.getenv("NUBANK_PASSWORD")

LIVEPIX_API_KEY = os.getenv("LIVEPIX_API_KEY")
LIVEPIX_TOKEN = os.getenv("LIVEPIX_TOKEN")
"""


# ============================================================
# RELOADING DO BOT
# ============================================================

# Após adicionar o módulo, reinicie o bot:

# Via comando: /reload
# Via bot: bot.reload_extension("modules.loja.banking")
# Via terminal: Ctrl+C e restart


# ============================================================
# TROUBLESHOOTING
# ============================================================

# Erro: "ModuleNotFoundError: No module named 'modules.loja.banking'"
# Solução: Verifique se os arquivos estão no caminho correto

# Erro: "BankingCog not found"
# Solução: Verifique se o arquivo cog.py foi criado corretamente

# Erro: "ImportError"
# Solução: Execute py_compile para verificar sintaxe:
# python -m py_compile modules/loja/banking/*.py


# ============================================================
# PRÓXIMAS INTEGRAÇÕES
# ============================================================

# Para usar as configurações de banco em pagamentos:

# functions/payments/create_payment.py:
"""
from modules.loja.banking import helpers

# Obter config PIX
pix_config = helpers.get_bank_config("pix")
pix_key = pix_config.get("pix_key")

# Obter status de ativação
enabled_banks = helpers.get_enabled_banks()
if enabled_banks.get("pix"):
    # PIX está ativado, processar pagamento
"""

# Exemplo de uso com função de pagamento:
"""
async def create_pix_payment(amount, order_id):
    pix_config = helpers.get_bank_config("pix")
    
    if not pix_config:
        raise ValueError("PIX não configurado")
    
    # Usar as configurações para criar pagamento
    from functions.payments.imap_nubank import generate_pix_qr_code
    
    qr_code = generate_pix_qr_code(
        pix_key=pix_config["pix_key"],
        merchant_name=pix_config["merchant_name"],
        merchant_city=pix_config["merchant_city"],
        amount=amount
    )
    
    return qr_code
"""

print("✅ Integration guide criado com sucesso!")
