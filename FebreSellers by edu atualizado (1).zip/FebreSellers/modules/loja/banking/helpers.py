"""
Helper functions para gerenciar configurações de bancos
"""

from functions.database import database as db
from typing import Dict, Any, Optional


def get_banking_config() -> Dict[str, Any]:
    """Obtém todas as configurações de banco"""
    return db.get_document("payment_configs") or {}


def get_bank_config(bank_name: str) -> Dict[str, Any]:
    """Obtém configuração de um banco específico"""
    configs = get_banking_config()
    return configs.get(bank_name, {})


def save_bank_config(bank_name: str, config: Dict[str, Any]) -> None:
    """Salva configuração de um banco"""
    configs = get_banking_config()
    configs[bank_name] = config
    db.save_document("payment_configs", {}, configs)


def delete_bank_config(bank_name: str) -> None:
    """Deleta configuração de um banco"""
    configs = get_banking_config()
    if bank_name in configs:
        del configs[bank_name]
        db.save_document("payment_configs", {}, configs)


def get_enabled_banks() -> Dict[str, bool]:
    """Obtém status de ativação de cada banco"""
    pagamentos = db.get_document("pagamentos") or {}
    return pagamentos


def enable_bank(bank_name: str) -> None:
    """Ativa um banco"""
    pagamentos = db.get_document("pagamentos") or {}
    pagamentos[bank_name] = True
    db.save_document("pagamentos", {}, pagamentos)


def disable_bank(bank_name: str) -> None:
    """Desativa um banco"""
    pagamentos = db.get_document("pagamentos") or {}
    pagamentos[bank_name] = False
    db.save_document("pagamentos", {}, pagamentos)


def validate_pix_config(pix_key: str, pix_key_type: str) -> tuple[bool, str]:
    """
    Valida configuração de PIX
    
    Returns:
        (is_valid, error_message)
    """
    if not pix_key or not pix_key.strip():
        return False, "A chave PIX não pode estar vazia"
    
    valid_types = ["cpf", "cnpj", "email", "telefone", "aleatoria"]
    if pix_key_type not in valid_types:
        return False, f"Tipo de chave inválido. Tipos válidos: {', '.join(valid_types)}"
    
    if pix_key_type == "cpf":
        pix_key_clean = pix_key.replace(".", "").replace("-", "").replace(" ", "")
        if not pix_key_clean.isdigit() or len(pix_key_clean) != 11:
            return False, "CPF inválido. Deve conter 11 dígitos"
    
    elif pix_key_type == "cnpj":
        pix_key_clean = pix_key.replace(".", "").replace("-", "").replace("/", "").replace(" ", "")
        if not pix_key_clean.isdigit() or len(pix_key_clean) != 14:
            return False, "CNPJ inválido. Deve conter 14 dígitos"
    
    elif pix_key_type == "email":
        if "@" not in pix_key or "." not in pix_key:
            return False, "Email inválido"
    
    elif pix_key_type == "telefone":
        pix_key_clean = pix_key.replace("(", "").replace(")", "").replace("-", "").replace(" ", "").replace("+", "")
        if not pix_key_clean.isdigit() or len(pix_key_clean) < 10:
            return False, "Telefone inválido. Deve conter pelo menos 10 dígitos"
    
    return True, ""


def validate_inter_config(config: Dict[str, Any]) -> tuple[bool, str]:
    """Valida configuração do Banco Inter"""
    required_fields = ["client_id", "client_secret", "account_number"]
    
    for field in required_fields:
        if not config.get(field):
            return False, f"Campo obrigatório ausente: {field}"
    
    return True, ""


def validate_nubank_config(config: Dict[str, Any]) -> tuple[bool, str]:
    """Valida configuração do Nubank"""
    if config.get("enabled"):
        required_fields = ["email", "password"]
        for field in required_fields:
            if not config.get(field):
                return False, f"Campo obrigatório ausente: {field}"
    
    return True, ""


def validate_livepix_config(config: Dict[str, Any]) -> tuple[bool, str]:
    """Valida configuração do LivePix"""
    required_fields = ["api_key", "token"]
    
    for field in required_fields:
        if not config.get(field):
            return False, f"Campo obrigatório ausente: {field}"
    
    return True, ""
