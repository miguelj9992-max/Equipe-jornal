"""
Módulo de Configuração de Bancos
Gerencia PIX, Inter, Nubank e LivePix
"""

from .cog import BankingCog
from .modals import PIXConfigModal, InterConfigModal, NubankConfigModal, LivePixConfigModal
from . import helpers

__all__ = [
    'BankingCog',
    'PIXConfigModal',
    'InterConfigModal', 
    'NubankConfigModal',
    'LivePixConfigModal',
    'helpers'
]

def setup(bot):
    """Setup function para carregar o cog"""
    bot.add_cog(BankingCog(bot))
