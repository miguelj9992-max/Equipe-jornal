# 🏦 Sistema de Configuração de Bancos

Sistema completo para configurar e gerenciar integrações bancárias no seu bot Discord.

## 📋 Bancos Suportados

### 1. **PIX** 💳
- Suporta múltiplos tipos de chaves: CPF, CNPJ, Email, Telefone, Chave Aleatória
- Gera QR Codes automaticamente
- Integração com MisticPay (opcional)

**Campos Obrigatórios:**
- Chave PIX
- Tipo de Chave
- Razão Social / Nome
- Cidade

**Exemplo:**
- Chave: `12345678901`
- Tipo: `cpf`
- Razão Social: `Minha Loja`
- Cidade: `São Paulo`

---

### 2. **Banco Inter** 🏦
- Integração com API do Banco Inter
- Suporte a transferências e pagamentos
- Sincronização de saldo

**Campos Obrigatórios:**
- Client ID
- Client Secret
- Número da Conta

**Como obter as credenciais:**
1. Acesse [https://www.bancointer.com.br/para-voce/api](https://www.bancointer.com.br/para-voce/api)
2. Registre sua aplicação
3. Gere as credenciais de autenticação

---

### 3. **Nubank** 💳
- Integração via IMAP (monitoramento de emails)
- Aprovação automática de pagamentos PIX
- Sincronização de transações

**Campos Obrigatórios:**
- Email Nubank
- Senha Nubank
- Chave PIX
- Tipo de Chave PIX

**Dica de Segurança:**
- Use uma senha de aplicação em vez da senha principal
- Ative autenticação de dois fatores no Nubank

**Como gerar senha de aplicação:**
1. Acesse o app do Nubank
2. Vá em Segurança → Senhas de Aplicação
3. Gere uma nova senha
4. Use essa senha na configuração

---

### 4. **LivePix** 📲
- Plataforma de pagamento via PIX
- Suporte a webhooks
- Integração simplificada

**Campos Obrigatórios:**
- API Key
- Token

**Campos Opcionais:**
- Webhook URL

**Como obter as credenciais:**
1. Acesse [https://livepix.gg](https://livepix.gg)
2. Crie uma conta
3. Vá em Configurações → Integração
4. Gere suas credenciais

---

## 🚀 Como Usar

### Acessar o Painel

Depois de integrado, o painel estará disponível em:
```
/painel → Loja → Bancos
```

### Configurar um Banco

1. Clique no botão do banco desejado (PIX, Inter, Nubank ou LivePix)
2. Clique em **"Configurar [Banco]"**
3. Preencha os campos solicitados
4. Confirme a configuração

### Ativar/Desativar um Banco

- Clique no botão **✅ Ativar** para começar a aceitar pagamentos
- Clique em **❌ Desativar** para pausar temporariamente

### Remover Configuração

- Clique em **"Remover Configuração"** para deletar as credenciais
- ⚠️ Isso não pode ser desfeito!

---

## 🔐 Segurança

### Boas Práticas

✅ **Fazer:**
- Usar senhas de aplicação quando disponível
- Ativar autenticação de dois fatores
- Manter suas credenciais secretas
- Mudar senhas regularmente
- Usar HTTPS para webhooks

❌ **Não fazer:**
- Compartilhar credenciais com outros usuários
- Usar a mesma senha em múltiplos serviços
- Armazenar credenciais em arquivos não criptografados
- Expor seus dados bancários em mensagens

### Criptografia

As credenciais são armazenadas no MongoDB. Recomenda-se:
1. Habilitar criptografia no MongoDB
2. Usar conexão SSL/TLS
3. Limitar acesso ao banco de dados

---

## 🧪 Testando Configurações

### PIX
```
Chave: seu_cpf@seu_email.com
Tipo: email
Razão: Minha Loja Teste
Cidade: São Paulo
```

### Validação
- A configuração exibe um ✅ quando válida
- Mensagens de erro aparecem em vermelho
- Clique em "Status" para ver informações atuais

---

## 📊 Visualizando Status

O painel mostra:
- ✅ Banco ativado / ❌ Banco desativado
- 🔧 Banco configurado / ❌ Não configurado
- Status de cada integração

---

## 🔄 Sincronização

O sistema sincroniza automaticamente:
- Configurações de PIX com MisticPay
- Credenciais do Nubank com IMAP
- Status de pagamentos com Inter
- Transações do LivePix

---

## 🆘 Troubleshooting

### "Erro: Chave PIX Inválida"
- Verifique se a chave tem o formato correto
- CPF deve ter 11 dígitos
- CNPJ deve ter 14 dígitos
- Email deve ter @ e .

### "Erro: Credenciais Inválidas"
- Verifique as credenciais no painel do banco
- Confirme que a senha está correta
- Tente gerar novas credenciais

### "Webhook não funciona"
- Verifique se a URL é pública
- Confirme que está usando HTTPS
- Teste com uma ferramenta como Postman

---

## 📝 Estrutura de Dados

### Configuração Armazenada
```json
{
  "pix": {
    "pix_key": "12345678901",
    "pix_key_type": "cpf",
    "merchant_name": "Minha Loja",
    "merchant_city": "São Paulo"
  },
  "inter": {
    "client_id": "...",
    "client_secret": "...",
    "account_number": "12345"
  },
  "nubank_imap": {
    "email": "seu@email.com",
    "password": "***",
    "pix_key": "chave",
    "pix_key_type": "cpf",
    "enabled": true
  },
  "livepix": {
    "api_key": "...",
    "token": "...",
    "webhook_url": "https://..."
  }
}
```

---

## 🔗 Integração

O módulo de banking está integrado com:
- `functions/payments/` - Processamento de pagamentos
- `modules/loja/` - Sistema de loja
- `connections/handlers/` - Gerenciamento de configurações
- Database MongoDB - Armazenamento seguro

---

## ✨ Recursos Futuros

- [ ] Suporte a Stripe
- [ ] Suporte a PayPal
- [ ] Dashboard de analytics
- [ ] Relatórios de transações
- [ ] Validação de CPF/CNPJ automática
- [ ] Backup automático de configurações

---

**Desenvolvido com ❤️ para seu bot Discord**
