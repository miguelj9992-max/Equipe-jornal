class SafeFormatter(dict):
    def __missing__(self, key):
        return f"{{{key}}}"


def get_message_style(panel_data: dict, category: str) -> str:
    """
    Retorna o estilo configurado ("embed" ou "content") para uma categoria
    de mensagem de ticket (ex: "CloseMessage", "NotifyMessage", etc).
    Por padrão o estilo é "embed", para não alterar o comportamento de
    paineis já existentes que nunca configuraram isso.
    """
    panel_data = panel_data or {}
    return panel_data.get("messages_style", {}).get(category, "embed")


def get_message_embed_config(panel_data: dict, category: str) -> dict:
    """
    Retorna a personalização de embed (título, imagem, cor, footer) configurada
    para uma categoria de mensagem de ticket (ex: "CloseMessage"). Vale apenas
    quando o estilo da categoria está como "embed".
    """
    panel_data = panel_data or {}
    return panel_data.get("messages_embed", {}).get(category, {}) or {}


def build_ticket_message(
    style: str,
    title: str = None,
    description: str = "",
    fields: list = None,
    footer: str = None,
    color=None,
    panel_data: dict = None,
    category: str = None,
) -> dict:
    """
    Monta o conteúdo de uma mensagem de ticket de acordo com o estilo
    configurado (embed ou mensagem solta/texto simples).

    :param style: "embed" ou "content"
    :param title: título padrão (usado se não houver personalização); no modo
                  texto vira um cabeçalho em negrito
    :param description: texto principal da mensagem
    :param fields: lista de tuplas (nome, valor) com informações extras
                   (ex: Categoria, Servidor, Fechado por, etc)
    :param footer: texto de rodapé padrão (usado se não houver personalização)
    :param color: cor padrão do embed (usada se não houver personalização)
    :param panel_data: dados do painel, usado para buscar a personalização de
                        embed (título/imagem/cor/footer) salva pelo usuário
    :param category: categoria da mensagem (ex: "CloseMessage"), usado junto
                      com panel_data para buscar a personalização
    :return: dict pronto para ser usado como **kwargs em `.send()`/`.author.send()`,
             contendo a chave "embed" ou a chave "content".
    """
    import disnake
    from functions.utils import utils

    fields = fields or []

    if style == "content":
        # Comportamento de texto simples permanece inalterado, sem
        # personalização de embed (imagem não se aplica a texto simples).
        lines = []
        if title:
            lines.append(f"**{title}**")
        if description:
            lines.append(description)
        for name, value in fields:
            if value:
                lines.append(f"**{name}:** {value}")
        if footer:
            lines.append(f"-# {footer}")

        content = "\n".join(part for part in lines if part).strip()
        return {"content": content[:2000] if content else "\u200b"}

    # Modo embed: aplica a personalização salva (título/imagem/cor/footer),
    # caindo para os valores padrão passados pela função quando não configurado.
    embed_cfg = get_message_embed_config(panel_data, category) if (panel_data and category) else {}

    final_title = embed_cfg.get("title") or title
    final_footer = embed_cfg.get("footer") or footer
    final_image_url = embed_cfg.get("image_url")

    final_color = color
    color_hex = embed_cfg.get("color")
    if color_hex:
        try:
            final_color = int(color_hex.lstrip("#"), 16)
        except ValueError:
            pass

    embed = disnake.Embed(
        title=final_title,
        description=description,
        color=final_color if final_color is not None else utils.get_primary_color()
    )
    for name, value in fields:
        if value:
            embed.add_field(name=name, value=value, inline=True)
    if final_footer:
        embed.set_footer(text=final_footer)
    if final_image_url:
        embed.set_image(url=final_image_url)

    return {"embed": embed}