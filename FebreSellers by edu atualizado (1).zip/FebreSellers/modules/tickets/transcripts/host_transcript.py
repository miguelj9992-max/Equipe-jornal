"""
Sistema de hospedagem de transcripts usando a API Node
Lê a URL da API do config_api.json
Integra em 3 pontos:
1. Ao fechar ticket (logs)
2. Ao enviar na DM
3. Ao clicar botão
"""

import disnake
from disnake.ext import commands
from functions.utils import utils
import aiohttp
import json
import os
from typing import Optional


def get_transcript_api_url() -> str:
    """Carrega a URL da API de transcripts do config_api.json"""
    try:
        config_path = os.path.join(os.path.dirname(__file__), '../../../configs/config_api.json')
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)

        api_host = config.get('transcripts', 'apiticket.shardweb.app')

        if not api_host.startswith('http'):
            api_host = f'https://{api_host}'

        return api_host.rstrip('/')

    except Exception as e:
        print(f"[TRANSCRIPT] Erro ao carregar config_api.json: {e}")
        return os.getenv("TRANSCRIPT_API_URL", "https://apiticket.shardweb.app").rstrip('/')


async def upload_transcript_to_api(
    transcript_html: str,
    channel_id: int,
    api_url: str = None
) -> Optional[str]:
    """
    Faz upload do transcript para a API Node e retorna a URL.
    """

    if api_url is None:
        api_url = get_transcript_api_url()

    try:
        async with aiohttp.ClientSession() as session:
            payload = {
                "content": transcript_html
            }

            async with session.post(
                f"{api_url}/transcripts/v1/{channel_id}",
                json=payload,
                timeout=aiohttp.ClientTimeout(total=30)
            ) as resp:

                if resp.status == 200:
                    result = await resp.json()
                    link = result.get("link")
                    print(f"[TRANSCRIPT] Upload bem-sucedido: {link}")
                    return link

                error_text = await resp.text()
                print(f"[TRANSCRIPT] Status {resp.status}: {error_text}")

    except Exception as e:
        print(f"[TRANSCRIPT] Erro ao fazer upload: {e}")

    return None


async def log_transcript(
    bot: commands.Bot,
    transcript_file: disnake.File,
    log_channel_id: int = None,
    message_to_reply: disnake.Message = None,
    api_url: str = None
):
    """
    Faz upload do transcript para a API e envia a URL no Discord.
    Usado quando o ticket é fechado e precisa enviar para logs.
    """

    if api_url is None:
        api_url = get_transcript_api_url()

    try:
        # ===== EXTRAIR ID DO CANAL DO NOME DO ARQUIVO =====
        # Esperado: transcript-123456789.html
        raw_name = transcript_file.filename.replace('.html', '')
        channel_id = raw_name.split('-')[-1]

        # ===== LER HTML =====
        transcript_file.fp.seek(0)
        transcript_html = transcript_file.fp.read().decode('utf-8')

        # ===== UPLOAD =====
        transcript_url = await upload_transcript_to_api(
            transcript_html,
            channel_id,
            api_url
        )

        if transcript_url and message_to_reply:

            embed = disnake.Embed(
                title="📄 Transcript do Ticket",
                description=f"[Clique aqui para visualizar o transcript]({transcript_url})",
                color=utils.get_color("success")
            )

            embed.set_footer(text="Transcript hospedado com segurança")

            try:
                await message_to_reply.reply(embed=embed)
                print("[TRANSCRIPT] Embed enviado com sucesso nos logs")
            except Exception as e:
                print(f"[TRANSCRIPT] Erro ao enviar embed: {e}")

        elif not transcript_url:
            print("[TRANSCRIPT] Falha ao fazer upload")

            if message_to_reply:
                try:
                    await message_to_reply.reply(
                        "⚠️ Não foi possível hospedar o transcript na API."
                    )
                except Exception:
                    pass

    except Exception as e:
        print(f"[TRANSCRIPT] Erro geral: {e}")

        if message_to_reply:
            try:
                await message_to_reply.reply(
                    "⚠️ Erro ao processar o transcript."
                )
            except Exception:
                pass