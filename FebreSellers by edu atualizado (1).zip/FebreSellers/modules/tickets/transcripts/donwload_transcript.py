"""
Sistema de download/envio de transcripts para DM
Lê a URL da API do config_api.json
Compatível com API Node /transcripts/v1/:channelId
"""

import disnake
from functions.utils import utils
from functions.emoji import emoji
from functions.database import database as db
from functions.transcript_cache import get_cached_link, save_link_to_cache
from ..utils import get_message_style, build_ticket_message
import json
import os
import aiohttp
from typing import Optional


def get_transcript_api_url() -> str:
    """Carrega a URL da API de transcripts do config_api.json"""
    try:
        config_path = os.path.join(os.path.dirname(__file__), '../../../configs/config_api.json')
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)

        api_host = config.get('transcripts', 'apiticket.shardweb.app')

        if not api_host.startswith('http'):
            api_host = f'https://{api_host}'

        return api_host.rstrip('/')

    except Exception as e:
        print(f"[TRANSCRIPT] Erro ao carregar config_api.json: {e}")
        return os.getenv("TRANSCRIPT_API_URL", "https://apiticket.shardweb.app").rstrip('/')


async def upload_transcript_to_api(
    transcript_html: str,
    channel_id: int,
    api_url: str = None
) -> Optional[str]:
    """
    Faz upload do transcript para a API Node.

    :param transcript_html: Conteúdo HTML do transcript
    :param channel_id: ID do canal
    :param api_url: URL base da API
    :return: URL do transcript ou None
    """

    if api_url is None:
        api_url = get_transcript_api_url()

    try:
        async with aiohttp.ClientSession() as session:
            payload = {
                "content": transcript_html
            }

            async with session.post(
                f"{api_url}/transcripts/v1/{channel_id}",
                json=payload,
                timeout=aiohttp.ClientTimeout(total=30)
            ) as resp:

                if resp.status == 200:
                    result = await resp.json()
                    return result.get("link")

                print(f"[TRANSCRIPT] Status inesperado: {resp.status}")

    except Exception as e:
        print(f"[TRANSCRIPT] Erro ao fazer upload: {e}")

    return None


async def send_transcript_to_dm(interaction: disnake.ApplicationCommandInteraction, transcript_file: disnake.File):
    """
    Envia o transcript gerado para a DM do usuário via link da API.
    """

    config = db.get_document("tickets_config") or {}
    tickets_data = db.get_document("tickets_data") or {}

    panel_id = None
    if isinstance(interaction.channel, (disnake.TextChannel, disnake.Thread)):
        for pid, users in tickets_data.get("panels", {}).items():
            for user_id, tickets in users.items():
                for ticket in tickets:
                    if ticket.get("ticket_id") == interaction.channel.id:
                        panel_id = pid
                        break
                if panel_id:
                    break
            if panel_id:
                break

    panel_data = config.get("panels", {}).get(panel_id, {}) if panel_id else {}
    messages = panel_data.get("messages", {})

    message_template = messages.get(
        "transcript_dm_message",
        "Aqui está o transcript que você solicitou para o ticket `{channel_name}`:"
    )

    message_content = message_template.format(
        channel_name=interaction.channel.name,
        guild_name=interaction.guild.name,
        user_mention=interaction.author.mention,
        user_name=interaction.author.name
    )

    try:
        channel_id = interaction.channel.id

        # ===== CACHE =====
        cached_url = get_cached_link(channel_id)

        if cached_url:
            transcript_url = cached_url
        else:
            transcript_file.fp.seek(0)
            transcript_html = transcript_file.fp.read().decode("utf-8")

            transcript_url = await upload_transcript_to_api(
                transcript_html,
                channel_id
            )

            if transcript_url:
                save_link_to_cache(channel_id, transcript_url)

        # ===== ENVIO DM =====
        if transcript_url:

            transcript_style = get_message_style(panel_data, "TranscriptMessage")
            message_kwargs = build_ticket_message(
                transcript_style,
                title=f"{emoji.receipt} Transcript do Ticket",
                description=message_content,
                fields=[
                    (f"{emoji.folder} Canal", f"`{interaction.channel.name}`"),
                    (f"{emoji.home} Servidor", f"``{interaction.guild.name}``"),
                    (f"{emoji.member} Usuário", interaction.author.mention),
                ],
                footer="Clique no botão abaixo para ver o transcript",
                panel_data=panel_data,
                category="TranscriptMessage"
            )

            view = disnake.ui.View()

            view.add_item(
                disnake.ui.Button(
                    label="Ver transcript",
                    style=disnake.ButtonStyle.link,
                    url=transcript_url
                )
            )

            await interaction.author.send(
                **message_kwargs,
                view=view
            )

            await interaction.followup.send(
                f"{emoji.double_check} Transcript enviado para sua DM!",
                ephemeral=True
            )

        else:
            await interaction.followup.send(
                f"{emoji.wrong} Não foi possível hospedar o transcript na API no momento.",
                ephemeral=True
            )

    except disnake.Forbidden:
        await interaction.followup.send(
            f"{emoji.wrong} Não consegui enviar o transcript para sua DM. Verifique se suas DMs estão abertas.",
            ephemeral=True
        )

    except Exception as e:
        print(f"Erro ao enviar transcript: {e}")
        await interaction.followup.send(
            f"{emoji.wrong} Ocorreu um erro ao processar o transcript.",
            ephemeral=True
        )