import asyncio
import disnake
from functions.utils import utils
from disnake.ext import commands

from .create_ticket import create_ticket_handler
from .setup_functions.close_ticket import CloseTicketModal, close_ticket
from functions.database import database as db
from functions.emoji import emoji
from functions.perms import perms
from functions.ai_api import chamar_ia
from .setup_team import AttendantSetupView
from .setup_member import UserSetupView
from . import setup_functions as sfp
from .setup_functions.transfer import transfer_ticket
from .permissions import check_attendant_permissions, get_attendant_roles

from .info import ticket_info
from .setup_functions.show_history import show_history
from .create_ticket import check_and_create_ticket
from .open_ticket import open_ticket
from ..utils import get_message_style, build_ticket_message
from functions.message import embed_message as message
BASE_PROMPT_FALLBACK = (
    "Você é AI, uma assistente virtual amigável e prestativa. Responda de forma direta, útil e educada."
)

_ticket_claim_locks: dict[int, asyncio.Lock] = {}


def _claim_lock(channel_id: int) -> asyncio.Lock:
    """Retorna um lock por ticket para impedir duas assunções simultâneas."""
    lock = _ticket_claim_locks.get(channel_id)
    if lock is None:
        lock = asyncio.Lock()
        _ticket_claim_locks[channel_id] = lock
    return lock


class TicketFunctionsCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    async def _call_ai(self, full_prompt: str) -> str:
        """Chama a API de IA usando a função centralizada com fallback."""
        return await chamar_ia(full_prompt, "Tickets")

    @staticmethod
    def _find_panel_by_channel(channel_id: int) -> tuple[str | None, dict, dict | None, int | None]:
        tickets_data = db.get_document("tickets_data") or {} or {}
        panels = (tickets_data.get("panels") or {})
        for panel_id, users in panels.items():
            for _uid, tickets in (users or {}).items():
                for t in (tickets or []):
                    if t.get("ticket_id") == channel_id and t.get("status") == "open":
                        config = db.get_document("tickets_config") or {} or {}
                        panel_data = (config.get("panels") or {}).get(panel_id, {})
                        try:
                            owner_id = int(_uid)
                        except (TypeError, ValueError):
                            owner_id = None
                        return panel_id, panel_data, t, owner_id
        return None, {}, None, None

    @commands.Cog.listener("on_button_click")
    async def ticket_actions_listener(self, inter: disnake.MessageInteraction):
        custom_id = inter.component.custom_id
        
        if custom_id.startswith("ticket_form_open:"):
            parts = custom_id.split(":")
            panel_id = parts[1] if len(parts) >= 2 else None
            option_id = parts[2] if len(parts) >= 3 else None
            
            if not panel_id or not option_id:
                await inter.response.send_message("Erro ao processar solicitação.", ephemeral=True)
                return
            
            config = db.get_document("tickets_config") or {}
            panel_data = config.get("panels", {}).get(panel_id)
            if not panel_data:
                await inter.response.send_message("Painel de ticket não encontrado.", ephemeral=True)
                return
            
            questions = panel_data.get("forms", {}).get(option_id, [])
            if not questions:
                await inter.response.send_message("Formulário não encontrado.", ephemeral=True)
                return
            
            option_data = next((opt for opt in panel_data.get("options", []) if str(opt.get("id")) == str(option_id)), None)
            
            from .open_ticket import TicketFormModal
            modal = TicketFormModal(inter, self.bot, panel_data, panel_id, questions, option_data)
            await inter.response.send_modal(modal)
            return
        
        if custom_id.startswith("create_ticket_"):
            panel_id = custom_id.split("_")[-1]
            await create_ticket_handler(inter, self.bot, panel_id)
        elif custom_id in ["close_ticket", "ticket_close_ticket", "ticket_close_ticket_user"]:
            panel_id, panel_data, ticket_data, ticket_owner_id = self._find_panel_by_channel(inter.channel.id)

            if not ticket_data:
                return await inter.response.send_message(
                    f"{emoji.wrong} Este canal não parece ser um ticket aberto.",
                    ephemeral=True
                )

            has_permission = await check_attendant_permissions(
                inter.author,
                inter.channel.id
            )

            if not has_permission:
                return await inter.response.send_message(
                    f"{emoji.wrong} Apenas atendentes podem fechar este ticket.",
                    ephemeral=True
                )

            require_reason = panel_data.get("preferences", {}).get("require_reason", {}).get("enabled", False)
            if require_reason:
                await inter.response.send_modal(CloseTicketModal(self.bot, inter.channel, require_reason=True))
            else:
                await close_ticket(bot=self.bot, channel=inter.channel, closed_by=inter.author, inter=inter)

        elif custom_id == "ticket_attendant_setup":
            panel_id, panel_data, ticket_data, _ = self._find_panel_by_channel(inter.channel.id)
            if not panel_data:
                return await inter.response.send_message(f"{emoji.wrong} Não foi possível encontrar a configuração para este ticket.", ephemeral=True)
            
            has_permission = await check_attendant_permissions(inter.author, inter.channel.id)
            if not has_permission:
                return await inter.response.send_message(f"{emoji.wrong} Você não tem permissão para usar este botão.", ephemeral=True)
            
            option_id = ticket_data.get("option_id")
            option_data = next((opt for opt in panel_data.get("options", []) if str(opt.get("id")) == str(option_id)), None) if option_id else None
            
            view = AttendantSetupView(panel_data, option_data)
            if not view.children:
                await inter.response.send_message("Essa função está desativada.", ephemeral=True)
            else:
                await inter.response.send_message(view=view, ephemeral=True)

        elif custom_id == "ticket_user_setup":
            panel_id, panel_data, ticket_data, _ = self._find_panel_by_channel(inter.channel.id)
            if not panel_data:
                return await inter.response.send_message(f"{emoji.wrong} Não foi possível encontrar a configuração para este ticket.", ephemeral=True)

            option_id = ticket_data.get("option_id")
            option_data = next((opt for opt in panel_data.get("options", []) if str(opt.get("id")) == str(option_id)), None) if option_id else None
            
            view = UserSetupView(panel_data, option_data)
            if not view.children:
                await inter.response.send_message("Essa função está desativada.", ephemeral=True)
            else:
                await inter.response.send_message(view=view, ephemeral=True)

        elif custom_id == "ticket_info":
            await ticket_info(inter)
        
        elif custom_id == "ticket_rename":
            await sfp.rename_ticket(inter)
        
        elif custom_id == "ticket_set_priority":
            await sfp.set_priority(inter, self.bot)

        elif custom_id == "ticket_resolved":
            await sfp.resolved_ticket(inter)
            
        elif custom_id == "ticket_claim":
            # Confirmar a interação antes de qualquer consulta ao banco, busca
            # de cargos ou operação de rede. Sem isso o Discord expira a
            # interação enquanto o banco é lido e o botão aparenta não responder.
            try:
                if not inter.response.is_done():
                    await inter.response.defer(ephemeral=True)
            except (disnake.NotFound, disnake.errors.NotFound):
                return

            async def claim_reply(content: str):
                try:
                    return await inter.followup.send(content, ephemeral=True)
                except Exception as error:
                    print(f"[TICKET] Falha ao enviar resposta de assumir: {error}")
                    return None

            has_permission = await check_attendant_permissions(inter.author, inter.channel.id)

            if not has_permission:
                return await claim_reply(
                    f"{emoji.wrong} Você não tem permissão para assumir este ticket.",
                )

            # A leitura + verificação + gravação deve ser atômica por canal;
            # duas equipes clicando juntas não podem sobrescrever o responsável.
            async with _claim_lock(inter.channel.id):
                tickets_data = db.get_document("tickets_data") or {}
                ticket_ref = None
                ticket_owner_id = None

                for panel in tickets_data.get("panels", {}).values():
                    for uid, user_tickets in (panel or {}).items():
                        for ticket in (user_tickets or []):
                            if ticket.get("ticket_id") == inter.channel.id:
                                ticket_ref = ticket
                                ticket_owner_id = uid
                                break
                        if ticket_ref:
                            break
                    if ticket_ref:
                        break

                if ticket_ref is None:
                    return await claim_reply(
                    f"{emoji.wrong} Não foi possível encontrar os dados deste ticket.",
                    )

                assumed_by = ticket_ref.get("assumed_by")
                if assumed_by is not None and str(assumed_by).strip():
                    if str(assumed_by) == str(inter.author.id):
                        return await claim_reply(
                        f"{emoji.wrong} Você já assumiu este ticket.",
                        )
                    assignee = inter.guild.get_member(int(assumed_by))
                    assignee_name = assignee.mention if assignee else "outro atendente"
                    return await claim_reply(
                        f"{emoji.wrong} Este ticket já foi assumido por {assignee_name}. Não é possível assumir novamente.",
                    )

                ticket_ref["assumed_by"] = inter.author.id
                db.save_document("tickets_data", tickets_data)

            # Desativa o botão na mensagem original para impedir novas tentativas.
            # A checagem no banco acima continua sendo a proteção definitiva para
            # cliques em mensagens antigas ou em caso de mais de uma instância.
            try:
                if inter.message and inter.message.components:
                    for row in inter.message.components:
                        for component in getattr(row, "children", []):
                            if getattr(component, "custom_id", None) == "ticket_claim":
                                component.disabled = True
                    await inter.message.edit(components=inter.message.components)
            except Exception as error:
                print(f"[TICKET] Não foi possível desativar o botão de assumir: {error}")

            from .history import log_ticket_event
            from ..utils import SafeFormatter
            log_ticket_event(inter.channel.id, "assume", inter.author.id)

            config = db.get_document("tickets_config") or {}
            panel_id, panel_data, _, _ = self._find_panel_by_channel(inter.channel.id)
            messages = panel_data.get("messages", {}) if panel_data else {}
            message_template = messages.get(
                "assume_message",
                "{autor_mention} assumiu o atendimento deste ticket."
            )

            ticket_owner = inter.guild.get_member(int(ticket_owner_id)) if ticket_owner_id else None
            placeholders = SafeFormatter(
                autor_mention=inter.author.mention,
                autor_name=inter.author.name,
                channel_name=inter.channel.name,
                guild_name=inter.guild.name,
                user_mention=ticket_owner.mention if ticket_owner else "usuário desconhecido",
                user_name=ticket_owner.name if ticket_owner else "usuário desconhecido",
            )
            formatted_message = message_template.format_map(placeholders)

            await claim_reply(
                f"{emoji.correct} Você assumiu este ticket com sucesso!",
            )

            assume_style = get_message_style(panel_data, "AssumeMessage")
            channel_kwargs = build_ticket_message(
                assume_style,
                title=f"{emoji.correct}Ticket Assumido",
                description=formatted_message,
                footer=f"Atendente: {inter.author.display_name}",
                panel_data=panel_data,
                category="AssumeMessage"
            )
            if "embed" in channel_kwargs:
                channel_kwargs["embed"].timestamp = disnake.utils.utcnow()
            try:
                await asyncio.wait_for(inter.channel.send(**channel_kwargs), timeout=10)
            except asyncio.TimeoutError:
                print(f"[TICKET] Timeout ao enviar mensagem pública de assumir no canal {inter.channel.id}")
            except Exception as error:
                print(f"[TICKET] Falha ao enviar mensagem pública de assumir: {error}")

            try:
                msg = inter.message
                if msg and msg.embeds:
                    embed = msg.embeds[0].copy()
                    staff_text = inter.author.mention
                    updated = False
                    for index, field in enumerate(embed.fields):
                        if "staff" in field.name.lower():
                            embed.set_field_at(
                                index,
                                name=f"{emoji.shield} Staff responsável",
                                value=staff_text,
                                inline=field.inline
                            )
                            updated = True
                            break
                    if not updated:
                        embed.add_field(
                            name=f"{emoji.shield} Staff responsável",
                            value=staff_text,
                            inline=True
                        )
                    await msg.edit(embed=embed)
            except Exception as e:
                print(f"Erro ao atualizar painel do ticket: {e}")

            try:
                if ticket_owner_id:
                    owner = await asyncio.wait_for(
                        inter.guild.fetch_member(int(ticket_owner_id)), timeout=8
                    )
                    if owner:
                        dm_template = messages.get(
                            "assume_dm_message",
                            "Olá {user_mention}, o atendente {autor_mention} assumiu seu ticket `{channel_name}`."
                        )
                        dm_message = dm_template.format_map(placeholders)
                        dm_kwargs = build_ticket_message(
                            assume_style,
                            title="Seu ticket foi assumido",
                            description=dm_message,
                            panel_data=panel_data,
                            category="AssumeMessage"
                        )
                        button = disnake.ui.Button(
                            label="Ir para o Ticket",
                            style=disnake.ButtonStyle.link,
                            url=inter.channel.jump_url
                        )
                        await asyncio.wait_for(
                            owner.send(**dm_kwargs, components=[button]), timeout=8
                        )
            except asyncio.TimeoutError:
                print(f"[TICKET] Timeout ao enviar DM de assumir para {ticket_owner_id}")
            except Exception as error:
                print(f"[TICKET] DM de assumir não enviada: {error}")
            
        elif custom_id == "ticket_leave_user":
            await inter.response.defer(ephemeral=True)
            from .setup_functions.leave_ticket import leave_ticket
            await leave_ticket(inter, self.bot)

        elif custom_id == "ticket_close_after_leave":
            has_permission = await check_attendant_permissions(inter.author, inter.channel.id)
            if not has_permission:
                return await inter.response.send_message(
                    f"{emoji.wrong} Apenas atendentes podem fechar este ticket.",
                    ephemeral=True,
                )
            await close_ticket(bot=self.bot, channel=inter.channel, closed_by=inter.author, inter=inter)

        elif custom_id == "ticket_add_user":
            await sfp.add_user(inter)
            
        elif custom_id == "ticket_remove_user":
            await sfp.remove_user(inter)
            
        elif custom_id == "ticket_notify":
            await sfp.notify(inter)
            
        elif custom_id == "ticket_create_call":
            await sfp.create_call(inter)
            
        elif custom_id == "ticket_transcript":
            await sfp.transcript(inter, self.bot)
            
        elif custom_id == "ticket_history":
            await sfp.show_history(inter)
            
        elif custom_id == "ticket_notes":
            await sfp.notes(inter)
            
        elif custom_id == "ticket_transfer":
            await transfer_ticket(inter)
        
        elif custom_id == "ticket_payment":
            await sfp.generate_pay(inter)
            
        elif custom_id == "ticket_add_user_user":
            await sfp.add_user(inter)
            
        elif custom_id == "ticket_remove_user_user":
            await sfp.remove_user(inter)
            
        elif custom_id == "ticket_transcript_user":
            await sfp.transcript(inter, self.bot)
            
        elif custom_id == "ticket_review":
            await sfp.review(inter)
            
        elif custom_id == "ticket_notify_user":
            await sfp.notify(inter)
            
        elif custom_id == "ticket_transfer_user":
            await transfer_ticket(inter)
            
        elif custom_id == "ticket_payment_user":
            await sfp.generate_pay(inter)

        elif custom_id == "ticket_request_call_user":
            await sfp.request_call(inter)
            
        elif custom_id == "ticket_approve_call_request":
            await sfp.approve_call_request(inter)
            
        elif custom_id == "ticket_archive":
            await sfp.archive_ticket(inter)
            
        elif custom_id == "ticket_unarchive":
            await sfp.unarchive_ticket(inter)

        elif custom_id.startswith("TicketReview_Rate_"):
            parts = custom_id.split("_")
            try:
                stars = int(parts[-1])
                channel_id = int(parts[-2])
                owner_id = parts[-3]
                panel_id = "_".join(parts[2:-3])
            except (ValueError, IndexError):
                return

            if not (1 <= stars <= 5):
                return

            tickets_data = db.get_document("tickets_data") or {}
            tickets = (
                tickets_data.get("panels", {})
                .get(panel_id, {})
                .get(str(owner_id), [])
            )
            ticket = next((tk for tk in tickets if tk.get("ticket_id") == channel_id), None)
            channel_name = (ticket or {}).get("channel_name") or "ticket"

            if ticket is None:
                return await inter.response.send_message(
                    "Não foi possível encontrar este ticket, a avaliação não pôde ser salva.",
                    ephemeral=True,
                )

            if ticket.get("review"):
                return await inter.response.send_message(
                    "Você já avaliou este ticket, obrigado!",
                    ephemeral=True,
                )

            config = db.get_document("tickets_config") or {}
            panel_data = config.get("panels", {}).get(panel_id, {})
            ask_comment = panel_data.get("preferences", {}).get("review", {}).get("ask_comment", False)

            if ask_comment:
                await inter.response.send_modal(
                    sfp.ReviewCommentModal(panel_id, owner_id, channel_id, channel_name, stars)
                )
            else:
                await sfp.finalize_review(inter, panel_id, owner_id, channel_id, channel_name, stars)

    @commands.Cog.listener("on_dropdown")
    async def ticket_dropdown_listener(self, inter: disnake.MessageInteraction):
        custom_id = inter.component.custom_id

        if custom_id.startswith("ticket_panel_option_select_"):
            panel_id = custom_id.replace("ticket_panel_option_select_", "")
            option_id = inter.values[0]

            config = db.get_document("tickets_config") or {}
            panel_data = config.get("panels", {}).get(panel_id)
            if not panel_data:
                if inter.response.is_done():
                    await inter.followup.send("Painel de ticket não encontrado.", ephemeral=True)
                else:
                    await inter.response.send_message("Painel de ticket não encontrado.", ephemeral=True)
                return

            options = panel_data.get("options", [])
            selected_option = next((opt for opt in options if str(opt.get("id")) == option_id), None)
            if not selected_option:
                if inter.response.is_done():
                    await inter.followup.send("Opção selecionada inválida.", ephemeral=True)
                else:
                    await inter.response.send_message("Opção selecionada inválida.", ephemeral=True)
                return

            await check_and_create_ticket(inter, self.bot, panel_id, selected_option)

        elif custom_id == "ticket_attendant_action_select":
            action = inter.values[0]

            if action == "ticket_notify":
                await sfp.notify(inter)
            elif action == "ticket_rename":
                await sfp.rename_ticket(inter)
            elif action == "ticket_add_user":
                await sfp.add_user(inter)
            elif action == "ticket_remove_user":
                await sfp.remove_user(inter)
            elif action == "ticket_transcript":
                await sfp.transcript(inter, self.bot)
            elif action == "ticket_close_ticket":
                panel_id, panel_data, ticket_data, ticket_owner_id = self._find_panel_by_channel(inter.channel.id)
                if not ticket_data:
                    return await inter.response.send_message(
                        f"{emoji.wrong} Este canal não parece ser um ticket aberto.",
                        ephemeral=True
                    )
                has_permission = await check_attendant_permissions(inter.author, inter.channel.id)
                if not has_permission:
                    return await inter.response.send_message(
                        f"{emoji.wrong} Apenas atendentes podem fechar este ticket.",
                        ephemeral=True
                    )
                require_reason = panel_data.get("preferences", {}).get("require_reason", {}).get("enabled", False)
                if require_reason:
                    await inter.response.send_modal(CloseTicketModal(self.bot, inter.channel, require_reason=True))
                else:
                    await close_ticket(bot=self.bot, channel=inter.channel, closed_by=inter.author, inter=inter)
            elif action == "ticket_set_priority":
                await sfp.set_priority(inter, self.bot)
            elif action == "ticket_resolved":
                await sfp.resolved_ticket(inter)
            elif action == "ticket_archive":
                await sfp.archive_ticket(inter)
            elif action == "ticket_history":
                await sfp.show_history(inter)
            elif action == "ticket_create_call":
                await sfp.create_call(inter)
            elif action == "ticket_transfer":
                await transfer_ticket(inter)
            elif action == "ticket_payment":
                await sfp.generate_pay(inter)

        elif custom_id == "ticket_user_action_select":
            action = inter.values[0]

            if action == "ticket_close_ticket_user":
                panel_id, panel_data, ticket_data, ticket_owner_id = self._find_panel_by_channel(inter.channel.id)
                if not ticket_data:
                    return await inter.response.send_message(
                        f"{emoji.wrong} Este canal não parece ser um ticket aberto.",
                        ephemeral=True
                    )
                require_reason = panel_data.get("preferences", {}).get("require_reason", {}).get("enabled", False)
                if require_reason:
                    await inter.response.send_modal(CloseTicketModal(self.bot, inter.channel, require_reason=True))
                else:
                    await close_ticket(bot=self.bot, channel=inter.channel, closed_by=inter.author, inter=inter)

            elif action == "ticket_notify_user":
                await sfp.notify(inter)
            elif action == "ticket_add_user_user":
                await sfp.add_user(inter)
            elif action == "ticket_remove_user_user":
                await sfp.remove_user(inter)
            elif action == "ticket_transfer_user":
                await transfer_ticket(inter)
            elif action == "ticket_request_call_user":
                await sfp.request_call(inter)
            elif action == "ticket_transcript_user":
                await sfp.transcript(inter, self.bot)
            elif action == "ticket_leave_user":
                from .setup_functions.leave_ticket import leave_ticket
                await leave_ticket(inter, self.bot)

    @commands.Cog.listener("on_message")
    async def on_ticket_message(self, message: disnake.Message):
        if message.author.bot:
            return

        tickets_data = db.get_document("tickets_data") or {}
        ticket_found = False
        channel_id = None

        if message.guild:
            panel_id, panel_data, ticket_data, _ = self._find_panel_by_channel(message.channel.id)
            if panel_id:
                channel_id = message.channel.id
        
        if channel_id:
            for panel in tickets_data.get("panels", {}).values():
                for user_tickets in panel.values():
                    for ticket in user_tickets:
                        if ticket.get("ticket_id") == channel_id and ticket.get("status") == "open":
                            ticket['last_activity_timestamp'] = int(message.created_at.timestamp())
                            ticket_found = True
                            break
                    if ticket_found: break
                if ticket_found: break
            
            if ticket_found:
                db.save_document("tickets_data", tickets_data)

        tickets_data = db.get_document("tickets_data") or {} or {}
        data_changed = False

        if not message.guild:
            return

        panel_id, panel_data, ticket_data, _ = self._find_panel_by_channel(message.channel.id)
        if not panel_id or not panel_data or not panel_data.get("ai_enabled", False):
            if data_changed: db.save_document("tickets_data", tickets_data)
            return

        ticket_id_to_check = str(message.channel.id)
        
        ai_silenced_map = tickets_data.setdefault("ai_silenced", {})
        if ai_silenced_map.get(ticket_id_to_check):
            if data_changed: db.save_document("tickets_data", tickets_data)
            return

        option_id = ticket_data.get("option_id")
        option_data = next((opt for opt in panel_data.get("options", []) if str(opt.get("id")) == str(option_id)), None) if option_id else None

        roles_config = {}
        if option_data:
            roles_config = option_data.get("roles", {})
        else:
            roles_config = panel_data.get("roles", {})

        atendentes_roles = get_attendant_roles(roles_config)
        is_atendente = isinstance(message.author, disnake.Member) and any(
            r.id in atendentes_roles for r in (message.author.roles or [])
        )

        mode = db.get_document("custom_mode").get("mode")
        primary_color_hex = db.get_document("custom_colors").get("primary")
        
        message_content = (
            f"{emoji.wand} **AI pausada para este ticket.**\n"
            f"{emoji.member} Um atendente já respondeu. A IA não responderá mais aqui."
        )

        if is_atendente:
            ai_silenced_map[ticket_id_to_check] = True
            data_changed = True
            try:
                if mode == "components":
                    container_kwargs = {}
                    if primary_color_hex:
                        container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))
                    await message.channel.send(
                        components=[
                            disnake.ui.Container(
                                disnake.ui.TextDisplay(message_content),
                                **container_kwargs
                            ),
                            disnake.ui.ActionRow(
                                disnake.ui.Button(
                                    label="Mensagem do Sistema",
                                    style=disnake.ButtonStyle.grey,
                                    disabled=True,
                                    custom_id="TicketAI_SystemBadge"
                                )
                            )
                        ],
                        flags=disnake.MessageFlags(is_components_v2=True)
                    )
                else:
                    embed_kwargs = {}
                    if primary_color_hex:
                        embed_kwargs["color"] = int(primary_color_hex.replace("#", ""), 16)
                    embed = disnake.Embed(
                        description=message_content,
                        **embed_kwargs
                    )
                    system_badge = disnake.ui.ActionRow(
                        disnake.ui.Button(
                            label="Mensagem do Sistema",
                            style=disnake.ButtonStyle.grey,
                            disabled=True,
                            custom_id="TicketAI_SystemBadge"
                        )
                    )
                    await message.channel.send(embed=embed, components=[system_badge])

            except Exception: pass
        
        else:
            user_text = (message.content or "").strip()
            if not user_text:
                if data_changed: db.save_document("tickets_data", tickets_data)
                return

            prompt_config = panel_data.get("ai_prompt") or BASE_PROMPT_FALLBACK
            full_prompt = f"{prompt_config}\n\nUsuário: {user_text}\nAssistente:"
            ai_text = await self._call_ai(full_prompt)
            if not ai_text:
                if data_changed: db.save_document("tickets_data", tickets_data)
                return

            ai_text = ai_text[:1900]
            try:
                await message.reply(ai_text, allowed_mentions=disnake.AllowedMentions.none())
            except Exception:
                try:
                    await message.channel.send(ai_text, allowed_mentions=disnake.AllowedMentions.none())
                except Exception: pass
        
        if data_changed:
            db.save_document("tickets_data", tickets_data)


def setup(bot: commands.Bot):
    bot.add_cog(TicketFunctionsCog(bot))
