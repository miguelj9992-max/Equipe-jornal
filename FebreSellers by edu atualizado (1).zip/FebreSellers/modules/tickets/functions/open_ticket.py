import disnake
import aiohttp
import io
import re
import time
import asyncio

from functions.emoji import emoji
from disnake.ext import commands
from functions.database import database as db
from functions.message import embed_message
from .ticket_checks import check_office_hours, check_permissions, check_existing_ticket
from modules.tickets.config.container_utils import ContainerUtils
from .logs_tickets import log_ticket_creation
from functions.utils import utils
from .permissions import get_attendant_roles


class TicketFormModal(disnake.ui.Modal):
    def __init__(self, inter: disnake.Interaction, bot: commands.Bot, panel_data: dict, panel_id: str, questions: list, option_data: dict = None):
        self.inter = inter
        self.bot = bot
        self.panel_data = panel_data
        self.panel_id = panel_id
        self.option_data = option_data
        self.questions = questions

        components = []
        for question in questions:
            style = disnake.TextInputStyle.paragraph if question.get("style") == "paragraph" else disnake.TextInputStyle.short
            components.append(
                disnake.ui.TextInput(
                    label=question["label"],
                    custom_id=str(question["id"]),
                    style=style,
                    placeholder=question.get("placeholder"),
                    required=question.get("required", True),
                    max_length=500
                )
            )

        super().__init__(title="Responda para Abrir o Ticket", components=components)

    async def callback(self, inter: disnake.ModalInteraction):
        # Garantir que emoji está disponível
        from functions.emoji import emoji
        
        # Fazer defer imediatamente para não expirar a interação durante verificações async
        if not inter.response.is_done():
            await inter.response.defer(ephemeral=True)
        
        # Mostrar mensagem de carregamento enquanto verifica
        loading_msg = await inter.followup.send(f"{emoji.loading} Verificando informações...", ephemeral=True)
        
        # Verificações LENTAS (OAuth2, horário, permissões, ticket existente)
        try:
            # Verificar se a verificação OAuth2 é obrigatória
            from modules.cloud.verification_check import is_verification_required, send_verification_required_message, is_user_verified
            
            if is_verification_required():
                # Verificar se o usuário está verificado na database antes de criar o ticket
                if isinstance(inter.user, disnake.Member):
                    member = inter.user
                elif inter.guild:
                    member = inter.guild.get_member(inter.user.id)
                else:
                    member = None
                
                if member:
                    verified = await is_user_verified(member)
                    if not verified:
                        # Deletar mensagem de loading e enviar mensagem de verificação
                        try:
                            if loading_msg:
                                try:
                                    await loading_msg.delete()
                                except:
                                    pass    
                        except:
                            pass
                        await send_verification_required_message(inter)
                        # Resetar o painel para remover valores selecionados dos selects
                        try:
                            if isinstance(self.inter, disnake.MessageInteraction) and hasattr(self.inter, 'message') and self.inter.message:
                                await reset_panel_message(self.inter, self.panel_data, self.panel_id, inter.user)
                            elif hasattr(inter, 'channel') and inter.channel and inter.guild:
                                # Buscar mensagens recentes do bot no canal que contenham o painel
                                async for msg in inter.channel.history(limit=20):
                                    if msg.author == inter.guild.me and msg.components:
                                        # Verificar se é a mensagem do painel procurando pelos custom_ids
                                        is_panel = False
                                        for component in message.components:
                                            if isinstance(component, disnake.ui.ActionRow):
                                                for item in component.children:
                                                    if hasattr(item, 'custom_id'):
                                                        custom_id = item.custom_id
                                                        if custom_id == f"create_ticket_{self.panel_id}" or custom_id == f"ticket_panel_option_select_{self.panel_id}":
                                                            is_panel = True
                                                            break
                                                if is_panel:
                                                    break
                                        if is_panel:
                                            # Criar objeto fake com message para resetar
                                            class FakeInter:
                                                def __init__(self, msg, guild):
                                                    self.channel = msg.channel
                                                    self.message = msg
                                            
                                            fake_inter = FakeInter(msg, inter.guild)
                                            await reset_panel_message(fake_inter, self.panel_data, self.panel_id)
                                            break
                        except Exception as e:
                            print(f"Erro ao resetar painel após mostrar mensagem de verificação no modal: {e}")
                        return

            # Verificar se a verificação PRÓPRIA do bot é obrigatória para abrir tickets
            from modules.verification import service as verification_service
            if not await verification_service.require_verification(inter, "tickets", loading_message=loading_msg):
                try:
                    await safe_reset_panel(self.inter if isinstance(self.inter, disnake.MessageInteraction) else inter, self.panel_data, self.panel_id)
                except Exception as e:
                    print(f"Erro ao resetar painel após bloqueio de verificação própria no modal: {e}")
                return
        except Exception as e:
            # Se houver erro na verificação, continuar normalmente (não bloquear)
            import traceback
            print(f"Erro ao verificar verificação OAuth2 no modal: {e}")
            traceback.print_exc()
        
        form_answers = {
            str(q["id"]): inter.text_values[str(q["id"])]
            for q in self.questions
        }
        
        # Verificações de horário, permissões e ticket existente
        ok, error_msg = await check_office_hours(inter, self.panel_data)
        if not ok:
            try:
                await loading_msg.edit(content=error_msg)
            except:
                await inter.followup.send(error_msg, ephemeral=True)    
            # Resetar o painel quando verificação falhar
            try:
                if isinstance(self.inter, disnake.MessageInteraction) and hasattr(self.inter, 'message') and self.inter.message:
                    await reset_panel_message(self.inter, self.panel_data, self.panel_id, inter.user)
                elif hasattr(inter, 'channel') and inter.channel and inter.guild:
                    # Buscar mensagens recentes do bot no canal que contenham o painel
                    async for message in inter.channel.history(limit=20):
                        if message.author == inter.guild.me and message.components:
                            # Verificar se é a mensagem do painel procurando pelos custom_ids
                            is_panel = False
                            for component in message.components:
                                if isinstance(component, disnake.ui.ActionRow):
                                    for item in component.children:
                                        if hasattr(item, 'custom_id'):
                                            custom_id = item.custom_id
                                            if custom_id == f"create_ticket_{self.panel_id}" or custom_id == f"ticket_panel_option_select_{self.panel_id}":
                                                is_panel = True
                                                break
                                    if is_panel:
                                        break
                            if is_panel:
                                # Criar objeto fake com message para resetar
                                class FakeInter:
                                    def __init__(self, msg, guild):
                                        self.message = msg
                                        self.guild = guild
                                
                                fake_inter = FakeInter(message, inter.guild)
                                await reset_panel_message(fake_inter, self.panel_data, self.panel_id)
                                break
            except Exception as e:
                print(f"Erro ao resetar painel após falha em verificação: {e}")
            return

        ok, error_msg = await check_permissions(inter, self.panel_data, self.option_data)
        if not ok:
            if loading_msg:
                try:
                    await loading_msg.edit(content=error_msg)
                except:
                    pass    
            # Resetar o painel quando verificação falhar
            try:
                if isinstance(self.inter, disnake.MessageInteraction) and hasattr(self.inter, 'message') and self.inter.message:
                    await reset_panel_message(self.inter, self.panel_data, self.panel_id, inter.user)
                elif hasattr(inter, 'channel') and inter.channel and inter.guild:
                    # Buscar mensagens recentes do bot no canal que contenham o painel
                    async for message in inter.channel.history(limit=20):
                        if message.author == inter.guild.me and message.components:
                            # Verificar se é a mensagem do painel procurando pelos custom_ids
                            is_panel = False
                            for component in message.components:
                                if isinstance(component, disnake.ui.ActionRow):
                                    for item in component.children:
                                        if hasattr(item, 'custom_id'):
                                            custom_id = item.custom_id
                                            if custom_id == f"create_ticket_{self.panel_id}" or custom_id == f"ticket_panel_option_select_{self.panel_id}":
                                                is_panel = True
                                                break
                                    if is_panel:
                                        break
                            if is_panel:
                                # Criar objeto fake com message para resetar
                                class FakeInter:
                                    def __init__(self, msg, guild):
                                        self.message = msg
                                        self.guild = guild
                                
                                fake_inter = FakeInter(msg, inter.guild)
                                await reset_panel_message(fake_inter, self.panel_data, self.panel_id)
                                break
            except Exception as e:
                print(f"Erro ao resetar painel após falha em verificação: {e}")
            return

        ok, error_msg = await check_existing_ticket(inter, self.bot, self.panel_id)
        if not ok:
            await loading_msg.edit(content=error_msg)
            # Resetar o painel quando verificação falhar
            try:
                if isinstance(self.inter, disnake.MessageInteraction) and hasattr(self.inter, 'message') and self.inter.message:
                    await reset_panel_message(self.inter, self.panel_data, self.panel_id, inter.user)
                elif hasattr(inter, 'channel') and inter.channel and inter.guild:
                    # Buscar mensagens recentes do bot no canal que contenham o painel
                    async for message in inter.channel.history(limit=20):
                        if message.author == inter.guild.me and message.components:
                            # Verificar se é a mensagem do painel procurando pelos custom_ids
                            is_panel = False
                            for component in message.components:
                                if isinstance(component, disnake.ui.ActionRow):
                                    for item in component.children:
                                        if hasattr(item, 'custom_id'):
                                            custom_id = item.custom_id
                                            if custom_id == f"create_ticket_{self.panel_id}" or custom_id == f"ticket_panel_option_select_{self.panel_id}":
                                                is_panel = True
                                                break
                                    if is_panel:
                                        break
                            if is_panel:
                                # Criar objeto fake com message para resetar
                                class FakeInter:
                                    def __init__(self, msg, guild):
                                        self.message = msg
                                        self.guild = guild
                                
                                fake_inter = FakeInter(msg, inter.guild)
                                await reset_panel_message(fake_inter, self.panel_data, self.panel_id)
                                break
            except Exception as e:
                print(f"Erro ao resetar painel após falha em verificação: {e}")
            return

        # Não deletar a mensagem de loading - ela será editada com a mensagem de sucesso
        try:
            await _finish_ticket_creation(
                inter, self.bot, self.panel_data, self.panel_id,
                option_data=self.option_data,
                form_answers=form_answers,
                loading_message=loading_msg
            )
            # Resetar a mensagem do painel original
            # Se self.inter tem message (interação original), usar ela
            # Caso contrário, buscar a mensagem do painel no canal
            try:
                if isinstance(self.inter, disnake.MessageInteraction) and hasattr(self.inter, 'message') and self.inter.message:
                    await reset_panel_message(self.inter, self.panel_data, self.panel_id, inter.user)
                elif hasattr(inter, 'channel') and inter.channel and inter.guild:
                    # Buscar mensagens recentes do bot no canal que contenham o painel
                    async for message in inter.channel.history(limit=20):
                        if message.author == inter.guild.me and message.components:
                            # Verificar se é a mensagem do painel procurando pelos custom_ids
                            is_panel = False
                            for component in message.components:
                                if isinstance(component, disnake.ui.ActionRow):
                                    for item in component.children:
                                        if hasattr(item, 'custom_id'):
                                            custom_id = item.custom_id
                                            if custom_id == f"create_ticket_{self.panel_id}" or custom_id == f"ticket_panel_option_select_{self.panel_id}":
                                                is_panel = True
                                                break
                                    if is_panel:
                                        break
                            if is_panel:
                                # Criar objeto fake com message para resetar
                                class FakeInter:
                                    def __init__(self, msg, guild):
                                        self.message = msg
                                        self.guild = guild
                                
                                fake_inter = FakeInter(msg, inter.guild)
                                await reset_panel_message(fake_inter, self.panel_data, self.panel_id)
                                break
            except Exception as e:
                print(f"Erro ao resetar painel após criar ticket via modal: {e}")
        except (ValueError, disnake.HTTPException) as e:
            # Garantir que emoji está disponível
            # Verificar se é erro de limite de canais
            error_message = str(e)
            if "Limite de canais exedido" in error_message or ("maximum" in error_message.lower() and "channel" in error_message.lower()):
                error_msg = f"{emoji.wrong} Limite de canais exedido na categoria, contate com administrador."
            elif isinstance(e, ValueError):
                error_msg = f"{emoji.wrong} {str(e)}"
            else:
                error_msg = f"{emoji.wrong} Ocorreu um erro ao criar o ticket: {e}"
            
            try:
                await loading_msg.edit(content=error_msg)
            except:
                await inter.followup.send(content=error_msg, ephemeral=True)
            # Resetar o painel quando erro ocorrer
            try:
                if isinstance(self.inter, disnake.MessageInteraction) and hasattr(self.inter, 'message') and self.inter.message:
                    await reset_panel_message(self.inter, self.panel_data, self.panel_id, inter.user)
                elif hasattr(inter, 'channel') and inter.channel and inter.guild:
                    # Buscar mensagens recentes do bot no canal que contenham o painel
                    async for message in inter.channel.history(limit=20):
                        if message.author == inter.guild.me and message.components:
                            # Verificar se é a mensagem do painel procurando pelos custom_ids
                            is_panel = False
                            for component in message.components:
                                if isinstance(component, disnake.ui.ActionRow):
                                    for item in component.children:
                                        if hasattr(item, 'custom_id'):
                                            custom_id = item.custom_id
                                            if custom_id == f"create_ticket_{self.panel_id}" or custom_id == f"ticket_panel_option_select_{self.panel_id}":
                                                is_panel = True
                                                break
                                    if is_panel:
                                        break
                            if is_panel:
                                # Criar objeto fake com message para resetar
                                class FakeInter:
                                    def __init__(self, msg, guild):
                                        self.message = msg
                                        self.guild = guild
                                
                                fake_inter = FakeInter(msg, inter.guild)
                                await reset_panel_message(fake_inter, self.panel_data, self.panel_id)
                                break
            except Exception as reset_error:
                print(f"Erro ao resetar painel após erro: {reset_error}")
        except Exception as e:
            # Garantir que emoji está disponível
            from functions.emoji import emoji
            try:
                await loading_msg.edit(content=f"{emoji.wrong} Ocorreu um erro inesperado: {e}")
            except:
                await inter.followup.send(content=f"{emoji.wrong} Ocorreu um erro inesperado: {e}", ephemeral=True)
            # Resetar o painel quando erro ocorrer
            try:
                if isinstance(self.inter, disnake.MessageInteraction) and hasattr(self.inter, 'message') and self.inter.message:
                    await reset_panel_message(self.inter, self.panel_data, self.panel_id, inter.user)
                elif hasattr(inter, 'channel') and inter.channel and inter.guild:
                    # Buscar mensagens recentes do bot no canal que contenham o painel
                    async for message in inter.channel.history(limit=20):
                        if message.author == inter.guild.me and message.components:
                            # Verificar se é a mensagem do painel procurando pelos custom_ids
                            is_panel = False
                            for component in message.components:
                                if isinstance(component, disnake.ui.ActionRow):
                                    for item in component.children:
                                        if hasattr(item, 'custom_id'):
                                            custom_id = item.custom_id
                                            if custom_id == f"create_ticket_{self.panel_id}" or custom_id == f"ticket_panel_option_select_{self.panel_id}":
                                                is_panel = True
                                                break
                                    if is_panel:
                                        break
                            if is_panel:
                                # Criar objeto fake com message para resetar
                                class FakeInter:
                                    def __init__(self, msg, guild):
                                        self.message = msg
                                        self.guild = guild
                                
                                fake_inter = FakeInter(msg, inter.guild)
                                await reset_panel_message(fake_inter, self.panel_data, self.panel_id)
                                break
            except Exception as reset_error:
                print(f"Erro ao resetar painel após erro: {reset_error}")

async def reset_panel_message(inter: disnake.MessageInteraction, panel_data: dict, panel_id: str):
    """Reseta a mensagem do painel removendo valores selecionados dos selects"""
    try:
        if not hasattr(inter, 'message') or not inter.message:
            return
        
        style = panel_data.get("message_style", "embed")
        payload = {}
        options = panel_data.get("options", [])
        action_row = None

        if len(options) > 1:
            select_options = []
            for opt in options:
                try:
                    opt_emoji = opt.get("emoji")
                    parsed_emoji = None
                    if opt_emoji:
                        parsed_emoji = utils.safe_get_emoji(opt_emoji)
                    
                    select_options.append(
                        disnake.SelectOption(
                            label=opt.get("name", "Opção sem nome"),
                            value=str(opt.get("id")),
                            emoji=parsed_emoji,
                            description=opt.get("description")
                        )
                    )
                except Exception:
                    select_options.append(
                        disnake.SelectOption(
                            label=opt.get("name", "Opção sem nome"),
                            value=str(opt.get("id")),
                            emoji=None,
                            description=opt.get("description")
                        )
                    )
            
            select = disnake.ui.StringSelect(
                custom_id=f"ticket_panel_option_select_{panel_id}",
                placeholder="Selecione uma opção para abrir o ticket...",
                options=select_options
            )
            action_row = disnake.ui.ActionRow(select)
        else:
            button_data = panel_data.get("button", {})
            button_style_map = {
                "green": disnake.ButtonStyle.success, "grey": disnake.ButtonStyle.secondary,
                "red": disnake.ButtonStyle.danger, "blue": disnake.ButtonStyle.primary
            }
            
            options = panel_data.get("options", [])

            if len(options) == 1:
                button_label = options[0].get("name") or "Abrir Ticket"
                button_emoji_raw = options[0].get("emoji") or button_data.get("emoji")
            else:
                button_label = button_data.get("label") or "Abrir Ticket"
                button_emoji_raw = button_data.get("emoji")

            button_emoji = None

            if button_emoji_raw:
                button_emoji = utils.safe_get_emoji(button_emoji_raw)

            if not button_emoji:
                button_emoji = emoji.mail2
            
            button_style = button_style_map.get(button_data.get("style", "grey").lower(), disnake.ButtonStyle.secondary)
            
            try:
                button = disnake.ui.Button(
                    label=button_label, 
                    emoji=button_emoji,
                    style=button_style, 
                    custom_id=f"create_ticket_{panel_id}"
                )
            except Exception:
                button = disnake.ui.Button(
                    label=button_label, 
                    emoji=None,
                    style=button_style, 
                    custom_id=f"create_ticket_{panel_id}"
                )
            action_row = disnake.ui.ActionRow(button)

        if style == "embed":
            content_data = panel_data.get("embed", {})
            try:
                color_str = content_data.get("color", "#ffffff").lstrip("#")
                color = disnake.Color(int(color_str, 16))
            except (ValueError, TypeError):
                color = utils.get_color("primary")

            embed = disnake.Embed(
                title=content_data.get("title"), 
                description=content_data.get("description"),
                color=color
            )
            
            # embed.set_thumbnail(url=inter.guild.icon.url if inter.guild.icon else None)

            if image_url := content_data.get("image_url"):
                if "http" in image_url: embed.set_image(url=image_url)
            if thumb_url := content_data.get("thumbnail_url"):
                if "http" in thumb_url: embed.set_thumbnail(url=thumb_url)
            if footer_text := content_data.get("footer"):
                embed.set_footer(text=footer_text)
            
            payload["embed"] = embed
            payload["components"] = [action_row]
            
        elif style == "content":
            content_data = panel_data.get("content", {})
            payload["content"] = content_data.get("content")
            payload["components"] = [action_row]
            if image_url := content_data.get("image_url"):
                if "http" in image_url:
                    try:
                        async with aiohttp.ClientSession() as session:
                            async with session.get(image_url) as resp:
                                if resp.status == 200:
                                    image_bytes = await resp.read()
                                    payload["file"] = disnake.File(io.BytesIO(image_bytes), filename="image.png")
                    except Exception:
                        pass
                        
        elif style == "container":
            content_data = panel_data.get("container", {})
            content = content_data.get("content")
            image_url = content_data.get("image_url")
            thumbnail_url = content_data.get("thumbnail_url")
            color_hex = content_data.get("color")

            container = ContainerUtils.montar_container(
                conteudo=content, 
                imagem_url=image_url, 
                cor_hex=color_hex, 
                extra_children=[action_row],
                thumbnail_url=thumbnail_url
            )
            payload["components"] = [container]
            payload["flags"] = disnake.MessageFlags(is_components_v2=True)

        # Editar a mensagem do painel
        try:
            # Verificar se a mensagem ainda existe e está acessível
            if not inter.message:
                return
            
            # Tentar buscar a mensagem novamente para garantir que ainda existe
            try:
                message = await inter.message.channel.fetch_message(inter.message.id)
            except (disnake.NotFound, disnake.HTTPException):
                # Mensagem não existe mais, não podemos editá-la
                return
            
            await message.edit(**payload)
        except (disnake.NotFound, disnake.HTTPException) as e:
            # Mensagem pode ter sido deletada ou não estar mais acessível
            # Não fazer nada, apenas ignorar silenciosamente
            pass
        except Exception as e:
            print(f"Erro inesperado ao resetar painel: {e}")
    except Exception as e:
        # Falha silenciosamente se não conseguir resetar o painel
        print(f"Erro ao resetar painel: {e}")

async def safe_reset_panel(inter, panel_data, panel_id):
    try:
        if isinstance(inter, disnake.MessageInteraction) and inter.message:
            await reset_panel_message(inter, panel_data, panel_id)
            return

        if not hasattr(inter, "channel") or not inter.channel:
            return

        async for msg in inter.channel.history(limit=20):
            if msg.author != inter.guild.me:
                continue

            if not msg.components:
                continue

            is_panel = any(
                hasattr(item, "custom_id") and item.custom_id in [
                    f"create_ticket_{panel_id}",
                    f"ticket_panel_option_select_{panel_id}"
                ]
                for row in msg.components
                if isinstance(row, disnake.ui.ActionRow)
                for item in row.children
            )

            if is_panel:
                fake = type("FakeInter", (), {"message": msg, "guild": inter.guild})
                await reset_panel_message(fake, panel_data, panel_id)
                break

    except Exception as e:
        print(f"[safe_reset_panel] erro: {e}")

def _apply_fixed_ticket_info(
    embed: disnake.Embed,
    channel: disnake.TextChannel | disnake.Thread,
    user: disnake.Member,
    option_data: dict = None
) -> disnake.Embed:
    """
    Aplica ao embed as informações fixas da mensagem de abertura do ticket,
    que nunca podem ser personalizadas pelo staff: a foto de perfil (thumbnail
    e autor) de quem abriu o ticket, quem abriu, o staff responsável e a
    categoria do ticket.
    """
    if hasattr(user, "display_avatar") and user.display_avatar:
        embed.set_thumbnail(url=user.display_avatar.url)
        embed.set_author(name=user.display_name, icon_url=user.display_avatar.url)
    elif hasattr(user, "avatar") and user.avatar:
        embed.set_thumbnail(url=user.avatar.url)
        embed.set_author(name=user.display_name)

    embed.add_field(
        name=f"{emoji.member} Criado por",
        value=user.mention,
        inline=True
    )

    tickets_data = db.get_document("tickets_data") or {}

    claimed_by = None
    found = False

    for panel in tickets_data.get("panels", {}).values():
        for user_tickets in panel.values():
            for ticket in user_tickets:
                if ticket.get("ticket_id") == channel.id:
                    claimed_by = ticket.get("claimed_by")
                    found = True
                    break
            if found:
                break
        if found:
            break

    if claimed_by:
        staff = channel.guild.get_member(claimed_by)
        staff_text = staff.mention if staff else "`Staff não encontrado`"
    else:
        staff_text = "`Nenhum staff assumiu`"

    embed.add_field(
        name=f"{emoji.shield} Staff responsável",
        value=staff_text,
        inline=True
    )

    selected_option_name = option_data.get("name") if option_data else None

    embed.add_field(
        name=f"{emoji.folder} Categoria",
        value=f"`{selected_option_name}`" if selected_option_name else "`Padrão`",
        inline=True
    )

    return embed


async def send_opening_message(
    channel: disnake.TextChannel | disnake.Thread,
    user: disnake.Member,
    panel_data: dict,
    option_data: dict = None,
    form_answers: dict = None,
    questions: list = None
):
    # configs seguras (evita crash se DB vier None)
    config_mode = db.get_document("custom_mode") or {}
    config_colors = db.get_document("custom_colors") or {}

    mode = config_mode.get("mode")
    primary_color_hex = config_colors.get("primary")

    # dados da mensagem de abertura
    open_message_data = (
        option_data.get("open_message", {})
        if option_data
        else panel_data.get("open_message", {})
    )

    style = open_message_data.get("style", "embed")
    

    # 1. Determina o conteúdo inicial (sem menções - serão enviadas separadamente)
    initial_content = ""

    # 2. Verifica se há conteúdo personalizado para a mensagem de abertura
    has_custom_content = False

    def create_default_opening_embed() -> disnake.Embed:
        embed_kwargs = {}

        if primary_color_hex:
            try:
                embed_kwargs["color"] = int(primary_color_hex.replace("#", ""), 16)
            except ValueError:
                pass

        description = (
            f"Olá {user.mention}, a equipe de atendimento já foi informada da abertura do seu ticket. "
            "Enquanto aguarda um staff, sinta-se à vontade para informar seu problema."
        )

        if form_answers and questions:
            question_map = {q['id']: q['label'] for q in questions}

            form_string = "\n\n**Motivo:**\n" + "\n".join(
                f"**{question_map.get(qid, 'Pergunta')}:** {answer}"
                for qid, answer in form_answers.items()
            )

            description += form_string

        embed = disnake.Embed(
            title="Ticket Aberto",
            description=description,
            **embed_kwargs
        )

        _apply_fixed_ticket_info(embed, channel, user, option_data)

        return embed

    if style == "embed":
        has_custom_content = bool(
            open_message_data.get("embed", {}).get("title") or
            open_message_data.get("embed", {}).get("description")
        )

    elif style == "content":
        has_custom_content = bool(
            open_message_data.get("content", {}).get("content") or
            open_message_data.get("content", {}).get("image_url")
        )

    elif style == "container":
        has_custom_content = bool(
            open_message_data.get("container", {}).get("content")
        )

    config_mode = db.get_document("custom_mode") or {}
    config_colors = db.get_document("custom_colors") or {}

    mode = config_mode.get("mode")
    primary_color_hex = config_colors.get("primary")

    action_row = disnake.ui.ActionRow(
        # disnake.ui.Button(
            # label="Sair do Ticket",
            # emoji=emoji.wrong,
            # style=disnake.ButtonStyle.grey,
            # custom_id="ticket_leave_user"
        # ),
        disnake.ui.Button(
            label="Assumir Ticket",
            emoji=emoji.double_check,
            style=disnake.ButtonStyle.green,
            custom_id="ticket_claim"
        ),
        disnake.ui.Button(
            label="Fechar Ticket",
            emoji=emoji.delete,
            style=disnake.ButtonStyle.red,
            custom_id="ticket_close_ticket_user"
        ),
        disnake.ui.Button(
            label="Painel do Atendente",
            emoji=emoji.shield_star,
            style=disnake.ButtonStyle.grey,
            custom_id="ticket_attendant_setup"
        ),
        disnake.ui.Button(
            label="Painel do Usuário",
            emoji=emoji.member,
            style=disnake.ButtonStyle.grey,
            custom_id="ticket_user_setup"
        ),
        disnake.ui.Button(
            label="Informações",
            emoji=emoji.information,
            style=disnake.ButtonStyle.grey,
            custom_id="ticket_info"
        )
    )

    if style == "container":
        if has_custom_content:
            if initial_content:
                await channel.send(initial_content)

            data = open_message_data.get("container", {})

            form_string = ""
            if form_answers and questions:
                question_map = {q['id']: q['label'] for q in questions}

                form_string = "\n\n**Respostas do Formulário:**\n" + "\n".join(
                    f"**{question_map.get(qid, 'Pergunta desconhecida')}:**\n{answer}"
                    for qid, answer in form_answers.items()
                )

            container_content = (data.get("content") or "") + form_string

            # Usa a foto de perfil do criador do ticket como thumbnail se nenhuma estiver configurada
            thumbnail = data.get("thumbnail_url")
            if not thumbnail and hasattr(user, "display_avatar") and user.display_avatar:
                thumbnail = user.display_avatar.url
            elif not thumbnail and hasattr(user, "avatar") and user.avatar:
                thumbnail = user.avatar.url

            container = ContainerUtils.montar_container(
                conteudo=container_content,
                imagem_url=data.get("image_url"),
                cor_hex=data.get("color"),
                thumbnail_url=thumbnail
            )

            await channel.send(
                components=[container],
                flags=disnake.MessageFlags(is_components_v2=True)
            )

        else:
            # Fallback padrão: usar container com thumbnail do usuário no canto superior direito
            avatar_url = None
            if hasattr(user, "display_avatar") and user.display_avatar:
                avatar_url = user.display_avatar.url
            elif hasattr(user, "avatar") and user.avatar:
                avatar_url = user.avatar.url

            default_embed = create_default_opening_embed()
            if avatar_url:
                default_embed.set_thumbnail(url=avatar_url)
            await channel.send(embed=default_embed)

        if action_row:
            await channel.send(components=[action_row])

        return
    # Lida com componentes legados (embed, content, ou apenas menções)
    payload = {}

    if not has_custom_content:
        embed_kwargs = {}

        if primary_color_hex:
            try:
                embed_kwargs["color"] = int(primary_color_hex.replace("#", ""), 16)
            except ValueError:
                pass

        description = (
            f"Olá {user.mention}, a equipe de atendimento já foi informada da abertura do seu ticket. "
            "Enquanto aguarda um staff, sinta-se à vontade para informar seu problema."
        )

        if form_answers and questions:
            question_map = {q['id']: q['label'] for q in questions}
            form_string = "\n\n**Motivo:**\n" + "\n".join(
                f"**{question_map.get(qid, 'Pergunta')}:** {answer}"
                for qid, answer in form_answers.items()
            )
            description += form_string

        payload["content"] = initial_content or None

        embed = disnake.Embed(
            title="Ticket Aberto",
            description=description,
            **embed_kwargs
        )

        _apply_fixed_ticket_info(embed, channel, user, option_data)

        payload["embed"] = embed

    elif style == "embed":
        data = open_message_data.get("embed", {})

        payload["content"] = initial_content if initial_content else None

        color_str = data.get("color") or primary_color_hex
        embed_kwargs = {}

        if color_str:
            try:
                embed_kwargs["color"] = disnake.Color(int(color_str.lstrip("#"), 16))
            except (ValueError, TypeError):
                pass

        description = data.get("description", "")

        form_string = ""

        if form_answers and questions:
            question_map = {q['id']: q['label'] for q in questions}
            form_string = "\n\n**Respostas do Formulário:**\n" + "\n".join(
                f"**{question_map.get(qid, 'Pergunta desconhecida')}:**\n{answer}"
                for qid, answer in form_answers.items()
            )

        full_description = f"{description}{form_string}".strip()

        embed = disnake.Embed(
            title=data.get("title") or "Ticket Aberto",
            description=full_description,
            **embed_kwargs
        )

        if image_url := data.get("image_url"):
            embed.set_image(url=image_url)

        # Título, descrição, cor e imagem são personalizáveis; o resto
        # (foto de perfil de quem abriu, autor, staff responsável e
        # categoria) é sempre fixo e não pode ser alterado.
        _apply_fixed_ticket_info(embed, channel, user, option_data)

        payload["embed"] = embed

    elif style == "content":
        data = open_message_data.get("content", {})
        content = data.get("content", "")

        form_string = ""

        if form_answers and questions:
            question_map = {q['id']: q['label'] for q in questions}
            form_string = "\n\n**Respostas do Formulário:**\n" + "\n".join(
                f"**{question_map.get(qid, 'Pergunta desconhecida')}:**\n`{answer}`"
                for qid, answer in form_answers.items()
            )

        payload["content"] = f"{initial_content}\n{content}{form_string}".strip()

        # Adiciona embed com a foto de perfil do criador do ticket no canto superior direito
        embed_kwargs = {}
        if primary_color_hex:
            try:
                embed_kwargs["color"] = disnake.Color(int(primary_color_hex.lstrip("#"), 16))
            except (ValueError, TypeError):
                pass
        user_embed = disnake.Embed(**embed_kwargs)
        if hasattr(user, "display_avatar") and user.display_avatar:
            user_embed.set_author(name=user.display_name, icon_url=user.display_avatar.url)
            user_embed.set_thumbnail(url=user.display_avatar.url)
        elif hasattr(user, "avatar") and user.avatar:
            user_embed.set_author(name=user.display_name)
            user_embed.set_thumbnail(url=user.avatar.url)
        payload["embed"] = user_embed

    if action_row:
        payload["components"] = [action_row]

    file_to_send = None

    if style == "content" and (image_url := open_message_data.get("content", {}).get("image_url")):
        if "http" in image_url:
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(image_url) as resp:
                        if resp.status == 200:
                            image_bytes = await resp.read()
                            file_to_send = disnake.File(io.BytesIO(image_bytes), filename="image.png")
            except Exception:
                pass

    roles_data = (
        option_data.get("roles", {})
        if option_data
        else panel_data.get("roles", {})
    )

    atendentes_roles_ids = get_attendant_roles(roles_data)

    role_mentions = []
    if atendentes_roles_ids:
        for role_id in atendentes_roles_ids:
            role = channel.guild.get_role(role_id)
            if role:
                role_mentions.append(role.mention)

    partes = role_mentions + [user.mention]
    mention_content = "||" + "".join(partes) + "||"

    payload["content"] = mention_content

    if payload.get("content") or payload.get("embed") or payload.get("components") or file_to_send:
        await channel.send(file=file_to_send, **payload)

async def open_ticket(inter: disnake.Interaction, bot: commands.Bot, panel_data: dict, panel_id: str, option_data: dict = None, loading_message: disnake.Message = None):
    # Esta função agora só é chamada depois de um message.wait
    # O chamador lida com as exceções.
    
    # Função auxiliar para editar a mensagem correta
    async def edit_message(content: str):
        if loading_message:
            try:
                await loading_message.edit(content=content)
            except:
                try:
                    await inter.edit_original_message(content=content)
                except:
                    pass
        else:
            try:
                await inter.edit_original_message(content=content)
            except:
                pass
    
    # Mover as checagens para cá para o fluxo sem formulário
    ok, error_msg = await check_office_hours(inter, panel_data)
    if not ok:
        await edit_message(error_msg)
        # Resetar o painel quando verificação falhar
        if isinstance(inter, disnake.MessageInteraction) and hasattr(inter, 'message') and inter.message:
            try:
                await safe_reset_panel(inter, panel_data, panel_id)
            except Exception as e:
                print(f"Erro ao resetar painel após falha em verificação: {e}")
        return

    ok, error_msg = await check_permissions(inter, panel_data, option_data)
    if not ok:
        await edit_message(error_msg)
        # Resetar o painel quando verificação falhar
        if isinstance(inter, disnake.MessageInteraction) and hasattr(inter, 'message') and inter.message:
            try:
                await safe_reset_panel(inter, panel_data, panel_id)
            except Exception as e:
                print(f"Erro ao resetar painel após falha em verificação: {e}")
        return

    ok, error_msg = await check_existing_ticket(inter, bot, panel_id)
    if not ok:
        await edit_message(error_msg)
        # Resetar o painel quando verificação falhar
        if isinstance(inter, disnake.MessageInteraction) and hasattr(inter, 'message') and inter.message:
            try:
                await safe_reset_panel(inter, panel_data, panel_id)
            except Exception as e:
                print(f"Erro ao resetar painel após falha em verificação: {e}")
        return

    # Verificar se a verificação PRÓPRIA do bot é obrigatória para abrir tickets
    from modules.verification import service as verification_service
    if not await verification_service.require_verification(inter, "tickets", loading_message=loading_message):
        if isinstance(inter, disnake.MessageInteraction) and hasattr(inter, 'message') and inter.message:
            try:
                await safe_reset_panel(inter, panel_data, panel_id)
            except Exception as e:
                print(f"Erro ao resetar painel após bloqueio de verificação própria: {e}")
        return

    await _finish_ticket_creation(inter, bot, panel_data, panel_id, option_data, loading_message=loading_message)


async def _finish_ticket_creation(
    inter: disnake.Interaction,
    bot,
    panel_data: dict,
    panel_id: str,
    option_data: dict = None,
    form_answers: dict = None,
    loading_message: disnake.Message = None
) -> disnake.TextChannel | disnake.Thread | None:

    user = inter.user
    mode = panel_data.get("mode") or "channel"

    if option_data:
        ticket_name_raw = option_data.get("name", "ticket")
    else:
        ticket_name_raw = panel_data.get("name", "ticket")

    # Sanitizar nome
    ticket_name = re.sub(
        r'[^a-z0-9-]',
        '',
        ticket_name_raw.lower().replace(' ', '-')
    )[:25]

    if not ticket_name:
        ticket_name = "ticket"

    new_ticket_channel = None

    # Import local para evitar import circular entre os pacotes config/functions
    from modules.tickets.config.preferencias import get_destination_mode
    use_individual_destination = get_destination_mode(panel_data) == "individual"

    # =========================
    # MODO TÓPICO
    # =========================
    if mode == "topic":

        channel_id = (
            (option_data.get("channel_id") if (option_data and use_individual_destination) else None)
            or panel_data.get("channel_id")
        )
        channel = bot.get_channel(channel_id)

        if not channel or not isinstance(channel, disnake.TextChannel):
            raise ValueError(
                "O canal para criação de tópicos não foi encontrado ou não é um canal de texto."
            )

        new_ticket_channel = await channel.create_thread(
            name=f"🎫・{ticket_name}-{user.name}",
            type=disnake.ChannelType.private_thread,
            invitable=False
        )

    # =========================
    # MODO CANAL
    # =========================
    elif mode == "channel":

        category_id = (
            (option_data.get("category_id") if (option_data and use_individual_destination) else None)
            or panel_data.get("category_id")
        )
        category = bot.get_channel(category_id)

        if not category or not isinstance(category, disnake.CategoryChannel):
            raise ValueError(
                "A categoria para criação de canais não foi encontrada."
            )

        # =========================
        # VERIFICAR LIMITE
        # =========================
        text_channels_in_category = [
            ch for ch in category.channels
            if isinstance(ch, disnake.TextChannel)
        ]

        # Se estiver cheia
        if len(text_channels_in_category) >= 50:

            found_category = None

            # Procurar categoria parecida com espaço
            for cat in inter.guild.categories:

                if cat.name.lower().startswith(category.name.lower()):

                    cat_channels = [
                        ch for ch in cat.channels
                        if isinstance(ch, disnake.TextChannel)
                    ]

                    if len(cat_channels) < 50:
                        found_category = cat
                        break

            # Se encontrou categoria livre
            if found_category:
                category = found_category

            else:
                # Criar nova categoria automaticamente
                try:
                    next_number = 2

                    existing_names = [
                        c.name.lower()
                        for c in inter.guild.categories
                    ]

                    while f"{category.name.lower()}-{next_number}" in existing_names:
                        next_number += 1

                    new_category = await inter.guild.create_category(
                        name=f"{category.name}-{next_number}"
                    )

                    category = new_category

                except Exception:
                    raise ValueError(
                        "Limite de canais atingido e não foi possível criar uma nova categoria."
                    )

        # =========================
        # PERMISSÕES
        # =========================
        roles_data = (
            option_data.get("roles", {})
            if option_data
            else panel_data.get("roles", {})
        )

        atendentes_roles_ids = get_attendant_roles(roles_data)

        overwrites = {
            inter.guild.default_role: disnake.PermissionOverwrite(
                read_messages=False
            ),

            user: disnake.PermissionOverwrite(
                read_messages=True,
                send_messages=True
            ),

            inter.guild.me: disnake.PermissionOverwrite(
                read_messages=True,
                send_messages=True,
                manage_channels=True
            )
        }

        for role_id in atendentes_roles_ids:

            role = inter.guild.get_role(role_id)

            if role:
                overwrites[role] = disnake.PermissionOverwrite(
                    read_messages=True,
                    send_messages=True
                )

        # =========================
        # CRIAR CANAL
        # =========================
        try:

            new_ticket_channel = await inter.guild.create_text_channel(
                name=f"🎫・{ticket_name}-{user.name}",
                category=category,
                overwrites=overwrites
            )

        except disnake.HTTPException as e:

            raise ValueError(
                f"Erro ao criar ticket: {e}"
            )

    else:

        raise ValueError(
            f"Modo de painel desconhecido ou não configurado: '{mode}'."
        )

    # =========================
    # SALVAR TICKET
    # =========================
    if new_ticket_channel:

        tickets_data = db.get_document("tickets_data") or {}

        user_tickets = (
            tickets_data
            .setdefault("panels", {})
            .setdefault(panel_id, {})
            .setdefault(str(user.id), [])
        )

        ticket_payload = {
            "ticket_id": new_ticket_channel.id,
            "status": "open",
            "created_at": int(time.time()),
            "claimed_by": None,
            "history": [
                {
                    "type": "create",
                    "author_id": user.id,
                    "timestamp": int(time.time()),
                    "details": {}
                }
            ]
        }

        if option_data:
            ticket_payload["option_id"] = option_data.get("id")

        if form_answers:
            ticket_payload["form_answers"] = form_answers

        user_tickets.append(ticket_payload)

        db.save_document("tickets_data", tickets_data)

        # =========================
        # LOG
        # =========================
        await log_ticket_creation(
            bot,
            new_ticket_channel,
            user,
            panel_data.get("name", "N/A"),
            mode
        )

        # =========================
        # MENSAGEM DE ABERTURA
        # =========================
        questions = []

        if form_answers and option_data:

            option_id = str(option_data.get("id"))

            questions = (
                panel_data
                .get("forms", {})
                .get(option_id, [])
            )

        await send_opening_message(
            new_ticket_channel,
            user,
            panel_data,
            option_data,
            form_answers,
            questions
        )


        # =========================
        # MENSAGEM SUCESSO
        # =========================
        success_msg = (
            f"{emoji.correct} Ticket criado com sucesso em "
            f"{new_ticket_channel.mention}!"
        )

        if loading_message:

            try:
                await loading_message.edit(
                    content=success_msg
                )

            except:

                try:
                    await inter.edit_original_message(
                        content=success_msg
                    )
                except:
                    pass

        else:

            try:
                await inter.edit_original_message(
                    content=success_msg
                )

            except:
                pass

        # =========================
        # RESETAR PAINEL
        # =========================
        if (
            isinstance(inter, disnake.MessageInteraction)
            and hasattr(inter, 'message')
            and inter.message
        ):

            try:
                await reset_panel_message(
                    inter,
                    panel_data,
                    panel_id
                )

            except Exception as e:
                print(
                    f"Erro ao resetar painel após criar ticket: {e}"
                )

    return new_ticket_channel