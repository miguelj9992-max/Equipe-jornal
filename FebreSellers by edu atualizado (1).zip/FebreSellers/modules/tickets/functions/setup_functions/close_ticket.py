import disnake
from functions.utils import utils
from disnake.ext import commands
import asyncio
import time
from disnake.ui import Modal, TextInput
from functions.database import database as db
from functions.transcript_cache import delete_link_from_cache, save_link_to_cache
from ..logs_tickets import log_ticket_closure
from functions.emoji import emoji
import traceback
import os
from ...transcripts import generate_transcript
from ...transcripts.host_transcript import log_transcript, upload_transcript_to_api
from ...utils import SafeFormatter, get_message_style, build_ticket_message
from events._common import enviar_log_container
from .review import send_review_request


class CloseTicketModal(Modal):
    def __init__(self, bot, channel: disnake.TextChannel, require_reason: bool = False):
        self.bot = bot
        self.channel = channel

        reason_label = "Motivo do Fechamento"

        if not require_reason:
            reason_label += " (Opcional)"

        components = [
            TextInput(
                label=reason_label,
                placeholder="Digite o motivo do fechamento do ticket.",
                custom_id="reason",
                style=disnake.TextInputStyle.paragraph,
                max_length=2000,
                required=require_reason
            )
        ]

        super().__init__(
            title="Fechar Ticket",
            components=components
        )

    async def callback(self, inter: disnake.ModalInteraction):
        reason = inter.text_values.get("reason")

        await close_ticket(
            bot=self.bot,
            channel=inter.channel,
            closed_by=inter.author,
            reason=reason,
            inter=inter
        )


async def close_ticket(
    bot: commands.Bot,
    channel: disnake.TextChannel,
    closed_by: disnake.Member,
    reason: str = None,
    inter: disnake.Interaction = None
):

    if inter and not inter.response.is_done():
        await inter.response.defer(ephemeral=True)

    config = db.get_document("tickets_config") or {}
    tickets_data = db.get_document("tickets_data") or {}

    found_panel_id = None
    ticket_found = False
    ticket_owner_id = None
    ticket = None

    # Procurar ticket
    for panel_id, users in tickets_data.get("panels", {}).items():

        for user_id, tickets in users.items():

            for tk in tickets:

                if (
                    tk.get("ticket_id") == channel.id
                    and tk.get("status") == "open"
                ):

                    ticket = tk

                    ticket["status"] = "closed"
                    ticket["closed_at"] = int(time.time())
                    ticket["closed_by"] = closed_by.id
                    ticket["channel_name"] = channel.name

                    if reason:
                        ticket["close_reason"] = reason

                    details = {
                        "channel_name": channel.name
                    }

                    if reason:
                        details["reason"] = reason

                    if "history" not in ticket:
                        ticket["history"] = []

                    event = {
                        "type": "close",
                        "author_id": closed_by.id,
                        "timestamp": int(time.time()),
                        "details": details
                    }

                    ticket["history"].append(event)

                    ticket_found = True
                    ticket_owner_id = user_id
                    found_panel_id = panel_id

                    break

            if ticket_found:
                break

        if ticket_found:
            break

    if not ticket_found:

        if inter:
            await inter.followup.send(
                "Este canal não parece ser um ticket aberto.",
                ephemeral=True
            )

        return

    # Apagar call do ticket
    call_channel_id = ticket.get("call_channel_id")

    if call_channel_id:

        try:
            call_channel = await bot.fetch_channel(call_channel_id)

            if call_channel:
                await call_channel.delete(
                    reason="Ticket fechado"
                )

        except disnake.NotFound:
            pass

        except disnake.Forbidden:
            pass

        except Exception:
            traceback.print_exc()

    # Limpar IA silenciada
    if "ai_silenced" in tickets_data:
        tickets_data["ai_silenced"].pop(
            str(channel.id),
            None
        )

    db.save_document(
        "tickets_data",
        tickets_data
    )

    panel_data = (
        config.get("panels", {})
        .get(found_panel_id, {})
    )

    ticket_mode = panel_data.get("mode") or "channel"

    ticket_owner = (
        bot.get_user(int(ticket_owner_id))
        if ticket_owner_id
        else None
    )

    # O autor pode não estar no cache local do bot. Nesse caso, busque-o pela
    # API para que a DM de fechamento e o transcript ainda sejam enviados.
    if ticket_owner is None and ticket_owner_id:
        try:
            ticket_owner = await bot.fetch_user(int(ticket_owner_id))
        except (disnake.NotFound, disnake.Forbidden, disnake.HTTPException, ValueError):
            ticket_owner = None

    transcript_preferences = panel_data.get("preferences", {}).get("transcripts", {})
    transcript_enabled = bool(transcript_preferences.get("send_on_close", False))

    # Transcript
    delete_link_from_cache(channel.id)

    transcript_file = None
    if transcript_enabled:
        transcript_file = await generate_transcript(channel, bot)

    final_transcript_url = None
    transcript_file_backup = None  # fallback se API falhar

    if transcript_file:

        transcript_file.fp.seek(0)
        transcript_html = (
            transcript_file.fp
            .read()
            .decode("utf-8")
        )

        # Salvar cópia do arquivo para fallback
        import io as _io
        transcript_file_backup = disnake.File(
            _io.BytesIO(transcript_html.encode()),
            filename=f"transcript-{channel.name}.html"
        )

        # BUG FIX: era channel.name (str), deve ser channel.id (int)
        final_transcript_url = await upload_transcript_to_api(
            transcript_html,
            channel.id
        )

        if final_transcript_url:
            save_link_to_cache(
                channel.id,
                final_transcript_url
            )



    # Logs (transcript enviado junto se disponível)
    await log_ticket_closure(
        bot,
        channel,
        closed_by,
        ticket_owner,
        ticket_mode,
        reason,
        transcript_url=final_transcript_url
    )

    notification_sent = False

    send_dm_pref = (
        panel_data.get("preferences", {})
        .get("send_close_message", {})
    )

    send_dm_enabled = send_dm_pref.get(
        "enabled",
        True
    )

    if ticket_owner and send_dm_enabled:

        messages = panel_data.get(
            "messages",
            {}
        )

        if reason:
            base_message = messages.get(
                "close_message_reason",
                "Seu ticket `{channel_name}` foi fechado "
                "por `{autor_mention}`.\n"
                "**Motivo:** {reason}"
            )

        else:
            base_message = messages.get(
                "close_message",
                "Seu ticket `{channel_name}` "
                "foi fechado por `{autor_mention}`."
            )

        placeholders = SafeFormatter(
            channel_name=channel.name,
            guild_name=channel.guild.name,
            autor_mention=closed_by.mention,
            autor_name=closed_by.name,
            user_mention=ticket_owner.mention,
            user_name=ticket_owner.name,
            reason=reason
        )

        close_message_content = (
            base_message.format_map(placeholders)
        )

        # Usar a opção selecionada do ticket em vez da categoria do canal
        option_label = None
        option_id = str(ticket.get("option_id")) if ticket and ticket.get("option_id") else None
        if option_id:
            option_data = next(
                (opt for opt in panel_data.get("options", []) if str(opt.get("id")) == option_id),
                None
            )
            option_label = option_data.get("name") if option_data else None

        if not option_label:
            option_label = channel.category.name if channel.category else "Sem categoria"

        closed_at_timestamp = int(time.time())

        close_fields = [
            (f"{emoji.folder} Categoria", f"`{option_label}`"),
            (f"{emoji.home} Servidor", f"`{channel.guild.name}`"),
            (f"{emoji.member} Fechado por", closed_by.mention),
            (f"{emoji.clock} Fechado em", f"<t:{closed_at_timestamp}:f>"),
        ]

        if reason:
            close_fields.append((f"{emoji.pin} Motivo", reason))

        close_style = get_message_style(panel_data, "CloseMessage")

        # Mensagem de transcript
        transcript_message_template = messages.get(
            "transcript_message",
            "Aqui está o transcript do seu ticket `{channel_name}`."
        )

        transcript_message_content = transcript_message_template.format_map(placeholders)

        if final_transcript_url:
            close_message_body = (
                f"{close_message_content}\n\n"
                f"{transcript_message_content}"
            )
        else:
            close_message_body = close_message_content

        message_kwargs = build_ticket_message(
            close_style,
            title="Ticket Fechado",
            description=close_message_body,
            fields=close_fields,
            panel_data=panel_data,
            category="CloseMessage"
        )

        if final_transcript_url:
            # API funcionou — botão de link
            payload = {
                **message_kwargs,
                "components": [
                    disnake.ui.ActionRow(
                        disnake.ui.Button(
                            label="Ver transcript",
                            style=disnake.ButtonStyle.link,
                            url=final_transcript_url
                        )
                    )
                ]
            }

            try:
                await ticket_owner.send(**payload)
                notification_sent = True
            except (disnake.Forbidden, disnake.HTTPException):
                pass

        elif transcript_file_backup:
            # API falhou — envia o arquivo HTML diretamente
            payload = {
                **message_kwargs,
                "components": [
                    disnake.ui.Button(
                        label="Mensagem do Sistema",
                        style=disnake.ButtonStyle.grey,
                        disabled=True
                    )
                ]
            }

            try:
                await ticket_owner.send(**payload)
                await ticket_owner.send(
                    content=transcript_message_content,
                    file=transcript_file_backup
                )
                notification_sent = True
            except (disnake.Forbidden, disnake.HTTPException):
                pass

        else:
            # Sem transcript — envia só a mensagem de fechamento
            payload = {
                **message_kwargs,
                "components": [
                    disnake.ui.Button(
                        label="Mensagem do Sistema",
                        style=disnake.ButtonStyle.grey,
                        disabled=True
                    )
                ]
            }

            try:
                await ticket_owner.send(**payload)
                notification_sent = True
            except (disnake.Forbidden, disnake.HTTPException):
                pass

    # Pedido de avaliação (1 a 5 estrelas) na DM do usuário
    if ticket_owner and found_panel_id and ticket_owner_id:
        try:
            await send_review_request(
                bot=bot,
                guild=channel.guild,
                ticket_owner=ticket_owner,
                panel_id=found_panel_id,
                owner_id=ticket_owner_id,
                channel_id=channel.id,
                channel_name=channel.name,
                closed_by=closed_by,
            )
        except Exception:
            traceback.print_exc()

    delete_link_from_cache(channel.id)

    feedback_message = (
        f"{emoji.lock} Ticket fechado por "
        f"{closed_by.mention}. "
    )

    if send_dm_enabled:

        if notification_sent:
            feedback_message += (
                f"O usuário foi notificado na DM."
            )

        else:
            feedback_message += (
                f"{emoji.wrong} Não foi possível notificar o usuário "
                "(DM fechada ou não encontrado)."
            )

    delete_timestamp = int(time.time()) + 5

    embed = disnake.Embed(
        title=f"{emoji.folder} Ticket fechado",
        description=(
            f"{feedback_message}\n\n"
            f"{emoji.clock} Este canal será excluído <t:{delete_timestamp}:R>."
        ),
        color=disnake.Color.red()
    )

    if inter:
        await inter.followup.send(embed=embed)

    await asyncio.sleep(5)

    try:
        await channel.delete()

    except disnake.NotFound:
        pass
