import disnake
from functions.utils import utils
from functions.database import database as db
from functions.emoji import emoji
from ..history import log_ticket_event
from ..permissions import get_attendant_roles, check_attendant_permissions


async def leave_ticket(inter: disnake.MessageInteraction, bot):
    """Remove o dono do ticket do canal e notifica os atendentes.
    
    ATENÇÃO: inter.response.defer(ephemeral=True) já foi chamado no cog.py
    antes de chamar esta função. Use inter.followup aqui.
    """

    channel = inter.channel
    tickets_data = db.get_document("tickets_data") or {}
    config = db.get_document("tickets_config") or {}

    # ── Localizar o ticket ──────────────────────────────────────────────────
    found_panel_id = None
    ticket_owner_id = None
    ticket_info = None

    for panel_id, users in tickets_data.get("panels", {}).items():
        for uid, user_tickets in users.items():
            for ticket in user_tickets:
                if ticket.get("ticket_id") == channel.id:
                    found_panel_id = panel_id
                    ticket_owner_id = uid
                    ticket_info = ticket
                    break
            if found_panel_id:
                break
        if found_panel_id:
            break

    if not found_panel_id or not ticket_info:
        return await inter.followup.send(
            f"{emoji.wrong} Não foi possível encontrar os dados deste ticket.",
            ephemeral=True,
        )

    # ── Verificar se é o dono do ticket ────────────────────────────────────
    if str(inter.author.id) != str(ticket_owner_id):
        return await inter.followup.send(
            f"{emoji.wrong} Apenas o criador do ticket pode sair dele.",
            ephemeral=True,
        )

    # ── Remover permissão de ver o canal ───────────────────────────────────
    try:
        await channel.set_permissions(
            inter.author,
            overwrite=disnake.PermissionOverwrite(
                view_channel=False,
                send_messages=False,
            ),
        )
    except disnake.Forbidden:
        return await inter.followup.send(
            f"{emoji.wrong} Não tenho permissão para remover você do canal.",
            ephemeral=True,
        )

    # ── Confirmar para o membro ─────────────────────────────────────────────
    await inter.followup.send(
        f"{emoji.correct} Você saiu do ticket **{channel.name}** com sucesso.",
        ephemeral=True,
    )

    # ── Descobrir cargos de atendente para mencionar ────────────────────────
    panel_data = config.get("panels", {}).get(found_panel_id, {})
    roles_data = panel_data.get("roles", {})
    atendente_role_ids = (
        roles_data.get("atendentes", [])
        or roles_data.get("mention", [])
    )

    if not atendente_role_ids:
        cargos_config = db.get_document("cargos") or {}
        cargo_suporte_id = cargos_config.get("cargo_suporte")
        if cargo_suporte_id:
            atendente_role_ids = [int(cargo_suporte_id)]

    mention_str = " ".join(
        f"<@&{rid}>" for rid in atendente_role_ids
    ) if atendente_role_ids else None

    # ── Embed de notificação para atendentes ────────────────────────────────
    embed = disnake.Embed(
        title=f"{emoji.ticket} Membro saiu do ticket",
        description=(
            f"{emoji.member} **Membro:** {inter.author.mention} (`{inter.author.name}`)\n"
            f"{emoji.speech} **Canal:** {channel.mention}\n"
            f"{emoji.time} **Horário:** <t:{int(inter.created_at.timestamp())}:f>\n\n"
            f"{emoji.warn} O membro que abriu este ticket saiu. "
            f"Você pode fechar o ticket abaixo."
        ),
        color=utils.get_primary_color(),
    )
    embed.set_thumbnail(url=inter.author.display_avatar.url)
    embed.set_footer(text=f"ID do membro: {inter.author.id}")

    close_row = disnake.ui.ActionRow(
        disnake.ui.Button(
            label="Fechar Ticket",
            style=disnake.ButtonStyle.danger,
            custom_id="ticket_close_after_leave",
            emoji=emoji.delete,
        )
    )

    await channel.send(
        content=mention_str,
        embed=embed,
        components=[close_row],
    )

    log_ticket_event(channel.id, "leave", inter.author.id)