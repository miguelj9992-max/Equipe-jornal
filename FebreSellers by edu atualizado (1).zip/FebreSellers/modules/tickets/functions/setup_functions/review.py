import time
import disnake

from functions.database import database as db
from functions.emoji import emoji, parse_emoji
from ..logs_tickets import log_ticket_review
from ...config.preferences.review import DEFAULT_REVIEW_MESSAGE, DEFAULT_THANKS_MESSAGE, _SafeDict


async def review(inter: disnake.MessageInteraction):
    await inter.response.send_message(
        "Assim que o ticket for fechado, você receberá uma DM para avaliar o atendimento.",
        ephemeral=True,
    )


def _stars_row(panel_id: str, owner_id, channel_id: int, selected: int = 0, disabled: bool = False) -> disnake.ui.ActionRow:
    # O Discord não permite repetir um emoji customizado várias vezes dentro
    # do label de um botão (só emoji unicode simples renderiza como texto).
    # Por isso usamos o emoji customizado configurado (emoji.star) como ícone
    # fixo do botão, e o número da nota como label.
    star_icon = parse_emoji(emoji.star)
    buttons = []
    for n in range(1, 6):
        style = disnake.ButtonStyle.green if (disabled and n <= selected) else disnake.ButtonStyle.grey
        buttons.append(
            disnake.ui.Button(
                label=str(n),
                emoji=star_icon,
                style=style,
                custom_id=f"TicketReview_Rate_{panel_id}_{owner_id}_{channel_id}_{n}",
                disabled=disabled,
            )
        )
    return disnake.ui.ActionRow(*buttons)


def _find_ticket(panel_id: str, owner_id, channel_id: int):
    """Retorna (tickets_data, ticket_dict) ou (tickets_data, None) se nao encontrado."""
    tickets_data = db.get_document("tickets_data") or {}
    tickets = (
        tickets_data.get("panels", {})
        .get(panel_id, {})
        .get(str(owner_id), [])
    )
    for tk in tickets:
        if tk.get("ticket_id") == channel_id:
            return tickets_data, tk
    return tickets_data, None


async def send_review_request(
    bot,
    guild: disnake.Guild,
    ticket_owner: disnake.User,
    panel_id: str,
    owner_id,
    channel_id: int,
    channel_name: str,
    closed_by: disnake.Member = None,
):
    """Envia a DM de avaliacao de 1 a 5 estrelas para o dono do ticket."""
    config = db.get_document("tickets_config") or {}
    panel_data = config.get("panels", {}).get(panel_id, {})
    preferences = panel_data.get("preferences", {}).get("review", {}) or {}

    if not preferences.get("enabled", False):
        return False

    _, ticket = _find_ticket(panel_id, owner_id, channel_id)
    if ticket is None:
        return False

    if ticket.get("review"):
        return False  # ja avaliado

    assumed_by = ticket.get("assumed_by")
    attendant = guild.get_member(assumed_by) if assumed_by else None

    custom_message = preferences.get("message") or DEFAULT_REVIEW_MESSAGE

    placeholders = _SafeDict(
        user_name=ticket_owner.name,
        user_mention=ticket_owner.mention,
        channel_name=channel_name,
        guild_name=guild.name,
        attendant_mention=attendant.mention if attendant else "nossa equipe",
        attendant_name=attendant.display_name if attendant else "nossa equipe",
    )

    content = custom_message.format_map(placeholders)

    primary_color_hex = db.get_document("custom_colors").get("primary")
    embed_kwargs = {}
    if primary_color_hex:
        embed_kwargs["color"] = int(primary_color_hex.replace("#", ""), 16)

    embed = disnake.Embed(
        title=f"{emoji.star} Avalie nosso Suporte",
        description=content,
        **embed_kwargs,
    )

    try:
        await ticket_owner.send(
            embed=embed,
            components=[_stars_row(panel_id, owner_id, channel_id)],
        )
        return True
    except (disnake.Forbidden, disnake.HTTPException):
        return False


class ReviewCommentModal(disnake.ui.Modal):
    def __init__(self, panel_id: str, owner_id, channel_id: int, channel_name: str, stars: int):
        self.panel_id = panel_id
        self.owner_id = owner_id
        self.channel_id = channel_id
        self.channel_name = channel_name
        self.stars = stars

        components = [
            disnake.ui.TextInput(
                label="Deixe um comentario (opcional)",
                custom_id="review_comment",
                style=disnake.TextInputStyle.paragraph,
                max_length=1000,
                required=False,
                placeholder="Conte um pouco sobre o atendimento que voce recebeu.",
            )
        ]
        super().__init__(
            title=f"Avaliacao: {'*' * stars}{'.' * (5 - stars)}",
            components=components,
            custom_id=f"TicketReviewComment_{panel_id}_{owner_id}_{channel_id}_{stars}",
        )

    async def callback(self, inter: disnake.ModalInteraction):
        comment = inter.text_values.get("review_comment", "").strip() or None
        await finalize_review(inter, self.panel_id, self.owner_id, self.channel_id, self.channel_name, self.stars, comment)


async def finalize_review(inter: disnake.Interaction, panel_id: str, owner_id, channel_id: int, channel_name: str, stars: int, comment: str = None):
    tickets_data, ticket = _find_ticket(panel_id, owner_id, channel_id)

    if ticket is None:
        return await inter.response.send_message("Nao foi possivel encontrar este ticket, a avaliacao nao pode ser salva.", ephemeral=True)

    if ticket.get("review"):
        return await inter.response.edit_message(components=[_stars_row(panel_id, owner_id, channel_id, selected=ticket["review"].get("stars", 0), disabled=True)])

    assumed_by = ticket.get("assumed_by")

    ticket["review"] = {
        "stars": stars,
        "comment": comment,
        "rated_at": int(time.time()),
        "attendant_id": assumed_by,
    }
    db.save_document("tickets_data", tickets_data)

    star = emoji.star or "⭐"
    thanks_embed = disnake.Embed(
        title=f"{emoji.star} Avaliacao enviada!",
        description=f"{star * stars}\n\n{DEFAULT_THANKS_MESSAGE}" + (f"\n\n> {comment}" if comment else ""),
    )

    await inter.response.edit_message(
        embed=thanks_embed,
        components=[_stars_row(panel_id, owner_id, channel_id, selected=stars, disabled=True)],
    )

    # Log
    guild = None
    for g in inter.bot.guilds:
        if g.get_member(int(owner_id)) or (assumed_by and g.get_member(assumed_by)):
            guild = g
            break

    if guild:
        attendant = guild.get_member(assumed_by) if assumed_by else None
        ticket_owner = guild.get_member(int(owner_id)) or inter.bot.get_user(int(owner_id))
        await log_ticket_review(inter.bot, guild, channel_name, ticket_owner, attendant, stars, comment)