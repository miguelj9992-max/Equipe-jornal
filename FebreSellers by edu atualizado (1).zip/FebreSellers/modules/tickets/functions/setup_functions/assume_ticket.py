"""
ATENÇÃO: A lógica de assumir ticket foi consolidada no cog.py
no handler do custom_id 'ticket_claim'. Esta função não é mais chamada.
"""
import disnake
from functions.utils import utils
from functions.database import database as db
from functions.perms import perms as perms_check
from functions.emoji import emoji
from ..history import log_ticket_event
from ...utils import SafeFormatter
from ..permissions import check_attendant_permissions, get_attendant_roles

async def assume_ticket(inter: disnake.MessageInteraction):
    # Toda a lógica foi movida para o bloco ticket_claim em cog.py
    # para evitar dupla verificação e campos inconsistentes.
    pass

async def _assume_ticket_legacy(inter: disnake.MessageInteraction):
    await inter.response.defer(ephemeral=True)

    channel = inter.channel
    config = db.get_document("tickets_config") or {}
    tickets_data = db.get_document("tickets_data") or {}

    found_panel_id = None
    ticket_owner_id = None
    ticket_info = None

    for panel_id, users in tickets_data.get("panels", {}).items():
        for user_id, tickets in users.items():
            for ticket in tickets:
                if ticket.get("ticket_id") == channel.id:
                    found_panel_id = panel_id
                    ticket_owner_id = user_id
                    ticket_info = ticket
                    break
            if found_panel_id:
                break
        if found_panel_id:
            break

    if not found_panel_id or not ticket_info:
        return await inter.followup.send("Não foi possível encontrar os dados deste ticket.", ephemeral=True)

    panel_data = config.get("panels", {}).get(found_panel_id)
    if not panel_data:
        return await inter.followup.send("Não foi possível encontrar a configuração do painel associado.", ephemeral=True)

    # ─── Verificar permissões ──────────────────────────────────────────────────
    is_bot_admin = await perms_check.check(inter.author.id)

    if not is_bot_admin:
        roles_data = panel_data.get("roles", {})
        atendentes_roles_ids = get_attendant_roles(roles_data)

        # Tentar também os campos alternativos usados em check_attendant_permissions
        if not atendentes_roles_ids:
            atendentes_roles_ids = (
                roles_data.get("atendentes", [])
                or roles_data.get("mention", [])
            )

        # Fallback: verificar cargo_suporte global
        if not atendentes_roles_ids:
            cargos_config = db.get_document("cargos") or {}
            cargo_suporte_id = cargos_config.get("cargo_suporte")
            if cargo_suporte_id:
                atendentes_roles_ids = [int(cargo_suporte_id)]

        user_roles_ids = [role.id for role in inter.author.roles]
        is_atendente = any(role_id in atendentes_roles_ids for role_id in user_roles_ids)

        if not is_atendente:
            return await inter.followup.send(
                f"{emoji.wrong} Você não tem permissão para assumir este ticket.",
                ephemeral=True
            )

    # ─── Verificar se o ticket já foi assumido ─────────────────────────────────
    assumed_by = ticket_info.get("assumed_by")
    if assumed_by:
        if assumed_by == inter.author.id:
            return await inter.followup.send("Você já assumiu este ticket.", ephemeral=True)
        else:
            assignee = inter.guild.get_member(assumed_by)
            assignee_name = assignee.mention if assignee else "outro atendente"
            return await inter.followup.send(
                f"{emoji.wrong} Este ticket já foi assumido por {assignee_name}.",
                ephemeral=True
            )

    # ─── Assumir ticket ────────────────────────────────────────────────────────
    ticket_info["assumed_by"] = inter.author.id
    db.save_document("tickets_data", tickets_data)

    log_ticket_event(inter.channel.id, "assume", inter.author.id)

    messages = panel_data.get("messages", {})
    message_template = messages.get(
        "assume_message",
        "{autor_mention} assumiu o atendimento deste ticket."
    )

    ticket_owner = inter.guild.get_member(int(ticket_owner_id))

    placeholders = SafeFormatter(
        autor_mention=inter.author.mention,
        autor_name=inter.author.name,
        channel_name=channel.name,
        guild_name=inter.guild.name,
        user_mention=ticket_owner.mention if ticket_owner else "usuário desconhecido",
        user_name=ticket_owner.name if ticket_owner else "usuário desconhecido"
    )
    formatted_message = message_template.format_map(placeholders)

    # Embed pública no canal — sempre enviada quando o ticket é assumido
    embed_channel = disnake.Embed(
        title=f"{emoji.correct}Ticket Assumido",
        description=formatted_message,
        color=utils.get_primary_color()
    )
    embed_channel.set_footer(text=f"Atendente: {inter.author.display_name}")
    embed_channel.timestamp = disnake.utils.utcnow()

    # Confirmação privada para o atendente
    await inter.followup.send(
        f"{emoji.correct} Você assumiu este ticket com sucesso!",
        ephemeral=True
    )

    # Envia embed pública no canal do ticket
    await channel.send(embed=embed_channel)

    # ─── Notificação por DM ao dono do ticket ─────────────────────────────────
    try:
        ticket_owner = await inter.guild.fetch_member(int(ticket_owner_id))
        if ticket_owner:
            dm_template = messages.get(
                "assume_dm_message",
                "Olá {user_mention}, o atendente {autor_mention} assumiu seu ticket `{channel_name}`."
            )
            dm_message = dm_template.format_map(placeholders)
            embed_dm = disnake.Embed(
                title="Seu ticket foi assumido",
                description=dm_message,
                color=utils.get_primary_color()
            )
            button = disnake.ui.Button(
                label="Ir para o Ticket",
                style=disnake.ButtonStyle.link,
                url=channel.jump_url
            )
            await ticket_owner.send(embed=embed_dm, components=[button])
    except disnake.Forbidden:
        await channel.send(
            f"{ticket_owner.mention if ticket_owner else ''}, não foi possível te notificar na DM que um atendente assumiu seu ticket. Verifique suas configurações de privacidade.",
            delete_after=15
        )
    except Exception:
        pass