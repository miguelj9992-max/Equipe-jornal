import disnake
from functions.database import database as db
from events._common import enviar_log
from functions.emoji import emoji

async def log_ticket_creation(bot, ticket_channel, ticket_owner, panel_name, ticket_mode):
    canais = db.get_document("canais")
    log_channel_id = canais.get("canal_de_logs_de_tickets")
    if not log_channel_id:
        return

    title = "Logs de Tickets - Abertos"
        
    linhas = [
        f"{emoji.textc} **Painel:** {panel_name}",
        f"{emoji.member} **Criador:** {ticket_owner.mention} (`{ticket_owner.id}`)",
        f"{emoji.textc} **Canal/Tópico:** {ticket_channel.mention} (`{ticket_channel.id}`)",
    ]

    guild = ticket_channel.guild
    await enviar_log(guild, int(log_channel_id), title, linhas)


async def log_ticket_closure(bot, ticket_channel, closed_by, ticket_owner, ticket_mode, reason=None, transcript_url=None):
    canais = db.get_document("canais")
    log_channel_id = canais.get("canal_de_logs_de_tickets")
    if not log_channel_id:
        return
        
    title = "Logs de Tickets - Fechados"
    
    linhas = [
        f"{emoji.textc} **Canal/Tópico:** `{ticket_channel.name}` (`{ticket_channel.id}`)",
    ]
    if ticket_owner:
        linhas.append(f"{emoji.member} **Dono do Ticket:** {ticket_owner.mention} (`{ticket_owner.id}`)")
    
    linhas.append(f"{emoji.member} **Fechado por:** {closed_by.mention} (`{closed_by.id}`)")

    if reason:
        linhas.append(f"{emoji.ban} **Motivo:** {reason}")


    guild = closed_by.guild

    # Adicionar botão de transcript como extra_component se disponível
    extra_components = None
    if transcript_url:
        import disnake
        extra_components = [
            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Ver Transcript",
                    style=disnake.ButtonStyle.link,
                    url=transcript_url
                )
            )
        ]

    return await enviar_log(guild, int(log_channel_id), title, linhas, extra_components=extra_components)


async def log_ticket_review(bot, guild, channel_name, ticket_owner, attendant, stars: int, comment: str = None):
    canais = db.get_document("canais")
    log_channel_id = canais.get("canal_de_logs_de_avaliacoes")
    if not log_channel_id:
        return

    title = "Logs de Tickets - Avaliações"

    star_emoji = emoji.star or "⭐"
    stars_display = f"{star_emoji * stars} (`{stars}/5`)"

    linhas = [
        f"{emoji.textc} **Ticket:** `{channel_name}`",
        f"{emoji.star} **Avaliação:** {stars_display}",
    ]

    if ticket_owner:
        linhas.append(f"{emoji.member} **Avaliado por:** {ticket_owner.mention} (`{ticket_owner.id}`)")

    if attendant:
        linhas.append(f"{emoji.shield_star} **Atendente:** {attendant.mention} (`{attendant.id}`)")
    else:
        linhas.append(f"{emoji.shield_star} **Atendente:** `Não identificado`")

    if comment:
        linhas.append(f"{emoji.interrogation} **Comentário:** {comment}")

    return await enviar_log(guild, int(log_channel_id), title, linhas)


async def log_ticket_reminder(bot, ticket_channel, reminded_by, ticket_owner):
    canais = db.get_document("canais")
    log_channel_id = canais.get("canal_de_logs_de_tickets")
    if not log_channel_id:
        return

    title = "Logs de Tickets - Lembrete"
    
    linhas = [
        f"{emoji.member} **Lembrado por:** {reminded_by.mention} (`{reminded_by.id}`)",
        f"{emoji.member} **Usuário Lembrado:** {ticket_owner.mention} (`{ticket_owner.id}`)",
        f"{emoji.textc} **Ticket:** {ticket_channel.mention} (`{ticket_channel.id}`)",
    ]

    guild = ticket_channel.guild
    await enviar_log(guild, int(log_channel_id), title, linhas)