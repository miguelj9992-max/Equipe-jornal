import disnake
from functions.database import database as db
from functions.emoji import emoji, parse_emoji

DEFAULT_REVIEW_MESSAGE = (
    "Olá {user_name}, seu ticket **{channel_name}** foi finalizado!\n"
    "Poderia avaliar de **1 a 5 estrelas** o atendimento que você recebeu de {attendant_mention}?"
)

DEFAULT_THANKS_MESSAGE = "Obrigado por avaliar o nosso suporte! ⭐"


def _get_review_prefs(panel_data: dict) -> dict:
    return panel_data.get("preferences", {}).get("review", {}) or {}


def _stars_row(amount: int = 5, disabled: bool = False) -> disnake.ui.ActionRow:
    # Mesma lógica da view real: emoji customizado como ícone fixo + número
    # da nota como label (Discord não repete emoji customizado em labels).
    star_icon = parse_emoji(emoji.star)
    return disnake.ui.ActionRow(
        *[
            disnake.ui.Button(
                label=str(n),
                emoji=star_icon,
                style=disnake.ButtonStyle.grey,
                custom_id=f"TicketReview_Preview_{n}",
                disabled=True,
            )
            for n in range(1, amount + 1)
        ]
    )


# --- Modal ---

class EditReviewMessageModal(disnake.ui.Modal):
    def __init__(self, panel_id: str, current_message: str):
        self.panel_id = panel_id
        components = [
            disnake.ui.TextInput(
                label="Mensagem enviada na DM",
                custom_id="review_message",
                style=disnake.TextInputStyle.paragraph,
                value=current_message,
                max_length=1000,
                required=False,
                placeholder="Deixe vazio para usar a mensagem padrão.",
            )
        ]
        super().__init__(
            title="Mensagem de Avaliação",
            components=components,
            custom_id=f"SetReviewMessageModal_{self.panel_id}",
        )

    async def callback(self, inter: disnake.ModalInteraction):
        # A lógica de salvar é tratada no cog
        pass


# --- Views ---

def ReviewView_components(inter: disnake.Interaction, panel_id: str) -> list:
    config = db.get_document("tickets_config") or {}
    panel_data = config.get("panels", {}).get(panel_id, {})
    preferences = _get_review_prefs(panel_data)

    enabled = preferences.get("enabled", False)
    ask_comment = preferences.get("ask_comment", False)
    custom_message = preferences.get("message", "")

    panel_name = panel_data.get("name", "N/A")
    primary_color_hex = db.get_document("custom_colors").get("primary")

    container_kwargs = {}
    if primary_color_hex:
        container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))

    status_enabled = f"{emoji.on if enabled else emoji.off} **Status:** {'`Ativado`' if enabled else '`Desativado`'}"
    status_comment = f"{emoji.on if ask_comment else emoji.off} **Pedir comentário junto da avaliação:** {'`Ativado`' if ask_comment else '`Desativado`'}"
    message_preview = custom_message or DEFAULT_REVIEW_MESSAGE

    options = [
        disnake.SelectOption(label="Ativar/Desativar Sistema", value="Toggle", emoji=emoji.power, description="Ativa ou desativa o pedido de avaliação ao fechar o ticket."),
        disnake.SelectOption(label="Editar Mensagem da DM", value="EditMessage", emoji=emoji.message, description="Edite a mensagem enviada na DM junto das estrelas."),
        disnake.SelectOption(label="Pedir Comentário Junto", value="ToggleComment", emoji=emoji.interrogation, description="Peça uma mensagem de avaliação junto das estrelas."),
        disnake.SelectOption(label="Visualizar Prévia", value="Preview", emoji=emoji.search, description="Veja como a mensagem de avaliação será enviada."),
    ]

    container = disnake.ui.Container(
        disnake.ui.TextDisplay(f"## \n-# Gerenciar Tickets > Editar Painel > {panel_name} > Preferências > **Avaliação de Suporte**"),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.TextDisplay(
            "Ao ativar, o usuário receberá uma DM pedindo para avaliar o atendimento "
            "de 1 a 5 estrelas assim que o ticket for fechado."
        ),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.TextDisplay(f"{status_enabled}\n{status_comment}"),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.TextDisplay(f"-# Mensagem atual:\n> {message_preview}"),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.TextDisplay(
            "-# Variáveis disponíveis: `{user_name}` `{channel_name}` `{guild_name}` "
            "`{attendant_mention}` `{attendant_name}`"
        ),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.ActionRow(
            disnake.ui.StringSelect(
                custom_id=f"TicketPref_Review_Select_{panel_id}",
                placeholder="Selecione uma opção para configurar",
                options=options,
            )
        ),
        **container_kwargs,
    )

    buttons = disnake.ui.ActionRow(
        disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id=f"TicketPref_Back_{panel_id}")
    )
    return [container, buttons]


def ReviewView_embed(inter: disnake.Interaction, panel_id: str):
    config = db.get_document("tickets_config") or {}
    panel_data = config.get("panels", {}).get(panel_id, {})
    preferences = _get_review_prefs(panel_data)

    enabled = preferences.get("enabled", False)
    ask_comment = preferences.get("ask_comment", False)
    custom_message = preferences.get("message", "")

    panel_name = panel_data.get("name", "N/A")
    primary_color_hex = db.get_document("custom_colors").get("primary")

    embed_kwargs = {}
    if primary_color_hex:
        embed_kwargs["color"] = int(primary_color_hex.replace("#", ""), 16)

    status_enabled = f"{emoji.on if enabled else emoji.off} **Status:** {'`Ativado`' if enabled else '`Desativado`'}"
    status_comment = f"{emoji.on if ask_comment else emoji.off} **Pedir comentário junto da avaliação:** {'`Ativado`' if ask_comment else '`Desativado`'}"
    message_preview = custom_message or DEFAULT_REVIEW_MESSAGE

    options = [
        disnake.SelectOption(label="Ativar/Desativar Sistema", value="Toggle", emoji=emoji.power, description="Ativa ou desativa o pedido de avaliação ao fechar o ticket."),
        disnake.SelectOption(label="Editar Mensagem da DM", value="EditMessage", emoji=emoji.message, description="Edite a mensagem enviada na DM junto das estrelas."),
        disnake.SelectOption(label="Pedir Comentário Junto", value="ToggleComment", emoji=emoji.interrogation, description="Peça uma mensagem de avaliação junto das estrelas."),
        disnake.SelectOption(label="Visualizar Prévia", value="Preview", emoji=emoji.search, description="Veja como a mensagem de avaliação será enviada."),
    ]

    embed = disnake.Embed(
        title=f"Preferências de Avaliação de Suporte: {panel_name}",
        description=(
            f"{status_enabled}\n{status_comment}\n\n"
            f"-# Mensagem atual:\n> {message_preview}\n\n"
            "-# Variáveis disponíveis: `{user_name}` `{channel_name}` `{guild_name}` "
            "`{attendant_mention}` `{attendant_name}`"
        ),
        **embed_kwargs,
    )

    components = [
        disnake.ui.ActionRow(
            disnake.ui.StringSelect(
                custom_id=f"TicketPref_Review_Select_{panel_id}",
                placeholder="Selecione uma opção para configurar",
                options=options,
            )
        ),
        disnake.ui.ActionRow(
            disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id=f"TicketPref_Back_{panel_id}")
        ),
    ]
    return embed, components


def build_review_preview_payload(inter: disnake.Interaction, panel_id: str) -> dict:
    """Monta um payload ephemeral simulando a DM de avaliação enviada ao usuário."""
    config = db.get_document("tickets_config") or {}
    panel_data = config.get("panels", {}).get(panel_id, {})
    preferences = _get_review_prefs(panel_data)
    custom_message = preferences.get("message", "") or DEFAULT_REVIEW_MESSAGE

    guild_name = inter.guild.name if inter.guild else "N/A"
    author = inter.author

    content = custom_message.format_map(
        _SafeDict(
            user_name=author.name,
            user_mention=author.mention,
            channel_name="ticket-exemplo",
            guild_name=guild_name,
            attendant_mention=author.mention,
            attendant_name=author.name,
        )
    )

    primary_color_hex = db.get_document("custom_colors").get("primary")
    embed_kwargs = {}
    if primary_color_hex:
        embed_kwargs["color"] = int(primary_color_hex.replace("#", ""), 16)

    embed = disnake.Embed(
        title="Avalie nosso Suporte",
        description=content,
        **embed_kwargs,
    )
    embed.set_footer(text="Prévia - Esta é uma simulação e não foi enviada de verdade.")

    return {
        "embed": embed,
        "components": [_stars_row(disabled=True)],
    }


class _SafeDict(dict):
    def __missing__(self, key):
        return f"{{{key}}}"