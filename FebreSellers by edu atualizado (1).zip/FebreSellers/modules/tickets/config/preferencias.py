import disnake
from functions.database import database as db
from functions.emoji import emoji

def PreferenciasView_components(inter: disnake.Interaction, panel_id: str) -> list:
    config = db.get_document("tickets_config") or {}
    panel_data = config.get("panels", {}).get(panel_id, {})
    panel_name = panel_data.get('name', 'N/A')
    primary_color_hex = db.get_document("custom_colors").get("primary")

    container_kwargs = {}
    if primary_color_hex:
        container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))

    options = [
        disnake.SelectOption(label="Configurar Sitema de Transcripts", value="Transcripts", emoji=emoji.receipt, description="Ativar e desativar o sistema de trancripts."),
        disnake.SelectOption(label="Configurar Setup Membro", value="MemberSetup", emoji=emoji.members, description="Definir quais botões estarão disponíveis para o membro."),
        disnake.SelectOption(label="Configurar Setup Atendente", value="AttendantSetup", emoji=emoji.hammer, description="Definir quais botões estarão disponíveis para o atendente."),
        disnake.SelectOption(label="Configurar Fechamento de Tickets", value="CloseTickets", emoji=emoji.delete, description="Configurar o Fechamento de Tickets dos tickets."),
        disnake.SelectOption(label="Configurar Formulários", value="Forms", emoji=emoji.interrogation, description="Crie formulários para a abertura de tickets."),
        disnake.SelectOption(label="Configurar Avaliação de Suporte", value="Review", emoji=emoji.star, description="Configure a avaliação de 1 a 5 estrelas enviada na DM ao fechar o ticket."),
        disnake.SelectOption(label="Configurar Destino dos Tickets", value="Destination", emoji=emoji.dir, description="Definir se o destino será geral (um para todas) ou individual (um por opção).")
    ]

    container = disnake.ui.Container(
        disnake.ui.TextDisplay(f"## \n-# Gerenciar Tickets > Editar Painel > {panel_name} > **Preferências**"),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.ActionRow(
            disnake.ui.StringSelect(
                custom_id=f"TicketPreferences_Select_{panel_id}",
                placeholder="Selecione uma opção para configurar",
                options=options
            )
        ),
        **container_kwargs
    )
    
    buttons = disnake.ui.ActionRow(
        disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id=f"TicketEdit_BackToPanel_{panel_id}")
    )
    return [container, buttons]

def PreferenciasView_embed(inter: disnake.Interaction, panel_id: str):
    config = db.get_document("tickets_config") or {}
    panel_data = config.get("panels", {}).get(panel_id, {})
    panel_name = panel_data.get('name', 'N/A')
    primary_color_hex = db.get_document("custom_colors").get("primary")

    embed_kwargs = {}
    if primary_color_hex:
        embed_kwargs["color"] = int(primary_color_hex.replace("#", ""), 16)

    options = [
        disnake.SelectOption(label="Configurar Sitema de Transcripts", value="Transcripts", emoji=emoji.receipt, description="Definir regras do sistema de transcripts."),
        disnake.SelectOption(label="Configurar Setup Membro", value="MemberSetup", emoji=emoji.members, description="Definir quais botões estarão disponíveis para o membro."),
        disnake.SelectOption(label="Configurar Setup Atendente", value="AttendantSetup", emoji=emoji.hammer, description="Definir quais botões estarão disponíveis para o atendente."),
        disnake.SelectOption(label="Configurar Fechamento de Tickets", value="CloseTickets", emoji=emoji.delete, description="Configurar o Fechamento de Tickets dos tickets."),
        disnake.SelectOption(label="Configurar Formulários", value="Forms", emoji=emoji.interrogation, description="Crie formulários para a abertura de tickets."),
        disnake.SelectOption(label="Configurar Avaliação de Suporte", value="Review", emoji=emoji.star, description="Configure a avaliação de 1 a 5 estrelas enviada na DM ao fechar o ticket."),
        disnake.SelectOption(label="Configurar Destino dos Tickets", value="Destination", emoji=emoji.dir, description="Definir se o destino será geral (um para todas) ou individual (um por opção).")
    ]

    embed = disnake.Embed(
        title=f"Preferências: {panel_name}",
        description="Selecione uma das opções abaixo para configurar.",
        **embed_kwargs
    )
    
    components = [
        disnake.ui.ActionRow(
            disnake.ui.StringSelect(
                custom_id=f"TicketPreferences_Select_{panel_id}",
                placeholder="Selecione uma opção para configurar",
                options=options
            )
        ),
        disnake.ui.ActionRow(
            disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id=f"TicketEdit_BackToPanel_{panel_id}")
        )
    ]
    return embed, components

# --- MODO DE DESTINO (GERAL x INDIVIDUAL) ---

def get_destination_mode(panel_data: dict) -> str:
    """Retorna 'geral' ou 'individual'. Padrão: 'geral' (mantém o comportamento antigo)."""
    preferences = panel_data.get("preferences", {})
    return preferences.get("destination_mode") or "geral"


def DestinationModeView_components(inter: disnake.Interaction, panel_id: str) -> list:
    config = db.get_document("tickets_config") or {}
    panel_data = config.get("panels", {}).get(panel_id, {})
    current_mode = get_destination_mode(panel_data)
    primary_color_hex = db.get_document("custom_colors").get("primary")

    container_kwargs = {}
    if primary_color_hex:
        container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))

    mode_label = "`Geral (um destino para todas as opções)`" if current_mode == "geral" else "`Individual (um destino por opção)`"

    container = disnake.ui.Container(
        disnake.ui.TextDisplay(f"## \n-# Gerenciar Tickets > Editar Painel > Preferências > **Destino dos Tickets**"),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.TextDisplay(
            "Escolha como o canal/categoria (ou tópico) de destino dos tickets será definido:\n\n"
            f"{emoji.dir} **Geral:** todas as opções do painel abrem no mesmo canal/categoria, definido em **Definir Categoria/Canal**.\n"
            f"{emoji.route} **Individual:** cada opção pode abrir em um canal/categoria diferente, configurado em **Editar Opções**.\n\n"
            f"**Modo Atual:** {mode_label}"
        ),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.ActionRow(
            disnake.ui.Button(
                label="Geral (Um para Todas)",
                style=disnake.ButtonStyle.blurple if current_mode == "geral" else disnake.ButtonStyle.grey,
                emoji=emoji.dir,
                custom_id=f"TicketPref_Destination_SetGeral_{panel_id}",
                disabled=current_mode == "geral"
            ),
            disnake.ui.Button(
                label="Individual (Um por Opção)",
                style=disnake.ButtonStyle.blurple if current_mode == "individual" else disnake.ButtonStyle.grey,
                emoji=emoji.route,
                custom_id=f"TicketPref_Destination_SetIndividual_{panel_id}",
                disabled=current_mode == "individual"
            ),
        ),
        **container_kwargs
    )

    buttons = disnake.ui.ActionRow(
        disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id=f"TicketPref_Back_{panel_id}")
    )
    return [container, buttons]


def DestinationModeView_embed(inter: disnake.Interaction, panel_id: str):
    config = db.get_document("tickets_config") or {}
    panel_data = config.get("panels", {}).get(panel_id, {})
    current_mode = get_destination_mode(panel_data)
    primary_color_hex = db.get_document("custom_colors").get("primary")

    embed_kwargs = {}
    if primary_color_hex:
        embed_kwargs["color"] = int(primary_color_hex.replace("#", ""), 16)

    mode_label = "`Geral (um destino para todas as opções)`" if current_mode == "geral" else "`Individual (um destino por opção)`"

    embed = disnake.Embed(
        title="Destino dos Tickets",
        description=(
            "Escolha como o canal/categoria (ou tópico) de destino dos tickets será definido:\n\n"
            f"**Geral:** todas as opções do painel abrem no mesmo canal/categoria, definido em **Definir Categoria/Canal**.\n"
            f"**Individual:** cada opção pode abrir em um canal/categoria diferente, configurado em **Editar Opções**.\n\n"
            f"**Modo Atual:** {mode_label}"
        ),
        **embed_kwargs
    )

    components = [
        disnake.ui.ActionRow(
            disnake.ui.Button(
                label="Geral (Um para Todas)",
                style=disnake.ButtonStyle.blurple if current_mode == "geral" else disnake.ButtonStyle.grey,
                emoji=emoji.dir,
                custom_id=f"TicketPref_Destination_SetGeral_{panel_id}",
                disabled=current_mode == "geral"
            ),
            disnake.ui.Button(
                label="Individual (Um por Opção)",
                style=disnake.ButtonStyle.blurple if current_mode == "individual" else disnake.ButtonStyle.grey,
                emoji=emoji.route,
                custom_id=f"TicketPref_Destination_SetIndividual_{panel_id}",
                disabled=current_mode == "individual"
            ),
        ),
        disnake.ui.ActionRow(
            disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id=f"TicketPref_Back_{panel_id}")
        )
    ]
    return embed, components