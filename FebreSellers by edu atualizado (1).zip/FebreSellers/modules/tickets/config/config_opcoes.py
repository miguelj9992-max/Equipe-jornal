import disnake
from functions.utils import utils
from functions.database import database as db
from functions.message import message, embed_message
from emoji import is_emoji
from functions.emoji import emoji
from .preferencias import get_destination_mode

# --- MODAL ---

class EditOptionModal(disnake.ui.Modal):
    def __init__(self, inter: disnake.CommandInteraction, panel_id: str, option_id: str):
        self.inter = inter
        self.panel_id = panel_id
        self.option_id = option_id

        config = db.get_document("tickets_config") or {}
        panel = config.get("panels", {}).get(panel_id, {})
        option_data = next((opt for opt in panel.get("options", []) if str(opt.get("id")) == option_id), None)

        if not option_data:
            option_data = {"name": "", "description": "", "emoji": ""}

        components = [
            disnake.ui.TextInput(
                label="Nome da Opção",
                placeholder="Ex: Suporte para Vendas",
                custom_id="option_name",
                max_length=50,
                value=option_data.get("name", "")
            ),
            disnake.ui.TextInput(
                label="Descrição da Opção",
                placeholder="Clique aqui para tirar dúvidas sobre vendas",
                custom_id="option_description",
                style=disnake.TextInputStyle.paragraph,
                max_length=100,
                value=option_data.get("description", "")
            ),
            disnake.ui.TextInput(
                label="Emoji (Opcional)",
                placeholder="Ex: 🛒",
                custom_id="option_emoji",
                max_length=100,
                value=option_data.get("emoji", ""),
                required=False
            ),
        ]
        super().__init__(title="Editar Opção", components=components, custom_id=f"edit_option_modal_{self.panel_id}_{self.option_id}")

    async def callback(self, inter: disnake.ModalInteraction):
        mode = db.get_document("custom_mode").get("mode")
        if mode == "embed":
            await embed_message.wait(inter, send=False)
        else:
            await message.wait(inter, send=False)
        
        option_name = inter.text_values["option_name"]
        option_description = inter.text_values["option_description"]
        option_emoji = inter.text_values["option_emoji"]
        
        if option_emoji:
            validation = utils.validate_emoji_for_components(option_emoji)
            if not validation["valid"]:
                error_msg = validation.get("error", "Emoji inválido")
                return await message.error(inter, f"O emoji fornecido não é válido para uso em componentes. {error_msg}\n\nUse um emoji unicode (ex: ✅) ou um emoji customizado no formato <:nome:id>.")
            # Converter para string apropriada
            if isinstance(validation["emoji"], disnake.PartialEmoji):
                option_emoji = str(validation["emoji"])
            else:
                option_emoji = validation["emoji"]
        
        config = db.get_document("tickets_config") or {}
        panel = config["panels"][self.panel_id]
        
        option_found = False
        for option in panel.get("options", []):
            if str(option.get("id")) == self.option_id:
                option["name"] = option_name
                option["description"] = option_description
                if option_emoji:
                    option["emoji"] = option_emoji
                elif "emoji" in option:
                    del option["emoji"]
                option_found = True
                break
        
        if not option_found:
            return await message.error(inter, "A opção que você tentou editar não foi encontrada.")

        db.save_document("tickets_config", config)
        
        mode = db.get_document("custom_mode").get("mode")
        if mode == "components":
            components = config_options_components(inter, self.panel_id)
            await inter.edit_original_message(components=components)
        else:
            embed, components = config_options_embed(inter, self.panel_id)
            await inter.edit_original_message(content=None, embed=embed, components=components)

# --- VIEWS ---

class SelectOptionToEdit(disnake.ui.StringSelect):
    def __init__(self, panel_id: str, options: list):
        select_options = []
        for opt in options:
            try:
                # Validar emoji de forma segura
                opt_emoji = opt.get('emoji')
                parsed_emoji = None
                if opt_emoji:
                    parsed_emoji = utils.safe_get_emoji(opt_emoji)
                
                select_options.append(
                    disnake.SelectOption(
                        label=opt['name'], 
                        value=str(opt['id']),
                        description=opt.get('description', '')[:100],
                        emoji=parsed_emoji
                    )
                )
            except Exception:
                # Se houver erro, criar sem emoji
                select_options.append(
                    disnake.SelectOption(
                        label=opt['name'], 
                        value=str(opt['id']),
                        description=opt.get('description', '')[:100],
                        emoji=None
                    )
                )
        
        is_disabled = not options
        if not options:
            select_options.append(disnake.SelectOption(label="Nenhuma opção para editar", value="placeholder"))

        super().__init__(
            placeholder="Selecione uma opção para editar...",
            options=select_options,
            custom_id=f"TicketOptions_SelectToEdit_{panel_id}",
            disabled=is_disabled
        )

class SelectOptionToDestination(disnake.ui.StringSelect):
    def __init__(self, panel_id: str, options: list):
        select_options = []
        for opt in options:
            try:
                opt_emoji = opt.get('emoji')
                parsed_emoji = None
                if opt_emoji:
                    parsed_emoji = utils.safe_get_emoji(opt_emoji)

                has_override = bool(opt.get('category_id') or opt.get('channel_id'))
                description = "Destino personalizado definido" if has_override else "Usando o destino padrão do painel"

                select_options.append(
                    disnake.SelectOption(
                        label=opt['name'],
                        value=str(opt['id']),
                        description=description,
                        emoji=parsed_emoji
                    )
                )
            except Exception:
                select_options.append(
                    disnake.SelectOption(
                        label=opt['name'],
                        value=str(opt['id']),
                        description="Configurar destino",
                        emoji=None
                    )
                )

        is_disabled = not options
        if not options:
            select_options.append(disnake.SelectOption(label="Nenhuma opção disponível", value="placeholder"))

        super().__init__(
            placeholder="Selecione uma opção para definir o canal/categoria de destino...",
            options=select_options,
            custom_id=f"TicketOptions_SelectToDestination_{panel_id}",
            disabled=is_disabled
        )

class SelectOptionToRemove(disnake.ui.StringSelect):
    def __init__(self, panel_id: str, options: list):
        select_options = []
        for opt in options:
            try:
                # Validar emoji de forma segura
                opt_emoji = opt.get('emoji')
                parsed_emoji = None
                if opt_emoji:
                    parsed_emoji = utils.safe_get_emoji(opt_emoji)
                
                select_options.append(
                    disnake.SelectOption(
                        label=opt['name'], 
                        value=str(opt['id']),
                        description=f"Clique para remover esta opção",
                        emoji=parsed_emoji
                    )
                )
            except Exception:
                # Se houver erro, criar sem emoji
                select_options.append(
                    disnake.SelectOption(
                        label=opt['name'], 
                        value=str(opt['id']),
                        description=f"Clique para remover esta opção",
                        emoji=None
                    )
                )
        
        is_disabled = not options
        if not options:
            select_options.append(disnake.SelectOption(label="Nenhuma opção para remover", value="placeholder"))

        super().__init__(
            placeholder="Selecione uma ou mais opções para remover...",
            options=select_options,
            custom_id=f"TicketOptions_SelectToRemove_{panel_id}",
            min_values=1,
            max_values=len(options) if options else 1,
            disabled=is_disabled
        )

# --- COMPONENTS MODE ---

def config_options_components(inter: disnake.Interaction, panel_id: str):
    config = db.get_document("tickets_config") or {}
    panel_data = config.get("panels", {}).get(panel_id)
    if not panel_data:
        return []

    panel_name = panel_data.get("name", "N/A")
    options = panel_data.get("options", [])
    destination_mode = get_destination_mode(panel_data)
    
    primary_color_hex = db.get_document("custom_colors").get("primary")
    container_kwargs = {}
    if primary_color_hex:
        container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))

    destination_hint = (
        "Destino: **Individual** — cada opção pode ter seu próprio canal/categoria."
        if destination_mode == "individual"
        else "Destino: **Geral** — para configurar um destino por opção, mude para *Individual* em Preferências > Destino dos Tickets."
    )

    container_components = [
        disnake.ui.TextDisplay(f"## \n-# Gerenciar Tickets > Editar Painel > **{panel_name}** > **Editar Opções**"),
        disnake.ui.Separator(),
        disnake.ui.TextDisplay(f"Gerencie as opções do painel. Atualmente há **{len(options)}/25** opções.\n-# {destination_hint}"),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.ActionRow(
            disnake.ui.Button(
                label="Adicionar Opção",
                emoji=emoji.plus,
                style=disnake.ButtonStyle.success,
                custom_id=f"TicketOptions_Add_{panel_id}",
                disabled=len(options) >= 25
            ),
            disnake.ui.Button(
                label="Reordenar Opções",
                emoji=emoji.settings2,
                style=disnake.ButtonStyle.blurple,
                custom_id=f"TicketOptionsReordenar:{panel_id}",
                disabled=len(options) < 2
            ),
        ),
        disnake.ui.ActionRow(SelectOptionToEdit(panel_id, options)),
    ]

    if destination_mode == "individual":
        container_components.append(disnake.ui.ActionRow(SelectOptionToDestination(panel_id, options)))

    container_components.append(disnake.ui.ActionRow(SelectOptionToRemove(panel_id, options)))

    container = disnake.ui.Container(
        *container_components,
        **container_kwargs
    )

    back_button_row = disnake.ui.ActionRow(
        disnake.ui.Button(
            label="Voltar",
            style=disnake.ButtonStyle.grey,
            emoji=emoji.back,
            custom_id=f"TicketEdit_BackToPanel_{panel_id}"
        )
    )
    
    return [container, back_button_row]

# --- EMBED MODE ---

class ConfigOptionsViewEmbed(disnake.ui.View):
    def __init__(self, inter: disnake.Interaction, panel_id: str):
        super().__init__(timeout=None)
        
        config = db.get_document("tickets_config") or {}
        panel_data = config.get("panels", {}).get(panel_id, {})
        options = panel_data.get("options", [])
        destination_mode = get_destination_mode(panel_data)

        self.add_item(SelectOptionToEdit(panel_id, options))
        if destination_mode == "individual":
            self.add_item(SelectOptionToDestination(panel_id, options))
        self.add_item(SelectOptionToRemove(panel_id, options))

        self.add_item(disnake.ui.Button(
            label="Adicionar Opção",
            emoji=emoji.plus,
            style=disnake.ButtonStyle.success,
            custom_id=f"TicketOptions_Add_{panel_id}",
            disabled=len(options) >= 25,
            row=2
        ))
        
        self.add_item(disnake.ui.Button(
            label="Reordenar Opções",
            emoji=emoji.settings2,
            style=disnake.ButtonStyle.blurple,
            custom_id=f"TicketOptionsReordenar:{panel_id}",
            disabled=len(options) < 2,
            row=2
        ))
        
        self.add_item(disnake.ui.Button(
            label="Voltar",
            style=disnake.ButtonStyle.grey,
            emoji=emoji.back,
            custom_id=f"TicketEdit_BackToPanel_{panel_id}",
            row=2
        ))


def config_options_embed(inter: disnake.Interaction, panel_id: str):
    config = db.get_document("tickets_config") or {}
    panel_data = config.get("panels", {}).get(panel_id)
    if not panel_data:
        return None, None 

    panel_name = panel_data.get("name", "N/A")
    options = panel_data.get("options", [])
    destination_mode = get_destination_mode(panel_data)
    
    primary_color_hex = db.get_document("custom_colors").get("primary")
    embed_kwargs = {}
    if primary_color_hex:
        embed_kwargs["color"] = int(primary_color_hex.replace("#", ""), 16)

    destination_hint = (
        "Destino: Individual — cada opção pode ter seu próprio canal/categoria."
        if destination_mode == "individual"
        else "Destino: Geral — para configurar um destino por opção, mude para Individual em Preferências > Destino dos Tickets."
    )

    embed = disnake.Embed(
        title=f"Editando Opções: {panel_name}",
        description=f"Gerencie as opções do painel. Você tem **{len(options)}/25** opções.\n-# {destination_hint}",
        **embed_kwargs
    )
    
    if not options:
        embed.description += "\n\nNenhuma opção foi adicionada ainda."
    else:
        for option in options:
            # Validar emoji antes de usar
            opt_emoji = option.get('emoji')
            emoji_display = ""
            if opt_emoji:
                try:
                    parsed_emoji = utils.safe_get_emoji(opt_emoji)
                    if parsed_emoji:
                        emoji_display = f"{str(parsed_emoji)} "
                except Exception:
                    pass  # Ignorar emoji inválido
            
            embed.add_field(
                name=f"{emoji_display}{option['name']}",
                value=option['description'],
                inline=False
            )
    
    components = [
        disnake.ui.ActionRow(SelectOptionToEdit(panel_id, options)),
    ]

    if destination_mode == "individual":
        components.append(disnake.ui.ActionRow(SelectOptionToDestination(panel_id, options)))

    components.append(disnake.ui.ActionRow(SelectOptionToRemove(panel_id, options)))
    components.append(
        disnake.ui.ActionRow(
            disnake.ui.Button(
                label="Adicionar Opção",
                emoji=emoji.plus,
                style=disnake.ButtonStyle.success,
                custom_id=f"TicketOptions_Add_{panel_id}",
                disabled=len(options) >= 25
            ),
            disnake.ui.Button(
                label="Reordenar Opções",
                emoji=emoji.settings2,
                style=disnake.ButtonStyle.blurple,
                custom_id=f"TicketOptionsReordenar:{panel_id}",
                disabled=len(options) < 2
            ),
            disnake.ui.Button(
                label="Voltar",
                style=disnake.ButtonStyle.grey,
                emoji=emoji.back,
                custom_id=f"TicketEdit_BackToPanel_{panel_id}"
            )
        )
    )
        
    return embed, components

# --- DESTINO DA OPÇÃO (CANAL/CATEGORIA POR OPÇÃO) ---

def _get_option_destination_context(inter: disnake.Interaction, panel_id: str, option_id: str):
    """Retorna (panel_data, option_data, panel_mode) para a tela de destino da opção."""
    config = db.get_document("tickets_config") or {}
    panel_data = config.get("panels", {}).get(panel_id, {})
    option_data = next((opt for opt in panel_data.get("options", []) if str(opt.get("id")) == option_id), None)
    panel_mode = panel_data.get("mode") or "channel"
    return panel_data, option_data, panel_mode


def _option_destination_select(panel_id: str, option_id: str, panel_mode: str):
    if panel_mode == "topic":
        return disnake.ui.ChannelSelect(
            placeholder="Selecione o canal de texto onde os tópicos serão criados...",
            custom_id=f"TicketOptDest_Select_{panel_id}_{option_id}",
            channel_types=[disnake.ChannelType.text],
            min_values=1,
            max_values=1,
        )
    return disnake.ui.ChannelSelect(
        placeholder="Selecione a categoria onde os canais serão criados...",
        custom_id=f"TicketOptDest_Select_{panel_id}_{option_id}",
        channel_types=[disnake.ChannelType.category],
        min_values=1,
        max_values=1,
    )


def OptionDestinationView_components(inter: disnake.Interaction, panel_id: str, option_id: str) -> list[disnake.ui.Container]:
    panel_data, option_data, panel_mode = _get_option_destination_context(inter, panel_id, option_id)
    if not option_data:
        return config_options_components(inter, panel_id)

    option_name = option_data.get("name", "N/A")

    if panel_mode == "topic":
        override_id = option_data.get("channel_id")
        override_obj = inter.bot.get_channel(override_id) if override_id else None
        status_line = f"{emoji.textc if override_obj else emoji.wrong} **Canal de Tópico:** {override_obj.mention if override_obj else '`Usando o padrão do painel`'}"
    else:
        override_id = option_data.get("category_id")
        override_obj = inter.bot.get_channel(override_id) if override_id else None
        status_line = f"{emoji.dir if override_obj else emoji.wrong} **Categoria:** `{override_obj.name if override_obj else 'Usando o padrão do painel'}`"

    primary_color_hex = db.get_document("custom_colors").get("primary")
    container_kwargs = {}
    if primary_color_hex:
        container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))

    container = disnake.ui.Container(
        disnake.ui.TextDisplay(f"## \n-# Gerenciar Tickets > Editar Opções > **{option_name}** > **Destino**"),
        disnake.ui.Separator(),
        disnake.ui.TextDisplay(
            f"Defina onde os tickets abertos através da opção **{option_name}** serão criados.\n"
            f"Se nenhum destino for definido aqui, será usado o destino padrão configurado no painel.\n\n"
            f"{status_line}"
        ),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
        disnake.ui.ActionRow(_option_destination_select(panel_id, option_id, panel_mode)),
        disnake.ui.ActionRow(
            disnake.ui.Button(
                label="Usar Padrão do Painel",
                style=disnake.ButtonStyle.grey,
                emoji=emoji.wrong,
                custom_id=f"TicketOptDest_Reset_{panel_id}_{option_id}",
                disabled=not override_id
            )
        ),
        **container_kwargs
    )

    back_button_row = disnake.ui.ActionRow(
        disnake.ui.Button(
            label="Voltar",
            style=disnake.ButtonStyle.grey,
            emoji=emoji.back,
            custom_id=f"TicketEdit_EditOptions_{panel_id}"
        )
    )

    return [container, back_button_row]


def OptionDestinationView_embed(inter: disnake.Interaction, panel_id: str, option_id: str):
    panel_data, option_data, panel_mode = _get_option_destination_context(inter, panel_id, option_id)
    if not option_data:
        return config_options_embed(inter, panel_id)

    option_name = option_data.get("name", "N/A")

    if panel_mode == "topic":
        override_id = option_data.get("channel_id")
        override_obj = inter.bot.get_channel(override_id) if override_id else None
        status_line = f"**Canal de Tópico:** {override_obj.mention if override_obj else '`Usando o padrão do painel`'}"
    else:
        override_id = option_data.get("category_id")
        override_obj = inter.bot.get_channel(override_id) if override_id else None
        status_line = f"**Categoria:** `{override_obj.name if override_obj else 'Usando o padrão do painel'}`"

    primary_color_hex = db.get_document("custom_colors").get("primary")
    embed_kwargs = {}
    if primary_color_hex:
        embed_kwargs["color"] = int(primary_color_hex.replace("#", ""), 16)

    embed = disnake.Embed(
        title=f"Destino da Opção: {option_name}",
        description=(
            f"Defina onde os tickets abertos através desta opção serão criados.\n"
            f"Se nenhum destino for definido aqui, será usado o destino padrão configurado no painel.\n\n"
            f"{status_line}"
        ),
        **embed_kwargs
    )

    components = [
        disnake.ui.ActionRow(_option_destination_select(panel_id, option_id, panel_mode)),
        disnake.ui.ActionRow(
            disnake.ui.Button(
                label="Usar Padrão do Painel",
                style=disnake.ButtonStyle.grey,
                emoji=emoji.wrong,
                custom_id=f"TicketOptDest_Reset_{panel_id}_{option_id}",
                disabled=not override_id
            ),
            disnake.ui.Button(
                label="Voltar",
                style=disnake.ButtonStyle.grey,
                emoji=emoji.back,
                custom_id=f"TicketEdit_EditOptions_{panel_id}"
            )
        )
    ]

    return embed, components