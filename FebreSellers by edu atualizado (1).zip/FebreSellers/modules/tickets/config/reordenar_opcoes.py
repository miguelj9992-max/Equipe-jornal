import disnake

from functions.database import database as db
from functions.emoji import emoji
from functions.message import message, embed_message
from functions.text_utils import safe_textdisplay, safe_select_option_label, safe_select_option_description
from functions.utils import utils


# Sessões temporárias de reordenação (não persistem no banco até o usuário
# clicar em "Salvar Alterações"). Chave: (panel_id, user_id)
_sessions: dict[tuple[str, int], dict] = {}


def _session_key(panel_id: str, user_id: int) -> tuple[str, int]:
    return (panel_id, user_id)


def _start_session(panel_id: str, user_id: int) -> dict:
    config = db.get_document("tickets_config") or {}
    panel = config.get("panels", {}).get(panel_id, {})
    order = [str(opt.get("id")) for opt in panel.get("options", [])]
    session = {"order": order, "selected": None}
    _sessions[_session_key(panel_id, user_id)] = session
    return session


def _get_session(panel_id: str, user_id: int) -> dict:
    key = _session_key(panel_id, user_id)
    if key not in _sessions:
        return _start_session(panel_id, user_id)
    return _sessions[key]


def _clear_session(panel_id: str, user_id: int) -> None:
    _sessions.pop(_session_key(panel_id, user_id), None)


# ---------------- Painel ----------------

def panel(inter: disnake.MessageInteraction, panel_id: str, reset: bool = False) -> dict:
    if reset:
        _start_session(panel_id, inter.user.id)
    mode = db.get_document("custom_mode").get("mode")
    if mode == "embed":
        return _panel_embed(inter, panel_id)
    return _panel_components(inter, panel_id)


def _build_shared(inter: disnake.MessageInteraction, panel_id: str) -> dict:
    config = db.get_document("tickets_config") or {}
    panel_data = config.get("panels", {}).get(panel_id, {})
    options_by_id = {str(opt.get("id")): opt for opt in panel_data.get("options", [])}

    session = _get_session(panel_id, inter.user.id)
    # Remove da ordem opções que possam ter sido apagadas enquanto a sessão estava aberta
    order = [option_id for option_id in session["order"] if option_id in options_by_id]
    # Adiciona opções criadas enquanto a sessão estava aberta
    for option_id in options_by_id.keys():
        if option_id not in order:
            order.append(option_id)
    session["order"] = order

    selected = session.get("selected")
    if selected not in order:
        selected = None
        session["selected"] = None

    lines = []
    select_options = []
    for idx, option_id in enumerate(order, start=1):
        opt = options_by_id.get(option_id) or {}
        name = opt.get("name") or option_id
        is_selected = option_id == selected

        if is_selected:
            lines.append(f"**{emoji.arrow} {idx}. {name}**")
        else:
            lines.append(f"-# {idx}. {name}")

        opt_emoji = opt.get("emoji")
        parsed_emoji = utils.safe_get_emoji(opt_emoji) if opt_emoji else None

        select_options.append(disnake.SelectOption(
            label=safe_select_option_label(f"{idx}. {name}"),
            value=option_id,
            description=safe_select_option_description(opt.get("description", "")[:100]),
            emoji=parsed_emoji,
            default=is_selected,
        ))

    if not select_options:
        select_options.append(disnake.SelectOption(label="Nenhuma opção encontrada", value="disabled"))

    select = disnake.ui.StringSelect(
        placeholder="Selecione uma opção para mover",
        options=select_options,
        custom_id=f"TicketOptionsReordenarSelect:{panel_id}",
        disabled=not order,
    )

    selected_index = order.index(selected) if selected in order else -1
    pode_mover_cima = selected_index > 0
    pode_mover_baixo = 0 <= selected_index < len(order) - 1

    order_text = "\n".join(lines) if lines else "`Nenhuma opção encontrada`"
    panel_name = safe_textdisplay(panel_data.get("name") or panel_id, 50)

    return {
        "panel_data": panel_data,
        "panel_name": panel_name,
        "order_text": order_text,
        "select": select,
        "pode_mover_cima": pode_mover_cima,
        "pode_mover_baixo": pode_mover_baixo,
    }


def _panel_components(inter: disnake.MessageInteraction, panel_id: str) -> dict:
    data = _build_shared(inter, panel_id)

    primary_color_hex = db.get_document("custom_colors").get("primary")
    container_kwargs = {}
    if primary_color_hex:
        container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))

    header_text = safe_textdisplay(
        f"## \n-# Gerenciar Tickets > Editar Painel > **{data['panel_name']}** > Editar Opções > **Reordenar**"
    )

    return {"components": [
        disnake.ui.Container(
            disnake.ui.TextDisplay(header_text),
            disnake.ui.Separator(),
            disnake.ui.TextDisplay("**Ordem Atual**"),
            disnake.ui.TextDisplay(safe_textdisplay(data["order_text"])),
            disnake.ui.Separator(),
            disnake.ui.TextDisplay("-# Selecione uma opção abaixo e use os botões para reordenar."),
            disnake.ui.ActionRow(data["select"]),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Mover para cima", emoji=emoji.arrow_up, style=disnake.ButtonStyle.grey, custom_id=f"TicketOptionsReordenarCima:{panel_id}", disabled=not data["pode_mover_cima"]),
                disnake.ui.Button(label="Mover para baixo", emoji=emoji.arrow_downward, style=disnake.ButtonStyle.grey, custom_id=f"TicketOptionsReordenarBaixo:{panel_id}", disabled=not data["pode_mover_baixo"]),
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Salvar Alterações", emoji=emoji.save, style=disnake.ButtonStyle.green, custom_id=f"TicketOptionsReordenarSalvar:{panel_id}"),
                disnake.ui.Button(label="Voltar", emoji=emoji.back, style=disnake.ButtonStyle.grey, custom_id=f"TicketOptionsReordenarVoltar:{panel_id}"),
            ),
            **container_kwargs,
        ),
    ]}


def _panel_embed(inter: disnake.MessageInteraction, panel_id: str) -> dict:
    data = _build_shared(inter, panel_id)

    primary_color_hex = db.get_document("custom_colors").get("primary")
    embed_kwargs = {}
    if primary_color_hex:
        embed_kwargs["color"] = int(primary_color_hex.replace("#", ""), 16)

    embed = disnake.Embed(
        description=(
            f"-# Gerenciar Tickets > Editar Painel > {data['panel_name']} > Editar Opções > **Reordenar**\n\n"
            f"**Ordem Atual**\n{data['order_text']}\n\n"
            f"-# Selecione uma opção abaixo e use os botões para reordenar."
        ),
        **embed_kwargs,
    )

    components = [
        disnake.ui.ActionRow(data["select"]),
        disnake.ui.ActionRow(
            disnake.ui.Button(label="Mover para cima", emoji=emoji.arrow_up, style=disnake.ButtonStyle.grey, custom_id=f"TicketOptionsReordenarCima:{panel_id}", disabled=not data["pode_mover_cima"]),
            disnake.ui.Button(label="Mover para baixo", emoji=emoji.arrow_downward, style=disnake.ButtonStyle.grey, custom_id=f"TicketOptionsReordenarBaixo:{panel_id}", disabled=not data["pode_mover_baixo"]),
        ),
        disnake.ui.ActionRow(
            disnake.ui.Button(label="Salvar Alterações", emoji=emoji.save, style=disnake.ButtonStyle.green, custom_id=f"TicketOptionsReordenarSalvar:{panel_id}"),
            disnake.ui.Button(label="Voltar", emoji=emoji.back, style=disnake.ButtonStyle.grey, custom_id=f"TicketOptionsReordenarVoltar:{panel_id}"),
        ),
    ]
    return {"embed": embed, "components": components}


# ---------------- Handlers ----------------

async def render(inter: disnake.MessageInteraction, panel_id: str, reset: bool = False):
    mode = db.get_document("custom_mode").get("mode")
    await (embed_message if mode == "embed" else message).wait(inter, send=False)
    panel_data = panel(inter, panel_id, reset=reset)
    if "embed" in panel_data:
        await inter.edit_original_message(content=None, **panel_data)
    else:
        await inter.edit_original_message(**panel_data)


async def handle_button(inter: disnake.MessageInteraction, custom_id: str) -> bool:
    """Retorna True se o custom_id foi tratado por este módulo."""

    if custom_id.startswith("TicketOptionsReordenar:"):
        panel_id = custom_id.split(":", 1)[1]
        await render(inter, panel_id, reset=True)
        return True

    if custom_id.startswith("TicketOptionsReordenarCima:") or custom_id.startswith("TicketOptionsReordenarBaixo:"):
        direction = "up" if custom_id.startswith("TicketOptionsReordenarCima:") else "down"
        panel_id = custom_id.split(":", 1)[1]

        session = _get_session(panel_id, inter.user.id)
        order = session["order"]
        selected = session.get("selected")
        if selected in order:
            idx = order.index(selected)
            target = idx - 1 if direction == "up" else idx + 1
            if 0 <= target < len(order):
                order[idx], order[target] = order[target], order[idx]

        await render(inter, panel_id)
        return True

    if custom_id.startswith("TicketOptionsReordenarSalvar:"):
        panel_id = custom_id.split(":", 1)[1]
        session = _get_session(panel_id, inter.user.id)

        config = db.get_document("tickets_config") or {}
        panel_data = config.get("panels", {}).get(panel_id)
        if panel_data:
            options_by_id = {str(opt.get("id")): opt for opt in panel_data.get("options", [])}
            order = [option_id for option_id in session["order"] if option_id in options_by_id]
            for option_id in options_by_id.keys():
                if option_id not in order:
                    order.append(option_id)

            if order:
                panel_data["options"] = [options_by_id[option_id] for option_id in order]
                db.save_document("tickets_config", config)

        _clear_session(panel_id, inter.user.id)

        mode = db.get_document("custom_mode").get("mode")
        await (embed_message if mode == "embed" else message).wait(inter, send=False)
        from .config_opcoes import config_options_components, config_options_embed
        if mode == "components":
            await inter.edit_original_message(components=config_options_components(inter, panel_id))
        else:
            embed, components = config_options_embed(inter, panel_id)
            await inter.edit_original_message(content=None, embed=embed, components=components)
        return True

    if custom_id.startswith("TicketOptionsReordenarVoltar:"):
        panel_id = custom_id.split(":", 1)[1]
        _clear_session(panel_id, inter.user.id)

        mode = db.get_document("custom_mode").get("mode")
        await (embed_message if mode == "embed" else message).wait(inter, send=False)
        from .config_opcoes import config_options_components, config_options_embed
        if mode == "components":
            await inter.edit_original_message(components=config_options_components(inter, panel_id))
        else:
            embed, components = config_options_embed(inter, panel_id)
            await inter.edit_original_message(content=None, embed=embed, components=components)
        return True

    return False


async def handle_dropdown(inter: disnake.MessageInteraction, custom_id: str) -> bool:
    """Retorna True se o custom_id foi tratado por este módulo."""

    if custom_id.startswith("TicketOptionsReordenarSelect:"):
        panel_id = custom_id.split(":", 1)[1]
        option_id = inter.values[0]
        if option_id == "disabled":
            return True

        session = _get_session(panel_id, inter.user.id)
        session["selected"] = option_id

        await render(inter, panel_id)
        return True

    return False