import disnake
from functions.utils import utils
from datetime import datetime

async def send_close_message(
    channel,
    user,
    autor,
    reason=None,
    transcript_url=None,
    opened_at=None
):

    config = {}  # se você usa db aqui pode puxar template também

    category_name = channel.category.name if channel.category else "Sem categoria"

    if opened_at:
        duration = datetime.utcnow() - opened_at
        duration_text = str(duration).split('.')[0]
    else:
        duration_text = "Desconhecido"

    embed = disnake.Embed(
        title="Ticket Fechado",
        description=f"Seu ticket `{channel.name}` foi fechado com sucesso.",
        color=utils.get_primary_color()
    )

    embed.add_field(
        name="👤 Fechado por",
        value=autor.mention,
        inline=True
    )

    embed.add_field(
        name="📁 Categoria",
        value=category_name,
        inline=True
    )

    embed.add_field(
        name="⏱️ Tempo aberto",
        value=duration_text,
        inline=True
    )

    if reason:
        embed.add_field(
            name="📌 Motivo",
            value=reason,
            inline=False
        )

    view = disnake.ui.View()

    if transcript_url:
        view.add_item(
            disnake.ui.Button(
                label="Ver transcript",
                style=disnake.ButtonStyle.link,
                url=transcript_url,
                emoji="📄"
            )
        )

    await channel.send(embed=embed, view=view)