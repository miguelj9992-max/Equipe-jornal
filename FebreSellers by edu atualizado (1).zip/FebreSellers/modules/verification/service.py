"""
Painel de funcionalidades protegidas por verificação.

Este módulo NÃO tem mais um sistema de verificação próprio - ele apenas
controla QUAIS funcionalidades exigem que o usuário esteja verificado, e
delega a checagem em si (e a mensagem/botão mostrados a quem não está
verificado) para a verificação OAuth2 do módulo `modules.cloud` (Lunar
Cloud). Ou seja: "estar verificado", para todos os efeitos deste módulo,
significa ter concluído a autorização OAuth2 pelo Discord.

Documentos salvos no banco de dados (via functions.database.database):
- "verification_config": {
      "verification_enabled": bool,
      "custom_verification_message": str,
      "message_mode": "text" | "embed",
      "button_label": str,
      "button_emoji": str,
      "embed_title": str,
      "embed_color": str,        -> hex, ex: "#ff0000" (vazio = cor primária do bot)
      "embed_thumbnail": str,    -> URL
      "embed_image": str,        -> URL
      "embed_footer_text": str,
      "embed_footer_icon": str,  -> URL
      "protected_features": {
          "buy": bool,           -> Comprar produto
          "tickets": bool,       -> Abrir ticket
          "coupons": bool,       -> Utilizar cupom
          "lunar_wallet": bool,  -> Adicionar saldo
          "commands": bool,      -> Usar comandos específicos (lista abaixo)
          "giveaways": bool,     -> Participar de sorteios
      },
      "protected_commands": [ "nome_do_comando", ... ]
  }
"""
from typing import Optional

import disnake

from functions.database import database as db
from functions.emoji import emoji, parse_emoji
from functions.utils import utils

CONFIG_DOC = "verification_config"

DEFAULT_MESSAGE = "Esse servidor requer que você esteja **verificado** para usar esta funcionalidade."
DEFAULT_BUTTON_LABEL = "Verificar"
DEFAULT_EMBED_TITLE = "Verificação Necessária"

# Chave interna -> rótulo exibido no painel de configuração
FEATURE_LABELS = {
    "buy": "Comprar Produto",
    "tickets": "Abrir Ticket",
    "coupons": "Utilizar Cupom",
    "lunar_wallet": "Adicionar Saldo",
    "commands": "Usar Comandos Específicos",
    "giveaways": "Participar de Sorteios",
}


def _default_protected_features() -> dict:
    return {key: False for key in FEATURE_LABELS}


def get_config() -> dict:
    """Retorna a configuração de verificação, já com os valores padrão preenchidos."""
    raw = db.get_document(CONFIG_DOC)
    if not isinstance(raw, dict):
        raw = {}

    protected_features = _default_protected_features()
    saved_features = raw.get("protected_features")
    if isinstance(saved_features, dict):
        for key in protected_features:
            if key in saved_features:
                protected_features[key] = bool(saved_features[key])

    message_mode = raw.get("message_mode")
    if message_mode not in ("text", "embed"):
        message_mode = "text"

    return {
        "verification_enabled": bool(raw.get("verification_enabled", False)),
        "custom_verification_message": raw.get("custom_verification_message") or DEFAULT_MESSAGE,
        "message_mode": message_mode,
        "button_label": (raw.get("button_label") or DEFAULT_BUTTON_LABEL).strip()[:80] or DEFAULT_BUTTON_LABEL,
        "button_emoji": raw.get("button_emoji") or "",
        "embed_title": raw.get("embed_title") or DEFAULT_EMBED_TITLE,
        "embed_color": raw.get("embed_color") or "",
        "embed_thumbnail": raw.get("embed_thumbnail") or "",
        "embed_image": raw.get("embed_image") or "",
        "embed_footer_text": raw.get("embed_footer_text") or "",
        "embed_footer_icon": raw.get("embed_footer_icon") or "",
        "protected_features": protected_features,
        "protected_commands": list(raw.get("protected_commands") or []),
    }


def save_config(config: dict) -> None:
    db.save_document(CONFIG_DOC, config)


def is_verification_enabled() -> bool:
    return get_config()["verification_enabled"]


def is_feature_protected(feature_key: str) -> bool:
    config = get_config()
    if not config["verification_enabled"]:
        return False
    return bool(config["protected_features"].get(feature_key, False))


def is_command_protected(command_name: str) -> bool:
    """Verifica se um comando específico está marcado como protegido."""
    config = get_config()
    if not config["verification_enabled"]:
        return False
    if not config["protected_features"].get("commands", False):
        return False
    protected_commands = {c.strip().lower() for c in config["protected_commands"] if c and c.strip()}
    if not protected_commands:
        return False
    name = (command_name or "").strip().lower()
    # Permite casar tanto o comando completo ("ticket fechar") quanto só o comando base ("ticket")
    return name in protected_commands or name.split(" ")[0] in protected_commands


def resolve_member(inter: disnake.Interaction) -> Optional[disnake.Member]:
    user = getattr(inter, "user", None) or getattr(inter, "author", None)
    if user is None:
        return None
    if isinstance(user, disnake.Member):
        return user
    if inter.guild:
        return inter.guild.get_member(user.id)
    return None


async def is_user_verified(member: disnake.Member) -> bool:
    """Checa o status de verificação REAL do usuário, consultando a
    verificação OAuth2 (Febre Cloud) - a mesma usada em `modules.cloud`."""
    from modules.cloud.verification_check import is_user_verified as cloud_is_user_verified
    return await cloud_is_user_verified(member)


async def get_verification_status(member: disnake.Member) -> str:
    """Consulta a Febre Cloud e retorna o status detalhado de verificação do
    usuário (verificado / não verificado / indisponível no momento) - ver
    `modules.cloud.verification_check` para os valores possíveis. Usado para
    mostrar a mensagem correta a quem for bloqueado."""
    from modules.cloud.verification_check import get_verification_status as cloud_get_verification_status
    return await cloud_get_verification_status(member)


def _apply_custom_button(view: disnake.ui.View, config: dict) -> None:
    """Aplica o texto/emoji personalizados ao botão de verificação, mantendo
    a URL/estilo (link) já montados pelo módulo cloud -- só a aparência do
    botão é customizável, já que um botão de link não pode ter outra cor."""
    if not view or not getattr(view, "children", None):
        return

    button = view.children[0]
    if not isinstance(button, disnake.ui.Button):
        return

    label = (config.get("button_label") or "").strip()
    if label:
        button.label = label[:80]

    raw_emoji = (config.get("button_emoji") or "").strip()
    if raw_emoji:
        button.emoji = parse_emoji(raw_emoji)


def _build_embed(config: dict, description: str) -> disnake.Embed:
    color_hex = (config.get("embed_color") or "").strip()
    if color_hex:
        try:
            color = disnake.Colour(int(color_hex.lstrip("#"), 16))
        except (ValueError, TypeError):
            color = utils.get_color("danger")
    else:
        color = utils.get_color("danger")

    embed = disnake.Embed(
        title=(config.get("embed_title") or DEFAULT_EMBED_TITLE).strip() or None,
        description=description,
        color=color,
    )

    thumbnail = (config.get("embed_thumbnail") or "").strip()
    if thumbnail:
        embed.set_thumbnail(url=thumbnail)

    image = (config.get("embed_image") or "").strip()
    if image:
        embed.set_image(url=image)

    footer_text = (config.get("embed_footer_text") or "").strip()
    footer_icon = (config.get("embed_footer_icon") or "").strip()
    if footer_text or footer_icon:
        embed.set_footer(text=footer_text or None, icon_url=footer_icon or None)

    return embed


async def _send_block_message(
    inter: disnake.Interaction,
    loading_message: Optional[disnake.Message] = None,
    status: str = "unverified",
) -> None:
    """Envia (ou edita a mensagem de carregamento) avisando que é necessário
    concluir a verificação OAuth2 (com o botão/link de verificação da Lunar
    Cloud), ou -- se a Febre Cloud estava indisponível na hora de checar --
    avisando que não foi possível validar a verificação naquele momento."""
    from modules.cloud.verification_check import get_verification_message_and_view, UNAVAILABLE

    cloud_text, view = get_verification_message_and_view(inter, status=status)
    if not cloud_text:
        # OAuth2 (Febre Cloud) não está configurada neste servidor - não bloquear
        # (mesmo comportamento de fail-open usado pelo próprio módulo cloud).
        return

    config = get_config()
    _apply_custom_button(view, config)

    if status == UNAVAILABLE:
        # Mensagem de indisponibilidade da Febre Cloud: não faz sentido
        # sobrepor com a mensagem customizada de "você precisa se
        # verificar", já que aqui não sabemos se o usuário está ou não
        # verificado -- só que não foi possível checar agora.
        description = f"{emoji.alert} {cloud_text}"
    else:
        custom_text = (config.get("custom_verification_message") or "").strip()
        description = f"{emoji.wrong} {custom_text or cloud_text}"

    content = None
    embed = None
    if config.get("message_mode") == "embed":
        embed = _build_embed(config, description)
    else:
        content = description

    try:
        if loading_message is not None:
            await loading_message.edit(content=content, embed=embed, view=view)
            return
    except Exception as e:
        print(f"[Verification] Erro ao editar mensagem de carregamento com aviso de bloqueio: {e}")

    try:
        if inter.response.is_done():
            await inter.followup.send(content=content, embed=embed, ephemeral=True, view=view)
        else:
            await inter.response.send_message(content=content, embed=embed, ephemeral=True, view=view)
    except Exception as e:
        print(f"[Verification] Erro ao enviar mensagem de bloqueio: {e}")


async def require_verification(
    inter: disnake.Interaction,
    feature_key: str,
    loading_message: Optional[disnake.Message] = None,
) -> bool:
    """
    Função central e reutilizável que os demais módulos devem chamar antes de
    executar qualquer funcionalidade protegida. Esta é a ÚNICA função que deve
    ser usada para validar acesso, evitando duplicar a lógica em cada módulo.

    A checagem de "verificado" usada aqui é sempre a verificação OAuth2
    (Febre Cloud) - não existe mais nenhum sistema de verificação próprio.

    Args:
        inter: Interação do Discord.
        feature_key: Chave da funcionalidade protegida (ver FEATURE_LABELS).
        loading_message: Se o fluxo já enviou uma mensagem de "carregando..."
            (padrão usado em vários pontos do bot), ela é editada com o aviso
            de bloqueio em vez de enviar uma nova mensagem.

    Retorna True se o usuário pode prosseguir.
    Retorna False se o usuário foi bloqueado (a mensagem de bloqueio, já com o
    link de verificação, é enviada/editada automaticamente) -- seja por não
    estar verificado, seja porque não foi possível confirmar o status na
    Febre Cloud no momento.
    """
    if not is_feature_protected(feature_key):
        return True

    member = resolve_member(inter)
    if member is None:
        # Não foi possível resolver o membro (ex: DM) - não bloquear.
        return True

    from modules.cloud.verification_check import VERIFIED, NOT_CONFIGURED

    status = await get_verification_status(member)
    if status in (VERIFIED, NOT_CONFIGURED):
        return True

    await _send_block_message(inter, loading_message, status=status)
    return False


async def block_command_if_needed(inter: disnake.Interaction, command_name: str) -> bool:
    """
    Usada pelo check global de slash commands: se o comando estiver marcado
    como protegido e o usuário não estiver verificado (OAuth2), bloqueia e
    envia o aviso. Retorna True se o comando pode prosseguir.
    """
    if not is_command_protected(command_name):
        return True

    member = resolve_member(inter)
    if member is None:
        return True

    from modules.cloud.verification_check import VERIFIED, NOT_CONFIGURED

    status = await get_verification_status(member)
    if status in (VERIFIED, NOT_CONFIGURED):
        return True

    await _send_block_message(inter, status=status)
    return False