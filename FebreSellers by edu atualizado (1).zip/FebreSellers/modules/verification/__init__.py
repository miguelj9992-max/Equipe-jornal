from .cog import setup as verification_setup
from .config import setup as verification_config_setup
from . import service


def setup(bot):
    verification_setup(bot)
    verification_config_setup(bot)


__all__ = ["setup", "service"]
