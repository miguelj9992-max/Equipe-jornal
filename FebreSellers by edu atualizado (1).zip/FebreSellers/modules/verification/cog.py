import disnake
from disnake.ext import commands

from . import service


class Verification(commands.Cog):
    """Cog responsável por bloquear, no nível global de slash commands,
    os comandos marcados como protegidos no painel de verificação.
    O "estar verificado" aqui é sempre a verificação OAuth2 (Febre Cloud) -
    este módulo não tem mais um fluxo próprio de auto-verificação."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._register_global_command_check()

    def _register_global_command_check(self) -> None:
        """Registra um check global em todos os slash commands do bot para
        bloquear automaticamente comandos marcados como protegidos pelo
        proprietário, sem precisar alterar cada comando individualmente."""

        async def _check(inter: disnake.ApplicationCommandInteraction) -> bool:
            command_name = inter.application_command.qualified_name if inter.application_command else inter.data.name
            return await service.block_command_if_needed(inter, command_name)

        self.bot.add_app_command_check(_check, slash_commands=True)


def setup(bot: commands.Bot):
    bot.add_cog(Verification(bot))