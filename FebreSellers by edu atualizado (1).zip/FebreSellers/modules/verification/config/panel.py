"""
Painel de configuração das funcionalidades protegidas por verificação.

A checagem de "verificado" usada por este painel é sempre a verificação
OAuth2 (Febre Cloud, módulo `modules.cloud`) - aqui só se controla QUAIS
funcionalidades exigem essa verificação.

Segue o mesmo padrão visual/estrutural utilizado nos demais painéis de
preferências do bot (ex: modules/loja/preferences), suportando tanto o modo
"embed" quanto o modo "components" (Components V2), conforme a configuração
"custom_mode" do bot.
"""
import disnake
from disnake.ext import commands

from functions.database import database as db
from functions.emoji import emoji, parse_emoji
from functions.message import message, embed_message

from .. import service

MESSAGE_MODAL_ID = "verification_message_modal"
MESSAGE_INPUT_ID = "verification_message_input"
COMMANDS_MODAL_ID = "verification_commands_modal"
COMMANDS_INPUT_ID = "verification_commands_input"
EMBED_MODAL_ID = "verification_embed_modal"
BUTTON_MODAL_ID = "verification_button_modal"

FEATURES_SELECT_ID = "Verification_Features_Select"
TOGGLE_BUTTON_ID = "Verification_Toggle"
EDIT_MESSAGE_BUTTON_ID = "Verification_EditMessage"
EDIT_COMMANDS_BUTTON_ID = "Verification_EditCommands"
TOGGLE_MODE_BUTTON_ID = "Verification_ToggleMode"
EDIT_EMBED_BUTTON_ID = "Verification_EditEmbed"
EDIT_BUTTON_BUTTON_ID = "Verification_EditButton"
OPEN_PANEL_BUTTON_ID = "Verification_Panel"
BACK_BUTTON_ID = "Painel_Configuracoes"


def _get_mode() -> str:
    doc = db.get_document("custom_mode") or {}
    if not isinstance(doc, dict):
        return "components"
    return doc.get("mode", "components")


def _primary_color():
    colors = db.get_document("custom_colors") or {}
    primary_color_hex = colors.get("primary") if isinstance(colors, dict) else None
    if not primary_color_hex:
        return None
    try:
        return disnake.Colour(int(primary_color_hex.replace("#", ""), 16))
    except (ValueError, TypeError):
        return None


class VerificationMessageModal(disnake.ui.Modal):
    def __init__(self, current_message: str = ""):
        components = [
            disnake.ui.Label(
                text="Mensagem para usuários não verificados",
                component=disnake.ui.TextInput(
                    custom_id=MESSAGE_INPUT_ID,
                    style=disnake.TextInputStyle.paragraph,
                    value=current_message,
                    placeholder="Mensagem exibida a quem não estiver verificado",
                    required=True,
                    max_length=500,
                ),
            )
        ]
        super().__init__(title="Mensagem de Verificação", custom_id=MESSAGE_MODAL_ID, components=components)

    async def callback(self, inter: disnake.ModalInteraction):
        text = (inter.text_values.get(MESSAGE_INPUT_ID) or "").strip()
        if not text:
            await inter.response.send_message(f"{emoji.wrong} A mensagem não pode estar vazia!", ephemeral=True)
            return

        config = service.get_config()
        config["custom_verification_message"] = text
        service.save_config(config)

        try:
            await VerificationConfigPanel._refresh(inter)
        except Exception as e:
            print(f"[Verification] Erro ao atualizar o painel após editar a mensagem: {e}")
            if inter.response.is_done():
                await inter.followup.send(f"{emoji.correct} Mensagem salva! (não foi possível atualizar o painel, feche e abra-o novamente)", ephemeral=True)
            else:
                await inter.response.send_message(f"{emoji.correct} Mensagem salva! (não foi possível atualizar o painel, feche e abra-o novamente)", ephemeral=True)


class VerificationCommandsModal(disnake.ui.Modal):
    def __init__(self, current_commands: list[str] = None):
        current_commands = current_commands or []
        components = [
            disnake.ui.Label(
                text="Comandos protegidos (separados por vírgula)",
                component=disnake.ui.TextInput(
                    custom_id=COMMANDS_INPUT_ID,
                    style=disnake.TextInputStyle.paragraph,
                    value=", ".join(current_commands),
                    placeholder="ex: comprar, sacar, orcamento",
                    required=False,
                    max_length=500,
                ),
            )
        ]
        super().__init__(title="Comandos Protegidos", custom_id=COMMANDS_MODAL_ID, components=components)

    async def callback(self, inter: disnake.ModalInteraction):
        raw = inter.text_values.get(COMMANDS_INPUT_ID) or ""
        commands_list = [c.strip().lower() for c in raw.split(",") if c.strip()]

        config = service.get_config()
        config["protected_commands"] = commands_list
        service.save_config(config)

        try:
            await VerificationConfigPanel._refresh(inter)
        except Exception as e:
            print(f"[Verification] Erro ao atualizar o painel após editar comandos protegidos: {e}")
            if inter.response.is_done():
                await inter.followup.send(f"{emoji.correct} Comandos salvos! (não foi possível atualizar o painel, feche e abra-o novamente)", ephemeral=True)
            else:
                await inter.response.send_message(f"{emoji.correct} Comandos salvos! (não foi possível atualizar o painel, feche e abra-o novamente)", ephemeral=True)


class VerificationEmbedModal(disnake.ui.Modal):
    def __init__(self, config: dict):
        components = [
            disnake.ui.Label(
                text="Título do Embed",
                component=disnake.ui.TextInput(
                    custom_id="embed_title",
                    style=disnake.TextInputStyle.short,
                    value=config.get("embed_title", ""),
                    placeholder="ex: Verificação Necessária",
                    required=False,
                    max_length=256,
                ),
            ),
            disnake.ui.Label(
                text="Cor (hex, opcional)",
                component=disnake.ui.TextInput(
                    custom_id="embed_color",
                    style=disnake.TextInputStyle.short,
                    value=config.get("embed_color", ""),
                    placeholder="ex: #FF0000 (vazio = cor padrão do bot)",
                    required=False,
                    max_length=7,
                ),
            ),
            disnake.ui.Label(
                text="URL da Thumbnail (opcional)",
                component=disnake.ui.TextInput(
                    custom_id="embed_thumbnail",
                    style=disnake.TextInputStyle.short,
                    value=config.get("embed_thumbnail", ""),
                    placeholder="https://...",
                    required=False,
                    max_length=300,
                ),
            ),
            disnake.ui.Label(
                text="URL da Imagem Grande (opcional)",
                component=disnake.ui.TextInput(
                    custom_id="embed_image",
                    style=disnake.TextInputStyle.short,
                    value=config.get("embed_image", ""),
                    placeholder="https://...",
                    required=False,
                    max_length=300,
                ),
            ),
            disnake.ui.Label(
                text="Texto do Rodapé (opcional)",
                component=disnake.ui.TextInput(
                    custom_id="embed_footer_text",
                    style=disnake.TextInputStyle.short,
                    value=config.get("embed_footer_text", ""),
                    placeholder="ex: Precisa de ajuda? Abra um ticket",
                    required=False,
                    max_length=100,
                ),
            ),
        ]
        super().__init__(title="Personalizar Embed", custom_id=EMBED_MODAL_ID, components=components)

    async def callback(self, inter: disnake.ModalInteraction):
        config = service.get_config()
        config["embed_title"] = (inter.text_values.get("embed_title") or "").strip()
        config["embed_color"] = (inter.text_values.get("embed_color") or "").strip()
        config["embed_thumbnail"] = (inter.text_values.get("embed_thumbnail") or "").strip()
        config["embed_image"] = (inter.text_values.get("embed_image") or "").strip()
        config["embed_footer_text"] = (inter.text_values.get("embed_footer_text") or "").strip()
        service.save_config(config)

        try:
            await VerificationConfigPanel._refresh(inter)
        except Exception as e:
            print(f"[Verification] Erro ao atualizar o painel após editar o embed: {e}")
            if inter.response.is_done():
                await inter.followup.send(f"{emoji.correct} Embed salvo! (não foi possível atualizar o painel, feche e abra-o novamente)", ephemeral=True)
            else:
                await inter.response.send_message(f"{emoji.correct} Embed salvo! (não foi possível atualizar o painel, feche e abra-o novamente)", ephemeral=True)


class VerificationButtonModal(disnake.ui.Modal):
    def __init__(self, config: dict):
        components = [
            disnake.ui.Label(
                text="Texto do Botão",
                component=disnake.ui.TextInput(
                    custom_id="button_label",
                    style=disnake.TextInputStyle.short,
                    value=config.get("button_label", "Verificar"),
                    placeholder="ex: Verificar",
                    required=True,
                    max_length=80,
                ),
            ),
            disnake.ui.Label(
                text="Emoji do Botão (opcional)",
                component=disnake.ui.TextInput(
                    custom_id="button_emoji",
                    style=disnake.TextInputStyle.short,
                    value=config.get("button_emoji", ""),
                    placeholder="ex: ✅ ou <:nome:id>",
                    required=False,
                    max_length=60,
                ),
            ),
        ]
        super().__init__(title="Personalizar Botão", custom_id=BUTTON_MODAL_ID, components=components)

    async def callback(self, inter: disnake.ModalInteraction):
        label = (inter.text_values.get("button_label") or "").strip()
        if not label:
            await inter.response.send_message(f"{emoji.wrong} O texto do botão não pode estar vazio!", ephemeral=True)
            return

        raw_emoji = (inter.text_values.get("button_emoji") or "").strip()
        if raw_emoji and parse_emoji(raw_emoji) is None:
            await inter.response.send_message(
                f"{emoji.wrong} Emoji inválido. Use um emoji padrão (ex: ✅) ou um emoji customizado do servidor (ex: <:nome:id>).",
                ephemeral=True,
            )
            return

        config = service.get_config()
        config["button_label"] = label
        config["button_emoji"] = raw_emoji
        service.save_config(config)

        try:
            await VerificationConfigPanel._refresh(inter)
        except Exception as e:
            print(f"[Verification] Erro ao atualizar o painel após editar o botão: {e}")
            if inter.response.is_done():
                await inter.followup.send(f"{emoji.correct} Botão salvo! (não foi possível atualizar o painel, feche e abra-o novamente)", ephemeral=True)
            else:
                await inter.response.send_message(f"{emoji.correct} Botão salvo! (não foi possível atualizar o painel, feche e abra-o novamente)", ephemeral=True)


class VerificationConfigPanel(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ------------------------------------------------------------------
    # Construção do painel
    # ------------------------------------------------------------------
    @staticmethod
    def panel(inter: disnake.Interaction) -> dict:
        mode = _get_mode()
        return VerificationConfigPanel._panel_embed() if mode == "embed" else VerificationConfigPanel._panel_components()

    @staticmethod
    def _status_lines() -> tuple[str, list[disnake.SelectOption]]:
        config = service.get_config()
        enabled = config["verification_enabled"]
        features = config["protected_features"]

        status_text = f"{emoji.on if enabled else emoji.off} **Status:** `{'Ativado' if enabled else 'Desativado'}`\n"

        active_features = [service.FEATURE_LABELS[k] for k, v in features.items() if v]
        status_text += (
            f"{emoji.shield} **Funcionalidades Protegidas:** `{', '.join(active_features) if active_features else 'Nenhuma'}`\n"
        )
        if features.get("commands"):
            protected_commands = config["protected_commands"]
            status_text += f"-# Comandos: `{', '.join(protected_commands) if protected_commands else 'Nenhum definido'}`\n"

        message_preview = config["custom_verification_message"]
        status_text += f"-# Mensagem: `{message_preview[:80]}{'...' if len(message_preview) > 80 else ''}`\n"

        mode_label = "Embed" if config.get("message_mode") == "embed" else "Texto simples"
        status_text += f"-# Formato: `{mode_label}`\n"

        button_preview = config.get("button_label") or "Verificar"
        button_emoji = config.get("button_emoji") or ""
        status_text += f"-# Botão: `{(button_emoji + ' ') if button_emoji else ''}{button_preview}`"

        options = [
            disnake.SelectOption(
                label=label,
                value=key,
                emoji=emoji.correct if features.get(key) else emoji.wrong,
                description=f"{'Desativar' if features.get(key) else 'Ativar'} exigência de verificação",
                # Sem isso, o menu sempre abre "zerado": ao marcar uma
                # funcionalidade em uma interação e depois abrir o menu de
                # novo para marcar outra, as que já estavam ativas não
                # apareciam pré-selecionadas -- e como on_dropdown grava o
                # conjunto completo enviado na interação (Discord manda
                # todos os valores marcados de uma vez), a segunda seleção
                # acabava substituindo a primeira em vez de somar a ela.
                default=bool(features.get(key)),
            )
            for key, label in service.FEATURE_LABELS.items()
        ]

        return status_text, options

    @staticmethod
    def _build_action_rows(enabled: bool) -> list[disnake.ui.ActionRow]:
        config = service.get_config()
        is_embed_mode = config.get("message_mode") == "embed"
        return [
            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Desativar" if enabled else "Ativar",
                    emoji=emoji.power,
                    style=disnake.ButtonStyle.red if enabled else disnake.ButtonStyle.green,
                    custom_id=TOGGLE_BUTTON_ID,
                ),
                disnake.ui.Button(
                    label="Mensagem",
                    emoji=emoji.edit,
                    style=disnake.ButtonStyle.blurple,
                    custom_id=EDIT_MESSAGE_BUTTON_ID,
                ),
                disnake.ui.Button(
                    label="Comandos Protegidos",
                    emoji=emoji.commands,
                    style=disnake.ButtonStyle.grey,
                    custom_id=EDIT_COMMANDS_BUTTON_ID,
                ),
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label=f"Formato: {'Embed' if is_embed_mode else 'Texto'}",
                    emoji=emoji.settings,
                    style=disnake.ButtonStyle.grey,
                    custom_id=TOGGLE_MODE_BUTTON_ID,
                ),
                disnake.ui.Button(
                    label="Personalizar Embed",
                    emoji=emoji.edit,
                    style=disnake.ButtonStyle.blurple,
                    custom_id=EDIT_EMBED_BUTTON_ID,
                    disabled=not is_embed_mode,
                ),
                disnake.ui.Button(
                    label="Personalizar Botão",
                    emoji=emoji.edit,
                    style=disnake.ButtonStyle.blurple,
                    custom_id=EDIT_BUTTON_BUTTON_ID,
                ),
            ),
        ]

    @staticmethod
    def _panel_components() -> dict:
        status_text, options = VerificationConfigPanel._status_lines()
        config = service.get_config()

        container_kwargs = {}
        color = _primary_color()
        if color:
            container_kwargs["accent_colour"] = color

        return {"components": [
            disnake.ui.Container(
                disnake.ui.TextDisplay(f"## \n-# Painel > Configurações > **Verificação**"),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(
                    "Escolha quais funcionalidades exigirão que o usuário esteja verificado "
                    "(verificação OAuth2 / Febre Cloud).\n\n" + status_text
                ),
                disnake.ui.Separator(),
                disnake.ui.ActionRow(
                    disnake.ui.StringSelect(
                        custom_id=FEATURES_SELECT_ID,
                        placeholder="Selecione as funcionalidades que exigirão verificação",
                        options=options,
                        min_values=0,
                        max_values=len(options),
                    )
                ),
                *VerificationConfigPanel._build_action_rows(config["verification_enabled"]),
                **container_kwargs,
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id=BACK_BUTTON_ID)
            )
        ]}

    @staticmethod
    def _panel_embed() -> dict:
        status_text, options = VerificationConfigPanel._status_lines()
        config = service.get_config()

        embed = disnake.Embed(
            title="Verificação de Usuários",
            description=(
                "-# Painel > Configurações > **Verificação**\n\n"
                "Escolha quais funcionalidades exigirão que o usuário esteja verificado "
                "(verificação OAuth2 / Febre Cloud).\n\n" + status_text
            ),
        )
        color = _primary_color()
        if color:
            embed.color = color

        components = [
            disnake.ui.ActionRow(
                disnake.ui.StringSelect(
                    custom_id=FEATURES_SELECT_ID,
                    placeholder="Selecione as funcionalidades que exigirão verificação",
                    options=options,
                    min_values=0,
                    max_values=len(options),
                )
            ),
            *VerificationConfigPanel._build_action_rows(config["verification_enabled"]),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id=BACK_BUTTON_ID)
            ),
        ]
        return {"embed": embed, "components": components}

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    @staticmethod
    async def _refresh(inter: disnake.Interaction):
        mode = _get_mode()
        panel = VerificationConfigPanel.panel(inter)
        if mode == "embed":
            if inter.response.is_done():
                await inter.edit_original_message(content=None, **panel)
            else:
                await inter.response.edit_message(content=None, **panel)
        else:
            if inter.response.is_done():
                await inter.edit_original_message(**panel, flags=disnake.MessageFlags(is_components_v2=True))
            else:
                await inter.response.edit_message(**panel, flags=disnake.MessageFlags(is_components_v2=True))

    # ------------------------------------------------------------------
    # Listeners
    # ------------------------------------------------------------------
    @commands.Cog.listener("on_button_click")
    async def on_button_click(self, inter: disnake.MessageInteraction):
        custom_id = inter.component.custom_id

        if custom_id == OPEN_PANEL_BUTTON_ID:
            mode = _get_mode()
            await (embed_message if mode == "embed" else message).wait(inter, send=False)
            panel = VerificationConfigPanel.panel(inter)
            if mode == "embed":
                await inter.edit_original_message(content=None, **panel)
            else:
                await inter.edit_original_message(**panel, flags=disnake.MessageFlags(is_components_v2=True))
            return

        if custom_id == TOGGLE_BUTTON_ID:
            config = service.get_config()
            config["verification_enabled"] = not config["verification_enabled"]
            service.save_config(config)
            await self._refresh_via_wait(inter)
            return

        if custom_id == EDIT_MESSAGE_BUTTON_ID:
            config = service.get_config()
            try:
                await inter.response.send_modal(VerificationMessageModal(config["custom_verification_message"]))
            except Exception as e:
                print(f"[Verification] Erro ao abrir o modal de mensagem: {e}")
                if not inter.response.is_done():
                    await inter.response.send_message(f"{emoji.wrong} Não foi possível abrir a edição da mensagem. Tente novamente.", ephemeral=True)
            return

        if custom_id == EDIT_COMMANDS_BUTTON_ID:
            config = service.get_config()
            try:
                await inter.response.send_modal(VerificationCommandsModal(config["protected_commands"]))
            except Exception as e:
                print(f"[Verification] Erro ao abrir o modal de comandos protegidos: {e}")
                if not inter.response.is_done():
                    await inter.response.send_message(f"{emoji.wrong} Não foi possível abrir a edição de comandos. Tente novamente.", ephemeral=True)
            return

        if custom_id == TOGGLE_MODE_BUTTON_ID:
            config = service.get_config()
            config["message_mode"] = "text" if config.get("message_mode") == "embed" else "embed"
            service.save_config(config)
            await self._refresh_via_wait(inter)
            return

        if custom_id == EDIT_EMBED_BUTTON_ID:
            config = service.get_config()
            try:
                await inter.response.send_modal(VerificationEmbedModal(config))
            except Exception as e:
                print(f"[Verification] Erro ao abrir o modal de embed: {e}")
                if not inter.response.is_done():
                    await inter.response.send_message(f"{emoji.wrong} Não foi possível abrir a personalização do embed. Tente novamente.", ephemeral=True)
            return

        if custom_id == EDIT_BUTTON_BUTTON_ID:
            config = service.get_config()
            try:
                await inter.response.send_modal(VerificationButtonModal(config))
            except Exception as e:
                print(f"[Verification] Erro ao abrir o modal do botão: {e}")
                if not inter.response.is_done():
                    await inter.response.send_message(f"{emoji.wrong} Não foi possível abrir a personalização do botão. Tente novamente.", ephemeral=True)
            return

    async def _refresh_via_wait(self, inter: disnake.MessageInteraction):
        mode = _get_mode()
        await (embed_message if mode == "embed" else message).wait(inter, send=False)
        await VerificationConfigPanel._refresh(inter)

    @commands.Cog.listener("on_dropdown")
    async def on_dropdown(self, inter: disnake.MessageInteraction):
        if inter.component.custom_id != FEATURES_SELECT_ID:
            return

        selected = set(inter.values or [])
        config = service.get_config()
        for key in config["protected_features"]:
            config["protected_features"][key] = key in selected
        service.save_config(config)

        await self._refresh_via_wait(inter)


def setup(bot: commands.Bot):
    bot.add_cog(VerificationConfigPanel(bot))