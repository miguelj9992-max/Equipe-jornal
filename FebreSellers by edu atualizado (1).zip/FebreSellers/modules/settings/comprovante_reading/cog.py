"""
/painel > Configurações > Leitura de Comprovante

Liga/desliga o sistema automático de leitura de comprovantes (OCR + IA) e
permite configurar o canal onde a staff recebe os comprovantes suspeitos ou
que precisam de revisão manual.

- Desligado (padrão): o botão "Enviar Comprovante" não aparece pra ninguém.
  Pagamentos manuais (PIX Manual) dependem 100% de um admin clicar em
  "Aprovar Pagamento" — igual era antes desse sistema existir.
- Ligado: o botão "Enviar Comprovante" passa a aparecer ao lado de
  "Aprovar Pagamento" nos pagamentos que exigem aprovação manual.

O canal configurado aqui é o mesmo usado por Configurações > Canais >
"Análise de Comprovantes" (chave "canal_de_analise_comprovantes" no
documento "canais") — mudar em um lugar reflete no outro.
"""

import disnake
from disnake.ext import commands

from functions.database import database as db
from functions.emoji import emoji

from modules.loja.comprovante import store as comprovante_store


class ComprovanteReadingChannelModal(disnake.ui.Modal):
    def __init__(self):
        components = [
            disnake.ui.Label(
                text="Canal de Análise de Comprovantes",
                component=disnake.ui.ChannelSelect(
                    placeholder="Escolha um canal de texto",
                    custom_id="comprovante_reading_channel_select",
                    channel_types=[disnake.ChannelType.text],
                    min_values=1,
                    max_values=1,
                ),
                description="A staff recebe aqui os comprovantes suspeitos/em análise manual, com botões de Aprovar/Recusar.",
            ),
        ]
        super().__init__(title="Canal de Comprovantes", components=components, custom_id="comprovante_reading_channel_modal")

    async def callback(self, inter: disnake.ModalInteraction):
        valores = inter.resolved_values
        selected = valores.get("comprovante_reading_channel_select")
        if isinstance(selected, (list, tuple)):
            selected = selected[0] if selected else None

        channel_id = None
        if isinstance(selected, (str, int)):
            channel_id = int(selected)
        elif hasattr(selected, "id"):
            channel_id = int(selected.id)

        if not channel_id or not inter.guild.get_channel(channel_id):
            await inter.response.send_message(f"{emoji.wrong} Canal inválido!", ephemeral=True)
            return

        canais = db.get_document("canais") or {}
        canais["canal_de_analise_comprovantes"] = str(channel_id)
        db.save_document("canais", canais)

        mode = db.get_document("custom_mode").get("mode")
        panel = ComprovanteReadingConfig.panel(inter)
        if mode == "embed":
            await inter.response.edit_message(content=None, **panel)
        else:
            await inter.response.edit_message(**panel, flags=disnake.MessageFlags(is_components_v2=True))


class ComprovanteReadingConfig(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @staticmethod
    def panel(inter: disnake.MessageInteraction) -> dict:
        mode = db.get_document("custom_mode").get("mode")
        return ComprovanteReadingConfig._panel_embed(inter) if mode == "embed" else ComprovanteReadingConfig._panel_components(inter)

    @staticmethod
    def _status_text(inter: disnake.MessageInteraction) -> str:
        enabled = comprovante_store.is_reading_enabled()
        canais = db.get_document("canais") or {}
        channel_id = canais.get("canal_de_analise_comprovantes")
        channel = inter.guild.get_channel(int(channel_id)) if channel_id and inter.guild else None

        text = f"{emoji.on if enabled else emoji.off} **Status:** `{'Ativado' if enabled else 'Desativado'}`\n"
        if enabled:
            text += (
                "-# O botão **Enviar Comprovante** aparece nos pagamentos manuais (PIX Manual), "
                "junto do botão de Aprovar Pagamento.\n\n"
            )
        else:
            text += (
                "-# Nenhuma leitura automática acontece. Pagamentos manuais dependem só de um "
                "admin clicar em **Aprovar Pagamento**.\n\n"
            )

        if channel:
            text += f"{emoji.textc} **Canal de análise:** {channel.mention}\n"
        else:
            text += f"{emoji.wrong} **Canal de análise:** Não configurado (cai no canal de Logs de Pedidos, se houver)\n"

        return text

    @staticmethod
    def _panel_components(inter: disnake.MessageInteraction) -> dict:
        colors = db.get_document("custom_colors") or {}
        primary_color_hex = colors.get("primary")
        enabled = comprovante_store.is_reading_enabled()

        container_kwargs = {}
        if primary_color_hex:
            container_kwargs["accent_colour"] = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))

        return {"components": [
            disnake.ui.Container(
                disnake.ui.TextDisplay(
                    f"## \n"
                    "-# Painel > Configurações > **Leitura de Comprovante**"
                ),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(
                    "Leitura automática dos comprovantes de pagamento enviados pelos "
                    "clientes em pedidos com Pix Manual, esse sistema funciona **Apenas** no Pix Manual como forma de pagamento.\n\n" + ComprovanteReadingConfig._status_text(inter)
                ),
                disnake.ui.Separator(),
                disnake.ui.ActionRow(
                    disnake.ui.Button(
                        label="Ativar" if not enabled else "Desativar",
                        emoji=emoji.power,
                        style=disnake.ButtonStyle.green if not enabled else disnake.ButtonStyle.red,
                        custom_id="ComprovanteReading_Toggle"
                    ),
                    disnake.ui.Button(
                        label="Configurar Canal",
                        emoji=emoji.textc,
                        style=disnake.ButtonStyle.blurple,
                        custom_id="ComprovanteReading_SetChannel"
                    ),
                ),
                **container_kwargs
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="Painel_Configuracoes")
            )
        ]}

    @staticmethod
    def _panel_embed(inter: disnake.MessageInteraction) -> dict:
        colors = db.get_document("custom_colors") or {}
        primary_color_hex = colors.get("primary")
        enabled = comprovante_store.is_reading_enabled()

        embed = disnake.Embed(
            title="Leitura de Comprovante",
            description=(
                "-# Painel > Configurações > **Leitura de Comprovante**\n\n"
                "Leitura automática (OCR + IA) dos comprovantes de pagamento enviados pelos "
                "clientes em pedidos com PIX Manual.\n\n" + ComprovanteReadingConfig._status_text(inter)
            )
        )
        if primary_color_hex:
            embed.color = int(primary_color_hex.replace("#", ""), 16)

        components = [
            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Ativar" if not enabled else "Desativar",
                    emoji=emoji.power,
                    style=disnake.ButtonStyle.green if not enabled else disnake.ButtonStyle.red,
                    custom_id="ComprovanteReading_Toggle"
                ),
                disnake.ui.Button(
                    label="Configurar Canal",
                    emoji=emoji.textc,
                    style=disnake.ButtonStyle.blurple,
                    custom_id="ComprovanteReading_SetChannel"
                ),
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="Painel_Configuracoes")
            )
        ]
        return {"embed": embed, "components": components}

    @commands.Cog.listener("on_button_click")
    async def on_button_click(self, inter: disnake.MessageInteraction):
        if inter.component.custom_id == "ComprovanteReading_Toggle":
            novo_estado = not comprovante_store.is_reading_enabled()
            comprovante_store.set_reading_enabled(novo_estado)

            mode = db.get_document("custom_mode").get("mode")
            panel = ComprovanteReadingConfig.panel(inter)
            if mode == "embed":
                await inter.response.edit_message(content=None, **panel)
            else:
                await inter.response.edit_message(**panel, flags=disnake.MessageFlags(is_components_v2=True))

        elif inter.component.custom_id == "ComprovanteReading_SetChannel":
            await inter.response.send_modal(ComprovanteReadingChannelModal())


def setup(bot: commands.Bot):
    bot.add_cog(ComprovanteReadingConfig(bot))