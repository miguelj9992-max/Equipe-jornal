from disnake.ext import commands
from .cog import setup


__all__ = ["setup"]