from disnake.ext import commands
import disnake
import json
from pathlib import Path
from datetime import datetime
import aiohttp

from functions.database import database as db
from functions.emoji import emoji
from functions.message import message, embed_message
from functions import plan


class ConfigurarPagamentos(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @staticmethod
    def _providers():
        """Retorna todos os provedores com suas informações"""
        return {
            "pix_manual": ("Pix Manual", emoji.pix),
            "mercado_pago": ("Mercado Pago", emoji.mercado_pago),
            "efibank": ("Efi Bank", emoji.efi_bank),
            "pushinpay": ("Pushin Pay", emoji.pushin_pay),
            "misticpay": ("MisticPay", emoji.pix),
            "promissepay": ("PromissePay", emoji.pix),
            "vexopay": ("VexoPay", emoji.pix),
            "lunar_wallet": ("Febre Wallet", emoji.wallet),
            "livepix": ("Live Pix", emoji.wallet),
            "pagbank": ("PagBank (Em breve)", emoji.pagbank),
            "picpay": ("PicPay (Em breve)", emoji.picpay),
            "stripe": ("Stripe", emoji.stripe),
            "nowpayments": ("NowPayments (Em breve)", emoji.wallet),
            "coinbase": ("Coinbase (Em breve)", emoji.wallet),
            "asaas": ("Asaas", emoji.card),
            "paypal": ("PayPal", emoji.wallet),
            "nubank": ("Nubank", emoji.nubank),
            "inter": ("Inter (Em breve)", emoji.bank),
            "bitcoin": ("Bitcoin (Em breve)", emoji.wallet),
            "litecoin": ("Litecoin (Em breve)", emoji.wallet),
            "ethereum": ("Ethereum (Em breve)", emoji.wallet),
        }

    @staticmethod
    def _providers_by_category():
        """Retorna os provedores organizados por categoria de pagamento"""
        return {
            "pix": [
                "pix_manual",
                "lunar_wallet",
                "mercado_pago",
                "efibank",
                "pushinpay",
                "misticpay",
                "promissepay",
                "vexopay",
                "livepix",
                "asaas",
                "nubank",
                "inter",
            ],
            "cartao": [
                "asaas",
                "stripe",
                "paypal",
            ],
            "crypto": [
                "stripe",
                "nowpayments",
                "coinbase",
                "bitcoin",
                "litecoin",
                "ethereum",
            ],
        }

    @staticmethod
    def _providers_coming_soon():
        """Lista de provedores que estão em breve"""
        return [
            "pagbank", "picpay", "nowpayments", 
            "coinbase",
            "bitcoin", "litecoin", "ethereum",
            "inter"
        ]

    @staticmethod
    def _load_config() -> dict:
        """Carrega configurações de pagamento do database"""
        return db.get_document("payment_configs") or {}

    @classmethod
    def _get_provider_status(cls, key: str, config: dict, pagamentos: dict) -> tuple[bool, bool, str]:
        """Retorna (enabled, configured, status_text) para um provedor"""
        # Provedores "em breve" nunca aparecem como ativados
        if key in cls._providers_coming_soon():
            return False, False, "Em breve"
        entry = config.get(key)
        if isinstance(entry, dict):
            enabled = bool(entry.get("enabled", False))
            if key == "mercado_pago":
                configured = bool(entry.get("access_token"))
            elif key == "efibank":
                cert_path = entry.get("cert_file")
                cert_ok = bool(cert_path) and Path(cert_path).exists()
                has_client = bool(entry.get("client_id") or entry.get("client"))
                has_secret = bool(entry.get("client_secret") or entry.get("token"))
                has_pix = bool(entry.get("pix_key"))
                configured = bool(has_client and has_secret and has_pix and cert_ok)
            elif key in {"pagbank", "picpay", "pushinpay", "asaas", "stripe", "coinbase", "nowpayments"}:
                token_key = {
                    "pagbank": "token_pagbank",
                    "picpay": "token_picpay",
                    "pushinpay": "token_pushinpay",
                    "asaas": "token_asaas",
                    "stripe": "token_stripe",
                    "coinbase": "token_coinbase",
                    "nowpayments": "token_nowpayments",
                }[key]
                configured = bool(entry.get(token_key))
            elif key == "paypal":
                configured = bool(entry.get("client_id") and entry.get("client_secret"))
            elif key == "misticpay":
                configured = bool(entry.get("client_id") and entry.get("client_secret"))
            elif key == "promissepay":
                configured = bool(entry.get("api_key"))
            elif key == "vexopay":
                configured = bool(entry.get("client_id") and entry.get("client_secret"))
            elif key == "livepix":
                configured = bool(entry.get("client_id") and entry.get("client_secret"))
            elif key == "lunar_wallet":
                # Não requer configuração externa, então o status visual (check/X)
                # acompanha diretamente o enabled: ligado = configurado, desligado = X
                configured = enabled
            elif key == "inter":
                from pathlib import Path as _Path
                cert_ok = bool(entry.get("cert_file")) and _Path(entry.get("cert_file","")).exists()
                key_ok  = bool(entry.get("key_file"))  and _Path(entry.get("key_file","")).exists()
                configured = bool(
                    entry.get("client_id") and entry.get("client_secret")
                    and entry.get("pix_key") and cert_ok and key_ok
                )
            elif key == "nubank":
                configured = bool(
                    entry.get("email") and entry.get("app_password") and entry.get("pix_key")
                )
            elif key == "pix_manual":
                configured = bool(entry.get("pix_key") and entry.get("pix_key_type"))
            elif key == "sync_wallet":
                configured = bool(entry.get("api_key"))
            else:
                configured = False
        elif isinstance(entry, bool):
            enabled = entry
            configured = False
        else:
            enabled = bool(pagamentos.get(key, False))
            configured = False
        
        if enabled:
            status_text = "Ativado"
        elif configured:
            status_text = "Desativado"
        else:
            status_text = "Não Configurado"
        
        return enabled, configured, status_text

    @classmethod
    def categoria_pagamentos_components(cls, inter: disnake.MessageInteraction) -> list[disnake.ui.Container]:
        """Componentes para seleção inicial de categoria de pagamento"""
        colors = db.get_document("custom_colors")
        primary_color_hex = colors.get("primary")

        container_kwargs = {}
        if primary_color_hex:
            primary_color = int(primary_color_hex.replace("#", ""), 16)
            container_kwargs["accent_colour"] = disnake.Colour(primary_color)

        return [
            disnake.ui.Container(
                disnake.ui.TextDisplay(f"## \n-# Painel > Configurações > **Formas de Pagamento**"),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(
                    f"{emoji.pix} **Pix**\n"
                    f"{emoji.card} **Cartão**\n"
                    f"{emoji.wallet} **Crypto**"
                ),
                disnake.ui.Separator(),
                disnake.ui.ActionRow(
                    disnake.ui.StringSelect(
                        custom_id="Configuracoes_Pagamentos_Categoria_Select",
                        placeholder="Selecione o tipo de pagamento",
                        options=[
                            disnake.SelectOption(
                                label="Pix",
                                value="pix",
                                emoji=emoji.pix,
                                description="Configure métodos de pagamento via Pix"
                            ),
                            disnake.SelectOption(
                                label="Cartão",
                                value="cartao",
                                emoji=emoji.card,
                                description="Configure métodos de pagamento com cartão"
                            ),
                            disnake.SelectOption(
                                label="Crypto",
                                value="crypto",
                                emoji=emoji.wallet,
                                description="Configure métodos de pagamento em criptomoedas"
                            ),
                        ],
                    )
                ),
                **container_kwargs,
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="Painel_Configuracoes")
            ),
        ]

    @classmethod
    def categoria_pagamentos_embed(cls, inter: disnake.MessageInteraction):
        """Embed para seleção inicial de categoria de pagamento"""
        colors = db.get_document("custom_colors")
        primary_color_hex = colors.get("primary")

        embed = disnake.Embed(
            title="Formas de Pagamento",
            description="Selecione o tipo de pagamento que deseja configurar.",
        )
        if primary_color_hex:
            embed.color = int(primary_color_hex.replace("#", ""), 16)

        embed.description = (
            f"-# Painel > Configurações > **Formas de Pagamento**\n\n"
            f"{emoji.pix} **Pix**\n"
            f"{emoji.card} **Cartão**\n"
            f"{emoji.wallet} **Crypto**"
        )

        components = [
            disnake.ui.ActionRow(
                disnake.ui.StringSelect(
                    custom_id="Configuracoes_Pagamentos_Categoria_Select",
                    placeholder="Selecione o tipo de pagamento",
                    options=[
                        disnake.SelectOption(
                            label="Pix",
                            value="pix",
                            emoji=emoji.pix,
                            description="Configure métodos de pagamento via Pix"
                        ),
                        disnake.SelectOption(
                            label="Cartão",
                            value="cartao",
                            emoji=emoji.card,
                            description="Configure métodos de pagamento com cartão"
                        ),
                        disnake.SelectOption(
                            label="Crypto",
                            value="crypto",
                            emoji=emoji.wallet,
                            description="Configure métodos de pagamento em criptomoedas"
                        ),
                    ],
                )
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="Painel_Configuracoes")
            ),
        ]
        return embed, components

    @classmethod
    def pagamentos_components(cls, inter: disnake.MessageInteraction, categoria: str = None) -> list[disnake.ui.Container]:
        """Componentes para listar provedores de uma categoria específica"""
        pagamentos = db.get_document("pagamentos") or {}
        config = cls._load_config()
        colors = db.get_document("custom_colors")
        primary_color_hex = colors.get("primary")

        container_kwargs = {}
        if primary_color_hex:
            primary_color = int(primary_color_hex.replace("#", ""), 16)
            container_kwargs["accent_colour"] = disnake.Colour(primary_color)

        # Se não especificou categoria, mostra a tela de seleção de categoria
        if not categoria:
            return cls.categoria_pagamentos_components(inter)

        # Obter provedores da categoria
        providers_dict = cls._providers()
        providers_by_cat = cls._providers_by_category()
        provider_keys = providers_by_cat.get(categoria, [])

        # Mapear nomes de categoria para exibição
        categoria_names = {
            "pix": "Pix",
            "cartao": "Cartão",
            "crypto": "Crypto",
        }
        categoria_name = categoria_names.get(categoria, categoria.capitalize())

        status_lines = []
        options = []
        for key in provider_keys:
            if key not in providers_dict:
                continue
            label, icon = providers_dict[key]
            enabled, configured, status_text = cls._get_provider_status(key, config, pagamentos)
            
            status_lines.append(f"{emoji.on if enabled else emoji.settings2 if configured else emoji.wrong} **{label}**")
            options.append(
                disnake.SelectOption(
                    label=f"Configurar {label}",
                    value=key,
                    emoji=icon,
                    description=f"Status: {status_text}",
                )
            )

        result = [
            disnake.ui.Container(
                disnake.ui.TextDisplay(f"## \n-# Painel > Configurações > **Formas de Pagamento** > **{categoria_name}**"),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay("\n".join(status_lines) if status_lines else "Nenhum provedor disponível nesta categoria."),
                disnake.ui.Separator(),
                disnake.ui.ActionRow(
                    disnake.ui.StringSelect(
                        custom_id=f"Configuracoes_Pagamentos_Select:{categoria}",
                        placeholder="Selecione uma forma de pagamento para configurar",
                        options=options,
                    )
                ),
                **container_kwargs,
            ),
        ]

        # Construir botões do ActionRow filtrando None
        back_button = disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="Configuracoes_Pagamentos")
        
        buttons = [back_button]
        buttons = [btn for btn in buttons if btn is not None]
        
        result.append(disnake.ui.ActionRow(*buttons))

        return result


    @classmethod
    def pagamentos_embed(cls, inter: disnake.MessageInteraction, categoria: str = None):
        """Embed para listar provedores de uma categoria específica"""
        # Se não especificou categoria, mostra a tela de seleção de categoria
        if not categoria:
            return cls.categoria_pagamentos_embed(inter)

        pagamentos = db.get_document("pagamentos") or {}
        config = cls._load_config()
        colors = db.get_document("custom_colors")
        primary_color_hex = colors.get("primary")

        # Obter provedores da categoria
        providers_dict = cls._providers()
        providers_by_cat = cls._providers_by_category()
        provider_keys = providers_by_cat.get(categoria, [])

        # Mapear nomes de categoria para exibição
        categoria_names = {
            "pix": "Pix",
            "cartao": "Cartão",
            "crypto": "Crypto",
        }
        categoria_name = categoria_names.get(categoria, categoria.capitalize())

        embed = disnake.Embed(
            title=f"Formas de Pagamento - {categoria_name}",
            description="Selecione uma forma de pagamento para configurar.",
        )
        if primary_color_hex:
            embed.color = int(primary_color_hex.replace("#", ""), 16)

        status_lines = []
        options = []
        for key in provider_keys:
            if key not in providers_dict:
                continue
            label, icon = providers_dict[key]
            enabled, configured, status_text = cls._get_provider_status(key, config, pagamentos)
            
            status_lines.append(f"{emoji.on if enabled else emoji.settings2 if configured else emoji.wrong} **{label}**")
            options.append(
                disnake.SelectOption(
                    label=f"Configurar {label}",
                    value=key,
                    emoji=icon,
                    description=f"Status: {status_text}",
                )
            )

        embed.description = f"-# Painel > Configurações > **Formas de Pagamento** > **{categoria_name}**\n\n" + "\n".join(status_lines) if status_lines else "Nenhum provedor disponível nesta categoria."

        components = [
            disnake.ui.ActionRow(
                disnake.ui.StringSelect(
                    custom_id=f"Configuracoes_Pagamentos_Select:{categoria}",
                    placeholder="Selecione uma forma de pagamento para configurar",
                    options=options,
                )
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="Configuracoes_Pagamentos"),
            ),
        ]

        # Filtrar None dos botões no ActionRow
        components[-1] = disnake.ui.ActionRow(
            *[btn for btn in components[-1].children if btn is not None]
        )

        return embed, components

    @classmethod
    def _lunar_wallet_status_lines(cls) -> dict:
        """Coleta os dados necessários para montar o painel da Febre Wallet."""
        from functions.payments.lunar_wallet import (
            get_balance,
            get_lunar_wallet_config,
            WITHDRAW_FLAT_FEE,
            MIN_WITHDRAW_AMOUNT,
            ENTRY_FIXED_FEE,
        )

        config = get_lunar_wallet_config()
        enabled = bool(config.get("enabled", False))
        balance = get_balance()
        fee_responsibility = config.get("fee_responsibility", "loja")

        def fmt(v: float) -> str:
            return f"R$ {v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")

        return {
            "enabled": enabled,
            "balance": balance,
            "balance_str": fmt(balance),
            "fee_responsibility": fee_responsibility,
            "fee_responsibility_label": "Loja" if fee_responsibility == "loja" else "Cliente",
            "withdraw_fee_str": fmt(WITHDRAW_FLAT_FEE),
            "min_withdraw_str": fmt(MIN_WITHDRAW_AMOUNT),
            "entry_fee_str": fmt(ENTRY_FIXED_FEE),
        }

    @classmethod
    def lunar_wallet_panel_components(cls, inter: disnake.MessageInteraction) -> list[disnake.ui.Container]:
        """Painel dedicado da Febre Wallet (Ligar/Desligar, Saque, Responsabilidade da Taxa)"""
        data = cls._lunar_wallet_status_lines()
        colors = db.get_document("custom_colors")
        primary_color_hex = colors.get("primary")
        container_kwargs = {}
        if primary_color_hex:
            primary_color = int(primary_color_hex.replace("#", ""), 16)
            container_kwargs["accent_colour"] = disnake.Colour(primary_color)

        toggle_label = "Desligar Febre Wallet" if data["enabled"] else "Ligar Febre Wallet"
        toggle_style = disnake.ButtonStyle.red if data["enabled"] else disnake.ButtonStyle.green

        result = [
            disnake.ui.Container(
                disnake.ui.TextDisplay(
                    f"## \n"
                    f"-# Painel > Configurações > Formas de Pagamento > Pix > **Febre Wallet**"
                ),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(
                    f"## {emoji.wallet} Febre Wallet\n"
                    f"* **Status:** `{'Ativado' if data['enabled'] else 'Desativado'}`\n"
                    f"* **Saldo Disponível:** `{data['balance_str']}`\n"
                    f"* **Responsabilidade Taxa:** `{data['fee_responsibility_label']}`"
                ),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(
                    f"**Taxas de Operação:**\n"
                    f"-# Entrada: taxa fixa de {data['entry_fee_str']} por recebimento\n"
                    f"-# Saque: taxa fixa de {data['withdraw_fee_str']} (mínimo {data['min_withdraw_str']})"
                ),
                disnake.ui.Separator(),
                disnake.ui.ActionRow(
                    disnake.ui.Button(label=toggle_label, style=toggle_style, emoji=emoji.power, custom_id="LunarWallet_Toggle"),
                    disnake.ui.Button(label="Saque", style=disnake.ButtonStyle.grey, emoji=emoji.bank, custom_id="LunarWallet_Saque"),
                    disnake.ui.Button(label="Responsabilidade Taxa", style=disnake.ButtonStyle.grey, emoji=emoji.hrench2, custom_id="LunarWallet_TaxaResp"),
                ),
                disnake.ui.ActionRow(
                    disnake.ui.Button(label="Extratos", style=disnake.ButtonStyle.grey, emoji=emoji.receipt if hasattr(emoji, "receipt") else None, custom_id="LunarWallet_Extratos"),
                ),
                **container_kwargs,
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="LunarWallet_Voltar"),
            ),
        ]
        return result

    @classmethod
    def lunar_wallet_panel_embed(cls, inter: disnake.MessageInteraction):
        """Versão em embed do painel da Febre Wallet"""
        data = cls._lunar_wallet_status_lines()
        colors = db.get_document("custom_colors")
        primary_color_hex = colors.get("primary")

        embed = disnake.Embed(
            title=f"{emoji.wallet} Febre Wallet",
            description=(
                f"-# Painel > Configurações > Formas de Pagamento > Pix > **Febre Wallet**\n\n"
                f"* **Status:** `{'Ativado' if data['enabled'] else 'Desativado'}`\n"
                f"* **Saldo Disponível:** `{data['balance_str']}`\n"
                f"* **Responsabilidade Taxa:** `{data['fee_responsibility_label']}`\n\n"
                f"**Taxas de Operação:**\n"
                f"Entrada: taxa fixa de {data['entry_fee_str']} por recebimento\n"
                f"Saque: taxa fixa de {data['withdraw_fee_str']} (mínimo {data['min_withdraw_str']})"
            ),
        )
        if primary_color_hex:
            embed.color = int(primary_color_hex.replace("#", ""), 16)

        toggle_label = "Desligar Febre Wallet" if data["enabled"] else "Ligar Febre Wallet"
        toggle_style = disnake.ButtonStyle.red if data["enabled"] else disnake.ButtonStyle.green

        components = [
            disnake.ui.ActionRow(
                disnake.ui.Button(label=toggle_label, style=toggle_style, emoji=emoji.power, custom_id="LunarWallet_Toggle"),
                disnake.ui.Button(label="Saque", style=disnake.ButtonStyle.grey, emoji=emoji.bank, custom_id="LunarWallet_Saque"),
                disnake.ui.Button(label="Responsabilidade Taxa", style=disnake.ButtonStyle.grey, emoji=emoji.hrench2, custom_id="LunarWallet_TaxaResp"),
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Extratos", style=disnake.ButtonStyle.grey, emoji=emoji.receipt if hasattr(emoji, "receipt") else None, custom_id="LunarWallet_Extratos"),
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="LunarWallet_Voltar"),
            ),
        ]
        return embed, components

    async def display_payments_panel(self, inter: disnake.MessageInteraction):
        mode = db.get_document("custom_mode").get("mode")

        if mode == "embed":
            await embed_message.wait(inter)
            embed, components = self.categoria_pagamentos_embed(inter)
            await inter.edit_original_message(content=None, embed=embed, components=components)
        else:
            await message.wait(inter)
            await inter.edit_original_message(components=self.categoria_pagamentos_components(inter))

    @commands.Cog.listener("on_button_click")
    async def on_button_click(self, inter: disnake.MessageInteraction):
        if inter.component.custom_id == "Configuracoes_Pagamentos":
            mode = db.get_document("custom_mode").get("mode")
            if mode == "embed":
                await embed_message.wait(inter, send=False)
                embed, components = self.categoria_pagamentos_embed(inter)
                await inter.edit_original_message(content=None, embed=embed, components=components)
            else:
                await message.wait(inter, send=False)
                await inter.edit_original_message(components=self.categoria_pagamentos_components(inter))
        
        elif inter.component.custom_id == "Configuracoes_Pagamentos_Tutorial_Pix":
            await inter.response.send_message(
                f"Acesse a documentação completa para configurar o pagamento via PIX:\n"
                f"O grande diferencial da Sync Wallet é que aceita menores e não tem MEDs.\n"
                f"https://docs.syncwallet.com.br/tutoriais/integrar-sync-bot",
                ephemeral=True
            )

        elif inter.component.custom_id == "LunarWallet_Voltar":
            mode = db.get_document("custom_mode").get("mode")
            if mode == "embed":
                await embed_message.wait(inter, send=False)
                embed, components = self.pagamentos_embed(inter, "pix")
                await inter.edit_original_message(content=None, embed=embed, components=components)
            else:
                await message.wait(inter, send=False)
                await inter.edit_original_message(
                    content=None,
                    components=self.pagamentos_components(inter, "pix"),
                )

        elif inter.component.custom_id == "LunarWallet_Toggle":
            from functions.payments.lunar_wallet import is_lunar_wallet_enabled, set_lunar_wallet_enabled

            new_state = not is_lunar_wallet_enabled()
            set_lunar_wallet_enabled(new_state)

            # Manter o documento "pagamentos" sincronizado (usado pelo checkout)
            pagamentos = db.get_document("pagamentos") or {}
            pagamentos["lunar_wallet"] = new_state
            db.save_document("pagamentos", {}, pagamentos)

            try:
                from modules.loja.cart.buy_modal import invalidate_payment_methods_cache
                from modules.loja.cart.checkout import invalidate_checkout_payment_cache
                invalidate_payment_methods_cache()
                invalidate_checkout_payment_cache()
            except Exception as e:
                print(f"[ConfigurarPagamentos] Falha ao invalidar cache de pagamentos: {e}")

            mode = db.get_document("custom_mode").get("mode")
            if mode == "embed":
                await embed_message.wait(inter, send=False)
                embed, components = self.lunar_wallet_panel_embed(inter)
                await inter.edit_original_message(content=None, embed=embed, components=components)
            else:
                await message.wait(inter, send=False)
                await inter.edit_original_message(
                    content=None,
                    components=self.lunar_wallet_panel_components(inter),
                )

        elif inter.component.custom_id == "LunarWallet_Saque":
            from functions.payments.lunar_wallet import get_balance

            balance = get_balance()
            if balance <= 0:
                await inter.response.send_message(
                    f"{emoji.wrong} Você ainda não tem saldo disponível para sacar na Febre Wallet.",
                    ephemeral=True,
                )
                return
            await inter.response.send_modal(LunarWalletSaqueModal())

        elif inter.component.custom_id == "LunarWallet_TaxaResp":
            await inter.response.send_modal(LunarWalletTaxaModal())

        elif inter.component.custom_id == "LunarWallet_Extratos":
            from functions.payments.lunar_wallet import get_transactions

            transactions = get_transactions(limit=25)

            if not transactions:
                await inter.response.send_message(
                    f"{emoji.information} Ainda não há transações registradas na Febre Wallet.",
                    ephemeral=True,
                )
                return

            options = []
            for tx in transactions:
                is_credit = tx.get("type") == "credit"
                amount_str = f"R$ {float(tx.get('amount') or 0):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
                try:
                    dt = datetime.fromisoformat(tx.get("created_at"))
                    date_str = dt.strftime("%d/%m/%Y %H:%M")
                except Exception:
                    date_str = tx.get("created_at", "")

                label = f"{'Venda' if is_credit else 'Saque'} • {amount_str} • {date_str}"
                label = label[:100]
                description = (tx.get("description") or "")[:100]

                options.append(
                    disnake.SelectOption(
                        label=label,
                        value=tx.get("id"),
                        description=description or None,
                        emoji=emoji.green if is_credit else emoji.red,
                    )
                )

            select_row = disnake.ui.ActionRow(
                disnake.ui.StringSelect(
                    placeholder="Selecione uma transação para gerar o comprovante",
                    custom_id="LunarWallet_ExtratoSelect",
                    options=options,
                )
            )

            await inter.response.send_message(
                content=f"{emoji.receipt if hasattr(emoji, 'receipt') else emoji.wallet} **Extratos da Febre Wallet**\nSelecione uma transação abaixo para gerar o comprovante em imagem. Apenas você poderá ver este comprovante.",
                components=[select_row],
                ephemeral=True,
            )

    @commands.Cog.listener("on_dropdown")
    async def on_dropdown(self, inter: disnake.MessageInteraction):
        # Extratos da Febre Wallet -> gerar comprovante da transação selecionada
        if inter.component.custom_id == "LunarWallet_ExtratoSelect":
            from functions.payments.lunar_wallet import get_transaction, get_balance
            from functions.payments.lunar_wallet_receipts import lunar_wallet_receipts

            tx_id = inter.values[0]
            tx = get_transaction(tx_id)

            if not tx:
                await inter.response.send_message(
                    f"{emoji.wrong} Essa transação não foi encontrada (pode ter saído do histórico).",
                    ephemeral=True,
                )
                return

            await inter.response.defer(ephemeral=True, with_message=True)

            try:
                if tx.get("type") == "credit":
                    receipt_buffer = lunar_wallet_receipts.generate_sale_receipt(
                        charge_amount=tx.get("charge_amount") or tx.get("amount"),
                        entry_fee=tx.get("fee") or 0,
                        credit_amount=tx.get("amount"),
                        buyer_name=tx.get("payer_name"),
                        description=tx.get("description"),
                        payment_id=tx.get("payment_id") or tx.get("id"),
                        new_balance=tx.get("balance_after"),
                        created_at=tx.get("created_at"),
                    )
                    filename = "comprovante_venda_lunar_wallet.png"
                else:
                    requested_amount = tx.get("amount")
                    fee = tx.get("fee") or 0
                    receipt_buffer = lunar_wallet_receipts.generate_withdraw_receipt(
                        requested_amount=requested_amount,
                        fee=fee,
                        net_amount=round(float(requested_amount) - float(fee), 2),
                        pix_key=tx.get("pix_key"),
                        pix_key_type=tx.get("pix_key_type"),
                        transaction_id=tx.get("withdraw_id") or tx.get("id"),
                        new_balance=tx.get("balance_after"),
                        created_at=tx.get("created_at"),
                        description=tx.get("description"),
                    )
                    filename = "comprovante_saque_lunar_wallet.png"

                receipt_file = disnake.File(receipt_buffer, filename=filename)
                await inter.followup.send(
                    content=f"{emoji.correct} Comprovante gerado — visível apenas para você.",
                    file=receipt_file,
                    ephemeral=True,
                )
            except Exception as e:
                print(f"[LunarWallet Extratos] Erro ao gerar comprovante: {e}")
                await inter.followup.send(
                    content=f"{emoji.wrong} Não foi possível gerar o comprovante. Veja o console do bot.",
                    ephemeral=True,
                )
            return

        # Seleção de categoria
        if inter.component.custom_id == "Configuracoes_Pagamentos_Categoria_Select":
            categoria = inter.values[0]
            mode = db.get_document("custom_mode").get("mode")
            
            if mode == "embed":
                await embed_message.wait(inter, send=False)
                embed, components = self.pagamentos_embed(inter, categoria)
                await inter.edit_original_message(content=None, embed=embed, components=components)
            else:
                await message.wait(inter, send=False)
                await inter.edit_original_message(components=self.pagamentos_components(inter, categoria))
        
        # Seleção de provedor (pode ter categoria no custom_id)
        elif inter.component.custom_id.startswith("Configuracoes_Pagamentos_Select"):
            # Extrair categoria do custom_id se existir
            parts = inter.component.custom_id.split(":")
            categoria = parts[1] if len(parts) > 1 else None
            key = inter.values[0]
            
            # Verificar se é um provedor "em breve"
            if key in self._providers_coming_soon():
                await inter.response.send_message(
                    f"{emoji.information} Essa forma de pagamento estará disponível em breve nas próximas atualizações.",
                    ephemeral=True
                )
                return
            
            # Verificar se o plano permite este provedor
            if not plan.should_allow_payment_provider(key):
                await inter.response.send_message(
                    f"{emoji.wrong} O plano **Free** permite apenas a forma de pagamento **Sync Wallet**.\n"
                    f"{emoji.arrow} Acesse https://syncwallet.com.br para criar sua conta.",
                    ephemeral=True
                )
                return
            if key in ["inter"]:
                await inter.response.send_message(
                    f"{emoji.information} Essa forma de pagamento estará disponível em breve nas próximas atualizações.",
                    ephemeral=True
                )
                return

            # Febre Wallet tem um painel dedicado (não usa o modal genérico)
            if key == "lunar_wallet":
                mode = db.get_document("custom_mode").get("mode")
                if mode == "embed":
                    await embed_message.wait(inter, send=False)
                    embed, components = self.lunar_wallet_panel_embed(inter)
                    await inter.edit_original_message(content=None, embed=embed, components=components)
                else:
                    await message.wait(inter, send=False)
                    await inter.edit_original_message(
                        content=None,
                        components=self.lunar_wallet_panel_components(inter),
                    )
                return

            await inter.response.send_modal(
                PaymentProviderModal(key, categoria, original_message_id=inter.message.id, original_channel_id=inter.channel.id)
            )    


class PaymentProviderModal(disnake.ui.Modal):
    def __init__(self, provider_key: str, categoria: str = None, original_message_id: int = None, original_channel_id: int = None):
        self.provider_key = provider_key
        self.categoria = categoria
        self.original_message_id = original_message_id
        self.original_channel_id = original_channel_id

        config = ConfigurarPagamentos._load_config()
        entry = config.get(provider_key) or {}
        if isinstance(entry, bool):
            entry = {"enabled": bool(entry)}

        enabled = bool(entry.get("enabled", False))

        providers_dict = ConfigurarPagamentos._providers()
        label = providers_dict.get(provider_key, (provider_key.capitalize(), ""))[0]

        components = [
            disnake.ui.Label(
                text="Status do provedor",
                component=disnake.ui.StringSelect(
                    placeholder="Ativar ou desativar",
                    custom_id="payment_status",
                    required=True,
                    options=[
                        disnake.SelectOption(label="Ativado", description="O provedor ficará ativado",emoji=emoji.on , value="enabled_True", default=enabled),
                        disnake.SelectOption(label="Desativado", description="O provedor ficará desativado", emoji=emoji.off, value="enabled_False", default=not enabled),
                    ],
                ),
                description="Define se o provedor estará ativo.",
            ),
        ]

        if provider_key == "mercado_pago":
            components.append(
                disnake.ui.Label(
                    text="Token Access",
                    component=disnake.ui.TextInput(
                        placeholder="Cole o Access Token do MercadoPago",
                        custom_id="mercado_pago_access_token",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("access_token") or ""),
                    ),
                    description="Access Token da sua conta Mercado Pago.",
                )
            )
        elif provider_key == "efibank":
            components.append(
                disnake.ui.Label(
                    text="Client ID",
                    component=disnake.ui.TextInput(
                        placeholder="Informe o Client ID da Efi",
                        custom_id="efibank_client_id",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("client_id") or entry.get("client") or ""),
                    ),
                    description="Identificador do cliente (Client ID).",
                )
            )
            components.append(
                disnake.ui.Label(
                    text="Client Secret",
                    component=disnake.ui.TextInput(
                        placeholder="Informe o Client Secret da Efi",
                        custom_id="efibank_client_secret",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("client_secret") or entry.get("token") or ""),
                    ),
                    description="Segredo do cliente (Client Secret).",
                )
            )
            components.append(
                disnake.ui.Label(
                    text="Chave Pix Aleatória",
                    component=disnake.ui.TextInput(
                        placeholder="Informe a Chave Pix Aleatória",
                        custom_id="efibank_pix_key",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("pix_key") or ""),
                    ),
                    description="Sua chave Pix aleatória cadastrada na Efi.",
                )
            )
            # Adicionar campo de upload de arquivo para o certificado .p12
            cert_path = entry.get("cert_file")
            cert_exists = bool(cert_path) and Path(cert_path).exists()
            components.append(
                disnake.ui.Label(
                    text="Certificado .p12",
                    component=disnake.ui.FileUpload(
                        custom_id="efibank_cert_file",
                        required=False,
                    ),
                    description="Envie o arquivo de certificado .p12 da Efi. Deixe vazio para manter o atual." if cert_exists else "Envie o arquivo de certificado .p12 da Efi.",
                )
            )
        elif provider_key == "pagbank":
            components.append(
                disnake.ui.Label(
                    text="Token PagBank",
                    component=disnake.ui.TextInput(
                        placeholder="Informe o token do PagBank",
                        custom_id="pagbank_token",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("token_pagbank") or ""),
                    ),
                    description="Token de API do PagBank.",
                )
            )
        elif provider_key == "picpay":
            components.append(
                disnake.ui.Label(
                    text="Token PicPay",
                    component=disnake.ui.TextInput(
                        placeholder="Informe o token do PicPay",
                        custom_id="picpay_token",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("token_picpay") or ""),
                    ),
                    description="Token de API do PicPay.",
                )
            )
        elif provider_key == "pushinpay":
            components.append(
                disnake.ui.Label(
                    text="Token PushinPay",
                    component=disnake.ui.TextInput(
                        placeholder="Informe o token do PushinPay",
                        custom_id="pushinpay_token",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("token_pushinpay") or ""),
                    ),
                    description="Token de API do PushinPay.",
                )
            )
        elif provider_key == "misticpay":
            components.append(
                disnake.ui.Label(
                    text="Client ID",
                    component=disnake.ui.TextInput(
                        placeholder="Informe o Client ID do MisticPay",
                        custom_id="misticpay_client_id",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("client_id") or ""),
                    ),
                    description="Client ID do MisticPay.",
                )
            )
            components.append(
                disnake.ui.Label(
                    text="Client Secret",
                    component=disnake.ui.TextInput(
                        placeholder="Informe o Client Secret do MisticPay",
                        custom_id="misticpay_client_secret",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("client_secret") or ""),
                    ),
                    description="Client Secret do MisticPay.",
                )
            )
        elif provider_key == "promissepay":
            components.append(
                disnake.ui.Label(
                    text="Chave de API",
                    component=disnake.ui.TextInput(
                        placeholder="Informe sua chave de API da PromissePay (sk_live_...)",
                        custom_id="promissepay_api_key",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("api_key") or ""),
                    ),
                    description="Chave de API da PromissePay (encontrada no painel promisse.com.br).",
                )
            )
        elif provider_key == "vexopay":
            components.append(
                disnake.ui.Label(
                    text="Client ID (ci)",
                    component=disnake.ui.TextInput(
                        placeholder="Informe o Client ID (ci) da VexoPay",
                        custom_id="vexopay_client_id",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("client_id") or ""),
                    ),
                    description="Client ID (ci) da VexoPay, encontrado em vexopay.com.br > API Keys.",
                )
            )
            components.append(
                disnake.ui.Label(
                    text="Client Secret (cs)",
                    component=disnake.ui.TextInput(
                        placeholder="Informe o Client Secret (cs) da VexoPay",
                        custom_id="vexopay_client_secret",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("client_secret") or ""),
                    ),
                    description="Client Secret (cs) da VexoPay.",
                )
            )
        elif provider_key == "livepix":
            components.append(
                disnake.ui.Label(
                    text="Client ID",
                    component=disnake.ui.TextInput(
                        placeholder="Informe o Client ID da aplicação LivePix",
                        custom_id="livepix_client_id",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("client_id") or ""),
                    ),
                    description="Client ID da sua aplicação, criada em livepix.gg > Configurações > Aplicações.",
                )
            )
            components.append(
                disnake.ui.Label(
                    text="Client Secret",
                    component=disnake.ui.TextInput(
                        placeholder="Informe o Client Secret da aplicação LivePix",
                        custom_id="livepix_client_secret",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("client_secret") or ""),
                    ),
                    description="Client Secret da sua aplicação LivePix.",
                )
            )
        elif provider_key == "asaas":
            components.append(
                disnake.ui.Label(
                    text="Token Asaas",
                    component=disnake.ui.TextInput(
                        placeholder="Informe o token do Asaas",
                        custom_id="asaas_token",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("token_asaas") or ""),
                    ),
                    description="Token de API do Asaas.",
                )
            )
        elif provider_key == "stripe":
            components.append(
                disnake.ui.Label(
                    text="Token Stripe",
                    component=disnake.ui.TextInput(
                        placeholder="Informe o token do Stripe",
                        custom_id="stripe_token",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("token_stripe") or ""),
                    ),
                    description="Token de API do Stripe.",
                )
            )
        elif provider_key == "coinbase":
            components.append(
                disnake.ui.Label(
                    text="Token Coinbase",
                    component=disnake.ui.TextInput(
                        placeholder="Informe o token do Coinbase",
                        custom_id="coinbase_token",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("token_coinbase") or ""),
                    ),
                    description="Token de API do Coinbase.",
                )
            )
        elif provider_key == "nowpayments":
            components.append(
                disnake.ui.Label(
                    text="Token NOWPayments",
                    component=disnake.ui.TextInput(
                        placeholder="Informe o token do NOWPayments",
                        custom_id="nowpayments_token",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("token_nowpayments") or ""),
                    ),
                    description="Token de API do NOWPayments.",
                )
            )
        elif provider_key == "paypal":
            components.append(
                disnake.ui.Label(
                    text="Client ID",
                    component=disnake.ui.TextInput(
                        placeholder="Informe o Client ID do PayPal",
                        custom_id="paypal_client_id",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("client_id") or ""),
                    ),
                    description="Client ID do PayPal.",
                )
            )
            components.append(
                disnake.ui.Label(
                    text="Client Secret",
                    component=disnake.ui.TextInput(
                        placeholder="Informe o Client Secret do PayPal",
                        custom_id="paypal_client_secret",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("client_secret") or ""),
                    ),
                    description="Client Secret do PayPal.",
                )
            )
        elif provider_key == "sync_wallet":
            # Sync Wallet - Solicitar API Key e coverFee
            api_key = entry.get("api_key")
            cover_fee = entry.get("cover_fee", False)
            components.append(
                disnake.ui.Label(
                    text="API Key da ",
                    component=disnake.ui.TextInput(
                        placeholder="Cole sua API Key aqui (vp_...)",
                        custom_id="sync_wallet_api_key",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(api_key or ""),
                    ),
                    description="API Key obtida em syncwallet.com.br/dashboard/credentials",
                )
            )
            components.append(
                disnake.ui.Label(
                    text="Cobrir Taxas",
                    component=disnake.ui.StringSelect(
                        placeholder="Selecione se deseja cobrir as taxas",
                        custom_id="sync_wallet_cover_fee",
                        required=False,
                        options=[
                            disnake.SelectOption(
                                label="Não cobrir taxas (padrão)",
                                description="Taxa será deduzida do valor do pagamento",
                                value="false",
                                default=not cover_fee
                            ),
                            disnake.SelectOption(
                                label="Cobrir taxas",
                                description="O cliente pagará a taxa para você",
                                value="true",
                                default=cover_fee
                            ),
                        ],
                    ),
                    description="Se ativado, seu clinte pagará a taxa da Sync Wallet.",
                )
            )
        elif provider_key == "pix_manual":
            components.append(
                disnake.ui.Label(
                    text="Chave PIX",
                    component=disnake.ui.TextInput(
                        placeholder="Digite sua chave PIX",
                        custom_id="pix_manual_key",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        max_length=50,
                        value=str(entry.get("pix_key") or ""),
                    ),
                    description="Sua chave PIX para receber pagamentos.",
                )
            )
            current_key_type = str(entry.get("pix_key_type") or "aleatoria")
            components.append(
                disnake.ui.Label(
                    text="Tipo da Chave PIX",
                    component=disnake.ui.StringSelect(
                        placeholder="Selecione o tipo da chave PIX",
                        custom_id="pix_manual_key_type",
                        options=[
                            disnake.SelectOption(label="Email", value="email", emoji=emoji.mail2, default=current_key_type=="email"),
                            disnake.SelectOption(label="Telefone", value="telefone", emoji=emoji.mobile, default=current_key_type=="telefone"),
                            disnake.SelectOption(label="CPF", value="cpf", emoji=emoji.member, default=current_key_type=="cpf"),
                            disnake.SelectOption(label="CNPJ", value="cnpj", emoji=emoji.store, default=current_key_type=="cnpj"),
                            disnake.SelectOption(label="Aleatória", value="aleatoria", emoji=emoji.link, default=current_key_type=="aleatoria"),
                        ],
                    ),
                    description="Tipo da chave PIX informada.",
                )
            )

        elif provider_key == "inter":
            components.append(
                disnake.ui.Label(
                    text="Client ID",
                    component=disnake.ui.TextInput(
                        placeholder="Client ID do portal de desenvolvedores do Inter",
                        custom_id="inter_client_id",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("client_id") or ""),
                    ),
                    description="Client ID gerado no portal developers.inter.co.",
                )
            )
            components.append(
                disnake.ui.Label(
                    text="Client Secret",
                    component=disnake.ui.TextInput(
                        placeholder="Client Secret do portal de desenvolvedores do Inter",
                        custom_id="inter_client_secret",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("client_secret") or ""),
                    ),
                    description="Client Secret gerado no portal developers.inter.co.",
                )
            )
            components.append(
                disnake.ui.Label(
                    text="Chave Pix",
                    component=disnake.ui.TextInput(
                        placeholder="Chave Pix cadastrada na conta Inter",
                        custom_id="inter_pix_key",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("pix_key") or ""),
                    ),
                    description="Chave Pix da conta Banco Inter para receber pagamentos.",
                )
            )
            components.append(
                disnake.ui.Label(
                    text="Certificados",
                    component=disnake.ui.TextInput(
                        placeholder="Use /inter_certificados para enviar os arquivos .crt e .key",
                        custom_id="inter_cert_info",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value="Configurado" if (entry.get("cert_file") and entry.get("key_file")) else "Não configurado — use /inter_certificados",
                    ),
                    description="Envie os arquivos .crt e .key usando o comando /inter_certificados.",
                )
            )

        elif provider_key == "nubank":
            components.append(
                disnake.ui.Label(
                    text="Email do Nubank",
                    component=disnake.ui.TextInput(
                        placeholder="seu@email.com",
                        custom_id="nubank_email",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("email") or ""),
                    ),
                    description="Email da conta Nubank que receberá os PIX.",
                )
            )
            components.append(
                disnake.ui.Label(
                    text="Senha do App (IMAP)",
                    component=disnake.ui.TextInput(
                        placeholder="Senha de app gerada no Gmail/Outlook",
                        custom_id="nubank_app_password",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("app_password") or ""),
                    ),
                    description="Senha de app do provedor de email (não é a senha normal).",
                )
            )
            components.append(
                disnake.ui.Label(
                    text="Chave Pix",
                    component=disnake.ui.TextInput(
                        placeholder="Chave Pix cadastrada no Nubank",
                        custom_id="nubank_pix_key",
                        style=disnake.TextInputStyle.short,
                        required=False,
                        value=str(entry.get("pix_key") or ""),
                    ),
                    description="Chave Pix da conta Nubank.",
                )
            )
            components.append(
                disnake.ui.Label(
                    text="Tipo da Chave Pix",
                    component=disnake.ui.StringSelect(
                        placeholder="Selecione o tipo da chave",
                        custom_id="nubank_pix_key_type",
                        required=False,
                        options=[
                            disnake.SelectOption(label="Email",     value="email",     emoji=emoji.mail2,   default=entry.get("pix_key_type") == "email"),
                            disnake.SelectOption(label="Telefone",  value="telefone",  emoji=emoji.mobile,  default=entry.get("pix_key_type") == "telefone"),
                            disnake.SelectOption(label="CPF",       value="cpf",       emoji=emoji.member,  default=entry.get("pix_key_type") == "cpf"),
                            disnake.SelectOption(label="CNPJ",      value="cnpj",      emoji=emoji.store,   default=entry.get("pix_key_type") == "cnpj"),
                            disnake.SelectOption(label="Aleatória", value="aleatoria", emoji=emoji.link,    default=entry.get("pix_key_type") == "aleatoria"),
                        ],
                    ),
                    description="Tipo da chave Pix informada.",
                )
            )

        super().__init__(title=f"Configurar {label}", components=components, custom_id=f"payment_provider_modal:{provider_key}")

    async def callback(self, inter: disnake.ModalInteraction):
        """Wrapper que garante que o usuário SEMPRE recebe algum feedback,
        mesmo se algo inesperado falhar no processamento (ex: Mongo fora do ar,
        erro de validação não previsto, etc). Sem isso, uma exceção não tratada
        em _process fazia o clique em 'Enviar' parecer não fazer nada."""
        import traceback
        try:
            await self._process(inter)
        except Exception:
            print("[PaymentProviderModal] Erro ao processar o modal de pagamento:")
            traceback.print_exc()
            fallback_text = (
                f"{emoji.wrong} Ocorreu um erro ao salvar as configurações. "
                f"Verifique o console/logs do bot para ver o erro completo."
            )
            try:
                if inter.response.is_done():
                    await inter.followup.send(content=fallback_text, ephemeral=True)
                else:
                    await inter.response.send_message(content=fallback_text, ephemeral=True)
            except Exception:
                traceback.print_exc()

    async def _process(self, inter: disnake.ModalInteraction):
        print("[DEBUG MODAL] _process foi chamado! provider_key =", self.provider_key)              

        mode = db.get_document("custom_mode").get("mode")

        # Mostrar loading imediatamente editando a mensagem efêmera do painel
        loading_component = disnake.ui.TextDisplay(f"{emoji.loading} Carregando informações...")
        await inter.response.edit_message(
            content=None,
            embed=None,
            components=loading_component,
        )

        valores = inter.resolved_values

        status_value = valores.get("payment_status")
        if isinstance(status_value, (list, tuple)):
            status_value = status_value[0] if status_value else None
        enabled = True if status_value == "enabled_True" else False

        access_token = valores.get("mercado_pago_access_token") if self.provider_key == "mercado_pago" else None
        efibank_client_id = valores.get("efibank_client_id") if self.provider_key == "efibank" else None
        efibank_client_secret = valores.get("efibank_client_secret") if self.provider_key == "efibank" else None
        efibank_pix_key = valores.get("efibank_pix_key") if self.provider_key == "efibank" else None
        efibank_cert_file = None
        cert_path = None  # Inicializar cert_path no escopo correto
        if self.provider_key == "efibank":
            # Processar arquivo de certificado se fornecido
            # Em modais, arquivos são acessados através de resolved_values
            cert_file_value = valores.get("efibank_cert_file")
            if cert_file_value:
                # Pode ser um único arquivo ou uma lista
                if isinstance(cert_file_value, (list, tuple)):
                    efibank_cert_file = cert_file_value[0] if cert_file_value else None
                else:
                    efibank_cert_file = cert_file_value
        pagbank_token = valores.get("pagbank_token") if self.provider_key == "pagbank" else None
        picpay_token = valores.get("picpay_token") if self.provider_key == "picpay" else None
        pushinpay_token = valores.get("pushinpay_token") if self.provider_key == "pushinpay" else None
        misticpay_client_id = valores.get("misticpay_client_id") if self.provider_key == "misticpay" else None
        misticpay_client_secret = valores.get("misticpay_client_secret") if self.provider_key == "misticpay" else None
        promissepay_api_key = valores.get("promissepay_api_key") if self.provider_key == "promissepay" else None
        vexopay_client_id = valores.get("vexopay_client_id") if self.provider_key == "vexopay" else None
        vexopay_client_secret = valores.get("vexopay_client_secret") if self.provider_key == "vexopay" else None
        livepix_client_id = valores.get("livepix_client_id") if self.provider_key == "livepix" else None
        livepix_client_secret = valores.get("livepix_client_secret") if self.provider_key == "livepix" else None
        asaas_token = valores.get("asaas_token") if self.provider_key == "asaas" else None
        stripe_token = valores.get("stripe_token") if self.provider_key == "stripe" else None
        coinbase_token = valores.get("coinbase_token") if self.provider_key == "coinbase" else None
        nowpayments_token = valores.get("nowpayments_token") if self.provider_key == "nowpayments" else None
        paypal_client_id = valores.get("paypal_client_id") if self.provider_key == "paypal" else None
        paypal_client_secret = valores.get("paypal_client_secret") if self.provider_key == "paypal" else None
        sync_wallet_api_key = valores.get("sync_wallet_api_key") if self.provider_key == "sync_wallet" else None
        sync_wallet_cover_fee = valores.get("sync_wallet_cover_fee") if self.provider_key == "sync_wallet" else None
        if isinstance(sync_wallet_cover_fee, (list, tuple)):
            sync_wallet_cover_fee = sync_wallet_cover_fee[0] if sync_wallet_cover_fee else None
        pix_manual_key = valores.get("pix_manual_key") if self.provider_key == "pix_manual" else None
        pix_manual_key_type = valores.get("pix_manual_key_type") if self.provider_key == "pix_manual" else None
        if isinstance(pix_manual_key_type, (list, tuple)):
            pix_manual_key_type = pix_manual_key_type[0] if pix_manual_key_type else None
        inter_client_id     = valores.get("inter_client_id")     if self.provider_key == "inter" else None
        inter_client_secret = valores.get("inter_client_secret") if self.provider_key == "inter" else None
        inter_pix_key       = valores.get("inter_pix_key")       if self.provider_key == "inter" else None
        inter_cert_file = None
        inter_key_file  = None
        nubank_email        = valores.get("nubank_email")        if self.provider_key == "nubank" else None
        nubank_app_password = valores.get("nubank_app_password") if self.provider_key == "nubank" else None
        nubank_pix_key      = valores.get("nubank_pix_key")      if self.provider_key == "nubank" else None
        nubank_pix_key_type = valores.get("nubank_pix_key_type") if self.provider_key == "nubank" else None
        if isinstance(nubank_pix_key_type, (list, tuple)):
            nubank_pix_key_type = nubank_pix_key_type[0] if nubank_pix_key_type else None
        configured = False
        error_text = None
        if self.provider_key == "nubank":
            existing = ConfigurarPagamentos._load_config().get("nubank_imap") or {}
            have_email    = bool(nubank_email        or existing.get("email"))
            have_password = bool(nubank_app_password or existing.get("app_password"))
            have_pix      = bool(nubank_pix_key      or existing.get("pix_key"))
            configured = bool(have_email and have_password and have_pix)
            if enabled and not configured:
                enabled = False
                error_text = "Para ativar o Nubank, informe o Email, Senha do App e Chave Pix."

        if self.provider_key == "inter":
            v = valores.get("inter_cert_file")
            if v:
                inter_cert_file = v[0] if isinstance(v, (list, tuple)) else v
            v = valores.get("inter_key_file")
            if v:
                inter_key_file = v[0] if isinstance(v, (list, tuple)) else v
        
        if self.provider_key == "sync_wallet":
            existing = ConfigurarPagamentos._load_config().get("sync_wallet") or {}
            
            # Validar API Key fornecida
            if sync_wallet_api_key:
                # Limpar espaços
                api_key = sync_wallet_api_key.strip()
                
                # Validar formato básico (deve começar com vp_)
                if api_key.startswith("vp_") and len(api_key) > 10:
                    # Tentar validar a API Key fazendo uma requisição
                    try:
                        from functions.payments.sync_wallet import get_sync_user
                        
                        # Testar API Key
                        result = await get_sync_user(api_key)
                        
                        if result and result.get("id"):
                            # API Key válida
                            configured = True
                            existing["api_key"] = api_key
                        else:
                            error_text = "API Key inválida. Verifique e tente novamente."
                            configured = False
                            enabled = False
                    except RuntimeError as e:
                        error_msg = str(e)
                        # Verificar se é erro de IP não autorizado ou similar
                        if "IP" in error_msg.upper() or "não autorizado" in error_msg.lower() or "unauthorized" in error_msg.lower():
                            configured = False
                            enabled = False
                            error_text = (
                                f"{emoji.wrong} **Erro de autenticação**\n"
                                f"**Possíveis causas:**\n"
                                f"1. API Key inválida ou expirada\n"
                                f"2. IP não autorizado nas configurações de segurança\n"
                                f"3. Verifique as configurações de segurança da sua conta Sync Wallet\n"
                                f"Após verificar, tente novamente."
                            )
                        else:
                            error_text = f"Erro ao validar API Key: {error_msg}"
                            configured = False
                            enabled = False
                    except Exception as e:
                        error_text = f"Erro ao validar API Key: {str(e)}"
                        configured = False
                        enabled = False
                else:
                    error_text = "API Key inválida. Deve começar com 'vp_' e ter mais de 10 caracteres."
                    configured = False
                    enabled = False
            else:
                # Verificar se já tem API Key salva
                if existing.get("api_key"):
                    configured = True
                else:
                    configured = False
                    if enabled:
                        error_text = "Para ativar a Sync Wallet, informe sua API Key."
                        enabled = False
        
        if self.provider_key == "promissepay":
            existing = ConfigurarPagamentos._load_config().get("promissepay") or {}

            if promissepay_api_key:
                api_key = promissepay_api_key.strip()
                try:
                    from functions.payments.promissepay import get_promissepay_balance

                    await get_promissepay_balance(api_key)
                    configured = True
                    existing["api_key"] = api_key
                except Exception as e:
                    error_text = f"Erro ao validar a chave de API da PromissePay: {str(e)}"
                    configured = False
                    enabled = False
            else:
                if existing.get("api_key"):
                    configured = True
                else:
                    configured = False
                    if enabled:
                        error_text = "Para ativar a PromissePay, informe sua chave de API."
                        enabled = False

        if self.provider_key == "vexopay":
            existing = ConfigurarPagamentos._load_config().get("vexopay") or {}
            have_client = bool(vexopay_client_id or existing.get("client_id"))
            have_secret = bool(vexopay_client_secret or existing.get("client_secret"))
            configured = bool(have_client and have_secret)

            # Se tem credenciais e está sendo ativado, validar consultando o saldo na API
            if enabled and configured:
                try:
                    from functions.payments.vexopay import get_vexopay_balance

                    client_id = vexopay_client_id or existing.get("client_id")
                    client_secret = vexopay_client_secret or existing.get("client_secret")

                    try:
                        await get_vexopay_balance(client_id, client_secret)
                        configured = True
                    except RuntimeError as e:
                        error_text = f"Erro ao validar as credenciais da VexoPay: {str(e)}"
                        configured = False
                        enabled = False
                    except Exception:
                        # Erro inesperado, não bloquear a ativação
                        configured = True
                except Exception:
                    configured = True

            if enabled and not configured:
                enabled = False
                if not error_text:
                    error_text = "Para ativar a VexoPay, informe o Client ID (ci) e o Client Secret (cs)."

        if self.provider_key == "livepix":
            existing = ConfigurarPagamentos._load_config().get("livepix") or {}
            have_client = bool(livepix_client_id or existing.get("client_id"))
            have_secret = bool(livepix_client_secret or existing.get("client_secret"))
            configured = bool(have_client and have_secret)

            # Se tem credenciais e está sendo ativado, validar obtendo um token OAuth2
            if enabled and configured:
                try:
                    from functions.payments.livepix import _get_access_token

                    client_id = livepix_client_id or existing.get("client_id")
                    client_secret = livepix_client_secret or existing.get("client_secret")

                    try:
                        await _get_access_token(client_id, client_secret)
                        configured = True
                    except RuntimeError as e:
                        error_text = f"Erro ao validar as credenciais da LivePix: {str(e)}"
                        configured = False
                        enabled = False
                    except Exception:
                        configured = True
                except Exception:
                    configured = True

            if enabled and not configured:
                enabled = False
                if not error_text:
                    error_text = "Para ativar a LivePix, informe o Client ID e o Client Secret da sua aplicação."

        if self.provider_key == "mercado_pago":
            if access_token:
                # Validação via API oficial do Mercado Pago
                try:
                    timeout = aiohttp.ClientTimeout(total=10)
                    async with aiohttp.ClientSession(timeout=timeout) as session:
                        headers = {"Authorization": f"Bearer {access_token}"}
                        async with session.get("https://api.mercadopago.com/users/me", headers=headers) as resp:
                            if resp.status == 200:
                                configured = True
                            else:
                                configured = False
                                error_text = "Token do Mercado Pago inválido ou expirado. Não foi possível ativar."
                except Exception:
                    configured = False
                    error_text = "Erro ao validar o token do Mercado Pago. Tente novamente."
            else:
                configured = False
                if enabled:
                    error_text = "Para ativar o Mercado Pago, informe um Access Token válido."
        if self.provider_key == "efibank":
            config = ConfigurarPagamentos._load_config()
            current = config.get(self.provider_key) or {}
            cert_path = current.get("cert_file")
            cert_exists = bool(cert_path) and Path(cert_path).exists()
            
            # Processar arquivo de certificado se fornecido
            if efibank_cert_file:
                try:
                    # Validar que é um arquivo .p12
                    if not efibank_cert_file.filename.lower().endswith(".p12"):
                        error_text = "O arquivo deve ser um certificado .p12"
                        configured = False
                    else:
                        # Salvar o arquivo
                        base_dir = Path(__file__).resolve().parents[3] / "database" / "payments" / "certs" / "efibank"
                        base_dir.mkdir(parents=True, exist_ok=True)
                        save_path = base_dir / f"cert_{inter.author.id}.p12"
                        data = await efibank_cert_file.read()
                        with save_path.open("wb") as fp:
                            fp.write(data)
                        cert_path = str(save_path)
                        cert_exists = True
                except Exception as e:
                    error_text = f"Erro ao processar o certificado: {str(e)}"
                    configured = False
            
            have_client = bool((efibank_client_id or current.get("client_id") or current.get("client")))
            have_secret = bool((efibank_client_secret or current.get("client_secret") or current.get("token")))
            have_pix = bool((efibank_pix_key or current.get("pix_key")))
            configured = bool(have_client and have_secret and have_pix and cert_exists)
            if enabled and not configured:
                enabled = False
                if not error_text:
                    error_text = "Para ativar a Efi, forneça Client ID, Client Secret, Chave Pix e o certificado .p12."

        elif self.provider_key in {"pagbank", "picpay", "pushinpay", "asaas", "stripe", "coinbase", "nowpayments"}:
            existing = ConfigurarPagamentos._load_config().get(self.provider_key) or {}
            token_key = {
                "pagbank": "token_pagbank",
                "picpay": "token_picpay",
                "pushinpay": "token_pushinpay",
                "asaas": "token_asaas",
                "stripe": "token_stripe",
                "coinbase": "token_coinbase",
                "nowpayments": "token_nowpayments",
            }[self.provider_key]
            token_value = {
                "pagbank": pagbank_token,
                "picpay": picpay_token,
                "pushinpay": pushinpay_token,
                "asaas": asaas_token,
                "stripe": stripe_token,
                "coinbase": coinbase_token,
                "nowpayments": nowpayments_token,
            }[self.provider_key]
            configured = bool((token_value is not None and token_value) or existing.get(token_key))
            if enabled and not configured:
                enabled = False
                error_text = "Informe o token para ativar este provedor."

        elif self.provider_key == "paypal":
            existing = ConfigurarPagamentos._load_config().get("paypal") or {}
            have_client = bool(paypal_client_id or existing.get("client_id"))
            have_secret = bool(paypal_client_secret or existing.get("client_secret"))
            configured = bool(have_client and have_secret)
            if enabled and not configured:
                enabled = False
                error_text = "Para ativar o PayPal, informe Client ID e Client Secret."

        elif self.provider_key == "misticpay":
            existing = ConfigurarPagamentos._load_config().get("misticpay") or {}
            have_client = bool(misticpay_client_id or existing.get("client_id"))
            have_secret = bool(misticpay_client_secret or existing.get("client_secret"))
            configured = bool(have_client and have_secret)
            
            # Se tem credenciais e está sendo ativado, validar com a API
            if enabled and configured:
                try:
                    from functions.payments.misticpay import create_misticpay_payment
                    import uuid
                    
                    # Usar credenciais novas ou existentes
                    client_id = misticpay_client_id or existing.get("client_id")
                    client_secret = misticpay_client_secret or existing.get("client_secret")
                    
                    # Tentar criar um pagamento de teste (valor mínimo)
                    try:
                        await create_misticpay_payment(
                            client_id=client_id,
                            client_secret=client_secret,
                            amount=1.0,  # Valor mínimo para teste
                            payer_name="Teste",
                            payer_document="12345678901",
                            description="Teste de configuração",
                            transaction_id=str(uuid.uuid4())
                        )
                        # Se chegou aqui, as credenciais estão válidas
                        configured = True
                    except RuntimeError as e:
                        error_msg = str(e)
                        # Verificar se é erro de IP não autorizado
                        if "IP não autorizado" in error_msg or "não está na lista de permissões" in error_msg or "IP" in error_msg and "permissões" in error_msg:
                            configured = False
                            enabled = False
                            
                            error_text = (
                                f"{emoji.wrong} **IP não autorizado**\n"
                                f"**Para resolver:**\n"
                                f"1. Ative a verificação de 2 fatores na sua conta MisticPay\n"
                                f"2. Libere todos os IPs nas configurações de segurança\n"
                                f"Após configurar, tente novamente."
                            )
                        else:
                            # Outro erro, mas as credenciais podem estar corretas
                            # Não bloquear a ativação, apenas avisar
                            configured = True  # Permitir ativar mesmo com erro (pode ser temporário)
                    except Exception as e:
                        # Erro inesperado, não bloquear
                        configured = True
                except Exception as e:
                    # Erro ao importar ou validar, não bloquear
                    configured = True
            
            if enabled and not configured:
                enabled = False
                if not error_text:
                    error_text = "Para ativar o MisticPay, informe Client ID e Client Secret."

        elif self.provider_key == "pix_manual":
            import re
            existing = ConfigurarPagamentos._load_config().get("pix_manual") or {}
            key = pix_manual_key or existing.get("pix_key")
            key_type_raw = pix_manual_key_type or existing.get("pix_key_type")
            # Normalizar o tipo (TextInput pode vir com espaços ou maiúsculas)
            key_type = key_type_raw.strip().lower() if key_type_raw else key_type_raw
            
            if key and key_type:
                # Validar formato da chave PIX
                key = key.strip()
                is_valid = False
                
                if key_type == "email":
                    is_valid = bool(re.match(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$", key))
                    if not is_valid:
                        error_text = "Email inválido! Formato esperado: usuario@dominio.com"
                elif key_type == "telefone":
                    clean_phone = re.sub(r"[^\d]", "", key)
                    is_valid = len(clean_phone) >= 10 and len(clean_phone) <= 11
                    if not is_valid:
                        error_text = "Telefone inválido! Use formato: (11) 98765-4321 ou 11987654321"
                elif key_type == "cpf":
                    clean_cpf = re.sub(r"[^\d]", "", key)
                    is_valid = len(clean_cpf) == 11
                    if is_valid:
                        # Validar dígitos verificadores do CPF
                        cpf_digits = [int(d) for d in clean_cpf]
                        # Primeiro dígito
                        sum1 = sum(cpf_digits[i] * (10 - i) for i in range(9))
                        digit1 = 0 if (sum1 % 11) < 2 else 11 - (sum1 % 11)
                        # Segundo dígito
                        sum2 = sum(cpf_digits[i] * (11 - i) for i in range(10))
                        digit2 = 0 if (sum2 % 11) < 2 else 11 - (sum2 % 11)
                        is_valid = cpf_digits[9] == digit1 and cpf_digits[10] == digit2
                    if not is_valid:
                        error_text = "CPF inválido! Use 11 dígitos: 123.456.789-00 ou 12345678900"
                elif key_type == "cnpj":
                    clean_cnpj = re.sub(r"[^\d]", "", key)
                    is_valid = len(clean_cnpj) == 14
                    if is_valid:
                        # Validar dígitos verificadores do CNPJ
                        cnpj_digits = [int(d) for d in clean_cnpj]
                        weights1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
                        sum1 = sum(cnpj_digits[i] * weights1[i] for i in range(12))
                        digit1 = 0 if (sum1 % 11) < 2 else 11 - (sum1 % 11)
                        weights2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
                        sum2 = sum(cnpj_digits[i] * weights2[i] for i in range(13))
                        digit2 = 0 if (sum2 % 11) < 2 else 11 - (sum2 % 11)
                        is_valid = cnpj_digits[12] == digit1 and cnpj_digits[13] == digit2
                    if not is_valid:
                        error_text = "CNPJ inválido! Use 14 dígitos: 12.345.678/0001-00 ou 12345678000100"
                elif key_type == "aleatoria":
                    # Chave aleatória: geralmente UUID ou string alfanumérica
                    is_valid = len(key) >= 8 and len(key) <= 50
                    if not is_valid:
                        error_text = "Chave aleatória inválida! Deve ter entre 8 e 50 caracteres"
                
                configured = is_valid
                if enabled and not configured:
                    enabled = False
                    if not error_text:
                        error_text = "Chave PIX inválida para o tipo selecionado."
            else:
                configured = False
                if enabled:
                    enabled = False
                    error_text = "Para ativar o PIX Manual, informe a chave PIX e o tipo."

        if self.provider_key == "nubank":
            existing = ConfigurarPagamentos._load_config().get("nubank_imap") or {}
            have_email    = bool(nubank_email        or existing.get("email"))
            have_password = bool(nubank_app_password or existing.get("app_password"))
            have_pix      = bool(nubank_pix_key      or existing.get("pix_key"))
            configured = bool(have_email and have_password and have_pix)
            if enabled and not configured:
                enabled = False
                error_text = "Para ativar o Nubank, informe o Email, Senha do App e Chave Pix."

        if self.provider_key == "inter":
            existing = ConfigurarPagamentos._load_config().get("inter") or {}
            cert_save_path = existing.get("cert_file")
            key_save_path  = existing.get("key_file")

            if inter_cert_file:
                try:
                    if not inter_cert_file.filename.lower().endswith(".crt"):
                        error_text = "O certificado deve ser um arquivo .crt"
                    else:
                        base_dir = Path(__file__).resolve().parents[3] / "database" / "payments" / "certs" / "inter"
                        base_dir.mkdir(parents=True, exist_ok=True)
                        save_path = base_dir / f"cert_{inter.author.id}.crt"
                        data = await inter_cert_file.read()
                        save_path.write_bytes(data)
                        cert_save_path = str(save_path)
                except Exception as e:
                    error_text = f"Erro ao salvar certificado: {e}"

            if inter_key_file:
                try:
                    if not inter_key_file.filename.lower().endswith(".key"):
                        error_text = "A chave privada deve ser um arquivo .key"
                    else:
                        base_dir = Path(__file__).resolve().parents[3] / "database" / "payments" / "certs" / "inter"
                        base_dir.mkdir(parents=True, exist_ok=True)
                        save_path = base_dir / f"key_{inter.author.id}.key"
                        data = await inter_key_file.read()
                        save_path.write_bytes(data)
                        key_save_path = str(save_path)
                except Exception as e:
                    error_text = f"Erro ao salvar chave privada: {e}"

            have_client = bool(inter_client_id     or existing.get("client_id"))
            have_secret = bool(inter_client_secret or existing.get("client_secret"))
            have_pix    = bool(inter_pix_key       or existing.get("pix_key"))
            have_cert   = bool(cert_save_path) and Path(cert_save_path).exists()
            have_key    = bool(key_save_path)  and Path(key_save_path).exists()
            configured  = bool(have_client and have_secret and have_pix and have_cert and have_key)
            if enabled and not configured:
                enabled = False
                if not error_text:
                    error_text = "Para ativar o Inter, preencha Client ID, Client Secret, Chave Pix e envie os arquivos .crt e .key."

        config = ConfigurarPagamentos._load_config()
        entry = config.get(self.provider_key)
        if not isinstance(entry, dict):
            entry = {}
        old_token = str(entry.get("access_token") or "")
        entry["enabled"] = enabled
        if self.provider_key == "mercado_pago":
            final_token = old_token
            if access_token is not None:
                if access_token == "":
                    # user cleared the token
                    final_token = ""
                elif configured:
                    # new valid token provided
                    final_token = access_token
                else:
                    # invalid/new token provided - keep old one
                    final_token = old_token
            entry["access_token"] = final_token
        elif self.provider_key == "efibank":
            if efibank_client_id is not None:
                entry["client_id"] = efibank_client_id
            if efibank_client_secret is not None:
                entry["client_secret"] = efibank_client_secret
            if efibank_pix_key is not None:
                entry["pix_key"] = efibank_pix_key
            # Salvar caminho do certificado se foi processado
            if cert_path:
                entry["cert_file"] = cert_path
        elif self.provider_key == "sync_wallet":
            # Sync Wallet - salvar API Key e coverFee
            if sync_wallet_api_key:
                entry["api_key"] = sync_wallet_api_key.strip()
            if sync_wallet_cover_fee is not None:
                entry["cover_fee"] = sync_wallet_cover_fee == "true"
        elif self.provider_key == "promissepay":
            # PromissePay - salvar chave de API
            if promissepay_api_key:
                entry["api_key"] = promissepay_api_key.strip()
        elif self.provider_key == "vexopay":
            if vexopay_client_id is not None:
                entry["client_id"] = vexopay_client_id
            if vexopay_client_secret is not None:
                entry["client_secret"] = vexopay_client_secret
        elif self.provider_key == "livepix":
            if livepix_client_id is not None:
                entry["client_id"] = livepix_client_id
            if livepix_client_secret is not None:
                entry["client_secret"] = livepix_client_secret
        elif self.provider_key in {"pagbank", "picpay", "pushinpay", "asaas", "stripe", "coinbase", "nowpayments"}:
            token_key = {
                "pagbank": "token_pagbank",
                "picpay": "token_picpay",
                "pushinpay": "token_pushinpay",
                "asaas": "token_asaas",
                "stripe": "token_stripe",
                "coinbase": "token_coinbase",
                "nowpayments": "token_nowpayments",
            }[self.provider_key]
            new_value = {
                "pagbank": pagbank_token,
                "picpay": picpay_token,
                "pushinpay": pushinpay_token,
                "asaas": asaas_token,
                "stripe": stripe_token,
                "coinbase": coinbase_token,
                "nowpayments": nowpayments_token,
            }[self.provider_key]
            old_value = str(entry.get(token_key) or "")
            final_value = old_value
            if new_value is not None:
                if new_value == "":
                    final_value = ""
                else:
                    final_value = new_value
            entry[token_key] = final_value
        elif self.provider_key == "paypal":
            if paypal_client_id is not None:
                entry["client_id"] = paypal_client_id
            if paypal_client_secret is not None:
                entry["client_secret"] = paypal_client_secret
        elif self.provider_key == "misticpay":
            if misticpay_client_id is not None:
                entry["client_id"] = misticpay_client_id
            if misticpay_client_secret is not None:
                entry["client_secret"] = misticpay_client_secret
        elif self.provider_key == "pix_manual":
            if pix_manual_key is not None:
                entry["pix_key"] = pix_manual_key.strip() if pix_manual_key else ""
            if pix_manual_key_type is not None:
                # Normaliza: trim + lowercase (o campo agora é TextInput)
                normalized = pix_manual_key_type.strip().lower() if pix_manual_key_type else ""
                valid_types = {"email", "telefone", "cpf", "cnpj", "aleatoria"}
                if normalized in valid_types:
                    entry["pix_key_type"] = normalized
                elif normalized:
                    entry["pix_key_type"] = normalized  # salva mesmo assim
            # Modo de pagamento sempre "generate": o bot sempre gera o QR code
            # e a Chave Pix a cada compra, sem a opção de modo estático.
            entry["payment_mode"] = "generate"
        elif self.provider_key == "inter":
            existing = config.get("inter") or {}
            if inter_client_id is not None:
                entry["client_id"] = inter_client_id
            if inter_client_secret is not None:
                entry["client_secret"] = inter_client_secret
            if inter_pix_key is not None:
                entry["pix_key"] = inter_pix_key.strip() if inter_pix_key else ""
            # Preservar ou atualizar caminhos de cert/key
            entry["cert_file"] = cert_save_path or existing.get("cert_file", "")
            entry["key_file"]  = key_save_path  or existing.get("key_file",  "")
        elif self.provider_key == "nubank":
            # Nubank salva em "nubank_imap" no payment_configs
            nubank_entry = config.get("nubank_imap") or {}
            nubank_entry["enabled"] = enabled
            if nubank_email is not None:
                nubank_entry["email"] = nubank_email.strip()
            if nubank_app_password is not None:
                nubank_entry["app_password"] = nubank_app_password.strip()
            if nubank_pix_key is not None:
                nubank_entry["pix_key"] = nubank_pix_key.strip()
            if nubank_pix_key_type is not None:
                nubank_entry["pix_key_type"] = nubank_pix_key_type
            config["nubank_imap"] = nubank_entry
            # Também salvar na key "nubank" para o status do painel
            entry = nubank_entry
        config[self.provider_key] = entry

        # Salvar configurações no database
        db.save_document("payment_configs", config)

        # Atualizar status de habilitado no documento pagamentos
        pagamentos = db.get_document("pagamentos") or {}
        pagamentos[self.provider_key] = enabled
        if self.provider_key == "nubank":
            # O checkout (checkout.py) verifica a chave "nubank_imap", não "nubank".
            # Sem isso, o pagamento fica marcado como "Desabilitado" mesmo ativado no painel.
            pagamentos["nubank_imap"] = enabled
        db.save_document("pagamentos", {}, pagamentos)

        # Invalidar cache de métodos de pagamento para refletir mudanças imediatamente
        try:
            from modules.loja.cart.buy_modal import invalidate_payment_methods_cache
            from modules.loja.cart.checkout import invalidate_checkout_payment_cache
            invalidate_payment_methods_cache()
            invalidate_checkout_payment_cache()
        except Exception as e:
            print(f"[PaymentProviderModal] Falha ao invalidar cache de pagamentos: {e}")

        mode = db.get_document("custom_mode").get("mode")
        try:
            # Editar com o painel atualizado (resposta já foi feita com o loading)
            if mode == "embed":
                embed, components = ConfigurarPagamentos.pagamentos_embed(inter, self.categoria)
                await inter.edit_original_message(content=None, embed=embed, components=components)
            else:
                await inter.edit_original_message(
                    content=None,
                    components=ConfigurarPagamentos.pagamentos_components(inter, self.categoria),
                )
        except Exception as e:
            print(f"[PaymentProviderModal] Falha ao atualizar painel: {e}")
            import traceback
            traceback.print_exc()
            try:
                if not inter.response.is_done():
                    await inter.response.send_message(
                        content=f"{emoji.wrong} Configurações salvas, mas não foi possível atualizar o painel — veja o console do bot.",
                        ephemeral=True,
                    )
                else:
                    await inter.followup.send(
                        content=f"{emoji.wrong} Configurações salvas, mas não foi possível atualizar o painel — veja o console do bot.",
                        ephemeral=True,
                    )
            except Exception:
                pass

        # Feedback ao usuário (ephemeral) se houve problema na validação
        if error_text:
            await message.error(inter, error_text, followup=True)


class LunarWalletSaqueModal(disnake.ui.Modal):
    """Modal para solicitar saque do saldo da Febre Wallet"""

    def __init__(self):
        components = [
            disnake.ui.Label(
                text="Valor a sacar (R$)",
                component=disnake.ui.TextInput(
                    placeholder="Ex: 100.00",
                    custom_id="lunar_wallet_saque_valor",
                    style=disnake.TextInputStyle.short,
                    required=True,
                    max_length=15,
                ),
                description="Valor será debitado do seu saldo (taxa de saque de R$ 1,00 é descontada do envio).",
            ),
            disnake.ui.Label(
                text="Chave PIX de destino",
                component=disnake.ui.TextInput(
                    placeholder="CPF, CNPJ, email, telefone ou chave aleatória",
                    custom_id="lunar_wallet_saque_pix_key",
                    style=disnake.TextInputStyle.short,
                    required=True,
                    max_length=100,
                ),
                description="Chave PIX que vai receber o valor sacado.",
            ),
            disnake.ui.Label(
                text="Tipo da Chave PIX",
                component=disnake.ui.StringSelect(
                    placeholder="Selecione o tipo da chave PIX",
                    custom_id="lunar_wallet_saque_pix_key_type",
                    options=[
                        disnake.SelectOption(label="Aleatória", value="aleatoria", emoji=emoji.link),
                        disnake.SelectOption(label="CPF", value="cpf", emoji=emoji.member),
                        disnake.SelectOption(label="CNPJ", value="cnpj", emoji=emoji.store),
                        disnake.SelectOption(label="Email", value="email", emoji=emoji.mail2),
                        disnake.SelectOption(label="Telefone", value="telefone", emoji=emoji.mobile),
                    ],
                ),
                description="Tipo da chave PIX informada acima.",
            ),
        ]
        super().__init__(title="Sacar da Febre Wallet", custom_id="LunarWalletSaqueModal", components=components)

    async def callback(self, inter: disnake.ModalInteraction):
        import traceback
        try:
            await self._process(inter)
        except Exception:
            print("[LunarWalletSaqueModal] Erro ao processar saque:")
            traceback.print_exc()
            fallback_text = f"{emoji.wrong} Ocorreu um erro ao processar o saque. Verifique o console/logs do bot."
            try:
                if inter.response.is_done():
                    await inter.followup.send(content=fallback_text, ephemeral=True)
                else:
                    await inter.response.send_message(content=fallback_text, ephemeral=True)
            except Exception:
                traceback.print_exc()

    async def _process(self, inter: disnake.ModalInteraction):
        import re as _re
        from functions.payments.lunar_wallet import request_lunar_wallet_withdraw

        valores = inter.resolved_values
        valor_raw = (valores.get("lunar_wallet_saque_valor") or "").strip()
        pix_key = (valores.get("lunar_wallet_saque_pix_key") or "").strip()
        pix_key_type = valores.get("lunar_wallet_saque_pix_key_type")
        if isinstance(pix_key_type, (list, tuple)):
            pix_key_type = pix_key_type[0] if pix_key_type else None

        # Mostrar loading imediatamente editando a mensagem do painel
        loading_component = disnake.ui.TextDisplay(f"{emoji.loading} Processando saque...")
        await inter.response.edit_message(content=None, embed=None, components=loading_component)

        # Validar valor
        valor_normalizado = valor_raw.replace("R$", "").replace(" ", "").replace(".", "").replace(",", ".")
        try:
            valor = float(valor_normalizado)
        except ValueError:
            valor = None

        error_text = None
        result = None

        if not valor or valor <= 0:
            error_text = "Valor inválido. Informe um número válido, ex: 100.00"
        elif not pix_key:
            error_text = "Informe a chave PIX de destino."
        elif not pix_key_type:
            error_text = "Selecione o tipo da chave PIX."
        else:
            key_type_norm = str(pix_key_type).strip().lower()
            is_valid = False
            if key_type_norm == "email":
                is_valid = bool(_re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", pix_key))
            elif key_type_norm == "telefone":
                digits = _re.sub(r"[^\d]", "", pix_key)
                is_valid = len(digits) in (10, 11, 12, 13)
            elif key_type_norm == "cpf":
                digits = _re.sub(r"[^\d]", "", pix_key)
                is_valid = len(digits) == 11
            elif key_type_norm == "cnpj":
                digits = _re.sub(r"[^\d]", "", pix_key)
                is_valid = len(digits) == 14
            elif key_type_norm == "aleatoria":
                is_valid = len(pix_key) >= 8

            if not is_valid:
                error_text = f"Chave PIX inválida para o tipo '{key_type_norm}'."
            else:
                try:
                    result = await request_lunar_wallet_withdraw(
                        amount=valor,
                        pix_key=pix_key,
                        pix_key_type=key_type_norm,
                    )
                except ValueError as e:
                    error_text = str(e)
                except Exception as e:
                    error_text = f"Erro ao processar o saque na LofyPay: {str(e)}"

        # Atualizar o painel da Febre Wallet com o saldo atualizado
        mode = db.get_document("custom_mode").get("mode")
        try:
            if mode == "embed":
                embed, components = ConfigurarPagamentos.lunar_wallet_panel_embed(inter)
                await inter.edit_original_message(content=None, embed=embed, components=components)
            else:
                await inter.edit_original_message(
                    content=None,
                    components=ConfigurarPagamentos.lunar_wallet_panel_components(inter),
                )
        except Exception as e:
            print(f"[LunarWalletSaqueModal] Falha ao atualizar painel: {e}")

        if error_text:
            await message.error(inter, error_text, followup=True)
        elif result:
            await inter.followup.send(
                content=(
                    f"{emoji.correct} Saque solicitado com sucesso!\n"
                    f"* Valor debitado do saldo: `R$ {result['requested_amount']:.2f}`\n"
                    f"* Taxa de saque: `R$ {result['fee']:.2f}`\n"
                    f"* Valor líquido enviado: `R$ {result['net_amount']:.2f}`\n"
                    f"* Chave PIX: `{result['pix_key']}` ({result['pix_key_type'].upper()})\n"
                    f"-# {emoji.receipt if hasattr(emoji, 'receipt') else ''} Use **Extratos** no painel da Febre Wallet para gerar o comprovante desta transação."
                ),
                ephemeral=True,
            )


class LunarWalletTaxaModal(disnake.ui.Modal):
    """Modal para definir quem arca com a taxa de recebimento da Febre Wallet"""

    def __init__(self):
        from functions.payments.lunar_wallet import get_fee_responsibility

        current = get_fee_responsibility()
        components = [
            disnake.ui.Label(
                text="Responsabilidade da Taxa",
                component=disnake.ui.StringSelect(
                    placeholder="Quem paga a taxa de recebimento?",
                    custom_id="lunar_wallet_taxa_responsabilidade",
                    options=[
                        disnake.SelectOption(
                            label="Loja paga (desconta do valor recebido)",
                            value="loja",
                            emoji=emoji.store,
                            default=current == "loja",
                        ),
                        disnake.SelectOption(
                            label="Cliente paga (taxa repassada na cobrança)",
                            value="cliente",
                            emoji=emoji.member,
                            default=current == "cliente",
                        ),
                    ],
                ),
                description="'Loja' = desconta a taxa do saldo. 'Cliente' = taxa repassada na cobrança.",
            ),
        ]
        super().__init__(title="Responsabilidade da Taxa", custom_id="LunarWalletTaxaModal", components=components)

    async def callback(self, inter: disnake.ModalInteraction):
        from functions.payments.lunar_wallet import set_lunar_wallet_fee_responsibility

        valores = inter.resolved_values
        value = valores.get("lunar_wallet_taxa_responsabilidade")
        if isinstance(value, (list, tuple)):
            value = value[0] if value else "loja"
        value = (value or "loja").strip().lower()
        if value not in ("loja", "cliente"):
            value = "loja"

        set_lunar_wallet_fee_responsibility(value)

        mode = db.get_document("custom_mode").get("mode")
        if mode == "embed":
            embed, components = ConfigurarPagamentos.lunar_wallet_panel_embed(inter)
            await inter.response.edit_message(content=None, embed=embed, components=components)
        else:
            await inter.response.edit_message(
                content=None,
                embed=None,
                components=ConfigurarPagamentos.lunar_wallet_panel_components(inter),
            )


def setup(bot: commands.Bot):
    bot.add_cog(ConfigurarPagamentos(bot))