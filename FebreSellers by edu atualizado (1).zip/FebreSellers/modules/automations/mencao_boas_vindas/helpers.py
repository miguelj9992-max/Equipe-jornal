from typing import Optional

import disnake

from functions.database import database as db


def carregar_config() -> dict:
    """Carrega a configuração do banco de dados."""
    dados = db.get_document("automations_mencao_boas_vindas") or {}

    if not isinstance(dados, dict):
        dados = {}

    # Valores padrão
    if "mensagem" not in dados:
        dados["mensagem"] = "{user}"
    if "canal_id" not in dados:
        dados["canal_id"] = None
    if "tempo_segundos" not in dados:
        dados["tempo_segundos"] = 5
    if "ativado" not in dados:
        dados["ativado"] = False

    return dados


def salvar_config(data: dict) -> None:
    """Salva a configuração no banco de dados."""
    atual = carregar_config()
    atual.update(data or {})
    db.save_document("automations_mencao_boas_vindas", {}, atual)


def obter_canal(guild: disnake.Guild) -> Optional[disnake.TextChannel]:
    """Obtém o canal configurado para a menção de boas-vindas."""
    if guild is None:
        return None
    config = carregar_config()
    canal_id = config.get("canal_id")
    try:
        canal_id_int = int(canal_id) if canal_id else None
    except Exception:
        canal_id_int = None
    if not canal_id_int:
        return None
    canal = guild.get_channel(canal_id_int)
    if isinstance(canal, disnake.TextChannel):
        return canal
    return None


def formatar_mensagem(template: str, member: disnake.Member) -> str:
    """Formata a mensagem de menção com as variáveis disponíveis."""
    guild = member.guild
    substituicoes = {
        "{user}": member.mention,
        "{nameserver}": guild.name if guild else "servidor",
        "{nameuser}": getattr(member, "name", str(member.id)),
        "{servercount}": str(getattr(guild, "member_count", "")),
    }
    conteudo = template or "{user}"
    for chave, valor in substituicoes.items():
        conteudo = conteudo.replace(chave, valor)
    return conteudo