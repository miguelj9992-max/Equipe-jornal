import disnake
from disnake.ext import commands

from functions.emoji import emoji
from functions.message import message, embed_message
from functions.database import database as db
from modules.automations.mencao_boas_vindas import helpers


class MencaoBoasVindasConfig(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @staticmethod
    def Painel() -> list[disnake.ui.Container]:
        config = helpers.carregar_config()
        mensagem = config.get("mensagem", "{user}")
        tempo = int(config.get("tempo_segundos", 5) or 0)
        ativado = bool(config.get("ativado", False))
        canal_id = config.get("canal_id")

        instrucoes = (
            "Envie uma menção simples aos novos membros ao entrarem no servidor "
            "e apague-a automaticamente após o tempo selecionado."
        )

        canal_texto = f"<#{canal_id}>" if canal_id else "Não definido"
        tempo_texto = "Nunca apaga" if tempo <= 0 else f"`{tempo}` segundo(s)"

        resumo = (
            f"{emoji.on if ativado else emoji.off} **Status:** `{'Ativado' if ativado else 'Desativado'}`\n"
            f"{emoji.dir} **Canal:** {canal_texto}\n"
            f"{emoji.edit} **Mensagem:** `{mensagem}`\n"
            f"{emoji.clock} **Apagar após:** {tempo_texto}"
        )

        primary_color_hex = db.get_document("custom_colors").get("primary")
        container_kwargs = {}
        if primary_color_hex:
            primary_color = int(primary_color_hex.replace("#", ""), 16)
            container_kwargs["accent_colour"] = disnake.Colour(primary_color)

        return [
            disnake.ui.Container(
                disnake.ui.TextDisplay(f"## \n-# Painel > Automações > **Menção Boas-Vindas**"),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(instrucoes),
                disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                disnake.ui.TextDisplay(resumo),
                disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                disnake.ui.ActionRow(
                    disnake.ui.ChannelSelect(
                        channel_types=[disnake.ChannelType.text],
                        placeholder="Selecione o canal onde a menção será enviada",
                        custom_id="MBV_SelectCanal",
                        min_values=1,
                        max_values=1,
                    )
                ),
                disnake.ui.ActionRow(
                    disnake.ui.Button(label=("Desativar" if ativado else "Ativar"), style=(disnake.ButtonStyle.red if ativado else disnake.ButtonStyle.green), emoji=emoji.power, custom_id="MBV_ToggleAtivo"),
                    disnake.ui.Button(label="Editar Mensagem", style=disnake.ButtonStyle.blurple, emoji=emoji.edit, custom_id="MBV_EditMensagem", disabled=not ativado),
                    disnake.ui.Button(label="Editar Duração", style=disnake.ButtonStyle.green, emoji=emoji.clock, custom_id="MBV_EditTempo", disabled=not ativado),
                ),
                **container_kwargs,
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="VoltarAutomações"),
            ),
        ]

    @staticmethod
    def PainelEmbed() -> tuple[disnake.Embed, list[disnake.ui.ActionRow]]:
        config = helpers.carregar_config()
        mensagem = config.get("mensagem", "{user}")
        tempo = int(config.get("tempo_segundos", 5) or 0)
        ativado = bool(config.get("ativado", False))
        canal_id = config.get("canal_id")

        canal_texto = f"<#{canal_id}>" if canal_id else "Não definido"
        tempo_texto = "Nunca apaga" if tempo <= 0 else f"`{tempo}` segundo(s)"

        resumo = (
            f"{emoji.on if ativado else emoji.off} **Status:** `{'Ativado' if ativado else 'Desativado'}`\n"
            f"{emoji.dir} **Canal:** {canal_texto}\n"
            f"{emoji.clock} **Apagar após:** {tempo_texto}"
        )

        primary_color_hex = db.get_document("custom_colors").get("primary")
        embed = disnake.Embed(
            title="Menção Boas-Vindas",
            description="Envie uma menção simples aos novos membros e apague-a automaticamente após o tempo selecionado."
        )
        if primary_color_hex:
            embed.color = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))

        embed.add_field(name="Configurações", value=resumo, inline=False)
        embed.add_field(name="Mensagem Atual", value=f"`{mensagem}`", inline=False)

        components = [
            disnake.ui.ActionRow(
                disnake.ui.ChannelSelect(
                    channel_types=[disnake.ChannelType.text],
                    placeholder="Selecione o canal onde a menção será enviada",
                    custom_id="MBV_SelectCanal",
                    min_values=1,
                    max_values=1,
                )
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label=("Desativar" if ativado else "Ativar"), style=(disnake.ButtonStyle.red if ativado else disnake.ButtonStyle.green), emoji=emoji.power, custom_id="MBV_ToggleAtivo"),
                disnake.ui.Button(label="Editar Mensagem", style=disnake.ButtonStyle.blurple, emoji=emoji.edit, custom_id="MBV_EditMensagem", disabled=not ativado),
                disnake.ui.Button(label="Editar Duração", style=disnake.ButtonStyle.green, emoji=emoji.clock, custom_id="MBV_EditTempo", disabled=not ativado),
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="VoltarAutomações"),
            ),
        ]
        return embed, components

    @commands.Cog.listener("on_button_click")
    async def MencaoBoasVindas_Button_Listener(self, inter: disnake.MessageInteraction):
        cid = inter.component.custom_id
        if not cid or not cid.startswith("MBV_"):
            return

        if cid == "MBV_EditMensagem":
            cfg = helpers.carregar_config()
            await inter.response.send_modal(EditarMensagemMBVModal(valor_atual=str(cfg.get("mensagem", "{user}"))))
        elif cid == "MBV_EditTempo":
            cfg = helpers.carregar_config()
            await inter.response.send_modal(EditarTempoMBVModal(valor_atual=int(cfg.get("tempo_segundos", 5) or 0)))
        elif cid == "MBV_ToggleAtivo":
            cfg = helpers.carregar_config()
            novo = not bool(cfg.get("ativado", False))
            helpers.salvar_config({"ativado": novo})
            await self._update_panel(inter)

    async def _update_panel(self, inter: disnake.Interaction):
        if not inter.response.is_done():
            await inter.response.defer(with_message=False)

        mode = db.get_document("custom_mode").get("mode")
        if mode == "embed":
            await embed_message.wait(inter, send=False)
            embed, components = self.PainelEmbed()
            await inter.edit_original_message(content=None, embed=embed, components=components)
        else:
            await message.wait(inter, send=False)
            components = self.Painel()
            await inter.edit_original_message(content=None, components=components)

    @commands.Cog.listener("on_dropdown")
    async def MencaoBoasVindas_Dropdown_Listener(self, inter: disnake.MessageInteraction):
        cid = inter.data.custom_id
        if cid != "MBV_SelectCanal":
            return

        valores = list(inter.values or [])
        if valores:
            # Selecionar um canal já ativa a automação automaticamente
            helpers.salvar_config({"canal_id": str(valores[0]), "ativado": True})

        await self._update_panel(inter)


class EditarMensagemMBVModal(disnake.ui.Modal):
    def __init__(self, valor_atual: str = "{user}"):
        components = [
            disnake.ui.TextInput(
                label="Mensagem da menção (Obrigatório)",
                placeholder="Use {user}, {nameserver}, {nameuser}, {servercount}",
                value=str(valor_atual or "{user}")[:4000],
                custom_id="mensagem",
                style=disnake.TextInputStyle.paragraph,
                required=True,
            )
        ]
        super().__init__(title="Editar Mensagem da Menção", custom_id="MBV_EditarMensagem_Modal", components=components)

    async def callback(self, inter: disnake.ModalInteraction):
        texto = inter.text_values.get("mensagem", "{user}").strip() or "{user}"
        helpers.salvar_config({"mensagem": texto})
        cog = inter.bot.get_cog("MencaoBoasVindasConfig")
        if cog:
            await cog._update_panel(inter)


class EditarTempoMBVModal(disnake.ui.Modal):
    def __init__(self, valor_atual: int = 5):
        components = [
            disnake.ui.TextInput(
                label="Tempo em segundos (0 = não apagar)",
                placeholder="Ex: 0, 3, 5, 10, 30",
                value=str(int(valor_atual or 0)),
                custom_id="tempo",
                style=disnake.TextInputStyle.short,
                required=True,
            )
        ]
        super().__init__(title="Editar Duração da Menção", custom_id="MBV_EditarTempo_Modal", components=components)

    async def callback(self, inter: disnake.ModalInteraction):
        texto = inter.text_values.get("tempo", "5").strip()
        try:
            valor = int(texto)
            if valor < 0:
                valor = 0
            helpers.salvar_config({"tempo_segundos": valor})
            cog = inter.bot.get_cog("MencaoBoasVindasConfig")
            if cog:
                await cog._update_panel(inter)
        except Exception:
            try:
                await inter.response.send_message("Valor inválido para tempo.", ephemeral=True)
            except Exception:
                pass


def setup(bot: commands.Bot):
    bot.add_cog(MencaoBoasVindasConfig(bot))