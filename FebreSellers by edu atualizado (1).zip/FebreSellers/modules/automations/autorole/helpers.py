from functions.database import database as db


def carregar_config():
    dados = db.get_document("automations_autorole") or {}

    if not isinstance(dados, dict):
        dados = {}

    if "ativado" not in dados:
        dados["ativado"] = False

    if "cargos" not in dados:
        dados["cargos"] = []

    return dados


def salvar_config(data: dict):
    atual = carregar_config()

    atual.update(data or {})

    db.save_document(
        "automations_autorole",
        {},
        atual
    )