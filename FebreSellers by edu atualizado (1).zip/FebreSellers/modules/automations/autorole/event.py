import disnake
from disnake.ext import commands

from . import helpers


class AutoroleEvent(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(
        self,
        member: disnake.Member
    ):
        cfg = helpers.carregar_config()

        if not cfg.get("ativado", False):
            return

        cargos_ids = cfg.get("cargos", [])

        if not cargos_ids:
            return

        for cargo_id in cargos_ids:
            try:
                cargo = member.guild.get_role(
                    int(cargo_id)
                )

                if cargo:
                    await member.add_roles(
                        cargo,
                        reason="Autorole"
                    )

            except Exception:
                pass


def setup(bot):
    bot.add_cog(AutoroleEvent(bot))