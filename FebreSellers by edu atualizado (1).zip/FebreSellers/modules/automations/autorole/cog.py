import disnake
from disnake.ext import commands

from functions.database import database as db
from functions.emoji import emoji
from functions.message import message, embed_message

from . import helpers


class AutoroleConfig(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @staticmethod
    def Painel():
        cfg = helpers.carregar_config()

        ativado = cfg.get(
            "ativado",
            False
        )

        cargos = cfg.get(
            "cargos",
            []
        )

        texto_cargos = (
            "\n".join(
                [f"<@&{c}>" for c in cargos]
            )
            if cargos else
            "Nenhum cargo configurado."
        )

        primary_color_hex = db.get_document("custom_colors").get("primary")
        container_kwargs = {}
        if primary_color_hex:
            primary_color = int(primary_color_hex.replace("#", ""), 16)
            container_kwargs["accent_colour"] = disnake.Colour(primary_color)

        return [
            disnake.ui.Container(
                disnake.ui.TextDisplay(
                    f"## \n-# Painel > Automações > **Autorole**"
                ),

                disnake.ui.Separator(),

                disnake.ui.TextDisplay(
                    f"{emoji.on if ativado else emoji.off} "
                    f"**Status:** "
                    f"`{'Ativado' if ativado else 'Desativado'}`\n\n"
                    f"**Cargos:**\n"
                    f"{texto_cargos}"
                ),

                disnake.ui.Separator(),

                disnake.ui.ActionRow(
                    disnake.ui.Button(
                        label="Ativar/Desativar",
                        custom_id="AR_TOGGLE",
                        style=disnake.ButtonStyle.grey
                    ),

                    disnake.ui.Button(
                        label="Configurar Cargos",
                        emoji=emoji.member,
                        custom_id="AR_CONFIG",
                        style=disnake.ButtonStyle.blurple
                    )
                ),

                **container_kwargs,
            ),

            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Voltar",
                    custom_id="VoltarAutomações",
                    style=disnake.ButtonStyle.grey,
                    emoji=emoji.back
                )
            )
        ]

    @staticmethod
    def PainelEmbed():
        cfg = helpers.carregar_config()

        ativado = cfg.get(
            "ativado",
            False
        )

        cargos = cfg.get(
            "cargos",
            []
        )

        texto_cargos = (
            "\n".join(
                [f"<@&{c}>" for c in cargos]
            )
            if cargos else
            "Nenhum cargo configurado."
        )

        embed = disnake.Embed(
            title="Autorole",
            description=(
                f"Status: "
                f"{'Ativado' if ativado else 'Desativado'}\n\n"
                f"Cargos:\n{texto_cargos}"
            )
        )

        primary_color_hex = db.get_document("custom_colors").get("primary")
        if primary_color_hex:
            embed.color = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))

        components = [
            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Ativar/Desativar",
                    custom_id="AR_TOGGLE",
                    style=disnake.ButtonStyle.grey
                ),

                disnake.ui.Button(
                    label="Configurar Cargos",
                    emoji=emoji.member,
                    custom_id="AR_CONFIG",
                    style=disnake.ButtonStyle.blurple
                )
            ),

            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Voltar",
                    custom_id="VoltarAutomações",
                    style=disnake.ButtonStyle.grey,
                    emoji=emoji.back
                )
            )
        ]

        return embed, components

    @commands.Cog.listener("on_button_click")
    async def buttons(
        self,
        inter: disnake.MessageInteraction
    ):
        cid = inter.component.custom_id

        if cid == "AR_TOGGLE":
            cfg = helpers.carregar_config()

            novo = not cfg.get(
                "ativado",
                False
            )

            helpers.salvar_config({
                "ativado": novo
            })

            await self._update_panel(inter)

        elif cid == "AR_CONFIG":
            await inter.response.send_modal(
                AutoroleModal()
            )

    async def _update_panel(self, inter: disnake.Interaction):
        if not inter.response.is_done():
            await inter.response.defer(with_message=False)

        mode = db.get_document("custom_mode").get("mode")

        if mode == "embed":
            await embed_message.wait(inter, send=False)
            embed, components = self.PainelEmbed()
            await inter.edit_original_message(content=None, embed=embed, components=components)
        else:
            await message.wait(inter, send=False)
            await inter.edit_original_message(content=None, components=self.Painel())


class AutoroleModal(disnake.ui.Modal):
    def __init__(self):
        cfg = helpers.carregar_config()

        cargos = ",".join(
            map(
                str,
                cfg.get("cargos", [])
            )
        )

        components = [
            disnake.ui.TextInput(
                label="IDs dos cargos",
                placeholder="123,456,789",
                custom_id="cargos",
                style=disnake.TextInputStyle.paragraph,
                value=cargos,
                required=False
            )
        ]

        super().__init__(
            title="Configurar Autorole",
            custom_id="AR_MODAL",
            components=components
        )

    async def callback(
        self,
        inter: disnake.ModalInteraction
    ):
        texto = inter.text_values.get(
            "cargos",
            ""
        )

        cargos = [
            x.strip()
            for x in texto.split(",")
            if x.strip().isdigit()
        ]

        helpers.salvar_config({
            "cargos": cargos
        })

        cog = inter.bot.get_cog(
            "AutoroleConfig"
        )

        if cog:
            await cog._update_panel(inter)


def setup(bot):
    bot.add_cog(
        AutoroleConfig(bot)
    )