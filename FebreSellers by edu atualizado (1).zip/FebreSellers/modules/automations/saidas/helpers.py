import io
from typing import Optional

import aiohttp
import disnake

from functions.database import database as db


def carregar_config() -> dict:
    """Carrega a configuração do banco de dados."""

    dados = db.get_document("automations_saidas") or {}

    if not isinstance(dados, dict):
        dados = {}

    # Valores padrão
    if "mensagem" not in dados:
        dados["mensagem"] = "{user} saiu do {nameserver}. Agora somos {servercount}."

    if "tempo_segundos" not in dados:
        dados["tempo_segundos"] = 0

    if "usar_componentes_v2" not in dados:
        dados["usar_componentes_v2"] = False

    if "ativado" not in dados:
        dados["ativado"] = True

    if "modo_envio" not in dados:
        dados["modo_envio"] = (
            "v2"
            if bool(dados.get("usar_componentes_v2", False))
            else "v1"
        )

    if "rota_envio" not in dados:
        dados["rota_envio"] = "canal"

    return dados


def salvar_config(data: dict) -> None:
    """Salva a configuração no banco de dados."""

    atual = carregar_config()

    atual.update(data or {})

    db.save_document(
        "automations_saidas",
        {},
        atual
    )


def obter_canal_id_saidas() -> Optional[str]:
    """Obtém o ID (string) do canal de saídas configurado, sem depender do guild."""

    definicoes = db.get_document("canais") or {}
    canal_id = definicoes.get("canal_de_saidas")
    return str(canal_id) if canal_id else None


def definir_canal_saidas(canal_id) -> None:
    """Define/atualiza o canal de saídas. Usa a mesma chave lida em Painel > Configurações > Canais,
    então o canal pode ser trocado tanto por lá quanto por Painel > Automações > Saídas."""

    definicoes = db.get_document("canais") or {}
    if not isinstance(definicoes, dict):
        definicoes = {}
    definicoes["canal_de_saidas"] = str(canal_id) if canal_id else None
    db.save_document("canais", {}, definicoes)


def obter_canal_saidas(
    guild: disnake.Guild
) -> Optional[disnake.TextChannel]:
    """Obtém o canal de saídas configurado."""

    canal_id = obter_canal_id_saidas()

    try:
        canal_id_int = int(canal_id) if canal_id else None
    except Exception:
        canal_id_int = None

    if not canal_id_int:
        return None

    canal = guild.get_channel(canal_id_int)

    if isinstance(canal, disnake.TextChannel):
        return canal

    return None


def formatar_mensagem(
    template: str,
    member: disnake.Member
) -> str:
    """Formata a mensagem de saída."""

    guild = member.guild

    substituicoes = {
        "{user}": member.mention,
        "{nameserver}": guild.name if guild else "servidor",
        "{nameuser}": getattr(member, "name", str(member.id)),
        "{servercount}": str(getattr(guild, "member_count", "")),
    }

    conteudo = template or ""

    for chave, valor in substituicoes.items():
        conteudo = conteudo.replace(chave, valor)

    return conteudo


def parse_hex_to_colour(
    value: Optional[str]
) -> Optional[disnake.Colour]:
    """Converte HEX para disnake.Colour."""

    if not value:
        return None

    try:
        s = str(value).strip().lower()

        if s.startswith("0x"):
            s = s[2:]

        if s.startswith("#"):
            s = s[1:]

        if len(s) != 6:
            return None

        int_val = int(s, 16)

        return disnake.Colour(int_val)

    except Exception:
        return None


def system_badge_row() -> disnake.ui.ActionRow:
    """Badge de sistema."""

    return disnake.ui.ActionRow(
        disnake.ui.Button(
            label="Mensagem do Sistema",
            style=disnake.ButtonStyle.grey,
            custom_id="SD_SystemBadge",
            disabled=True
        )
    )


def montar_embed_preview(
    conteudo: str,
    cfg: dict
) -> disnake.Embed:
    """Monta embed de prévia."""

    embed = disnake.Embed(
        description=conteudo
    )

    titulo = (
        cfg.get("embed_titulo") or ""
    ).strip()

    if titulo:
        embed.title = titulo

    banner = (
        cfg.get("embed_banner_url") or ""
    ).strip()

    if banner.startswith("http://") or banner.startswith("https://"):
        try:
            embed.set_image(banner)
        except Exception:
            pass

    thumb = (
        cfg.get("embed_thumb_url") or ""
    ).strip()

    if thumb.startswith("http://") or thumb.startswith("https://"):
        try:
            embed.set_thumbnail(thumb)
        except Exception:
            pass

    cor_hex = (
        cfg.get("embed_cor") or ""
    ).strip().lstrip("#")

    if cor_hex:
        try:
            embed.colour = int(cor_hex, 16)
        except Exception:
            pass

    else:
        try:
            colors = db.get_document("custom_colors") or {}

            primary_hex = (
                colors.get("primary") or ""
            ).strip().lstrip("#")

            if primary_hex:
                embed.colour = int(primary_hex, 16)

        except Exception:
            pass

    return embed


def montar_container_preview(
    conteudo: str,
    cfg: dict
) -> disnake.ui.Container:
    """Monta container V2."""

    children = [
        disnake.ui.TextDisplay(conteudo)
    ]

    url = (
        cfg.get("v2_imagem_url") or ""
    ).strip()

    if url.startswith("http://") or url.startswith("https://"):
        try:
            children.append(
                disnake.ui.Separator(
                    spacing=disnake.SeparatorSpacing.small
                )
            )

            children.append(
                disnake.ui.MediaGallery(
                    disnake.MediaGalleryItem(
                        url,
                        description="",
                        spoiler=False
                    )
                )
            )

        except Exception:
            pass

    cor_container = parse_hex_to_colour(
        cfg.get("v2_cor_container")
    )

    if not cor_container:
        try:
            colors = db.get_document("custom_colors") or {}

            primary_hex = colors.get("primary")

        except Exception:
            primary_hex = None

        cor_container = parse_hex_to_colour(
            primary_hex
        )

    if cor_container:
        return disnake.ui.Container(
            *children,
            accent_colour=cor_container
        )

    return disnake.ui.Container(*children)


async def baixar_imagem(
    url: Optional[str]
) -> Optional[disnake.File]:
    """Baixa uma imagem de uma URL e a retorna como disnake.File.

    Usa um User-Agent de navegador porque diversos serviços de hospedagem de imagem
    (Imgur, CDNs, etc.) bloqueiam/retornam erro para requisições feitas por bots sem
    esse cabeçalho, fazendo o download falhar silenciosamente e a imagem não ser enviada.
    """

    url = (url or "").strip()

    if not (
        url.startswith("http://")
        or url.startswith("https://")
    ):
        return None

    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        ),
        "Accept": "image/*,*/*;q=0.8",
    }

    try:
        timeout = aiohttp.ClientTimeout(total=10)
        async with aiohttp.ClientSession(timeout=timeout, headers=headers) as session:
            async with session.get(url, allow_redirects=True) as resp:

                if resp.status != 200:
                    return None

                content_type = (resp.headers.get("Content-Type") or "").lower()
                if content_type and not content_type.startswith("image/"):
                    return None

                bytes_data = await resp.read()
                if not bytes_data:
                    return None

                extensao = "png"
                if "jpeg" in content_type or "jpg" in content_type:
                    extensao = "jpg"
                elif "gif" in content_type:
                    extensao = "gif"
                elif "webp" in content_type:
                    extensao = "webp"

                return disnake.File(
                    io.BytesIO(bytes_data),
                    filename=f"saidas.{extensao}"
                )

    except Exception:
        return None