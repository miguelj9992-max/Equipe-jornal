import disnake
from disnake.ext import commands

from functions.emoji import emoji
from functions.message import message, embed_message
from functions.database import database as db
from modules.automations.saidas import helpers


class SaidasConfig(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @staticmethod
    def Painel() -> list[disnake.ui.Container]:
        config = helpers.carregar_config()

        mensagem = config.get("mensagem", "")
        tempo = int(config.get("tempo_segundos", 0) or 0)
        modo = str(config.get("modo_envio", "v1"))
        ativado = bool(config.get("ativado", True))
        rota = str(config.get("rota_envio", "canal"))

        instrucoes = (
            "Configure as mensagens e opções de saída do servidor."
        )

        modo_label = (
            "Content"
            if modo == "v1"
            else ("Componentes V2" if modo == "v2" else "Embed")
        )

        canal_id = helpers.obter_canal_id_saidas()
        canal_label = f"<#{canal_id}>" if canal_id else "Não definido"

        resumo = (
            f"{emoji.on if ativado else emoji.off} "
            f"**Status:** `{'Ativado' if ativado else 'Desativado'}`\n"
            f"{emoji.edit} **Mensagem atual:**\n"
            f"`{(mensagem[:350] + '...') if len(mensagem) > 350 else mensagem or 'vazia'}`\n\n"
            f"{emoji.clock} **Duração:** `{tempo}` segundos\n"
            f"{emoji.reload} **Modo de envio:** `{modo_label}`\n"
            f"{emoji.route} **Caminho:** "
            f"`{'Canal de saídas' if rota == 'canal' else ('Canal de saídas e DM' if rota == 'canal_dm' else 'DM')}`\n"
            f"{emoji.dir} **Canal:** {canal_label}"
        )

        preview_disponivel = bool(mensagem and mensagem.strip())

        primary_color_hex = db.get_document("custom_colors").get("primary")

        container_kwargs = {}

        if primary_color_hex:
            primary_color = int(primary_color_hex.replace("#", ""), 16)
            container_kwargs["accent_colour"] = disnake.Colour(primary_color)

        return [
            disnake.ui.Container(
                disnake.ui.TextDisplay(
                    f"## \n"
                    f"-# Painel > Automações > **Saídas**"
                ),

                disnake.ui.Separator(),

                disnake.ui.TextDisplay(instrucoes),

                disnake.ui.Separator(
                    spacing=disnake.SeparatorSpacing.small
                ),

                disnake.ui.TextDisplay(resumo),

                disnake.ui.Separator(
                    spacing=disnake.SeparatorSpacing.small
                ),

                disnake.ui.ActionRow(
                    disnake.ui.Button(
                        label="",
                        style=disnake.ButtonStyle.grey,
                        emoji=emoji.power,
                        custom_id="SD_ToggleAtivo"
                    ),

                    disnake.ui.Button(
                        label="Editar Mensagem",
                        style=disnake.ButtonStyle.blurple,
                        emoji=emoji.edit,
                        custom_id="SD_EditMensagem",
                        disabled=not ativado
                    ),

                    disnake.ui.Button(
                        label="Editar Duração",
                        style=disnake.ButtonStyle.green,
                        emoji=emoji.clock,
                        custom_id="SD_EditTempo",
                        disabled=not ativado
                    ),
                ),

                disnake.ui.ActionRow(
                    disnake.ui.Button(
                        label="Prévia",
                        style=disnake.ButtonStyle.grey,
                        emoji=emoji.search,
                        custom_id="SD_Preview",
                        disabled=not preview_disponivel or not ativado
                    ),

                    disnake.ui.Button(
                        label="Trocar Estilo",
                        style=disnake.ButtonStyle.grey,
                        emoji=emoji.reload,
                        custom_id="SD_AbrirModo",
                        disabled=not ativado
                    ),

                    disnake.ui.Button(
                        label="Mudar Caminho",
                        style=disnake.ButtonStyle.grey,
                        emoji=emoji.route,
                        custom_id="SD_AbrirRota",
                        disabled=not ativado
                    ),

                    disnake.ui.Button(
                        label="Selecionar Canal",
                        style=disnake.ButtonStyle.grey,
                        emoji=emoji.dir,
                        custom_id="SD_AbrirCanal",
                        disabled=not ativado
                    ),
                ),

                **container_kwargs,
            ),

            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Voltar",
                    style=disnake.ButtonStyle.grey,
                    emoji=emoji.back,
                    custom_id="VoltarAutomações",
                ),
            ),
        ]

    @staticmethod
    def PainelEmbed() -> tuple[disnake.Embed, list[disnake.ui.ActionRow]]:
        config = helpers.carregar_config()

        mensagem = config.get("mensagem", "")
        tempo = int(config.get("tempo_segundos", 0) or 0)
        modo = str(config.get("modo_envio", "v1"))
        ativado = bool(config.get("ativado", True))
        rota = str(config.get("rota_envio", "canal"))

        modo_label = (
            "Content"
            if modo == "v1"
            else ("Componentes V2" if modo == "v2" else "Embed")
        )

        canal_id = helpers.obter_canal_id_saidas()
        canal_label = f"<#{canal_id}>" if canal_id else "Não definido"

        resumo = (
            f"{emoji.on if ativado else emoji.off} "
            f"**Status:** `{'Ativado' if ativado else 'Desativado'}`\n"
            f"{emoji.clock} **Duração:** `{tempo}` segundos\n"
            f"{emoji.reload} **Modo de envio:** `{modo_label}`\n"
            f"{emoji.route} **Caminho:** "
            f"`{'Canal de saídas' if rota == 'canal' else ('Canal de saídas e DM' if rota == 'canal_dm' else 'DM')}`\n"
            f"{emoji.dir} **Canal:** {canal_label}"
        )

        mensagem_resumo = (
            (mensagem[:350] + "...")
            if len(mensagem) > 350
            else (mensagem or "vazia")
        )

        preview_disponivel = bool(mensagem and mensagem.strip())

        primary_color_hex = db.get_document("custom_colors").get("primary")

        embed = disnake.Embed(
            title="Saídas",
            description="Configure as mensagens e opções de saída do servidor."
        )

        if primary_color_hex:
            embed.color = disnake.Colour(
                int(primary_color_hex.replace("#", ""), 16)
            )

        embed.add_field(
            name="Configurações",
            value=resumo,
            inline=False
        )

        embed.add_field(
            name="Mensagem Atual",
            value=f"`{mensagem_resumo}`",
            inline=False
        )

        components = [
            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="",
                    style=disnake.ButtonStyle.grey,
                    emoji=emoji.power,
                    custom_id="SD_ToggleAtivo"
                ),

                disnake.ui.Button(
                    label="Editar Mensagem",
                    style=disnake.ButtonStyle.blurple,
                    emoji=emoji.edit,
                    custom_id="SD_EditMensagem",
                    disabled=not ativado
                ),

                disnake.ui.Button(
                    label="Editar Duração",
                    style=disnake.ButtonStyle.green,
                    emoji=emoji.clock,
                    custom_id="SD_EditTempo",
                    disabled=not ativado
                ),
            ),

            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Prévia",
                    style=disnake.ButtonStyle.grey,
                    emoji=emoji.search,
                    custom_id="SD_Preview",
                    disabled=not preview_disponivel or not ativado
                ),

                disnake.ui.Button(
                    label="Trocar Estilo",
                    style=disnake.ButtonStyle.grey,
                    emoji=emoji.reload,
                    custom_id="SD_AbrirModo",
                    disabled=not ativado
                ),

                disnake.ui.Button(
                    label="Mudar Caminho",
                    style=disnake.ButtonStyle.grey,
                    emoji=emoji.route,
                    custom_id="SD_AbrirRota",
                    disabled=not ativado
                ),

                disnake.ui.Button(
                    label="Selecionar Canal",
                    style=disnake.ButtonStyle.grey,
                    emoji=emoji.dir,
                    custom_id="SD_AbrirCanal",
                    disabled=not ativado
                ),
            ),

            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Voltar",
                    style=disnake.ButtonStyle.grey,
                    emoji=emoji.back,
                    custom_id="VoltarAutomações"
                ),
            ),
        ]

        return embed, components

    @staticmethod
    def PainelSelecionarCanal() -> list[disnake.ui.Container]:
        primary_color_hex = db.get_document("custom_colors").get("primary")
        container_kwargs = {}
        if primary_color_hex:
            primary_color = int(primary_color_hex.replace("#", ""), 16)
            container_kwargs["accent_colour"] = disnake.Colour(primary_color)
        canal_id = helpers.obter_canal_id_saidas()
        canal_label = f"<#{canal_id}>" if canal_id else "Não definido"
        return [
            disnake.ui.Container(
                disnake.ui.TextDisplay(f"## \n-# Automações > Saídas > **Selecionar Canal**"),
                disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                disnake.ui.TextDisplay(f"Selecione abaixo o canal onde as mensagens de saída serão enviadas.\n\n**Canal atual:** {canal_label}"),
                disnake.ui.ActionRow(
                    disnake.ui.ChannelSelect(
                        channel_types=[disnake.ChannelType.text],
                        placeholder="Selecione o canal de saídas",
                        custom_id="SD_SelectCanal",
                        min_values=1,
                        max_values=1,
                    )
                ),
                **container_kwargs,
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="SD_VoltarPainelSD"),
            ),
        ]

    @staticmethod
    def PainelSelecionarCanalEmbed() -> tuple[disnake.Embed, list[disnake.ui.ActionRow]]:
        canal_id = helpers.obter_canal_id_saidas()
        canal_label = f"<#{canal_id}>" if canal_id else "Não definido"

        primary_color_hex = db.get_document("custom_colors").get("primary")
        embed = disnake.Embed(
            title="Selecionar Canal",
            description="Escolha o canal onde as mensagens de saída serão enviadas."
        )
        if primary_color_hex:
            embed.color = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))
        embed.add_field(name="Canal atual", value=canal_label, inline=False)

        components = [
            disnake.ui.ActionRow(
                disnake.ui.ChannelSelect(
                    channel_types=[disnake.ChannelType.text],
                    placeholder="Selecione o canal de saídas",
                    custom_id="SD_SelectCanal",
                    min_values=1,
                    max_values=1,
                )
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="SD_VoltarPainelSD"),
            ),
        ]
        return embed, components

    @commands.Cog.listener("on_button_click")
    async def Saidas_Button_Listener(
        self,
        inter: disnake.MessageInteraction
    ):
        cid = inter.component.custom_id

        if not cid or not cid.startswith("SD_"):
            return

        if cid == "SD_EditMensagem":
            cfg = helpers.carregar_config()

            await inter.response.send_modal(
                EditarMensagemSDModal(
                    str(cfg.get("modo_envio", "v1"))
                )
            )

        elif cid == "SD_EditTempo":
            cfg = helpers.carregar_config()

            await inter.response.send_modal(
                EditarTempoSDModal(
                    valor_atual=int(
                        cfg.get("tempo_segundos", 0) or 0
                    )
                )
            )

        elif cid == "SD_Preview":
            await self._handle_preview(inter)

        elif cid == "SD_ToggleAtivo":
            cfg = helpers.carregar_config()

            novo = not bool(cfg.get("ativado", True))

            helpers.salvar_config({
                "ativado": novo
            })

            await self._update_panel(inter)

        elif cid in (
            "SD_AbrirRota",
            "SD_AbrirModo",
            "SD_AbrirCanal",
            "SD_VoltarPainelSD"
        ):
            await self._update_panel(inter)

    async def _handle_preview(
        self,
        inter: disnake.MessageInteraction
    ):
        cfg = helpers.carregar_config()

        mensagem = cfg.get("mensagem", "")

        if not mensagem or not mensagem.strip():
            await inter.response.send_message(
                "Configure a mensagem antes de visualizar a prévia.",
                ephemeral=True
            )
            return

        membro_preview = (
            inter.author
            if isinstance(inter.author, disnake.Member)
            else inter.guild.me
        )

        conteudo = helpers.formatar_mensagem(
            mensagem,
            membro_preview
        )

        modo = str(cfg.get("modo_envio", "v1"))

        try:
            if modo == "v2":
                await inter.response.send_message(
                    components=[
                        helpers.montar_container_preview(
                            conteudo,
                            cfg
                        ),
                        helpers.system_badge_row()
                    ],
                    flags=disnake.MessageFlags(
                        is_components_v2=True
                    ),
                    ephemeral=True
                )

            elif modo == "embed":
                embed = helpers.montar_embed_preview(
                    conteudo,
                    cfg
                )

                await inter.response.send_message(
                    embed=embed,
                    components=[
                        helpers.system_badge_row()
                    ],
                    ephemeral=True
                )

            else:
                kwargs = {
                    "content": conteudo,
                    "components": [
                        helpers.system_badge_row()
                    ]
                }

                file = await helpers.baixar_imagem(
                    cfg.get("v1_imagem_url")
                )

                if file:
                    kwargs["file"] = file

                await inter.response.send_message(
                    **kwargs,
                    ephemeral=True
                )

        except Exception:
            pass

    async def _update_panel(
        self,
        inter: disnake.Interaction
    ):
        if not inter.response.is_done():
            await inter.response.defer(
                with_message=False
            )

        mode = db.get_document(
            "custom_mode"
        ).get("mode")

        if mode == "embed":
            await embed_message.wait(
                inter,
                send=False
            )
        else:
            await message.wait(
                inter,
                send=False
            )

        cid = ""
        if isinstance(inter, disnake.MessageInteraction):
            cid = inter.component.custom_id

        if mode == "embed":
            if cid in ("SD_AbrirCanal", "SD_SelectCanal"):
                embed, components = self.PainelSelecionarCanalEmbed()
            else:  # Voltar, Toggle ou vindo de um Modal
                embed, components = self.PainelEmbed()

            await inter.edit_original_message(
                content=None,
                embed=embed,
                components=components
            )

        else:
            if cid in ("SD_AbrirCanal", "SD_SelectCanal"):
                components = self.PainelSelecionarCanal()
            else:  # Voltar, Toggle ou vindo de um Modal
                components = self.Painel()

            await inter.edit_original_message(
                content=None,
                components=components
            )

    @commands.Cog.listener("on_dropdown")
    async def Saidas_Dropdown_Listener(
        self,
        inter: disnake.MessageInteraction
    ):
        cid = inter.data.custom_id
        if not cid or not cid.startswith("SD_"):
            return

        if cid == "SD_SelectCanal":
            valores = list(inter.values or [])
            if valores:
                helpers.definir_canal_saidas(valores[0])

        await self._update_panel(inter)


class EditarMensagemSDModal(disnake.ui.Modal):
    def __init__(self, modo: str):
        cfg = helpers.carregar_config()

        modo = str(
            modo or cfg.get("modo_envio", "v1")
        )

        base_inputs = [
            disnake.ui.TextInput(
                label="Mensagem de saída (Obrigatório)",
                placeholder="Use {user}, {nameserver}, {nameuser}, {servercount}",
                value=str(cfg.get("mensagem", ""))[:4000],
                custom_id="mensagem",
                style=disnake.TextInputStyle.paragraph,
                required=True,
            )
        ]

        if modo == "v2":
            inputs = base_inputs + [
                disnake.ui.TextInput(
                    label="Imagem URL (Opcional)",
                    placeholder="https://...",
                    value=str(
                        cfg.get("v2_imagem_url", "")
                    )[:4000],
                    custom_id="v2_imagem_url",
                    style=disnake.TextInputStyle.short,
                    required=False
                ),

                disnake.ui.TextInput(
                    label="Cor do Container (Opcional)",
                    placeholder="#ffffff",
                    value=str(
                        cfg.get("v2_cor_container", "")
                    )[:16],
                    custom_id="v2_cor_container",
                    style=disnake.TextInputStyle.short,
                    required=False
                ),
            ]

            titulo = "Editar Mensagem (Componentes)"

        elif modo == "embed":
            inputs = base_inputs + [
                disnake.ui.TextInput(
                    label="Título (Opcional)",
                    placeholder="Ex: Até logo!",
                    value=str(
                        cfg.get("embed_titulo", "")
                    )[:256],
                    custom_id="embed_titulo",
                    style=disnake.TextInputStyle.short,
                    required=False
                ),

                disnake.ui.TextInput(
                    label="Banner URL (Opcional)",
                    placeholder="https://...",
                    value=str(
                        cfg.get("embed_banner_url", "")
                    )[:4000],
                    custom_id="embed_banner_url",
                    style=disnake.TextInputStyle.short,
                    required=False
                ),

                disnake.ui.TextInput(
                    label="Thumbnail URL (Opcional)",
                    placeholder="https://...",
                    value=str(
                        cfg.get("embed_thumb_url", "")
                    )[:4000],
                    custom_id="embed_thumb_url",
                    style=disnake.TextInputStyle.short,
                    required=False
                ),

                disnake.ui.TextInput(
                    label="Cor do Embed (Opcional)",
                    placeholder="#ffffff",
                    value=str(
                        cfg.get("embed_cor", "")
                    )[:16],
                    custom_id="embed_cor",
                    style=disnake.TextInputStyle.short,
                    required=False
                ),
            ]

            titulo = "Editar Mensagem (Embed)"

        else:
            inputs = base_inputs + [
                disnake.ui.TextInput(
                    label="Imagem URL (Opcional)",
                    placeholder="https://...",
                    value=str(
                        cfg.get("v1_imagem_url", "")
                    )[:4000],
                    custom_id="v1_imagem_url",
                    style=disnake.TextInputStyle.short,
                    required=False
                ),
            ]

            titulo = "Editar Mensagem (Padrão)"

        super().__init__(
            title=titulo,
            custom_id="SD_EditarMensagem_Modal",
            components=inputs
        )

    async def callback(
        self,
        inter: disnake.ModalInteraction
    ):
        valores = dict(inter.text_values)

        helpers.salvar_config(valores)

        cog = inter.bot.get_cog(
            "SaidasConfig"
        )

        if cog:
            await cog._update_panel(inter)


class EditarTempoSDModal(disnake.ui.Modal):
    def __init__(
        self,
        valor_atual: int = 0
    ):
        components = [
            disnake.ui.TextInput(
                label="Tempo em segundos (0 = não apagar)",
                placeholder="Ex: 0, 1, 5, 10, 60",
                value=str(int(valor_atual or 0)),
                custom_id="tempo",
                style=disnake.TextInputStyle.short,
                required=True,
            )
        ]

        super().__init__(
            title="Editar Duração da Mensagem",
            custom_id="SD_EditarTempo_Modal",
            components=components
        )

    async def callback(
        self,
        inter: disnake.ModalInteraction
    ):
        texto = inter.text_values.get(
            "tempo",
            "0"
        ).strip()

        try:
            valor = int(texto)

            if valor < 0:
                valor = 0

            helpers.salvar_config({
                "tempo_segundos": valor
            })

            cog = inter.bot.get_cog(
                "SaidasConfig"
            )

            if cog:
                await cog._update_panel(inter)

        except Exception:
            try:
                await inter.response.send_message(
                    "Valor inválido para tempo.",
                    ephemeral=True
                )
            except Exception:
                pass


def setup(bot: commands.Bot):
    bot.add_cog(SaidasConfig(bot))