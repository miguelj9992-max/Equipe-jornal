import asyncio
import disnake
from disnake.ext import commands

from modules.automations.saidas import helpers


class SaidasEvent(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_remove(
        self,
        member: disnake.Member
    ):
        cfg = helpers.carregar_config()

        if not cfg.get("ativado", True):
            return

        mensagem = cfg.get("mensagem", "")

        if not mensagem:
            return

        conteudo = helpers.formatar_mensagem(
            mensagem,
            member
        )

        rota = str(
            cfg.get("rota_envio", "canal")
        )

        modo = str(
            cfg.get("modo_envio", "v1")
        )

        tempo = int(
            cfg.get("tempo_segundos", 0) or 0
        )

        canal = helpers.obter_canal_saidas(
            member.guild
        )

        async def enviar(
            destino
        ):
            try:
                if modo == "embed":
                    embed = helpers.montar_embed_preview(
                        conteudo,
                        cfg
                    )

                    msg = await destino.send(
                        embed=embed
                    )

                elif modo == "v2":
                    msg = await destino.send(
                        components=[
                            helpers.montar_container_preview(
                                conteudo,
                                cfg
                            )
                        ],
                        flags=disnake.MessageFlags(
                            is_components_v2=True
                        )
                    )

                else:
                    kwargs = {
                        "content": conteudo
                    }

                    file = await helpers.baixar_imagem(
                        cfg.get("v1_imagem_url")
                    )

                    if file:
                        kwargs["file"] = file

                    msg = await destino.send(
                        **kwargs
                    )

                if tempo > 0:
                    await asyncio.sleep(tempo)

                    await msg.delete()

            except Exception:
                pass

        if rota in ("canal", "canal_dm") and canal:
            await enviar(canal)

        if rota in ("dm", "canal_dm"):
            try:
                await enviar(member)
            except Exception:
                pass


def setup(bot):
    bot.add_cog(SaidasEvent(bot))