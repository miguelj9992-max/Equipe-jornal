from functions.database import database as db


def carregar_config() -> dict:
    return db.get_document("automations_cartas") or {
        "ativado": False,
        "canal_id": None,
        "allow_anonymous": True,
    }


def salvar_config(data: dict) -> None:
    db.save_document("automations_cartas", {}, data)
