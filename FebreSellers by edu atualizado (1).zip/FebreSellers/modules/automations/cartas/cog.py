import disnake
from disnake.ext import commands

from functions.database import database as db
from functions.emoji import emoji
from functions.message import message, embed_message
from .helpers import carregar_config, salvar_config


class SetCartasChannelModal(disnake.ui.Modal):
    def __init__(self):
        components = [
            disnake.ui.TextInput(
                label="Canal de cartas",
                placeholder="ID ou menção do canal (ex: #cartas)",
                custom_id="channel_id",
                max_length=100,
            )
        ]
        super().__init__(
            title="Definir Canal de Cartas",
            custom_id="Cartas_SetCanalModal",
            components=components,
        )

    async def callback(self, inter: disnake.ModalInteraction):
        canal_text = inter.text_values.get("channel_id", "").strip()
        if canal_text.startswith("<#") and canal_text.endswith(">"):
            canal_text = canal_text[2:-1]

        try:
            canal_id = int(canal_text)
        except (TypeError, ValueError):
            await inter.response.send_message(
                "Canal inválido. Use um ID de canal ou uma menção de canal válida.",
                ephemeral=True,
            )
            return

        canal_obj = inter.guild.get_channel(canal_id) if inter.guild else None
        if canal_obj is None:
            await inter.response.send_message(
                "Canal inválido ou não encontrado no servidor.",
                ephemeral=True,
            )
            return

        config = carregar_config()
        config["canal_id"] = canal_obj.id
        salvar_config(config)

        await inter.response.send_message(
            f"Canal de cartas definido para {canal_obj.mention}.",
            ephemeral=True,
        )


class CartasCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @staticmethod
    def Painel() -> list[disnake.ui.Container]:
        config = carregar_config()
        ativado = bool(config.get("ativado", False))
        canal_id = config.get("canal_id")
        allow_anonymous = bool(config.get("allow_anonymous", True))
        canal_text = "Nenhum canal definido" if canal_id is None else f"<#{canal_id}>"

        resumo = (
            f"{emoji.on if ativado else emoji.off} **Status:** `{'Ativado' if ativado else 'Desativado'}`\n"
            f"{emoji.cardbox} **Canal de cartas:** `{canal_text}`\n"
            f"{emoji.mail2} **Anônimas:** `{'Permitidas' if allow_anonymous else 'Bloqueadas'}`\n"
            f"\nUse `/cartas enviar` para mandar uma carta para outro membro."
        )

        primary_color_hex = db.get_document("custom_colors").get("primary")
        container_kwargs = {}
        if primary_color_hex:
            primary_color = int(primary_color_hex.replace("#", ""), 16)
            container_kwargs["accent_colour"] = disnake.Colour(primary_color)

        return [
            disnake.ui.Container(
                disnake.ui.TextDisplay(f"## {emoji.mail2} Painel > Automações > **Cartas**"),
                disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                disnake.ui.TextDisplay("Envie cartas entre membros diretamente pelo servidor."),
                disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                disnake.ui.TextDisplay(resumo),
                disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                disnake.ui.ActionRow(
                    disnake.ui.Button(label="Ativar/Desativar", style=disnake.ButtonStyle.grey, emoji=emoji.power, custom_id="Cartas_ToggleAtivo"),
                    disnake.ui.Button(label="Definir Canal", style=disnake.ButtonStyle.green, emoji=emoji.route, custom_id="Cartas_SetCanal"),
                    disnake.ui.Button(label="Anônimas", style=disnake.ButtonStyle.grey, emoji=emoji.mail2, custom_id="Cartas_ToggleAnonimo"),
                ),
                **container_kwargs,
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="VoltarAutomações"),
            ),
        ]

    @staticmethod
    def PainelEmbed() -> tuple[disnake.Embed, list[disnake.ui.ActionRow]]:
        config = carregar_config()
        ativado = bool(config.get("ativado", False))
        canal_id = config.get("canal_id")
        allow_anonymous = bool(config.get("allow_anonymous", True))
        canal_text = "Nenhum canal definido" if canal_id is None else f"<#{canal_id}>"

        primary_color_hex = db.get_document("custom_colors").get("primary")
        embed = disnake.Embed(
            title="Cartas",
            description="Envie cartas entre membros diretamente pelo servidor."
        )
        if primary_color_hex:
            embed.color = disnake.Colour(int(primary_color_hex.replace("#", ""), 16))

        embed.add_field(name="Configurações", value=
            f"{emoji.on if ativado else emoji.off} **Status:** `{'Ativado' if ativado else 'Desativado'}`\n"
            f"{emoji.cardbox} **Canal de cartas:** `{canal_text}`\n"
            f"{emoji.mail2} **Anônimas:** `{'Permitidas' if allow_anonymous else 'Bloqueadas'}`",
            inline=False
        )
        embed.add_field(name="Como usar", value="Use `/cartas enviar` para mandar uma carta.", inline=False)

        components = [
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Ativar/Desativar", style=disnake.ButtonStyle.grey, emoji=emoji.power, custom_id="Cartas_ToggleAtivo"),
                disnake.ui.Button(label="Definir Canal", style=disnake.ButtonStyle.green, emoji=emoji.route, custom_id="Cartas_SetCanal"),
                disnake.ui.Button(label="Anônimas", style=disnake.ButtonStyle.grey, emoji=emoji.mail2, custom_id="Cartas_ToggleAnonimo"),
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="VoltarAutomações"),
            ),
        ]
        return embed, components

    @commands.Cog.listener("on_button_click")
    async def on_button_click(self, inter: disnake.MessageInteraction):
        cid = inter.component.custom_id

        if cid == "Cartas_ToggleAtivo":
            config = carregar_config()
            config["ativado"] = not bool(config.get("ativado", False))
            salvar_config(config)
            await self._update_panel(inter)

        elif cid == "Cartas_ToggleAnonimo":
            config = carregar_config()
            config["allow_anonymous"] = not bool(config.get("allow_anonymous", True))
            salvar_config(config)
            await self._update_panel(inter)

        elif cid == "Cartas_SetCanal":
            await inter.response.send_modal(SetCartasChannelModal())

    async def _update_panel(self, inter: disnake.MessageInteraction):
        if not inter.response.is_done():
            await inter.response.defer(with_message=False)

        mode = db.get_document("custom_mode").get("mode")

        if mode == "embed":
            await embed_message.wait(inter, send=False)
            embed, components = self.PainelEmbed()
            await inter.edit_original_message(content=None, embed=embed, components=components)
        else:
            await message.wait(inter, send=False)
            await inter.edit_original_message(content=None, components=self.Painel())

def setup(bot: commands.Bot):
    bot.add_cog(CartasCog(bot))