import disnake
from modules.automations.forms.runtime import open_form


async def handle_form_select(inter: disnake.MessageInteraction):
    value = inter.values[0]

    # aqui você decide qual form abrir
    # exemplo: value = form_id

    await open_form(inter, value)