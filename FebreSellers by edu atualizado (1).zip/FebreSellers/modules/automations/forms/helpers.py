from functions.database import database as db

DB_PATH = "database/automations/forms.json"


def carregar_config():
    return db.obter(DB_PATH) or {"ativado": False, "forms": {}}


def salvar_config(data):
    db.salvar(DB_PATH, data)