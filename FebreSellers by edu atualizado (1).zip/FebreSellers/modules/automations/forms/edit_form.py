import disnake
from disnake.ext import commands
from functions.database import database as db
from functions.emoji import emoji
from functions.message import message, embed_message
from . import helpers


def get_forms():
    config = helpers.carregar_config()
    return config.get("forms", {})


class SelectFormToEdit(disnake.ui.StringSelect):
    def __init__(self, forms_chunk, chunk_index: int, total_forms: int):

        options = [
            disnake.SelectOption(
                label=data["name"],
                value=form_id,
                description="Clique para editar o formulário"
            )
            for form_id, data in forms_chunk
        ]

        placeholder = "Selecione um formulário para editar..."

        if total_forms > 25:
            start_index = chunk_index * 25 + 1
            end_index = start_index + len(forms_chunk) - 1
            placeholder = f"Formulários ({start_index}-{end_index})"

        if total_forms == 0:
            options = [
                disnake.SelectOption(
                    label="Nenhum formulário encontrado",
                    value="disabled"
                )
            ]

        super().__init__(
            placeholder=placeholder,
            options=options,
            custom_id=f"select_form_to_edit_{chunk_index}",
            disabled=(total_forms == 0)
        )


# =========================
# EDIT LIST VIEW
# =========================

def EditFormView_components():
    forms = get_forms()
    items = list(forms.items())
    total = len(items)

    components = [
        disnake.ui.TextDisplay(
            f"##  Formulários\n-# Selecione um formulário para editar"
        ),
        disnake.ui.Separator()
    ]

    if total == 0:
        components.append(disnake.ui.ActionRow(SelectFormToEdit([], 0, 0)))
    else:
        chunk_size = 25
        for i in range(0, total, chunk_size):
            chunk_index = i // chunk_size
            chunk = items[i:i + chunk_size]
            components.append(
                disnake.ui.ActionRow(
                    SelectFormToEdit(chunk, chunk_index, total)
                )
            )

    components.append(
        disnake.ui.ActionRow(
            disnake.ui.Button(
                label="Voltar",
                style=disnake.ButtonStyle.grey,
                emoji=emoji.back,
                custom_id="Forms_Painel"
            )
        )
    )

    return components


def EditFormView_embed():
    forms = get_forms()
    items = list(forms.items())
    total = len(items)

    embed = disnake.Embed(
        title="Editar Formulários",
        description="Selecione um formulário abaixo."
    )

    components = []

    if total == 0:
        components.append(disnake.ui.ActionRow(SelectFormToEdit([], 0, 0)))
    else:
        chunk_size = 25
        for i in range(0, total, chunk_size):
            chunk_index = i // chunk_size
            chunk = items[i:i + chunk_size]
            components.append(
                disnake.ui.ActionRow(
                    SelectFormToEdit(chunk, chunk_index, total)
                )
            )

    components.append(
        disnake.ui.ActionRow(
            disnake.ui.Button(
                label="Voltar",
                style=disnake.ButtonStyle.grey,
                emoji=emoji.back,
                custom_id="Forms_Painel"
            )
        )
    )

    return embed, components


# =========================
# SPECIFIC FORM VIEW
# =========================

def SpecificFormView_components(form_id: str):
    forms = get_forms()
    data = forms.get(form_id)

    if not data:
        return EditFormView_components()

    name = data.get("name", "N/A")

    container = disnake.ui.Container(
        disnake.ui.TextDisplay(
            f"##  Editando Formulário\n**{name}**"
        ),
        disnake.ui.Separator(),

        disnake.ui.ActionRow(
            disnake.ui.Button(
                label="Definir Mensagem",
                style=disnake.ButtonStyle.grey,
                emoji=emoji.embed,
                custom_id=f"FormEdit_SetMessage_{form_id}"
            ),
            disnake.ui.Button(
                label="Definir Perguntas",
                style=disnake.ButtonStyle.grey,
                emoji=emoji.question,
                custom_id=f"FormEdit_SetQuestions_{form_id}"
            ),
        ),

        disnake.ui.ActionRow(
            disnake.ui.Button(
                label="Configurações Gerais",
                style=disnake.ButtonStyle.grey,
                emoji=emoji.settings2,
                custom_id=f"FormEdit_Advanced_{form_id}"
            ),
            disnake.ui.Button(
                label="Estatísticas",
                style=disnake.ButtonStyle.grey,
                emoji=emoji.chart,
                custom_id=f"FormEdit_Stats_{form_id}"
            ),
        )
    )

    return [
        container,
        disnake.ui.ActionRow(
            disnake.ui.Button(
                label="Voltar",
                style=disnake.ButtonStyle.grey,
                emoji=emoji.back,
                custom_id="Forms_Editar"
            )
        )
    ]


def SpecificFormView_embed(form_id: str):
    forms = get_forms()
    data = forms.get(form_id)

    if not data:
        return EditFormView_embed()

    name = data.get("name", "N/A")

    embed = disnake.Embed(
        title=f"Editando: {name}",
        description="Escolha uma opção abaixo."
    )

    components = [
        disnake.ui.ActionRow(
            disnake.ui.Button(
                label="Definir Mensagem",
                style=disnake.ButtonStyle.grey,
                emoji=emoji.embed,
                custom_id=f"FormEdit_SetMessage_{form_id}"
            ),
            disnake.ui.Button(
                label="Definir Perguntas",
                style=disnake.ButtonStyle.grey,
                emoji=emoji.question,
                custom_id=f"FormEdit_SetQuestions_{form_id}"
            ),
        ),

        disnake.ui.ActionRow(
            disnake.ui.Button(
                label="Configurações",
                style=disnake.ButtonStyle.grey,
                emoji=emoji.settings2,
                custom_id=f"FormEdit_Advanced_{form_id}"
            ),
            disnake.ui.Button(
                label="Estatísticas",
                style=disnake.ButtonStyle.grey,
                emoji=emoji.chart,
                custom_id=f"FormEdit_Stats_{form_id}"
            ),
        ),

        disnake.ui.ActionRow(
            disnake.ui.Button(
                label="Voltar",
                style=disnake.ButtonStyle.grey,
                emoji=emoji.back,
                custom_id="Forms_Editar"
            )
        )
    ]

    return embed, components