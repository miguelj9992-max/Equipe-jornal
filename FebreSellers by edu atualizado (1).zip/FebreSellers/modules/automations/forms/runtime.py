import disnake
from functions.database import database as db


class DynamicFormModal(disnake.ui.Modal):
    def __init__(self, form_id: str):
        self.form_id = form_id

        config = db.obter("database/automations/forms.json") or {}
        form = config.get("forms", {}).get(form_id, {})

        components = []

        for q in form.get("questions", []):
            components.append(
                disnake.ui.TextInput(
                    label=q.get("label", "Pergunta"),
                    placeholder=q.get("placeholder", ""),
                    custom_id=q["id"],
                    style=disnake.TextInputStyle.paragraph if q.get("style") == "paragraph" else disnake.TextInputStyle.short,
                    required=q.get("required", False),
                    max_length=1000
                )
            )

        super().__init__(
            title=form.get("name", "Formulário"),
            components=components
        )

    async def callback(self, inter: disnake.ModalInteraction):
        embed = disnake.Embed(
            title="Formulário Enviado",
            color=0x2B2D31
        )

        for k, v in inter.text_values.items():
            embed.add_field(name=k, value=v, inline=False)

        await inter.channel.send(embed=embed)
        await inter.response.send_message("Enviado!", ephemeral=True)


async def open_form(inter: disnake.Interaction, form_id: str):
    config = db.obter("database/automations/forms.json") or {}

    if form_id not in config.get("forms", {}):
        await inter.response.send_message("Formulário não encontrado.", ephemeral=True)
        return

    await inter.response.send_modal(DynamicFormModal(form_id))