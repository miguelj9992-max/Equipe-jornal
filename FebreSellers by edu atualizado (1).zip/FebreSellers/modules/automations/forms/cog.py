import disnake
from disnake.ext import commands
from functions.database import database as db
from functions.emoji import emoji
from functions.message import message, embed_message
from functions.utils import utils
from . import helpers
from .edit_form import EditFormView_components, EditFormView_embed, SpecificFormView_components, SpecificFormView_embed
from functions.utils import utils as utils_module


# ── Helpers de UI reutilizáveis ───────────────────────────────────────────────

def _get_color(primary_color_hex):
    """Retorna um disnake.Colour a partir de uma string hex, ou None."""
    if not primary_color_hex:
        return None
    try:
        return disnake.Colour(int(primary_color_hex.lstrip("#"), 16))
    except (ValueError, TypeError):
        return None


def _build_questions_embed(form_name, questions, form_id, primary_color_hex):
    """Constrói embed + components para a tela de perguntas."""
    color = _get_color(primary_color_hex)
    embed_kwargs = {"color": color} if color else {}
    embed = disnake.Embed(
        title=f"Perguntas: {form_name}",
        description="\n".join([f"**{i+1}.** {q['label']}" for i, q in enumerate(questions)]) if questions else "Nenhuma pergunta cadastrada.",
        **embed_kwargs
    )
    components = [
        disnake.ui.ActionRow(
            disnake.ui.Button(label="Adicionar Pergunta", style=disnake.ButtonStyle.green, emoji=emoji.plus, custom_id=f"FormQ_Add_{form_id}"),
        ),
        disnake.ui.ActionRow(
            disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id=f"FormEdit_Back_{form_id}"),
        )
    ]
    if questions:
        remove_select = disnake.ui.StringSelect(
            custom_id=f"FormQ_Remove_{form_id}",
            placeholder="Selecione uma pergunta para remover...",
            min_values=1,
            max_values=len(questions),
            options=[disnake.SelectOption(label=q["label"], value=q["id"]) for q in questions]
        )
        components.insert(1, disnake.ui.ActionRow(remove_select))
    return embed, components


def _build_questions_container(form_name, questions, form_id, primary_color_hex):
    """Constrói container + back_row para a tela de perguntas (components v2)."""
    color = _get_color(primary_color_hex)
    container_kwargs = {"accent_colour": color} if color else {}

    text_items = [
        disnake.ui.TextDisplay(f"## \n-# Formulários > **{form_name}** > Perguntas"),
        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
    ]
    if questions:
        q_text = "\n".join([f"**{i+1}.** {q['label']}" for i, q in enumerate(questions)])
        text_items.append(disnake.ui.TextDisplay(q_text))
        remove_select = disnake.ui.StringSelect(
            custom_id=f"FormQ_Remove_{form_id}",
            placeholder="Selecione uma pergunta para remover...",
            min_values=1,
            max_values=len(questions),
            options=[disnake.SelectOption(label=q["label"], value=q["id"]) for q in questions]
        )
        text_items.append(disnake.ui.ActionRow(remove_select))
    else:
        text_items.append(disnake.ui.TextDisplay("Nenhuma pergunta cadastrada."))

    text_items.append(disnake.ui.ActionRow(
        disnake.ui.Button(label="Adicionar Pergunta", style=disnake.ButtonStyle.green, emoji=emoji.plus, custom_id=f"FormQ_Add_{form_id}"),
    ))
    container = disnake.ui.Container(*text_items, **container_kwargs)
    back_row = disnake.ui.ActionRow(
        disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id=f"FormEdit_Back_{form_id}"),
    )
    return container, back_row


# ── Modal: criar formulário ───────────────────────────────────────────────────

class CreateFormModal(disnake.ui.Modal):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        components = [
            disnake.ui.TextInput(
                label="Nome do Formulário",
                placeholder="Ex: Aplicação para Staff",
                custom_id="form_name",
                max_length=50,
            ),
        ]
        super().__init__(title="Criar Novo Formulário", components=components, custom_id="create_form_modal")

    async def callback(self, inter: disnake.ModalInteraction):
        if not inter.response.is_done():
            await inter.response.defer(with_message=False)

        mode = db.get_document("custom_mode").get("mode")
        form_id = utils.gerar_id()
        form_name = inter.text_values["form_name"]

        config = helpers.carregar_config()
        config.setdefault("forms", {})
        config["forms"][form_id] = {"name": form_name}
        helpers.salvar_config(config)

        if mode == "components":
            await inter.edit_original_message(components=FormsCog.Painel())
        else:
            embed, components = FormsCog.PainelEmbed()
            await inter.edit_original_message(content=None, embed=embed, components=components)


# ── Cog principal ─────────────────────────────────────────────────────────────

class FormsCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @staticmethod
    def Painel() -> list[disnake.ui.Container]:
        config = helpers.carregar_config()
        ativado = config.get("ativado", False)
        forms = config.get("forms", {})
        form_count = len(forms)

        resumo = (
            f"{emoji.on if ativado else emoji.off} **Status:** `{'Ativado' if ativado else 'Desativado'}`\n"
            f"{emoji.receipt} **Formulários Criados:** `{form_count}`\n"
        )

        botoes_principais = [
            disnake.ui.Button(label="", style=disnake.ButtonStyle.grey, emoji=emoji.power, custom_id="Forms_ToggleAtivo"),
            disnake.ui.Button(label="Adicionar", style=disnake.ButtonStyle.green, emoji=emoji.plus, custom_id="Forms_Adicionar", disabled=not ativado),
            disnake.ui.Button(label="Editar", style=disnake.ButtonStyle.grey, emoji=emoji.edit, custom_id="Forms_Editar", disabled=form_count == 0 or not ativado),
        ]

        primary_color_hex = db.get_document("custom_colors").get("primary")
        color = _get_color(primary_color_hex)
        container_kwargs = {"accent_colour": color} if color else {}

        return [
            disnake.ui.Container(
                disnake.ui.TextDisplay(f"## \n-# Painel > Automações > **Formulários**"),
                disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                disnake.ui.TextDisplay("Crie formulários personalizados para os membros preencherem."),
                disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                disnake.ui.TextDisplay(resumo),
                disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                disnake.ui.ActionRow(*botoes_principais),
                **container_kwargs,
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="VoltarAutomações"),
            )
        ]

    @staticmethod
    def PainelEmbed() -> tuple[disnake.Embed, list[disnake.ui.ActionRow]]:
        config = helpers.carregar_config()
        ativado = config.get("ativado", False)
        forms = config.get("forms", {})
        form_count = len(forms)

        resumo = (
            f"{emoji.on if ativado else emoji.off} **Status:** `{'Ativado' if ativado else 'Desativado'}`\n"
            f"{emoji.receipt} **Formulários Criados:** `{form_count}`\n"
        )

        primary_color_hex = db.get_document("custom_colors").get("primary")
        embed = disnake.Embed(
            title="Formulários",
            description="Crie formulários personalizados para os membros preencherem."
        )
        color = _get_color(primary_color_hex)
        if color:
            embed.color = color

        embed.add_field(name="Configurações", value=resumo, inline=False)

        components = [
            disnake.ui.ActionRow(
                disnake.ui.Button(label="", style=disnake.ButtonStyle.grey, emoji=emoji.power, custom_id="Forms_ToggleAtivo"),
                disnake.ui.Button(label="Adicionar", style=disnake.ButtonStyle.green, emoji=emoji.plus, custom_id="Forms_Adicionar", disabled=not ativado),
                disnake.ui.Button(label="Editar", style=disnake.ButtonStyle.grey, emoji=emoji.edit, custom_id="Forms_Editar", disabled=form_count == 0 or not ativado),
            ),
            disnake.ui.ActionRow(
                disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id="VoltarAutomações"),
            )
        ]
        return embed, components

    # ── Listener unificado de botões ──────────────────────────────────────────
    @commands.Cog.listener("on_button_click")
    async def Forms_Button_Listener(self, inter: disnake.MessageInteraction):
        custom_id = inter.component.custom_id

        # ── Painel principal ──────────────────────────────────────────────────
        if custom_id == "Forms_ToggleAtivo":
            await inter.response.defer(with_message=False)
            config = helpers.carregar_config()
            config["ativado"] = not config.get("ativado", False)
            helpers.salvar_config(config)
            mode = db.get_document("custom_mode").get("mode")
            if mode == "embed":
                embed, components = self.PainelEmbed()
                await inter.edit_original_message(content=None, embed=embed, components=components)
            else:
                await inter.edit_original_message(components=self.Painel())

        elif custom_id == "Forms_Adicionar":
            await inter.response.send_modal(CreateFormModal(self.bot))

        elif custom_id == "Forms_Editar":
            await inter.response.defer(with_message=False)
            mode = db.get_document("custom_mode").get("mode")
            if mode == "embed":
                embed, components = EditFormView_embed()
                await inter.edit_original_message(content=None, embed=embed, components=components)
            else:
                await inter.edit_original_message(components=EditFormView_components())

        elif custom_id == "Forms_Painel":
            await inter.response.defer(with_message=False)
            mode = db.get_document("custom_mode").get("mode")
            if mode == "embed":
                embed, components = self.PainelEmbed()
                await inter.edit_original_message(content=None, embed=embed, components=components)
            else:
                await inter.edit_original_message(components=self.Painel())

        # ── Sub-botões de formulário ──────────────────────────────────────────
        elif custom_id.startswith("FormQ_Add_"):
            form_id = custom_id[len("FormQ_Add_"):]
            await inter.response.send_modal(AddQuestionModal(form_id))

        elif custom_id.startswith("FormMsg_Set_"):
            form_id = custom_id[len("FormMsg_Set_"):]
            await inter.response.send_modal(SetMessageModal(form_id))

        elif custom_id.startswith("FormAdv_SetChannel_"):
            form_id = custom_id[len("FormAdv_SetChannel_"):]
            await inter.response.send_modal(SetChannelModal(form_id))

        elif custom_id.startswith("FormAdv_Delete_"):
            await inter.response.defer(with_message=False)
            form_id = custom_id[len("FormAdv_Delete_"):]
            config = helpers.carregar_config()
            config.get("forms", {}).pop(form_id, None)
            helpers.salvar_config(config)
            mode = db.get_document("custom_mode").get("mode")
            if mode == "embed":
                embed, components = EditFormView_embed()
                await inter.edit_original_message(content=None, embed=embed, components=components)
            else:
                await inter.edit_original_message(components=EditFormView_components())

        # ── Ações de edição de formulário ─────────────────────────────────────
        elif custom_id.startswith("FormEdit_"):
            await inter.response.defer(with_message=False)
            mode = db.get_document("custom_mode").get("mode")

            # Formato: FormEdit_<Acao>_<form_id>
            parts = custom_id.split("_", 2)
            if len(parts) < 3:
                return
            action = parts[1]
            form_id = parts[2]

            config = helpers.carregar_config()
            form_data = config.get("forms", {}).get(form_id)
            if not form_data:
                return

            form_name = form_data.get("name", "N/A")
            primary_color_hex = db.get_document("custom_colors").get("primary")
            color = _get_color(primary_color_hex)

            # ── Definir Perguntas ─────────────────────────────────────
            if action == "SetQuestions":
                questions = form_data.get("questions", [])
                if mode == "embed":
                    embed, components = _build_questions_embed(form_name, questions, form_id, primary_color_hex)
                    await inter.edit_original_message(content=None, embed=embed, components=components)
                else:
                    container, back_row = _build_questions_container(form_name, questions, form_id, primary_color_hex)
                    await inter.edit_original_message(
                        components=[container, back_row],
                        flags=disnake.MessageFlags(is_components_v2=True)
                    )

            # ── Definir Mensagem ──────────────────────────────────────
            elif action == "SetMessage":
                current_msg = form_data.get("message", "")
                if mode == "embed":
                    embed_kwargs = {"color": color} if color else {}
                    embed = disnake.Embed(
                        title=f"Mensagem: {form_name}",
                        description=f"**Mensagem atual:**\n{current_msg or '`Não definida`'}",
                        **embed_kwargs
                    )
                    components = [
                        disnake.ui.ActionRow(
                            disnake.ui.Button(label="Definir Mensagem", style=disnake.ButtonStyle.green, emoji=emoji.edit, custom_id=f"FormMsg_Set_{form_id}"),
                        ),
                        disnake.ui.ActionRow(
                            disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id=f"FormEdit_Back_{form_id}"),
                        )
                    ]
                    await inter.edit_original_message(content=None, embed=embed, components=components)
                else:
                    container_kwargs = {"accent_colour": color} if color else {}
                    container = disnake.ui.Container(
                        disnake.ui.TextDisplay(f"## \n-# Formulários > **{form_name}** > Mensagem"),
                        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                        disnake.ui.TextDisplay(f"**Mensagem atual:**\n{current_msg or '`Não definida`'}"),
                        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                        disnake.ui.ActionRow(
                            disnake.ui.Button(label="Definir Mensagem", style=disnake.ButtonStyle.green, emoji=emoji.edit, custom_id=f"FormMsg_Set_{form_id}"),
                        ),
                        **container_kwargs
                    )
                    back_row = disnake.ui.ActionRow(
                        disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id=f"FormEdit_Back_{form_id}"),
                    )
                    await inter.edit_original_message(
                        components=[container, back_row],
                        flags=disnake.MessageFlags(is_components_v2=True)
                    )

            # ── Configurações Gerais ──────────────────────────────────
            elif action == "Advanced":
                channel_id = form_data.get("channel_id")
                channel_mention = f"<#{channel_id}>" if channel_id else "`Não definido`"
                if mode == "embed":
                    embed_kwargs = {"color": color} if color else {}
                    embed = disnake.Embed(title=f"Configurações: {form_name}", **embed_kwargs)
                    embed.add_field(name=f"{emoji.textc} Canal de Respostas", value=channel_mention, inline=False)
                    components = [
                        disnake.ui.ActionRow(
                            disnake.ui.Button(label="Definir Canal", style=disnake.ButtonStyle.grey, emoji=emoji.textc, custom_id=f"FormAdv_SetChannel_{form_id}"),
                            disnake.ui.Button(label="Deletar Formulário", style=disnake.ButtonStyle.red, emoji=emoji.delete, custom_id=f"FormAdv_Delete_{form_id}"),
                        ),
                        disnake.ui.ActionRow(
                            disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id=f"FormEdit_Back_{form_id}"),
                        )
                    ]
                    await inter.edit_original_message(content=None, embed=embed, components=components)
                else:
                    container_kwargs = {"accent_colour": color} if color else {}
                    container = disnake.ui.Container(
                        disnake.ui.TextDisplay(f"## \n-# Formulários > **{form_name}** > Configurações"),
                        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                        disnake.ui.TextDisplay(f"{emoji.textc} **Canal de Respostas:** {channel_mention}"),
                        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                        disnake.ui.ActionRow(
                            disnake.ui.Button(label="Definir Canal", style=disnake.ButtonStyle.grey, emoji=emoji.textc, custom_id=f"FormAdv_SetChannel_{form_id}"),
                            disnake.ui.Button(label="Deletar Formulário", style=disnake.ButtonStyle.red, emoji=emoji.delete, custom_id=f"FormAdv_Delete_{form_id}"),
                        ),
                        **container_kwargs
                    )
                    back_row = disnake.ui.ActionRow(
                        disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id=f"FormEdit_Back_{form_id}"),
                    )
                    await inter.edit_original_message(
                        components=[container, back_row],
                        flags=disnake.MessageFlags(is_components_v2=True)
                    )

            # ── Estatísticas ──────────────────────────────────────────
            elif action == "Stats":
                questions = form_data.get("questions", [])
                submissions = form_data.get("submissions", 0)
                if mode == "embed":
                    embed_kwargs = {"color": color} if color else {}
                    embed = disnake.Embed(title=f"Estatísticas: {form_name}", **embed_kwargs)
                    embed.add_field(name=f"{emoji.chart} Respostas Recebidas", value=f"`{submissions}`", inline=True)
                    embed.add_field(name=f"{emoji.question} Perguntas", value=f"`{len(questions)}`", inline=True)
                    components = [
                        disnake.ui.ActionRow(
                            disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id=f"FormEdit_Back_{form_id}"),
                        )
                    ]
                    await inter.edit_original_message(content=None, embed=embed, components=components)
                else:
                    container_kwargs = {"accent_colour": color} if color else {}
                    container = disnake.ui.Container(
                        disnake.ui.TextDisplay(f"## \n-# Formulários > **{form_name}** > Estatísticas"),
                        disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small),
                        disnake.ui.TextDisplay(
                            f"{emoji.chart} **Respostas Recebidas:** `{submissions}`\n"
                            f"{emoji.question} **Perguntas:** `{len(questions)}`"
                        ),
                        **container_kwargs
                    )
                    back_row = disnake.ui.ActionRow(
                        disnake.ui.Button(label="Voltar", style=disnake.ButtonStyle.grey, emoji=emoji.back, custom_id=f"FormEdit_Back_{form_id}"),
                    )
                    await inter.edit_original_message(
                        components=[container, back_row],
                        flags=disnake.MessageFlags(is_components_v2=True)
                    )

            # ── Voltar ao painel do formulário específico ─────────────
            elif action == "Back":
                if mode == "embed":
                    embed, components = SpecificFormView_embed(form_id)
                    await inter.edit_original_message(content=None, embed=embed, components=components)
                else:
                    components = SpecificFormView_components(form_id)
                    await inter.edit_original_message(components=components)

    # ── Listener unificado de dropdowns ──────────────────────────────────────
    @commands.Cog.listener("on_dropdown")
    async def Forms_Dropdown_Listener(self, inter: disnake.MessageInteraction):
        if not isinstance(inter.component, disnake.ui.StringSelect):
            return

        custom_id = inter.component.custom_id

# ── Selecionar formulário para editar ─────────────────────────
        if custom_id.startswith("select_form_to_edit_"):
            form_id = inter.values[0]
            if form_id == "disabled":
                await inter.response.defer()
                return
            await inter.response.defer(with_message=False)
            mode = db.get_document("custom_mode").get("mode")
            if mode == "embed":
                embed, components = SpecificFormView_embed(form_id)
                await inter.edit_original_message(content=None, embed=embed, components=components)
            else:
                components = SpecificFormView_components(form_id)
                await inter.edit_original_message(components=components)

        # ── Remover pergunta ──────────────────────────────────────────
        elif custom_id.startswith("FormQ_Remove_"):
            # CORREÇÃO: defer ANTES de qualquer edit (resposta única à interação)
            await inter.response.defer(with_message=False)
            form_id = custom_id[len("FormQ_Remove_"):]
            config = helpers.carregar_config()
            form_data = config.get("forms", {}).get(form_id, {})
            questions = form_data.get("questions", [])
            to_remove = set(inter.values)
            form_data["questions"] = [q for q in questions if q["id"] not in to_remove]
            helpers.salvar_config(config)

            questions_updated = form_data["questions"]
            form_name = form_data.get("name", "N/A")
            mode = db.get_document("custom_mode").get("mode")
            primary_color_hex = db.get_document("custom_colors").get("primary")

            if mode == "embed":
                embed, components = _build_questions_embed(form_name, questions_updated, form_id, primary_color_hex)
                # Após defer, usar edit_original_message (NÃO inter.response.edit_message)
                await inter.edit_original_message(content=None, embed=embed, components=components)
            else:
                container, back_row = _build_questions_container(form_name, questions_updated, form_id, primary_color_hex)
                await inter.edit_original_message(
                    components=[container, back_row],
                    flags=disnake.MessageFlags(is_components_v2=True)
                )


# ── Modais auxiliares ─────────────────────────────────────────────────────────

class AddQuestionModal(disnake.ui.Modal):
    def __init__(self, form_id: str):
        self.form_id = form_id
        components = [
            disnake.ui.TextInput(label="Pergunta", placeholder="Ex: Qual o seu nome?", custom_id="q_label", max_length=100),
            disnake.ui.TextInput(label="Placeholder", placeholder="Ex: Digite seu nome aqui", custom_id="q_placeholder", max_length=100, required=False),
            disnake.ui.TextInput(label="Estilo (short ou paragraph)", placeholder="short", custom_id="q_style", max_length=10, required=False),
            disnake.ui.TextInput(label="Obrigatória? (sim ou nao)", placeholder="sim", custom_id="q_required", max_length=5, required=False),
        ]
        super().__init__(title="Adicionar Pergunta", components=components, custom_id=f"modal_add_question_{form_id}")

    async def callback(self, inter: disnake.ModalInteraction):
        config = helpers.carregar_config()
        form_data = config.get("forms", {}).get(self.form_id, {})
        questions = form_data.get("questions", [])
        style_val = inter.text_values.get("q_style", "").strip().lower()
        required_val = inter.text_values.get("q_required", "sim").strip().lower()
        questions.append({
            "id": utils_module.gerar_id(),
            "label": inter.text_values["q_label"].strip(),
            "placeholder": inter.text_values.get("q_placeholder", "").strip(),
            "style": "paragraph" if style_val == "paragraph" else "short",
            "required": required_val not in ("nao", "não", "no", "false", "0")
        })
        form_data["questions"] = questions
        config["forms"][self.form_id] = form_data
        helpers.salvar_config(config)

        mode = db.get_document("custom_mode").get("mode")
        primary_color_hex = db.get_document("custom_colors").get("primary")
        form_name = form_data.get("name", "N/A")

        if mode == "embed":
            embed, components = _build_questions_embed(form_name, questions, self.form_id, primary_color_hex)
            # Modal callbacks usam inter.response.edit_message (primeira resposta)
            await inter.response.edit_message(content=None, embed=embed, components=components)
        else:
            container, back_row = _build_questions_container(form_name, questions, self.form_id, primary_color_hex)
            await inter.response.edit_message(
                components=[container, back_row],
                flags=disnake.MessageFlags(is_components_v2=True)
            )


class SetMessageModal(disnake.ui.Modal):
    def __init__(self, form_id: str):
        self.form_id = form_id
        components = [
            disnake.ui.TextInput(
                label="Mensagem de Abertura",
                placeholder="Ex: Preencha este formulário...",
                custom_id="msg_content",
                style=disnake.TextInputStyle.paragraph,
                max_length=1000,
                required=False
            ),
        ]
        super().__init__(title="Definir Mensagem", components=components, custom_id=f"modal_set_message_{form_id}")

    async def callback(self, inter: disnake.ModalInteraction):
        config = helpers.carregar_config()
        form_data = config.get("forms", {}).get(self.form_id, {})
        form_data["message"] = inter.text_values.get("msg_content", "").strip()
        config["forms"][self.form_id] = form_data
        helpers.salvar_config(config)

        mode = (db.get_document("custom_mode") or {}).get("mode", "embed")
        if mode == "embed":
            embed, components = SpecificFormView_embed(self.form_id)
            await inter.response.edit_message(content=None, embed=embed, components=components)
        else:
            await inter.response.edit_message(components=SpecificFormView_components(self.form_id))


class SetChannelModal(disnake.ui.Modal):
    def __init__(self, form_id: str):
        self.form_id = form_id
        components = [
            disnake.ui.TextInput(
                label="ID do Canal de Respostas",
                placeholder="Ex: 123456789012345678",
                custom_id="channel_id",
                max_length=25
            ),
        ]
        super().__init__(title="Definir Canal", components=components, custom_id=f"modal_set_channel_{form_id}")

    async def callback(self, inter: disnake.ModalInteraction):
        config = helpers.carregar_config()
        form_data = config.get("forms", {}).get(self.form_id, {})
        raw = inter.text_values.get("channel_id", "").strip()
        if raw.isdigit():
            form_data["channel_id"] = int(raw)
        config["forms"][self.form_id] = form_data
        helpers.salvar_config(config)

        mode = db.get_document("custom_mode").get("mode")
        if mode == "embed":
            embed, components = SpecificFormView_embed(self.form_id)
            await inter.response.edit_message(content=None, embed=embed, components=components)
        else:
            await inter.response.edit_message(components=SpecificFormView_components(self.form_id))


def setup(bot: commands.Bot):
    bot.add_cog(FormsCog(bot))