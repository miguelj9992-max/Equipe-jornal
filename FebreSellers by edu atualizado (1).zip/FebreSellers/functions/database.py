import json
import os
import time
import threading
import copy
from typing import Optional, Any
from connections.mongo_db import collection as bot_collection

class database:
    # Cache em memória para documentos frequentemente acessados
    _cache: dict[str, tuple[Any, float]] = {}
    _cache_lock = threading.Lock()
    _default_ttl = 60  # 60 segundos por padrão
    
    # Documentos que devem ser cacheados por mais tempo (configurações raramente alteradas)
    _long_cache_docs = {
        "custom_mode",
        "custom_colors",
        "canais",
    }
    _long_cache_ttl = 300  # 5 minutos para documentos de configuração
    @staticmethod
    def obter(filename: str):
        try:
            with open(f"{filename}", "r", encoding="utf-8") as file:
                return json.load(file)
        except (FileNotFoundError, json.JSONDecodeError):
            return {}
    
    @staticmethod
    def salvar(filename: str, data: dict):
        with open(f"{filename}", "w", encoding="utf-8") as file:
            json.dump(data, file, indent=4, ensure_ascii=False)

    @staticmethod
    def get_document(config_type: str):
        """
        Obtém um documento de configuração específico do bot.
        Usa cache em memória para melhorar performance.
        config_type é usado como _id do documento.
        Retorna um dicionário vazio ou lista vazia se nenhum documento for encontrado.
        
        Se o documento contém apenas a chave 'items' (além de _id), retorna a lista diretamente.
        """
        current_time = time.time()
        
        # Verificar cache primeiro
        with database._cache_lock:
            if config_type in database._cache:
                cached_data, expiry_time = database._cache[config_type]
                if current_time < expiry_time:
                    # Cache válido, retornar cópia profunda para evitar mutação
                    return copy.deepcopy(cached_data)
        
        # Cache não encontrado ou expirado, buscar do MongoDB
        try:
            document = bot_collection.find_one({"_id": config_type})
            if document:
                # Remove o _id para manter compatibilidade
                doc_copy = document.copy()
                doc_copy.pop("_id", None)
                
                # Se o documento tem apenas 'items', retornar a lista diretamente
                if len(doc_copy) == 1 and "items" in doc_copy:
                    result = doc_copy["items"]
                else:
                    result = doc_copy
                
                # Armazenar no cache (fazer cópia profunda para evitar mutação)
                cached_result = copy.deepcopy(result)
                ttl = database._long_cache_ttl if config_type in database._long_cache_docs else database._default_ttl
                with database._cache_lock:
                    database._cache[config_type] = (cached_result, current_time + ttl)
                
                # Retornar cópia profunda para evitar mutação
                return copy.deepcopy(result)
            
            # Documento não encontrado, cachear resultado vazio por menos tempo
            empty_result = {}
            with database._cache_lock:
                database._cache[config_type] = (empty_result, current_time + 10)  # 10 segundos para "não encontrado"
            return empty_result
            
        except Exception:
            # Em caso de erro, retornar vazio
            return {}

    @staticmethod
    def get_documents(query: dict = None):
        """
        Obtém múltiplos documentos de configuração do bot.
        Retorna uma lista de dicionários.
        """
        if query is None:
            query = {}
        documents = list(bot_collection.find(query))
        # Remove o _id de cada documento
        for doc in documents:
            doc.pop("_id", None)
        return documents

    @staticmethod
    def delete_document(config_type: str):
        """
        Deleta um documento de configuração específico do bot.
        """
        try:
            bot_collection.delete_one({"_id": config_type})
        except Exception as e:
            # Não deixar uma instabilidade passageira do Mongo (ex: eleição de
            # primary em andamento, rede) derrubar o processo inteiro do bot
            # durante o startup.
            print(f"[MongoDB] Erro ao deletar documento '{config_type}': {e}")
        finally:
            # Invalidar cache mesmo se o delete no Mongo falhar, para não
            # servir um dado potencialmente obsoleto do cache local.
            with database._cache_lock:
                database._cache.pop(config_type, None)

    @staticmethod
    def delete_documents(query: dict):
        """
        Deleta múltiplos documentos de configuração do bot.
        """
        try:
            # Buscar IDs dos documentos que serão deletados para invalidar cache
            documents_to_delete = list(bot_collection.find(query, {"_id": 1}))
            deleted_ids = [doc["_id"] for doc in documents_to_delete]
            
            bot_collection.delete_many(query)
            
            # Invalidar cache dos documentos deletados
            with database._cache_lock:
                for doc_id in deleted_ids:
                    database._cache.pop(doc_id, None)
        except Exception as e:
            print(f"[MongoDB] Erro ao deletar documentos (query={query}): {e}")
        
    @staticmethod
    def save_document(config_type: str, query_or_data=None, data=None):
        """
        Salva um documento de configuração do bot (atualiza se existir, insere se não).
        config_type é usado como _id do documento.
        
        Aceita duas assinaturas para retrocompatibilidade:
        - save_document(config_type, data) - Nova assinatura
        - save_document(config_type, {}, data) - Assinatura antiga (query ignorado)
        
        Suporta tanto dicionários quanto listas.
        """
        # Se data é None, então query_or_data é o data (nova assinatura)
        if data is None:
            data = query_or_data
        # Caso contrário, query_or_data é o query (ignorado) e data é o terceiro argumento
        
        # Se data é uma lista, encapsular em um dicionário
        if isinstance(data, list):
            document = {
                "_id": config_type,
                "items": data
            }
            cache_data = data
        else:
            # Se é um dicionário, copiar e adicionar _id
            data_copy = data.copy()
            data_copy["_id"] = config_type
            document = data_copy
            # Para cache, remover _id novamente
            cache_data = {k: v for k, v in data_copy.items() if k != "_id"}
            # Se o documento tem apenas 'items', retornar a lista diretamente
            if len(cache_data) == 1 and "items" in cache_data:
                cache_data = cache_data["items"]
        
        bot_collection.replace_one(
            {"_id": config_type},
            document,
            upsert=True
        )
        
        # Atualizar cache imediatamente (fazer cópia profunda)
        current_time = time.time()
        ttl = database._long_cache_ttl if config_type in database._long_cache_docs else database._default_ttl
        cached_data = copy.deepcopy(cache_data)
        with database._cache_lock:
            database._cache[config_type] = (cached_data, current_time + ttl)

    # Intervalo mínimo entre varreduras completas do cluster. Essa varredura é
    # cara (uma consulta por coleção, em TODAS as databases do cluster) e roda
    # de forma síncrona/bloqueante. Repeti-la a cada reinício do bot é o que
    # estava travando o processo (e o healthcheck HTTP) por mais de 2 minutos
    # a cada início — inclusive em ciclos de crash/restart, o que agravava o
    # problema em vez de resolvê-lo.
    _CLEANUP_MIN_INTERVAL_SECONDS = 6 * 60 * 60  # 6 horas

    @staticmethod
    def cleanup_database_collections(bot_id: str, force: bool = False):
        """
        Limpa coleções no cluster MongoDB quando o limite de 500 collections é atingido.
        O limite do Atlas M0 é por CLUSTER (todas as databases somadas), então
        precisamos escanear TODAS as databases, não apenas a deste bot.
        Estratégia:
          1. Remove coleções sem _meta_initialization (inicialização incompleta/abandonada)
          2. Remove coleções com initialized_at mais antigo (bots inativos)

        Por ser uma operação pesada (uma query por coleção do cluster inteiro),
        só roda de fato no máximo a cada `_CLEANUP_MIN_INTERVAL_SECONDS`. Chamadas
        mais frequentes que isso (ex: bot reiniciando em loop) são ignoradas,
        a não ser que `force=True` seja passado explicitamente.
        """
        from connections.mongo_db import client as mongo_client
        from connections.mongo_db import database_name as own_database_name

        TARGET_MARGIN = 450  # Manter margem de segurança

        # Databases que NUNCA devem ser limpas (sistema, ou a deste bot)
        protected_databases = {"admin", "local", "config", own_database_name}

        try:
            if not force:
                last_run_doc = bot_collection.find_one({"_id": "_meta_cleanup"})
                last_run_at = (last_run_doc or {}).get("last_run_at", 0)
                elapsed = time.time() - last_run_at
                if elapsed < database._CLEANUP_MIN_INTERVAL_SECONDS:
                    print(
                        f"[Cleanup] Última varredura há {elapsed/60:.1f}min "
                        f"(mínimo: {database._CLEANUP_MIN_INTERVAL_SECONDS/60:.0f}min). Pulando desta vez."
                    )
                    return
        except Exception as e:
            # Se nem der pra checar o timestamp, não bloqueia a limpeza —
            # apenas segue com a varredura normalmente.
            print(f"[Cleanup] Aviso: não foi possível checar última varredura: {e}")

        try:
            # Listar TODAS as databases do cluster
            all_db_names = mongo_client.list_database_names()
            # Filtrar databases de sistema
            all_db_names = [db for db in all_db_names if db not in protected_databases]

            # Catalogar coleções candidatas para remoção (em TODAS as databases)
            candidates = []  # [(db_name, coll_name, priority)]  priority: 0=abandoned, 1=old, 2=error
            total_count = 0

            for db_name in all_db_names:
                try:
                    db = mongo_client[db_name]
                    coll_names = db.list_collection_names()
                    total_count += len(coll_names)

                    for coll_name in coll_names:
                        try:
                            coll = db[coll_name]
                            init_doc = coll.find_one({"_id": "_meta_initialization"})
                            if not init_doc:
                                candidates.append((db_name, coll_name, 0))  # abandoned → highest priority
                            else:
                                ts = init_doc.get("initialized_at", 0)
                                candidates.append((db_name, coll_name, 1))  # old → second priority
                        except Exception:
                            candidates.append((db_name, coll_name, 2))  # error → lowest priority
                except Exception as e:
                    print(f"[Cleanup] ⚠️ Erro ao acessar database '{db_name}': {e}")

            # Também contar coleções protegidas (para o total correto)
            for db_name in protected_databases:
                try:
                    db = mongo_client[db_name]
                    total_count += len(db.list_collection_names())
                except Exception:
                    pass

            print(f"[Cleanup] Total de coleções no cluster: {total_count}")

            if total_count < TARGET_MARGIN:
                print("[Cleanup] Dentro do limite seguro, nada a limpar.")
                return

            # Ordenar: abandoned primeiro, depois old (por timestamp crescente), depois erros
            # Separar old para ordenar por timestamp
            abandoned = [(db, c) for db, c, p in candidates if p == 0]
            errors = [(db, c) for db, c, p in candidates if p == 2]

            # Para coleções old, pegar o timestamp
            old_with_ts = []
            for db_name, coll_name, priority in candidates:
                if priority == 1:
                    try:
                        ts = mongo_client[db_name][coll_name].find_one(
                            {"_id": "_meta_initialization"}
                        ).get("initialized_at", 0)
                        old_with_ts.append((ts, db_name, coll_name))
                    except Exception:
                        errors.append((db_name, coll_name))
            old_with_ts.sort(key=lambda x: x[0])

            # Montar lista final: abandoned → mais antigas → erros
            drop_list = abandoned + [(db, c) for _, db, c in old_with_ts] + errors

            need_to_drop = total_count - TARGET_MARGIN
            dropped = 0

            for db_name, coll_name in drop_list[:need_to_drop]:
                try:
                    mongo_client[db_name].drop_collection(coll_name)
                    dropped += 1
                    print(f"[Cleanup] ✅ Removida: {db_name}.{coll_name}")
                except Exception as e:
                    print(f"[Cleanup] ⚠️ Erro ao remover '{db_name}.{coll_name}': {e}")

            remaining = total_count - dropped
            print(f"[Cleanup] {dropped} coleções removidas. Total agora: {remaining}")

            if remaining >= 500:
                print("[Cleanup] ❌ Ainda no limite. Considere fazer upgrade do plano MongoDB Atlas.")

        except Exception as e:
            print(f"[Cleanup] Erro geral na limpeza: {e}")
        finally:
            try:
                bot_collection.update_one(
                    {"_id": "_meta_cleanup"},
                    {"$set": {"last_run_at": time.time()}},
                    upsert=True,
                )
            except Exception as e:
                print(f"[Cleanup] Aviso: não foi possível salvar o timestamp da varredura: {e}")

    @staticmethod
    def initialize_database_if_needed():
        """
        Verifica se o bot já foi inicializado. Se não, popula a coleção do bot
        com o arquivo consolidado 'database_template.json'.
        Cada chave do JSON vira um documento com _id = nome da chave.
        """
        initialization_doc = bot_collection.find_one({"_id": "_meta_initialization"})

        if initialization_doc:
            # O bot já foi inicializado, não faz nada.
            return

        print("Primeira inicialização detectada. Populando a coleção do bot com valores padrão...")

        template_file = "database_template.json"
        
        try:
            with open(template_file, "r", encoding="utf-8") as f:
                all_configs = json.load(f)
            
            for config_type, default_data in all_configs.items():
                try:
                    if isinstance(default_data, list):
                        # Se for lista, salva como um documento com a lista dentro
                        database.save_document(config_type, {"items": default_data})
                        print(f" - Config '{config_type}' inicializada com {len(default_data)} itens.")
                    else:
                        # Se for dict, salva diretamente
                        database.save_document(config_type, default_data)
                        print(f" - Config '{config_type}' inicializada com sucesso.")
                
                except Exception as e:
                    print(f"Erro ao inicializar a config '{config_type}': {e}")
            
            # Marca que a inicialização foi concluída para não rodar novamente.
            try:
                bot_collection.insert_one({
                    "_id": "_meta_initialization",
                    "initialized_at": os.path.getmtime(template_file)
                })
                print("Inicialização da coleção do bot concluída.")
            except Exception as e:
                print(f"Erro ao marcar inicialização: {e}")
                print("[Atenção] A coleção pode estar cheia. O bot tentará recriar documentos na próxima inicialização.")
        
        except FileNotFoundError:
            print(f"ERRO: Arquivo '{template_file}' não encontrado!")
        except json.JSONDecodeError as e:
            print(f"ERRO: Arquivo '{template_file}' contém JSON inválido: {e}")

    @staticmethod
    def migrate_default_primary_color():
        """
        Migração automática: o padrão antigo da cor primária era o azul/blurple
        '#5865F2'. Se o documento 'custom_colors' de uma instância ainda estiver
        exatamente com esse valor, significa que o dono nunca customizou a cor
        manualmente pelo painel — nesse caso, atualiza automaticamente para o
        novo padrão '#ffffff'. Roda em toda inicialização, em todas as
        instâncias/tokens, mas nunca sobrescreve uma cor escolhida pelo usuário.
        """
        try:
            colors = bot_collection.find_one({"_id": "custom_colors"})
            if not colors:
                return

            current_primary = str(colors.get("primary", "")).strip().lower()

            if current_primary in ("#5865f2", "5865f2"):
                bot_collection.update_one(
                    {"_id": "custom_colors"},
                    {"$set": {"primary": "#ffffff"}}
                )
                # Invalida o cache em memória para refletir a mudança imediatamente
                with database._cache_lock:
                    database._cache.pop("custom_colors", None)
                print("[MongoDB] Cor primária padrão migrada de #5865F2 para #ffffff.")
        except Exception as e:
            print(f"[MongoDB] Erro ao migrar cor primária padrão: {e}")

    @staticmethod
    def verify_and_create_missing_documents():
        """
        Verifica se todos os documentos do template existem na database.
        Se algum estiver faltando, cria com os valores padrão do template.
        Executa toda vez que o bot inicia.
        """
        template_file = "database_template.json"
        
        try:
            with open(template_file, "r", encoding="utf-8") as f:
                all_configs = json.load(f)
            
            missing_count = 0
            for config_type, default_data in all_configs.items():
                # Verifica se o documento existe
                existing_doc = bot_collection.find_one({"_id": config_type})
                
                if not existing_doc:
                    # Documento não existe, criar com valores padrão
                    try:
                        if isinstance(default_data, list):
                            database.save_document(config_type, {"items": default_data})
                            print(f"[MongoDB] Documento faltante '{config_type}' criado com {len(default_data)} itens.")
                        else:
                            database.save_document(config_type, default_data)
                            print(f"[MongoDB] Documento faltante '{config_type}' criado com sucesso.")
                        missing_count += 1
                    except Exception as e:
                        print(f"[MongoDB] Erro ao criar documento '{config_type}': {e}")
            
            if missing_count > 0:
                print(f"[MongoDB] {missing_count} documento(s) faltante(s) foi(ram) criado(s).")
            else:
                print("[MongoDB] Todos os documentos do template estão presentes na database.")
        
        except FileNotFoundError:
            print(f"[MongoDB] ERRO: Arquivo '{template_file}' não encontrado!")
        except json.JSONDecodeError as e:
            print(f"[MongoDB] ERRO: Arquivo '{template_file}' contém JSON inválido: {e}")
        except Exception as e:
            print(f"[MongoDB] ERRO ao verificar documentos: {e}")
    
    @staticmethod
    def clear_cache(config_type: Optional[str] = None):
        """
        Limpa o cache de documentos.
        
        Args:
            config_type: Se fornecido, limpa apenas o cache deste documento.
                        Se None, limpa todo o cache.
        """
        with database._cache_lock:
            if config_type:
                database._cache.pop(config_type, None)
            else:
                database._cache.clear()
    
    @staticmethod
    def get_cache_stats() -> dict:
        """
        Retorna estatísticas do cache.
        """
        with database._cache_lock:
            current_time = time.time()
            valid_entries = sum(1 for _, (_, expiry) in database._cache.items() if current_time < expiry)
            expired_entries = len(database._cache) - valid_entries
            return {
                "total_entries": len(database._cache),
                "valid_entries": valid_entries,
                "expired_entries": expired_entries,
                "cached_documents": list(database._cache.keys())
            }