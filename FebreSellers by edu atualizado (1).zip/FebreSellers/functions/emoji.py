# functions/emoji.py
import asyncio
import os
import disnake
from functions.database import database as db
from core.enable_intents import enable_intents


def parse_emoji(emoji_value) -> "disnake.PartialEmoji | None":
    """Converte qualquer valor de emoji para disnake.PartialEmoji ou None.

    O disnake (versões recentes) não aceita str pura nos campos `emoji` de
    SelectOption/Button — precisa ser PartialEmoji ou None.

    Aceita:
      - None / "" / falsy → retorna None
      - disnake.PartialEmoji → retorna direto (se válido)
      - "<:nome:id>" ou "<a:nome:id>" → PartialEmoji com id
      - Emoji Unicode, ex. "🛒" → PartialEmoji(name="🛒")
    """
    if not emoji_value:
        return None

    if isinstance(emoji_value, disnake.PartialEmoji):
        if emoji_value.id or emoji_value.name:
            return emoji_value
        return None

    if isinstance(emoji_value, str):
        emoji_value = emoji_value.strip()
        if not emoji_value:
            return None
        if emoji_value.startswith("<"):
            try:
                partial = disnake.PartialEmoji.from_str(emoji_value)
                if partial.id:
                    return partial
            except Exception:
                pass
            return None
        # Emoji Unicode
        try:
            return disnake.PartialEmoji(name=emoji_value)
        except Exception:
            return None

    return None

class _EmojiMeta(type):
    """Metaclasse que evita AttributeError ao acessar um emoji que ainda
    não foi sincronizado com o Discord (ex.: logo após o bot iniciar,
    enquanto a sincronização em segundo plano ainda está em andamento).
    Nesses casos retorna None, e o Discord simplesmente exibe o
    botão/menu sem ícone, em vez de quebrar o painel inteiro.
    """
    def __getattr__(cls, name):
        return None


class emoji(metaclass=_EmojiMeta):
    db = db.obter("database/emojis/emojis.json") or {}
    for key, value in db.items():
        locals()[key] = value

def reload_emoji_class():
    try:
        emoji.db = db.obter("database/emojis/emojis.json") or {}
        for key, value in emoji.db.items():
            setattr(emoji, key, value)
        print(f"[Emojis] Classe emoji recarregada com {len(emoji.db)} emojis")
    except Exception as e:
        print(f"[Emojis] Falha ao recarregar classe emoji: {e}")

async def init_on_startup(bot_token: str, app_id: str) -> None:
    try:
        print("[Emojis] Iniciando sistema de emojis...")

        emojis_data = db.obter("database/emojis/emojis_data.json") or {}
        config_emoji = db.obter("configs/config_emoji.json") or {}

        configured = str(emojis_data.get("configured", "")).lower()
        last_token = str(emojis_data.get("lastToken", "") or "")
        print(f"[Emojis] Status: configured={configured}, token_match={last_token == bot_token}")

        try:
            asset_names = {
                os.path.splitext(name)[0]
                for name in os.listdir("database/emojis/assets")
                if name.endswith((".png", ".gif"))
            }
        except OSError:
            asset_names = set()
        known_names = set((db.obter("database/emojis/emojis.json") or {}).keys())
        has_new_assets = bool(asset_names - known_names)
        should_sync = (configured != "true") or (last_token and last_token != bot_token) or has_new_assets
        if not should_sync:
            print("[Emojis] Emojis já sincronizados com o token atual")
            return

        print("[Emojis] Iniciando sincronização de emojis...")
        try:
            await asyncio.get_running_loop().run_in_executor(None, enable_intents, bot_token, app_id)
        except Exception as e:
            print(f"[Emojis] Falha ao ativar intents: {e}")

        try:
            from functions.emojis import emojis as Emojis
        except Exception as e:
            print(f"[Emojis] Falha ao importar manager de emojis: {e}")
            return

        emoji_manager = Emojis(bot_token, app_id)
        total = len(getattr(emoji_manager, "emojis_db", {}) or {})
        print(f"[Emojis] Total de emojis a sincronizar: {total}")

        async def _run_sync_and_reload():
            try:
                await emoji_manager.sync_all_async()
                try:
                    reload_emoji_class()
                except Exception as e:
                    print(f"[Emojis] Erro ao recarregar classe apos sync: {e}")
            except Exception as e:
                print(f"[Emojis] Falha fatal durante sincronizacao: {type(e).__name__}: {e}")

        asyncio.create_task(_run_sync_and_reload())

    except Exception as e:
        print(f"[Emojis] Erro init_on_startup: {e}")
