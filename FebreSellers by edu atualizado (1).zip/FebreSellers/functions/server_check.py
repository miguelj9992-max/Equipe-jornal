import json
import disnake
from disnake.ext import commands
from functools import wraps
from typing import Optional, Union

_MAIN_SERVER_ID: Optional[int] = None


def get_main_server_id() -> Optional[int]:
    """Obtém o ID do servidor principal do config.json (com cache)."""
    global _MAIN_SERVER_ID

    if _MAIN_SERVER_ID is not None:
        return _MAIN_SERVER_ID

    try:
        with open("config.json", "r", encoding="utf-8") as f:
            config = json.load(f)
            server_id = config.get("bot", {}).get("server")

            if server_id:
                _MAIN_SERVER_ID = int(server_id)
                return _MAIN_SERVER_ID

    except Exception as e:
        print(f"[SERVER_CHECK] Erro ao ler config.json: {e}")

    return None


def is_main_server(guild_id: Union[int, str, None]) -> bool:
    """Verifica se o guild_id é do servidor principal."""
    if guild_id is None:
        return False

    main_server_id = get_main_server_id()
    if main_server_id is None:
        return True  # libera tudo se não tiver config

    try:
        return int(guild_id) == main_server_id
    except Exception:
        return False


def check_server_slash_command():
    def decorator(func):
        if hasattr(func, '_exclude_from_check') and func._exclude_from_check:
            return func

        @wraps(func)
        async def wrapper(self, inter: disnake.ApplicationCommandInteraction, *args, **kwargs):

            # DM ou erro de guild
            if inter.guild_id is None:
                await inter.response.send_message(
                    "Este comando só funciona em servidor.",
                    ephemeral=True
                )
                return

            if not is_main_server(inter.guild_id):
                await inter.response.send_message(
                    "Acesso Negado: Este comando só pode ser usado no servidor principal.",
                    ephemeral=True
                )
                return

            return await func(self, inter, *args, **kwargs)

        return wrapper
    return decorator


def check_server_prefix_command():
    def decorator(func):
        @wraps(func)
        async def wrapper(self, ctx: commands.Context, *args, **kwargs):

            if ctx.guild is None:
                return

            if not is_main_server(ctx.guild.id):
                await ctx.send(
                    "Acesso Negado: Este comando só pode ser usado no servidor principal.",
                    delete_after=10
                )
                return

            return await func(self, ctx, *args, **kwargs)

        return wrapper
    return decorator


def exclude_from_check(func):
    func._exclude_from_check = True
    return func


async def check_server_event(guild_id: Union[int, str, None]) -> bool:
    return is_main_server(guild_id)


def check_interaction_server(inter: Union[disnake.Interaction, disnake.ApplicationCommandInteraction]) -> bool:
    if not inter.guild:
        return False
    return is_main_server(inter.guild.id)


async def send_server_error(inter: Union[disnake.Interaction, disnake.ApplicationCommandInteraction], ephemeral: bool = True):
    msg = "Acesso Negado: Esta ação só pode ser realizada no servidor principal."

    try:
        if not inter.response.is_done():
            await inter.response.send_message(msg, ephemeral=ephemeral)
        else:
            await inter.followup.send(msg, ephemeral=ephemeral)
    except Exception:
        pass
