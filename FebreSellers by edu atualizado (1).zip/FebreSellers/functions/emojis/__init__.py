# functions/emojis/__init__.py
import os
import re
import asyncio
import aiohttp
import json
from .database import load_emojis, save_emojis
from .verify import verify_emojis_batch
from .upload import upload_emoji_async
from .delete import delete_emoji_async

class emojis:
    DB_PATH = "database/emojis/emojis.json"
    ASSETS_PATH = "database/emojis/assets"

    def __init__(self, bot_token: str, app_id: str):
        self.bot_token = bot_token
        self.app_id = app_id
        self.guild_id = app_id  # compatibilidade com código legado
        self.emojis_db = load_emojis() or {}
        self._ensure_emojis_structure()

    def get(self, name: str):
        return self.emojis_db.get(name)

    def list(self):
        return self.emojis_db

    def save(self):
        try:
            save_emojis(self.emojis_db)
        except Exception as e:
            print(f"[Emojis] Falha ao salvar emojis.json: {e}")

    def _ensure_emojis_structure(self):
        if not os.path.exists(self.ASSETS_PATH):
            print(f"[Emojis] Pasta de assets não encontrada: {self.ASSETS_PATH}")
            return
        data = {}
        try:
            for f in os.listdir(self.ASSETS_PATH):
                if f.endswith((".png", ".gif")):
                    data[os.path.splitext(f)[0]] = ""
        except Exception as e:
            print(f"[Emojis] Erro ao escanear assets: {e}")
            return
        if data:
            novos = 0
            for name in data:
                if name not in self.emojis_db:
                    self.emojis_db[name] = ""
                    novos += 1
            if novos:
                self.save()
                print(f"[Emojis] {novos} novos assets adicionados ao banco")

    async def _list_guild_emojis_async(self, session: aiohttp.ClientSession):
        # Application Emojis usam a rota /applications/{app_id}/emojis
        url = f"https://discord.com/api/v10/applications/{self.app_id}/emojis"
        headers = {"Authorization": f"Bot {self.bot_token}"}
        try:
            async with session.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=20)) as r:
                if r.status == 200:
                    data = await r.json()
                    if isinstance(data, dict):
                        return data.get("items", [])
                    elif isinstance(data, list):
                        return data
                else:
                    txt = await r.text()
                    print(f"[Emojis] Falha ao listar emojis: {r.status} - {txt}")
        except Exception as e:
            print(f"[Emojis] Exception ao listar emojis: {e}")
        return []

    def find_guild_emoji(self, name: str, guild_emojis: list):
        for e in guild_emojis:
            if isinstance(e, dict) and e.get("name") == name:
                return e
        return None

    def get_emoji_id(self, name: str, guild_emojis: list):
        g = self.find_guild_emoji(name, guild_emojis)
        return g.get("id") if g else None

    def emoji_name_exists(self, name: str, guild_emojis: list) -> bool:
        return self.find_guild_emoji(name, guild_emojis) is not None

    async def validate_or_create_async(self, session: aiohttp.ClientSession, name: str, guild_emojis: list):
        """
        Retorna (tag, status) onde status é:
          'synced'   - já estava ok, nada a fazer
          'reused'   - reutilizado do Discord pelo nome
          'created'  - novo upload feito com sucesso
          'error'    - falhou (tag será None)
        """
        tag = self.emojis_db.get(name, "")
        create = False

        if not tag:
            create = True
        else:
            match = re.search(r"<a?:\w+:(\d+)>", tag)
            emoji_id = match.group(1) if match else None
            if emoji_id:
                try:
                    verify = await verify_emojis_batch(self.app_id, self.bot_token, [emoji_id])
                    if not verify.get(emoji_id, False):
                        try:
                            await delete_emoji_async(session, self.app_id, self.bot_token, emoji_id)
                        except Exception:
                            pass
                        create = True
                        self.emojis_db[name] = ""
                except Exception:
                    create = True
            else:
                create = True

        if not create:
            return tag, "synced"

        # já existe no Discord pelo nome — reutiliza
        existing = self.find_guild_emoji(name, guild_emojis)
        if existing:
            animated = existing.get("animated", False)
            emoji_id = existing.get("id")
            tag = f"<a:{name}:{emoji_id}>" if animated else f"<:{name}:{emoji_id}>"
            self.emojis_db[name] = tag
            return tag, "reused"

        gif = os.path.join(self.ASSETS_PATH, f"{name}.gif")
        png = os.path.join(self.ASSETS_PATH, f"{name}.png")
        path = gif if os.path.isfile(gif) else png
        if not os.path.isfile(path):
            return None, "error"

        try:
            new_id = await upload_emoji_async(session, name, path, self.app_id, self.bot_token)
        except Exception:
            new_id = None

        if not new_id:
            return None, "error"

        animated = path.endswith(".gif")
        tag = f"<a:{name}:{new_id}>" if animated else f"<:{name}:{new_id}>"
        self.emojis_db[name] = tag
        await asyncio.sleep(0.25)
        return tag, "created"

    def _set_configured_True(self):
        try:
            path = "database/emojis/emojis_data.json"
            data = {"configured": "true", "lastToken": self.bot_token}
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
            print("[Emojis] emojis_data.json atualizado com sucesso")
        except Exception as e:
            print(f"[Emojis] Falha ao atualizar emojis_data.json: {e}")

    async def sync_all_async(self, progress_callback=None, error_callback=None):
        total = len(self.emojis_db)
        success = 0
        errors = 0
        created = 0
        reused = 0
        print(f"[Emojis] Iniciando sincronizacao de {total} emojis...")

        connector = aiohttp.TCPConnector(limit=3)
        async with aiohttp.ClientSession(connector=connector) as session:
            guild_emojis = await self._list_guild_emojis_async(session)
            names = list(self.emojis_db.keys())
            batch_size = 3
            for i in range(0, len(names), batch_size):
                batch = names[i: i + batch_size]
                tasks = [self.validate_or_create_async(session, name, guild_emojis) for name in batch]
                await asyncio.sleep(0.2)
                results = await asyncio.gather(*tasks, return_exceptions=True)
                batch_created = 0
                for name, result in zip(batch, results):
                    if isinstance(result, Exception):
                        errors += 1
                        print(f'  [{name}] erro ao sincronizar: {result}')
                    else:
                        tag, status = result
                        if status == "synced":
                            success += 1
                            print(f'  [{name}] sincronizado com sucesso')
                        elif status == "reused":
                            success += 1
                            reused += 1
                            print(f'  [{name}] emoji ja sincronizado, reutilizando')
                        elif status == "created":
                            success += 1
                            created += 1
                            batch_created += 1
                            print(f'  [{name}] sincronizado com sucesso')
                        else:
                            errors += 1
                            print(f'  [{name}] erro ao sincronizar')

                if batch_created > 0:
                    try:
                        guild_emojis = await self._list_guild_emojis_async(session)
                    except Exception as e:
                        print(f'  [list_emojis] erro ao atualizar lista apos batch: {e}')
                await asyncio.sleep(0.6)

        self.save()
        print(f"\n[Emojis] Concluido: {success}/{total} ok | {created} novos | {reused} reutilizados | {errors} erros")
        if errors == 0:
            self._set_configured_True()
        return success, total
