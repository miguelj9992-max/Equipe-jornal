# functions/emojis/upload.py
import os
import base64
import aiohttp

async def upload_emoji(session: aiohttp.ClientSession, name: str, image_path: str, app_id: str, bot_token: str):
    """
    Upload de um único emoji usando sessão existente.
    Retorna emoji_id (string) em caso de sucesso, ou None em caso de falha.
    """
    try:
        if not os.path.isfile(image_path):
            print(f"[EmojiUpload] Arquivo não encontrado: {image_path}")
            return None

        ext = os.path.splitext(image_path)[1].lower()
        with open(image_path, "rb") as f:
            image_data = f.read()

        tipo = "gif" if ext == ".gif" else "png"
        base64_image = f"data:image/{tipo};base64,{base64.b64encode(image_data).decode()}"

        url = f"https://discord.com/api/v10/applications/{app_id}/emojis"
        headers = {
            "Authorization": f"Bot {bot_token}",
            "Content-Type": "application/json"
        }
        payload = {"name": name, "image": base64_image}

        async with session.post(url, headers=headers, json=payload, timeout=aiohttp.ClientTimeout(total=30)) as r:
            if r.status == 201:
                data = await r.json()
                emoji_id = data.get("id")
                print(f"[EmojiUpload] Emoji '{name}' criado! ID: {emoji_id}")
                return emoji_id
            else:
                txt = await r.text()
                print(f"[EmojiUpload] Erro ao criar '{name}': {r.status} - {txt}")
                return None

    except Exception as e:
        print(f"[EmojiUpload] Falha ao enviar {name}: {e}")
        return None


# compatibilidade: função importada em outros módulos
async def upload_emoji_async(session: aiohttp.ClientSession, name: str, image_path: str, app_id: str, bot_token: str):
    return await upload_emoji(session, name, image_path, app_id, bot_token)


async def upload_emoji_auto_session(name: str, image_path: str, app_id: str, bot_token: str):
    async with aiohttp.ClientSession() as session:
        return await upload_emoji(session, name, image_path, app_id, bot_token)


async def upload_emojis_batch(emojis_data, app_id: str, bot_token: str, max_concurrent: int = 3):
    """
    Upload em série (com limite); emojis_data = [(name, path), ...]
    """
    connector = aiohttp.TCPConnector(limit=max_concurrent)
    async with aiohttp.ClientSession(connector=connector) as session:
        results = []
        for name, path in emojis_data:
            res = await upload_emoji(session, name, path, app_id, bot_token)
            results.append(res)
            # pequeno delay entre uploads para evitar burst / rate limit
            await aiohttp.helpers.sleep(0.35) if hasattr(aiohttp.helpers, "sleep") else __import__("asyncio").sleep(0.35)
        return results
