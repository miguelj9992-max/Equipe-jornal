# functions/emojis/delete.py
import aiohttp
import asyncio


async def delete_emoji_async(
    session: aiohttp.ClientSession, app_id: str, bot_token: str, emoji_id: str
) -> bool:
    # Application Emojis usam a rota /applications/{app_id}/emojis/{emoji_id}
    url = f"https://discord.com/api/v10/applications/{app_id}/emojis/{emoji_id}"
    headers = {"Authorization": f"Bot {bot_token}"}

    async with session.delete(url, headers=headers) as response:
        if response.status == 204:
            print(f"[EmojiDelete] Emoji ID '{emoji_id}' deletado com sucesso!")
            return True
        elif response.status == 404:
            print(f"[EmojiDelete] Emoji ID '{emoji_id}' não encontrado")
            return False
        else:
            text = await response.text()
            print(f"[EmojiDelete] Erro ao deletar emoji ID '{emoji_id}'. Status: {response.status} - {text}")
            return False


def delete_emoji(app_id: str, bot_token: str, emoji_id: str) -> bool:
    return asyncio.run(delete_emoji_wrapper(app_id, bot_token, emoji_id))


async def delete_emoji_wrapper(app_id: str, bot_token: str, emoji_id: str) -> bool:
    async with aiohttp.ClientSession() as session:
        return await delete_emoji_async(session, app_id, bot_token, emoji_id)
