# functions/emojis/verify.py
import aiohttp
import asyncio
import os
import json


def verify_emoji(app_id: str, bot_token: str, emoji_id: str) -> bool:
    return asyncio.run(verify_emoji_async(app_id, bot_token, emoji_id))


async def verify_emoji_async(app_id: str, bot_token: str, emoji_id: str) -> bool:
    config_emoji_path = "configs/config_emoji.json"
    config_emoji = {}
    if os.path.exists(config_emoji_path):
        with open(config_emoji_path, "r", encoding="utf-8") as f:
            config_emoji = json.load(f)

    if config_emoji.get("isConfigured", False):
        return True

    emojis_data_path = "database/emojis/emojis_data.json"
    emojis_data = {}
    if os.path.exists(emojis_data_path):
        with open(emojis_data_path, "r", encoding="utf-8") as f:
            emojis_data = json.load(f)

    configured = emojis_data.get("configured", "false")
    last_token = emojis_data.get("lastToken", "")
    should_verify = configured != "True" or (last_token and last_token != bot_token)

    if not should_verify:
        return True

    # Application Emojis usam a rota /applications/{app_id}/emojis/{emoji_id}
    url = f"https://discord.com/api/v10/applications/{app_id}/emojis/{emoji_id}"
    headers = {"Authorization": f"Bot {bot_token}"}

    async with aiohttp.ClientSession() as session:
        async with session.get(url, headers=headers) as resp:
            return resp.status == 200


async def verify_emojis_batch(
    app_id: str, bot_token: str, emoji_ids: list, max_concurrent: int = 20
) -> dict:
    config_emoji_path = "configs/config_emoji.json"
    config_emoji = {}
    if os.path.exists(config_emoji_path):
        with open(config_emoji_path, "r", encoding="utf-8") as f:
            config_emoji = json.load(f)

    if config_emoji.get("isConfigured", False):
        return {emoji_id: True for emoji_id in emoji_ids}

    emojis_data_path = "database/emojis/emojis_data.json"
    emojis_data = {}
    if os.path.exists(emojis_data_path):
        with open(emojis_data_path, "r", encoding="utf-8") as f:
            emojis_data = json.load(f)

    configured = emojis_data.get("configured", "false")
    last_token = emojis_data.get("lastToken", "")
    should_verify = configured != "True" or (last_token and last_token != bot_token)

    if not should_verify:
        return {emoji_id: True for emoji_id in emoji_ids}

    connector = aiohttp.TCPConnector(limit=max_concurrent)
    async with aiohttp.ClientSession(connector=connector) as session:
        tasks = [_verify_single_emoji(session, app_id, bot_token, eid) for eid in emoji_ids]
        results = await asyncio.gather(*tasks, return_exceptions=True)

    return dict(zip(emoji_ids, [r if not isinstance(r, Exception) else False for r in results]))


async def _verify_single_emoji(
    session: aiohttp.ClientSession, app_id: str, bot_token: str, emoji_id: str
) -> bool:
    url = f"https://discord.com/api/v10/applications/{app_id}/emojis/{emoji_id}"
    headers = {"Authorization": f"Bot {bot_token}"}
    try:
        async with session.get(url, headers=headers) as resp:
            return resp.status == 200
    except Exception as e:
        print(f"[EmojiVerify] Erro ao verificar emoji '{emoji_id}': {e}")
        return False
