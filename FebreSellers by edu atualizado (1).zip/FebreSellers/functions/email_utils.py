import json
import os
import smtplib
import ssl
import asyncio
import re
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from functions.database import database as db

CONFIG_EMAIL_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "configs", "config_email.json")

_sender_config_cache = None


def is_valid_email(email: str) -> bool:
    """Valida se uma string é um email válido."""
    if not email:
        return False
    pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    return bool(re.match(pattern, email))


def _get_sender_config() -> dict:
    """
    Carrega as credenciais FIXAS do email do bot (lunarapplications2026@gmail.com)
    a partir de configs/config_email.json. Essas credenciais são as mesmas para
    todos os servidores que usam o bot — o usuário não configura isso, apenas
    o email de destino.
    """
    global _sender_config_cache
    if _sender_config_cache is not None:
        return _sender_config_cache

    print(f"[EMAIL][DEBUG] Tentando carregar config de: {CONFIG_EMAIL_PATH}")
    print(f"[EMAIL][DEBUG] Arquivo existe? {os.path.isfile(CONFIG_EMAIL_PATH)}")

    try:
        with open(CONFIG_EMAIL_PATH, "r", encoding="utf-8") as f:
            _sender_config_cache = json.load(f)
        print(f"[EMAIL][DEBUG] Config carregada: smtp_user={_sender_config_cache.get('smtp_user')!r} | smtp_pass_len={len(_sender_config_cache.get('smtp_pass') or '')}")
    except FileNotFoundError:
        print(f"[EMAIL][DEBUG] ERRO: arquivo não encontrado em {CONFIG_EMAIL_PATH}")
        _sender_config_cache = {}
    except json.JSONDecodeError as e:
        print(f"[EMAIL][DEBUG] ERRO: JSON inválido em config_email.json: {e}")
        _sender_config_cache = {}

    return _sender_config_cache


def _send_email_sync(dest_email: str, subject: str, body_text: str, body_html: str = None):
    """Parte síncrona/bloqueante do envio (executada em thread separada)."""
    sender_config = _get_sender_config()

    smtp_server = sender_config.get("smtp_server", "smtp.gmail.com")
    smtp_port = sender_config.get("smtp_port", 587)
    smtp_user = sender_config.get("smtp_user")
    smtp_pass = sender_config.get("smtp_pass")
    use_tls = sender_config.get("use_tls", True)

    if not smtp_user or not smtp_pass or smtp_pass == "COLOQUE_AQUI_A_SENHA_DE_APP_DO_GMAIL":
        raise RuntimeError(
            "Credenciais do email do bot não configuradas. "
            "Edite configs/config_email.json e coloque a senha de app do Gmail em 'smtp_pass'."
        )

    message = MIMEMultipart("alternative")
    message["Subject"] = subject
    message["From"] = f" <{smtp_user}>"
    message["To"] = dest_email

    message.attach(MIMEText(body_text, "plain"))
    if body_html:
        message.attach(MIMEText(body_html, "html"))

    context = ssl.create_default_context()

    with smtplib.SMTP(smtp_server, smtp_port, timeout=20) as server:
        if use_tls:
            server.starttls(context=context)
        server.login(smtp_user, smtp_pass)
        server.sendmail(smtp_user, dest_email, message.as_string())


async def send_notification_email(subject: str, body_text: str, body_html: str = None):
    """
    Envia um email de notificação para o email configurado pelo usuário no painel
    (/painel > configurações > notificações > Email), usando sempre o email fixo
    do bot (lunarapplications2026@gmail.com) como remetente.
    """
    config = db.get_document("notifications_email_config")
    if not config or not config.get("enabled"):
        return False, "Notificações por email desativadas."

    dest_email = config.get("email")
    if not dest_email or not is_valid_email(dest_email):
        return False, "Nenhum email de destino configurado."

    try:
        # smtplib é bloqueante, então roda em uma thread separada para não
        # travar o event loop do bot enquanto o email é enviado.
        await asyncio.to_thread(_send_email_sync, dest_email, subject, body_text, body_html)
        return True, "Email enviado com sucesso."
    except smtplib.SMTPAuthenticationError:
        return False, "Erro ao enviar email: autenticação falhou (verifique a senha de app do Gmail)."
    except Exception as e:
        return False, f"Erro ao enviar email: {str(e)}"