"""
Banco Inter Payment Integration
Integração com a API do Banco Inter para pagamentos PIX
Documentação: https://developers.inter.co/references/cobrancas
"""

import aiohttp
import uuid
import base64
import ssl
import time
from pathlib import Path
from typing import Any, Dict, Optional

from functions.database import database as db

INTER_API_BASE  = "https://cdpj.partners.bancointer.com.br"
INTER_TOKEN_URL = f"{INTER_API_BASE}/oauth/v2/token"
# Endpoint correto para cobrança PIX imediata (cob)
INTER_COB_URL   = f"{INTER_API_BASE}/cobranca/v3/cobrancas"
# Endpoint para buscar QR Code de uma cobrança
INTER_QR_URL    = f"{INTER_API_BASE}/cobranca/v3/cobrancas/{{txid}}/qrcode"


def _load_config() -> dict:
    return db.get_document("payment_configs") or {}


def _get_inter_config() -> dict:
    cfg = _load_config().get("inter") or {}
    if not cfg.get("client_id"):
        raise ValueError("Client ID do Inter não configurado. Configure em Configurações > Formas de Pagamento > Pix > Inter")
    if not cfg.get("client_secret"):
        raise ValueError("Client Secret do Inter não configurado. Configure em Configurações > Formas de Pagamento > Pix > Inter")
    if not cfg.get("pix_key"):
        raise ValueError("Chave Pix do Inter não configurada. Configure em Configurações > Formas de Pagamento > Pix > Inter")
    cert_file = cfg.get("cert_file")
    key_file  = cfg.get("key_file")
    if not cert_file or not Path(cert_file).exists():
        raise ValueError("Certificado .crt do Inter não encontrado. Reconfigure em Configurações > Formas de Pagamento > Pix > Inter")
    if not key_file or not Path(key_file).exists():
        raise ValueError("Chave privada .key do Inter não encontrada. Reconfigure em Configurações > Formas de Pagamento > Pix > Inter")
    return cfg


def _build_ssl_context(cert_file: str, key_file: str) -> ssl.SSLContext:
    """Cria SSLContext com o certificado mTLS do Inter."""
    ctx = ssl.create_default_context()
    ctx.load_cert_chain(certfile=cert_file, keyfile=key_file)
    return ctx


async def _get_access_token(
    client_id: str,
    client_secret: str,
    cert_file: str,
    key_file: str,
    scopes: str = "cob.write cob.read pix.read",
) -> str:
    """Obtém o access_token OAuth2 do Banco Inter via mTLS."""
    ssl_ctx = _build_ssl_context(cert_file, key_file)
    credentials = base64.b64encode(f"{client_id}:{client_secret}".encode()).decode()

    headers = {
        "Authorization": f"Basic {credentials}",
        "Content-Type": "application/x-www-form-urlencoded",
    }
    data = {
        "grant_type": "client_credentials",
        "scope": scopes,
    }

    async with aiohttp.ClientSession() as session:
        async with session.post(
            INTER_TOKEN_URL,
            headers=headers,
            data=data,
            ssl=ssl_ctx,
        ) as resp:
            body = await resp.json()
            if resp.status != 200:
                raise RuntimeError(f"Erro ao obter token Inter: {body}")
            return body["access_token"]


async def create_inter_payment(
    client_id: str,
    client_secret: str,
    pix_key: str,
    cert_file: str,
    key_file: str,
    amount: float,
    description: str = "Pagamento",
    expiry_seconds: int = 3600,
    transaction_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Cria uma cobrança PIX imediata via Banco Inter (API v3).

    Returns:
        {
            "payment_id": str,       # txid da cobrança
            "qr_code": str,          # copia-e-cola (payload PIX)
            "qr_code_image": str,    # base64 PNG do QR Code
            "expiry": int,           # timestamp Unix de expiração
            "amount": float,
        }
    """
    # Sanitizar chave PIX antes de usar
    pix_key = pix_key.strip() if pix_key else ""
    if not pix_key:
        raise ValueError("Chave PIX não pode ser vazia.")

    # txid: 26-35 chars alfanuméricos (sem hífen)
    txid = (transaction_id or str(uuid.uuid4())).replace("-", "")[:35]

    ssl_ctx = _build_ssl_context(cert_file, key_file)
    token = await _get_access_token(client_id, client_secret, cert_file, key_file)

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }

    # Payload correto para API v3 do Inter
    payload = {
        "seuNumero": txid[:25],          # identificador único do pagador (max 25)
        "valorTotal": f"{amount:.2f}",   # valor como string com 2 casas
        "dataVencimento": _get_due_date(expiry_seconds),
        "numDiasAgenda": 1,
        "pagador": {
            "cpfCnpj": "00000000000",    # CPF genérico (obrigatório pela API)
            "tipoPessoa": "FISICA",
            "nome": "Pagador",
            "email": "",
            "ddd": "",
            "telefone": "",
            "cep": "",
            "numero": "",
            "complemento": "",
            "bairro": "",
            "cidade": "",
            "uf": "SP",
            "endereco": "",
        },
        "mensagem": {
            "linha1": description[:75] if description else "Pagamento",
        },
        "desconto": {"codigo": "NAOTEMDESCONTO"},
        "multa":    {"codigo": "NAOTEMMULTA"},
        "mora":     {"codigo": "ISENTO"},
        "finalidade": "OUTROS",
        "chave": pix_key,
    }

    async with aiohttp.ClientSession() as session:
        # Criar cobrança
        async with session.post(
            INTER_COB_URL,
            json=payload,
            headers=headers,
            ssl=ssl_ctx,
        ) as resp:
            body = await resp.json()
            if resp.status not in (200, 201):
                err = body.get("message") or body.get("mensagem") or str(body)
                raise RuntimeError(f"Erro ao criar cobrança Inter: {err}")
            # A API retorna o txid gerado
            txid_retornado = body.get("codigoSolicitacao") or txid

        # Buscar QR Code
        qr_code_str = ""
        qr_code_b64 = ""
        qr_url = INTER_QR_URL.format(txid=txid_retornado)
        async with session.get(
            qr_url,
            headers=headers,
            ssl=ssl_ctx,
        ) as resp:
            if resp.status == 200:
                detail = await resp.json()
                qr_code_str = detail.get("qrcode", "")
                qr_code_b64 = detail.get("imagemQrcode", "")

    return {
        "payment_id": txid_retornado,
        "qr_code": qr_code_str,
        "qr_code_image": qr_code_b64,
        "expiry": int(time.time()) + expiry_seconds,
        "amount": amount,
    }


def _get_due_date(expiry_seconds: int) -> str:
    """Retorna a data de vencimento no formato YYYY-MM-DD."""
    import datetime
    due = datetime.datetime.utcnow() + datetime.timedelta(seconds=expiry_seconds)
    return due.strftime("%Y-%m-%d")


async def check_inter_payment(
    client_id: str,
    client_secret: str,
    cert_file: str,
    key_file: str,
    txid: str,
) -> Dict[str, Any]:
    """
    Consulta o status de uma cobrança PIX Inter.

    Returns:
        {
            "paid": bool,
            "status": str,
            "raw": dict,
        }
    """
    ssl_ctx = _build_ssl_context(cert_file, key_file)
    token = await _get_access_token(
        client_id, client_secret, cert_file, key_file,
        scopes="cob.read pix.read",
    )

    headers = {"Authorization": f"Bearer {token}"}

    async with aiohttp.ClientSession() as session:
        async with session.get(
            f"{INTER_COB_URL}/{txid}",
            headers=headers,
            ssl=ssl_ctx,
        ) as resp:
            body = await resp.json()
            if resp.status != 200:
                raise RuntimeError(f"Erro ao consultar cobrança Inter: {body}")

    status = body.get("situacao", "")
    # Cobrança paga = situação PAGO ou RECEBIDO
    paid = status in ("PAGO", "RECEBIDO", "CONCLUIDA")

    return {
        "paid": paid,
        "status": status,
        "raw": body,
    }


# ── Settings-backed wrappers (usados pelo bot) ────────────────────────────────

async def create_inter_payment_from_settings(
    amount: float,
    description: str = "Pagamento",
    expiry_seconds: int = 3600,
    transaction_id: Optional[str] = None,
) -> Dict[str, Any]:
    cfg = _get_inter_config()
    return await create_inter_payment(
        client_id=cfg["client_id"],
        client_secret=cfg["client_secret"],
        pix_key=cfg["pix_key"],
        cert_file=cfg["cert_file"],
        key_file=cfg["key_file"],
        amount=amount,
        description=description,
        expiry_seconds=expiry_seconds,
        transaction_id=transaction_id,
    )


async def check_inter_payment_from_settings(txid: str) -> Dict[str, Any]:
    cfg = _get_inter_config()
    return await check_inter_payment(
        client_id=cfg["client_id"],
        client_secret=cfg["client_secret"],
        cert_file=cfg["cert_file"],
        key_file=cfg["key_file"],
        txid=txid,
    )
