"""
Modal base com tratamento de erro centralizado.

Por padrão, quando um erro ocorre dentro do callback de um disnake.ui.Modal,
o próprio disnake captura a exceção e chama Modal.on_error(), cuja implementação
padrão apenas faz `traceback.print_exception(...)` para o stderr.

Isso NUNCA passa pelo bot.dispatch(...), então listeners como
`on_interaction_error` (usado em events/interaction_monitor.py para logar
no console/webhook) nunca são chamados para erros de Modal. Resultado:
a interação falha no Discord ("A interação falhou") e nada aparece nos logs
monitorados.

Basta herdar de LoggedModal no lugar de disnake.ui.Modal para corrigir isso.
"""
import sys
import traceback

import disnake


class LoggedModal(disnake.ui.Modal):
    async def on_error(self, error: Exception, interaction: disnake.ModalInteraction) -> None:
        # Mantém o comportamento padrão (log no console/stderr)
        traceback.print_exception(error.__class__, error, error.__traceback__, file=sys.stderr)

        # Repassa o erro para o sistema central de monitoramento
        # (events/interaction_monitor.py escuta "on_interaction_error")
        try:
            interaction.bot.dispatch("interaction_error", interaction, error)
        except Exception:
            pass

        # Avisa o usuário em vez de deixar a interação falhar silenciosamente
        try:
            from functions.message import message
            texto = "Ocorreu um erro ao processar essa ação. Tente novamente."
            if interaction.response.is_done():
                await message.error(interaction, texto)
            else:
                await message.error(interaction, texto, send=True)
        except Exception:
            pass