"""
Vigia (watchdog) do event loop.

Objetivo: detectar e LOGAR sempre que o event loop do bot ficar travado por
mais tempo que o esperado. Isso não depende de saber qual código está
bloqueando — ele mede o tempo real do relógio vs. o tempo que deveria ter
passado num `asyncio.sleep`. Se algum código em qualquer lugar (uma task, um
comando, uma lib de terceiros) travar o loop com uma chamada síncrona/lenta,
esse watchdog aparece no log com o horário exato e a duração do travamento —
o que deve bater com o horário de um "Bot disconnected from Discord" causado
por perda de heartbeat.

Como ler o log:
  - "Loop travado por X.XXs" com X > ~5s é forte candidato a causar
    desconexão do gateway (o Discord espera heartbeat a cada ~41s, mas
    travamentos de vários segundos já atrasam tudo e são sinal de bug).
  - Se esse aviso aparecer JUNTO (mesmo minuto) de um "Bot disconnected from
    Discord" no log do websocket_ready.py, achamos o culpado: é uma chamada
    bloqueante em algum lugar do código, não é falta de RAM.
"""

import asyncio
import io
import logging
import math
import os
import sys
import threading
import time
import traceback
from datetime import datetime

from disnake.ext import commands, tasks

logger = logging.getLogger("loop_watchdog")

CHECK_INTERVAL_SECONDS = 1.0
# Tolerância: só loga se o atraso passar disso (evita ruído de pequenas
# variações normais do sistema operacional/scheduler)
WARN_THRESHOLD_SECONDS = 0.5
# Auto-recuperação: se o event loop ficar congelado por mais que isso, o
# processo se encerra sozinho para a plataforma reiniciar o bot. Um
# travamento dessa duração já derrubou o gateway do Discord de qualquer
# forma — ficar vivo congelado só mantém o bot offline para sempre.
FREEZE_SELF_KILL_SECONDS = 90


def _dump_running_tasks_stacks() -> str:
    """Tira uma 'foto' da pilha de chamadas (arquivo + linha) de todas as
    tasks asyncio vivas no momento. Isso mostra EXATAMENTE qual função/linha
    de código estava rodando quando o loop travou — é a forma mais direta de
    achar o culpado de um travamento sem precisar adivinhar.
    Observação: para uma task rodando código síncrono bloqueante (ex: uma
    chamada `requests.get` direta, sem executor), a "foto" vai mostrar a
    linha exata onde ela ficou presa esperando a rede responder.
    """
    buf = io.StringIO()
    tasks_now = asyncio.all_tasks()
    buf.write(f"--- {len(tasks_now)} task(s) ativa(s) no momento do travamento ---\n")
    for t in tasks_now:
        name = t.get_name() if hasattr(t, "get_name") else str(t)
        buf.write(f"\n[Task: {name}]\n")
        try:
            t.print_stack(file=buf)
        except Exception as e:
            buf.write(f"  (não foi possível obter stack: {e})\n")
    return buf.getvalue()


class LoopWatchdog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._last_tick = None
        self.watchdog_loop.start()
        # Thread paralela de auto-recuperação: se o event loop congelar por
        # mais que FREEZE_SELF_KILL_SECONDS (ex.: chamada de rede síncrona sem
        # timeout em algum lugar — algo que não aparece nas stacks do asyncio),
        # encerra o processo. A plataforma reinicia o bot e ele volta ao ar
        # sozinho, em vez de ficar offline até alguém reiniciar na mão.
        self._kill_thread = threading.Thread(target=self._freeze_self_check, daemon=True)
        self._kill_thread.start()

    def _freeze_self_check(self) -> None:
        while True:
            time.sleep(5)
            last = self._last_tick
            if last is not None and (time.monotonic() - last) > FREEZE_SELF_KILL_SECONDS:
                frozen_for = int(time.monotonic() - last)
                print(
                    f"[Watchdog] Event loop congelado por {frozen_for}s "
                    f"(limite {FREEZE_SELF_KILL_SECONDS}s) — encerrando o processo "
                    f"para a plataforma reiniciar o bot automaticamente."
                )
                # Imprimir a stack da MAIN THREAD neste exato momento. O dump
                # de tasks do watchdog só roda DEPOIS que o loop descongela
                # (por isso nunca mostrou o culpado — todas as tasks já
                # estavam "dormindo"). Esta thread roda FORA do loop, então
                # consegue ver o frame exato onde a main thread está presa
                # (ex.: chamada síncrona de rede/IMAP/socket sem timeout).
                try:
                    main_thread_id = threading.main_thread().ident
                    print("[Watchdog] Stack da main thread durante o congelamento:")
                    for thread_id, frame in sys._current_frames().items():
                        if thread_id == main_thread_id:
                            traceback.print_stack(frame)
                except Exception as exc:
                    print(f"[Watchdog] Não foi possível capturar stack da main thread: {exc}")
                os._exit(1)

    def cog_unload(self):
        self.watchdog_loop.cancel()

    @staticmethod
    def _safe_latency_ms(latency) -> str:
        """Formata a latência do gateway sem nunca lançar exceção.

        Quando o websocket do Discord cai, o disnake define ``bot.latency``
        como ``inf`` (e ``inf`` é truthy!). ``round(inf * 1000)`` levanta
        OverflowError, que matava este watchdog inteiro (task de fundo sem
        try/except) bem no momento em que mais precisávamos dele — logo
        depois de uma desconexão do gateway.
        """
        try:
            if latency and math.isfinite(latency):
                return str(round(latency * 1000))
        except (TypeError, ValueError, OverflowError):
            pass
        return "?"

    @tasks.loop(seconds=CHECK_INTERVAL_SECONDS)
    async def watchdog_loop(self):
        try:
            now = time.monotonic()

            if self._last_tick is not None:
                expected = CHECK_INTERVAL_SECONDS
                actual = now - self._last_tick
                lag = actual - expected

                if lag > WARN_THRESHOLD_SECONDS:
                    latency_ms = self._safe_latency_ms(self.bot.latency)
                    logger.warning(
                        f"⚠️ Loop travado por {lag:.2f}s (esperado {expected:.1f}s, "
                        f"levou {actual:.2f}s) | ws_latency={latency_ms}ms | "
                        f"horário={datetime.now().strftime('%H:%M:%S')}"
                    )
                    # Isso só consegue mostrar a pilha de tasks que ainda estão
                    # rodando DENTRO do asyncio (ex: presas num `await` demorado).
                    # Se o travamento foi uma chamada síncrona pura (ex: uma
                    # função sem `async`/`await` no meio do caminho, tipo
                    # `requests.get` fora de executor), a task correspondente
                    # aparece "congelada" na linha exata que chamou essa função —
                    # geralmente é exatamente isso que aparece aqui.
                    logger.warning(_dump_running_tasks_stacks())

            self._last_tick = now
        except Exception:
            # O watchdog é a única ferramenta que detecta travamentos do
            # event loop — ele nunca pode morrer. Qualquer erro inesperado
            # aqui é logado e a próxima iteração continua monitorando.
            logger.exception("[Watchdog] Erro inesperado no ciclo (monitoramento continua).")

    @watchdog_loop.before_loop
    async def before_watchdog(self):
        await self.bot.wait_until_ready()
        logger.info("[Watchdog] Monitoramento de travamento do event loop iniciado.")


def setup(bot: commands.Bot):
    bot.add_cog(LoopWatchdog(bot))
