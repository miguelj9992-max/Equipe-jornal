import time
from typing import Optional, Callable, Iterable

import disnake

from functions.database import database as db
from functions.emoji import emoji


def obter_canal_id(chave: str) -> Optional[int]:
    dados = db.get_document("canais") or {}
    valor = dados.get(chave)

    if not valor:
        return None

    try:
        return int(valor)

    except (TypeError, ValueError):
        return None


def criar_container_log(
    titulo: str,
    linhas: list[str],
    imagem_filename: Optional[str] = None
) -> disnake.ui.Container:

    linhas_filtradas = [l for l in linhas if l]

    corpo = (
        "\n".join(linhas_filtradas)
        if linhas_filtradas
        else ""
    )

    colors = db.get_document("custom_colors") or {}

    primary_color = colors.get(
        "primary",
        "#ffffff"
    )

    children = [
        disnake.ui.TextDisplay(
            f"##  \n"
            f"-# {titulo}"
        ),

        disnake.ui.Separator(),

        disnake.ui.TextDisplay(corpo),
    ]

    # Componentes V2 não exibem anexos automaticamente; é preciso referenciá-los
    # explicitamente via attachment://<nome do arquivo> dentro de um componente.
    if imagem_filename:
        children.append(disnake.ui.Separator(spacing=disnake.SeparatorSpacing.small))
        children.append(
            disnake.ui.MediaGallery(
                disnake.MediaGalleryItem(f"attachment://{imagem_filename}")
            )
        )

    children.append(disnake.ui.Separator())

    children.append(
        disnake.ui.TextDisplay(
            f"{emoji.calendar} **Data:** "
            f"<t:{int(time.time())}:f> "
            f"(<t:{int(time.time())}:R>)"
        )
    )

    return disnake.ui.Container(
        *children,

        accent_colour=disnake.Colour(
            int(primary_color.replace("#", ""), 16)
        )
    )


def criar_embed_log(
    guild: disnake.Guild,
    titulo: str,
    linhas: list[str],
    imagem_filename: Optional[str] = None
) -> disnake.Embed:

    linhas_filtradas = [l for l in linhas if l]

    corpo = (
        "\n".join(linhas_filtradas)
        if linhas_filtradas
        else "Nenhuma informação adicional."
    )

    colors = db.get_document("custom_colors") or {}

    primary_color = colors.get(
        "primary",
        "#ffffff"
    )

    embed = disnake.Embed(
        title=titulo,
        description=corpo,
        color=disnake.Colour(
            int(primary_color.replace("#", ""), 16)
        )
    )

    if imagem_filename:
        embed.set_image(f"attachment://{imagem_filename}")

    return embed


async def enviar_log_container(
    guild: disnake.Guild,
    canal_id: Optional[int],
    titulo: str,
    linhas: list[str],
    extra_components: Optional[list] = None,
) -> Optional[disnake.Message]:

    if not canal_id:
        return None

    canal = guild.get_channel(canal_id)

    if not canal:
        return None

    try:
        container = criar_container_log(
            titulo,
            linhas
        )

        components = [container]

        if extra_components:
            components.extend(extra_components)

        return await canal.send(
            components=components,
            flags=disnake.MessageFlags(
                is_components_v2=True
            ),
            allowed_mentions=disnake.AllowedMentions.none()
        )

    except Exception:
        return None


async def enviar_log(
    guild: disnake.Guild,
    canal_id: Optional[int],
    titulo: str,
    linhas: list[str],
    extra_components: Optional[list] = None,
    file: Optional[disnake.File] = None,
    allowed_mentions: Optional[disnake.AllowedMentions] = None
) -> Optional[disnake.Message]:

    if not canal_id:
        return None

    canal = guild.get_channel(canal_id)

    if not canal:
        return None

    mode = (
        db.get_document("custom_mode") or {}
    ).get("mode", "embed")

    # Por padrão mantém o comportamento antigo (menção sem notificação/ping).
    # Chamadores podem passar allowed_mentions explicitamente (ex: para permitir
    # notificação real da menção) através do parâmetro acima.
    mentions = allowed_mentions if allowed_mentions is not None else disnake.AllowedMentions.none()

    try:

        if mode == "components":

            container = criar_container_log(
                titulo,
                linhas,
                imagem_filename=file.filename if file else None
            )

            components = [container]

            if extra_components:
                components.extend(extra_components)

            message = await canal.send(
                components=components,
                file=file,
                flags=disnake.MessageFlags(
                    is_components_v2=True
                ),
                allowed_mentions=mentions
            )

        else:

            embed = criar_embed_log(
                guild,
                titulo,
                linhas,
                imagem_filename=file.filename if file else None
            )

            message = await canal.send(
                embed=embed,
                components=extra_components,
                file=file,
                allowed_mentions=mentions
            )

        return message

    except Exception as e:
        print(
            f"[LOG ERROR] "
            f"Erro ao enviar log: {e}"
        )

        return None


async def buscar_executor_auditlog(
    guild: disnake.Guild,
    actions: Iterable[disnake.AuditLogAction],
    matcher: Callable[[disnake.AuditLogEntry], bool],
    max_age_seconds: int = 60,
    retries: int = 3,
    delay_seconds: float = 0.8,
) -> Optional[disnake.abc.User]:

    agora = time.time()

    try:

        for _ in range(retries):

            for action in actions:

                async for entry in guild.audit_logs(
                    action=action,
                    limit=20
                ):

                    created = getattr(
                        entry,
                        "created_at",
                        None
                    )

                    if (
                        created
                        and (
                            agora - created.timestamp()
                        ) > max_age_seconds
                    ):
                        break

                    try:

                        if matcher(entry):
                            return entry.user

                    except Exception:
                        continue

            try:
                import asyncio

                await asyncio.sleep(delay_seconds)

            except Exception:
                pass

    except Exception:
        return None

    return None


def verificar_guild(guild: int) -> bool:
    """
    Verifica se o servidor é o servidor do bot.
    """

    config = db.obter("config.json")

    guild_id = config["bot"]["server"]

    if not guild_id:
        return False

    return str(guild) == str(guild_id)