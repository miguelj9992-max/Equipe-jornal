"""
WebSocket initialization event
"""

import disnake
from disnake.ext import commands
import logging
import asyncio
import math
from datetime import datetime

logger = logging.getLogger(__name__)

class WebSocketReady(commands.Cog):
    """Handle WebSocket initialization when bot is ready"""
    
    def __init__(self, bot):
        self.bot = bot
        self.websocket_initialized = False

    @staticmethod
    def _safe_latency_ms(latency) -> str:
        """Formata a latência do gateway sem nunca lançar exceção.

        No disnake, quando o websocket cai, ``bot.latency`` vira ``inf``
        (valor truthy!). ``round(inf * 1000)`` levanta OverflowError — era
        essa exceção que derrubava o on_disconnect/on_resumed no meio do
        tratamento da desconexão (e o bot ficava sem log nem aviso).
        """
        try:
            if latency and math.isfinite(latency):
                return str(round(latency * 1000))
        except (TypeError, ValueError, OverflowError):
            pass
        return "?"
        
    @commands.Cog.listener()
    async def on_ready(self):
        """Initialize WebSocket connection when bot is ready"""
        
        # Prevent multiple initializations
        if self.websocket_initialized:
            return
            
        self.websocket_initialized = True
        
        # Store bot start time
        if not hasattr(self.bot, 'start_time'):
            self.bot.start_time = datetime.now()
        
        logger.info(f"Bot {self.bot.user.name} is ready!")
        logger.info(f"Bot ID: {self.bot.user.id}")
        logger.info(f"Guilds: {len(self.bot.guilds)}")
        
        # CORREÇÃO: este cog chegou a inicializar seu PRÓPRIO SocketIOManager
        # via `connections.initialize()`, independente do gerenciador já
        # criado por `events/on_ready.py` (OnLoad._initialize_cloud_websocket,
        # que usa `modules/cloud/update_api.get_websocket_manager()`).
        # Nada no projeto lê `bot.ws_manager` (o valor que `connections.initialize`
        # define) — ou seja, essa segunda conexão era só um cliente Socket.IO
        # extra, tentando se conectar ao mesmo endpoint em paralelo.
        # Resultado no log: duas mensagens duplicadas de
        # "[SocketIO] Erro na tentativa de conexão..." a cada ciclo de 5s,
        # duas tasks `_connect_loop` simultâneas, DNS/handshake em dobro e
        # mais uma fonte de contenção para a event loop (contribuindo para os
        # avisos "Loop travado"). Isso não altera a aprovação de pagamento em
        # si (que depende do IMAP do Nubank / do polling de pagamento em
        # checkout.py), mas remove ruído e carga desnecessária no loop.
        # A inicialização real do WebSocket do Cloud continua acontecendo
        # normalmente em `events/on_ready.py`.
        logger.info(
            "Connection Manager: inicialização delegada a events/on_ready.py "
            "(evita segunda conexão Socket.IO duplicada)."
        )
    
    @commands.Cog.listener()
    async def on_disconnect(self):
        """Handle bot disconnect"""
        self._disconnect_count = getattr(self, "_disconnect_count", 0) + 1
        latency_ms = self._safe_latency_ms(self.bot.latency)
        logger.warning(
            f"🔌 Bot disconnected from Discord | disconexão nº {self._disconnect_count} | "
            f"última latência conhecida={latency_ms}ms | "
            f"horário={datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        )

        # Notify WebSocket manager if connected
        if hasattr(self.bot, 'websocket_manager') and self.bot.websocket_manager:
            try:
                await self.bot.websocket_manager.emit_event('bot_disconnected', {
                    'timestamp': datetime.now().isoformat()
                })
            except:
                pass
    
    @commands.Cog.listener()
    async def on_resumed(self):
        """Handle bot resume after disconnect"""
        latency_ms = self._safe_latency_ms(self.bot.latency)
        logger.info(
            f"✅ Bot connection resumed | latência={latency_ms}ms | "
            f"horário={datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        )
        
        # Notify WebSocket manager if connected
        if hasattr(self.bot, 'websocket_manager') and self.bot.websocket_manager:
            try:
                await self.bot.websocket_manager.emit_event('bot_resumed', {
                    'timestamp': datetime.now().isoformat()
                })
            except:
                pass
    
    def cog_unload(self):
        """Cleanup when cog is unloaded"""
        if hasattr(self.bot, 'websocket_manager') and self.bot.websocket_manager:
            asyncio.create_task(self.bot.websocket_manager.disconnect())

def setup(bot):
    bot.add_cog(WebSocketReady(bot))
