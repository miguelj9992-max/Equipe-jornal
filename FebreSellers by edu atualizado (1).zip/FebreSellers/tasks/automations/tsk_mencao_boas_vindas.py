import asyncio
import traceback

import disnake
from disnake.ext import commands

from modules.automations.mencao_boas_vindas import helpers


class MencaoBoasVindasTask(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._send_semaphore = asyncio.Semaphore(10)
        print("[MencaoBoasVindas] Cog carregado com sucesso.")

    async def _apagar_depois(self, msg: disnake.Message, segundos: int) -> None:
        try:
            await asyncio.sleep(max(1, segundos))
            await msg.delete()
        except Exception as e:
            print(f"[MencaoBoasVindas] Falha ao apagar mensagem: {e}")

    async def _enviar_mencao(self, member: disnake.Member) -> None:
        """Envia a menção de boas-vindas e agenda sua exclusão, se configurado."""
        if not member or not getattr(member, "guild", None):
            print("[MencaoBoasVindas] Ignorado: member ou guild inválido.")
            return

        config = helpers.carregar_config()
        print(f"[MencaoBoasVindas] Config carregada: {config}")

        if not bool(config.get("ativado", False)):
            print("[MencaoBoasVindas] Ignorado: automação está DESATIVADA na config.")
            return

        canal = helpers.obter_canal(member.guild)
        if not canal:
            print(f"[MencaoBoasVindas] Ignorado: canal não encontrado. canal_id salvo = {config.get('canal_id')!r}. "
                  f"Verifique se o bot tem acesso a esse canal e se ele ainda existe.")
            return

        print(f"[MencaoBoasVindas] Canal resolvido: #{canal.name} ({canal.id})")

        perms = canal.permissions_for(member.guild.me)
        if not perms.send_messages:
            print(f"[MencaoBoasVindas] Ignorado: o bot NÃO tem permissão de enviar mensagens em #{canal.name}.")
            return

        conteudo = helpers.formatar_mensagem(config.get("mensagem", "{user}"), member)
        if not conteudo:
            print("[MencaoBoasVindas] Ignorado: mensagem formatada ficou vazia.")
            return

        print(f"[MencaoBoasVindas] Enviando mensagem: {conteudo!r} para {member} em #{canal.name}")

        async with self._send_semaphore:
            tentativa = 0
            while tentativa < 3:
                try:
                    msg = await canal.send(
                        content=conteudo,
                        allowed_mentions=disnake.AllowedMentions(users=True),
                    )
                    print(f"[MencaoBoasVindas] Mensagem enviada com sucesso (id={msg.id}).")

                    tempo = int(config.get("tempo_segundos", 5) or 0)
                    if msg and tempo > 0:
                        asyncio.create_task(self._apagar_depois(msg, tempo))
                    break
                except Exception as e:
                    print(f"[MencaoBoasVindas] ERRO ao enviar mensagem (tentativa {tentativa + 1}/3): {e}")
                    traceback.print_exc()
                    await asyncio.sleep(0.5 * (2 ** tentativa))
                    tentativa += 1

    @commands.Cog.listener()
    async def on_member_join(self, member: disnake.Member):
        """Disparado quando um membro entra no servidor."""
        print(f"[MencaoBoasVindas] on_member_join disparado para {member} no servidor {member.guild}.")
        try:
            await self._enviar_mencao(member)
        except Exception as e:
            print(f"[MencaoBoasVindas] ERRO inesperado em on_member_join: {e}")
            traceback.print_exc()


def setup(bot: commands.Bot):
    bot.add_cog(MencaoBoasVindasTask(bot))
    print("[MencaoBoasVindas] setup() executado, cog adicionado ao bot.")