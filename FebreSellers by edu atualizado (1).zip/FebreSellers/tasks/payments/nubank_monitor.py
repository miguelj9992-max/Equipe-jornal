"""
Task de monitoramento contínuo do Nubank IMAP
Verifica emails de 5 em 5 segundos automaticamente
"""
import asyncio
from datetime import datetime, date
from disnake.ext import commands, tasks
import disnake

from functions.database import database as db
from functions.payments.imap_nubank import (
    monitor_nubank_imap_payments,
    cleanup_old_nubank_emails,
    _clear_processed_email_uids as nubank_clear_uids,
    get_pending_ambiguous_notices,
    clear_ambiguous_notice,
)
from functions.emoji import emoji


def _tracking_items(tracking: dict) -> dict:
    """Retorna os registros de pagamento em formatos antigos ou atuais."""
    if not isinstance(tracking, dict):
        return {}
    items = tracking.get("items")
    if isinstance(items, dict):
        return items
    # Alguns documentos antigos foram salvos diretamente como
    # {message_id: record}, sem o contêiner ``items``.
    return {
        key: value
        for key, value in tracking.items()
        if isinstance(value, dict) and ("provider" in value or "status" in value)
    }


class NubankMonitorTask(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.stats = {
            "total_checks": 0,
            "total_approved": 0,
            "errors": 0,
            "started_at": None,
            "last_check": None,
            "last_approval": None,
            "last_cleanup_date": None,
        }
        self._last_config_warning = None
        self._current_interval = 10
        self.nubank_monitor.start()

    def cog_unload(self):
        """Para o monitor quando o cog for descarregado"""
        self.nubank_monitor.cancel()

    @tasks.loop(seconds=10)
    async def nubank_monitor(self):
        """Monitora emails do Nubank periodicamente (intervalo configurável)."""
        try:
            config = db.get_document("payment_configs") or {}
            # Compatibilidade com configurações antigas salvas como ``nubank``.
            nubank_config = dict(config.get("nubank") or {})
            nubank_config.update(config.get("nubank_imap") or {})
            
            if not nubank_config.get("enabled"):
                warning = "nubank_imap desativado"
                if self._last_config_warning != warning:
                    print("[Nubank Monitor] Automação desativada: "
                          "ative payment_configs.nubank_imap.enabled e configure as credenciais.")
                    self._last_config_warning = warning
                return

            email_address = nubank_config.get("email")
            app_password = nubank_config.get("app_password") or nubank_config.get("password")
            if not email_address or not app_password:
                warning = "credenciais ausentes"
                if self._last_config_warning != warning:
                    print("[Nubank Monitor] Automação não iniciada: e-mail ou senha de app do IMAP ausente.")
                    self._last_config_warning = warning
                return
            self._last_config_warning = None

            # Ajusta o intervalo do loop dinamicamente se o admin alterar a
            # configuração de check_interval_seconds no database.
            desired_interval = int(nubank_config.get("check_interval_seconds") or 10)
            desired_interval = max(desired_interval, 5)  # intervalo curto, mas sem criar ciclos concorrentes
            if desired_interval != self._current_interval:
                self._current_interval = desired_interval
                self.nubank_monitor.change_interval(seconds=desired_interval)

            self.stats["last_check"] = datetime.utcnow().isoformat()
            self.stats["total_checks"] += 1

            # Verificar emails e obter pagamentos aprovados
            approved_payments = await monitor_nubank_imap_payments()

            if approved_payments:
                self.stats["total_approved"] += len(approved_payments)
                self.stats["last_approval"] = datetime.utcnow().isoformat()
                print(f"\n✅ Nubank Monitor: {len(approved_payments)} pagamento(s) aprovado(s)!")

                for payment in approved_payments:
                    await self._handle_approved_payment(payment)

            # Avisar administradores diretamente no(s) carrinho(s) quando um Pix
            # chega mas não pode ser confirmado automaticamente por segurança
            # (ex.: dois carrinhos pendentes com o mesmo valor na mesma janela
            # de tempo). Sem isso o pagamento ficava "travado" silenciosamente
            # até alguém notar por acaso e aprovar manualmente.
            await self._notify_ambiguous_payments()

            # Recuperar cobranças do `/pagamento` que já foram aprovadas no
            # documento do Nubank, mas não chegaram a atualizar a mensagem do
            # Discord (por exemplo, se o bot reiniciou entre as duas etapas).
            await self._sync_approved_command_payments()

            # Verificar pagamentos pendentes antigos periodicamente (a cada ~20 verificações)
            if self.stats["total_checks"] % 20 == 0:
                await self._check_pending_payments()

            # Limpeza de e-mails antigos já processados: no máximo uma vez por dia
            today = date.today().isoformat()
            if self.stats.get("last_cleanup_date") != today:
                self.stats["last_cleanup_date"] = today
                try:
                    result = await cleanup_old_nubank_emails()
                    if result and not result.get("skipped"):
                        print(f"[IMAP] Limpeza diária: {result}")
                except Exception as e:
                    print(f"❌ Erro na limpeza diária de e-mails Nubank: {e}")

        except Exception as e:
            self.stats["errors"] += 1
            import traceback
            print(f"❌ Erro no Nubank Monitor: {e}")
            print(f"   Traceback: {traceback.format_exc()}")

    @nubank_monitor.before_loop
    async def before_nubank_monitor(self):
        """Aguarda o bot estar pronto antes de iniciar."""
        await self.bot.wait_until_ready()
        self.stats["started_at"] = datetime.utcnow().isoformat()
        # IMPORTANTE: não limpar os UIDs de e-mails já processados aqui.
        # O estado é persistido no database justamente para sobreviver a
        # reinicializações do bot — limpar aqui faria reprocessar até 7 dias
        # de e-mails a cada restart, o que é desnecessário e pode gerar
        # comportamento inesperado. `nubank_clear_uids()` continua disponível
        # para reset manual/administrativo quando necessário.

    async def _notify_ambiguous_payments(self):
        """
        Avisa um administrador diretamente no(s) carrinho(s) candidatos quando
        um pagamento chega mas não pôde ser confirmado automaticamente por
        segurança (ex.: dois carrinhos pendentes com o mesmo valor dentro da
        mesma janela de tempo, sem TXID para diferenciar). O bot nunca
        adivinha nesse caso — mas agora avisa quem precisa resolver na mão,
        em vez de só imprimir no console.
        """
        notices = get_pending_ambiguous_notices()
        if not notices:
            return

        cargos_data = db.get_document("cargos") or {}
        cargo_admin_id = cargos_data.get("cargo_admin")
        loja_data = db.get_document("loja_data") or {}
        carts = loja_data.get("carts", {})

        for notice in notices:
            email_id = notice.get("email_id")
            amount = notice.get("amount") or 0
            candidate_cart_ids = notice.get("candidate_cart_ids") or []

            sent_to_any = False
            for cart_id in candidate_cart_ids:
                cart = carts.get(cart_id)
                if not cart:
                    continue
                try:
                    guild = self.bot.get_guild(cart.get("guild_id"))
                    if not guild:
                        continue
                    thread = guild.get_thread(cart.get("thread_id"))
                    if not thread:
                        continue

                    admin_mention = ""
                    if cargo_admin_id:
                        role = guild.get_role(int(cargo_admin_id))
                        if role:
                            admin_mention = f" {role.mention}"

                    await thread.send(
                        f"{emoji.warn} **Pagamento recebido, mas não pôde ser confirmado automaticamente.**\n"
                        f"Chegou um Pix de R$ {amount:.2f} compatível com este carrinho, mas há outro(s) "
                        f"carrinho(s) pendente(s) com o mesmo valor no mesmo período — por segurança, o "
                        f"bot não adivinha qual é o correto.\n\n"
                        f"Um administrador precisa conferir e aprovar manualmente o carrinho certo.{admin_mention}"
                    )
                    sent_to_any = True
                except Exception as e:
                    print(f"[IMAP] Erro ao avisar carrinho {cart_id} sobre pagamento ambíguo: {e}")

            if not sent_to_any:
                print(f"[IMAP] ⚠️ Pagamento ambíguo (e-mail {email_id}, R$ {amount:.2f}) não pôde ser "
                      f"avisado em nenhum carrinho candidato (thread/guild indisponível)")

            # Marca como processado mesmo se nenhum envio deu certo, para não
            # tentar reenviar indefinidamente a cada ciclo de 3s um aviso que
            # nunca vai conseguir ser entregue (ex.: thread já foi apagada).
            clear_ambiguous_notice(email_id)

    async def _sync_approved_command_payments(self):
        """Finaliza cobranças do `/pagamento` aprovadas durante uma interrupção."""
        tracking = db.get_document("payment_tracking") or {"items": {}}
        pending_nubank = db.get_document("nubank_pending_payments") or {}
        items = _tracking_items(tracking)

        for msg_id, rec in items.items():
            if not isinstance(rec, dict) or rec.get("provider") != "nubank":
                continue
            if rec.get("status") in {"approved", "paid", "completed"}:
                continue

            payment_id = (
                rec.get("nubank_payment_id")
                or (rec.get("ids") or {}).get("payment_id")
                or (rec.get("ids") or {}).get("id")
            )
            nubank_record = pending_nubank.get(str(payment_id)) if payment_id else None
            if not isinstance(nubank_record, dict) or nubank_record.get("status") != "approved":
                continue

            try:
                payment_cog = self.bot.get_cog("PaymentCog")
                if payment_cog is not None:
                    await payment_cog._mark_payment_approved(
                        str(msg_id),
                        rec,
                        send_email=True,
                    )
                    print(f"✅ Cobrança /pagamento recuperada após aprovação do Nubank: {msg_id}")
                else:
                    rec["status"] = "approved"
                    rec["approved_at"] = nubank_record.get("approved_at") or datetime.utcnow().isoformat()
                    items[str(msg_id)] = rec
                    tracking["items"] = items
                    db.save_document("payment_tracking", tracking)
                    print(f"✅ payment_tracking recuperado para Nubank: {msg_id} (fallback)")
            except Exception as recovery_error:
                import traceback
                print(f"⚠️ Falha ao recuperar /pagamento {msg_id}: {recovery_error}")
                print(traceback.format_exc())

    async def _check_pending_payments(self):
        """
        Verifica pagamentos pendentes antigos que podem ter sido perdidos.
        Executa a cada 100 segundos (20 verificações).
        """
        try:
            pending_payments = db.get_document("nubank_pending_payments") or {}
            pending_list = [
                (payment_id, data)
                for payment_id, data in pending_payments.items()
                if isinstance(data, dict) and data.get("status") == "pending"
            ]

            if not pending_list:
                return

            approved_payments = await monitor_nubank_imap_payments()

            if approved_payments:
                print(f"✅ {len(approved_payments)} pagamento(s) pendente(s) aprovado(s) em batch!")
                for payment in approved_payments:
                    await self._handle_approved_payment(payment)
                    self.stats["total_approved"] += 1
                    self.stats["last_approval"] = datetime.utcnow().isoformat()

        except Exception as e:
            import traceback
            print(f"❌ Erro ao verificar pagamentos pendentes: {e}")
            print(f"   Traceback: {traceback.format_exc()}")

    async def _handle_approved_payment(self, payment: dict):
        """
        Processa um pagamento Nubank aprovado de forma completa:
        entrega automática, cargos, DM e logs — via _handle_payment_approved do checkout.

        Args:
            payment: Dados do pagamento aprovado retornados por monitor_nubank_imap_payments
        """
        payment_id = payment.get("payment_id")
        cart_id = payment.get("cart_id")
        amount = payment.get("amount", 0)
        payer_name = payment.get("payer_name")

        print(f"💰 Processando pagamento aprovado: {payment_id}")
        print(f"   Carrinho: {cart_id}")
        print(f"   Valor: R$ {amount:.2f}")
        print(f"   Pagador: {payer_name or 'N/A'}")

        # ─── Tentar resolver o cart_id ───────────────────────────────────────
        # O monitor retorna o cart_id diretamente (salvo em nubank_pending_payments).
        # Se vier vazio, tentamos encontrar via payment_id no payment_tracking.
        resolved_cart_id = cart_id

        if not resolved_cart_id:
            tracking = db.get_document("payment_tracking") or {"items": {}}
            for msg_id, rec in _tracking_items(tracking).items():
                rec_ids = rec.get("ids") or {}
                rec_pid = rec_ids.get("payment_id") or rec_ids.get("id")
                if rec_pid == payment_id:
                    resolved_cart_id = rec.get("cart_id") or rec_ids.get("cart_id")
                    break

        # Compatibilidade com pagamentos criados antes da correção, que podem
        # conter um cart_id temporário: localizar o carrinho pelo payment_id salvo.
        loja_data = db.get_document("loja_data") or {}
        carts = loja_data.get("carts", {}) or {}
        if resolved_cart_id not in carts:
            for candidate_id, candidate in carts.items():
                pdata = candidate.get("payment_data") or {}
                provider = pdata.get("provider") or {}
                raw = pdata.get("raw") or provider.get("raw_response") or {}
                ids = pdata.get("payment_ids") or {}
                known_ids = {
                    str(pdata.get("payment_id") or ""),
                    str(provider.get("payment_id") or ""),
                    str(provider.get("txid") or ""),
                    str(raw.get("payment_id") or ""),
                    str(raw.get("txid") or ""),
                    str(ids.get("payment_id") or ""),
                    str(ids.get("txid") or ""),
                }
                if str(payment_id) in known_ids:
                    resolved_cart_id = candidate_id
                    print(f"[NubankMonitor] Carrinho legado localizado pelo payment_id: {candidate_id}")
                    break

        if not resolved_cart_id or resolved_cart_id not in carts:
            # Não é um pagamento de carrinho da loja.
            # Tentar atualizar o payment_tracking do comando /pagamento.
            tracking = db.get_document("payment_tracking") or {"items": {}}
            tracking_items = _tracking_items(tracking)
            matched_msg_id = None
            matched_record = None
            for msg_id, rec in tracking_items.items():
                if rec.get("provider") != "nubank":
                    continue
                rec_nubank_id = rec.get("nubank_payment_id") or (rec.get("ids") or {}).get("id") or (rec.get("ids") or {}).get("payment_id")
                if rec_nubank_id == payment_id and rec.get("status") == "pending":
                    matched_msg_id = str(msg_id)
                    matched_record = rec
                    break

            if matched_msg_id and matched_record:
                # O registro é finalizado pelo PaymentCog, não apenas por uma
                # troca de status. Assim a mensagem é editada, a venda é
                # registrada, a DM é enviada e um produto opcional é entregue.
                # Se o cog não estiver carregado, mantemos um fallback seguro que
                # ao menos persiste a confirmação para não perder o pagamento.
                try:
                    payment_cog = self.bot.get_cog("PaymentCog")
                    if payment_cog is not None:
                        await payment_cog._mark_payment_approved(
                            matched_msg_id,
                            matched_record,
                            send_email=True,
                        )
                        print(f"✅ Fluxo completo do /pagamento executado para {matched_msg_id}")
                    else:
                        matched_record["status"] = "approved"
                        matched_record["approved_at"] = datetime.utcnow().isoformat()
                        tracking["items"] = tracking_items
                        tracking_items[matched_msg_id] = matched_record
                        db.save_document("payment_tracking", tracking)
                        print(f"✅ payment_tracking atualizado para nubank {payment_id} (via /pagamento; fallback)")
                except Exception as approval_error:
                    import traceback
                    print(f"⚠️ Erro ao finalizar o /pagamento aprovado {payment_id}: {approval_error}")
                    print(traceback.format_exc())
            else:
                print(f"⚠️ Não foi possível encontrar o cart_id nem o tracking para o pagamento {payment_id}. Pulando.")
            return

        # ─── Verificar se o carrinho já foi aprovado (evitar duplicata) ──────
        loja_data = db.get_document("loja_data") or {}
        cart = loja_data.get("carts", {}).get(resolved_cart_id, {})
        if cart.get("status") in ("approved", "completed", "delivered"):
            print(f"ℹ️ Carrinho {resolved_cart_id} já está aprovado. Ignorando duplicata.")
            return

        # ─── Delegar ao handler completo do checkout ──────────────────────────
        # _handle_payment_approved cuida de:
        #   • marcar cart como approved
        #   • process_automatic_delivery (entrega de estoque)
        #   • atribuir/remover cargos
        #   • enviar DM ao comprador
        #   • gerar log de venda
        #   • atualizar embed no canal/tópico
        try:
            from modules.loja.cart.checkout import _handle_payment_approved
            await _handle_payment_approved(resolved_cart_id, self.bot)
            print(f"✅ Pagamento {payment_id} / carrinho {resolved_cart_id} processado com sucesso!")
        except Exception as e:
            import traceback
            print(f"❌ Erro ao processar pagamento {payment_id}: {e}")
            print(f"   Traceback: {traceback.format_exc()}")

def setup(bot: commands.Bot):
    bot.add_cog(NubankMonitorTask(bot))
