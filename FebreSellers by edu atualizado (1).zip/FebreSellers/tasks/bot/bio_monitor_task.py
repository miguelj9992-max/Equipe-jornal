from disnake.ext import tasks

# Task vazia só para não quebrar imports se algum módulo chamar
@tasks.loop(hours=24)
async def bio_monitor_task(bot):
    pass

@bio_monitor_task.before_loop
async def before_bio_monitor_task():
    pass
