import disnake
import asyncio
from disnake.ext import commands
from .status_rotator import status_rotator_task
import core

class StatusRotatorCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._bio_updated_once = False

    @commands.Cog.listener("on_ready")
    async def on_ready(self):
        if not status_rotator_task.is_running():
            status_rotator_task.start(self.bot)
        else:
            status_rotator_task.restart(self.bot)
        
        # Atualiza a bio somente ao iniciar o bot
        if not self._bio_updated_once:
            try:
                loop = asyncio.get_running_loop()
                await loop.run_in_executor(None, core.change_bio)
                print("Bio atualizada ao iniciar o bot")
                self._bio_updated_once = True
            except Exception as e:
                print(f"Erro ao atualizar bio ao iniciar: {e}")

def setup(bot: commands.Bot):
    bot.add_cog(StatusRotatorCog(bot))
