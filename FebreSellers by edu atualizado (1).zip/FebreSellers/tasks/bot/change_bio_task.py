from disnake.ext import tasks

# Task vazia apenas para não quebrar imports
@tasks.loop(hours=24)
async def change_bio_task(bot):
    pass

@change_bio_task.before_loop
async def before_change_bio_task():
    pass
