from functions.database import database as db
from disnake.ext import tasks
import disnake
import itertools
import asyncio

def get_status_obj(status_type: str) -> disnake.Status:
    status_map = {
        "online": disnake.Status.online,
        "idle": disnake.Status.idle,
        "dnd": disnake.Status.dnd,
        "streaming": disnake.Status.streaming
    }
    return status_map.get(status_type, disnake.Status.online)

@tasks.loop(seconds=15)
async def status_rotator_task(bot: disnake.Client):
    # A leitura do Mongo é síncrona (pymongo); rodar em thread separada evita
    # travar o loop de eventos (e derrubar o gateway do Discord) caso o banco
    # demore para responder.
    loop = asyncio.get_running_loop()
    try:
        database = await asyncio.wait_for(
            loop.run_in_executor(None, db.get_document, "custom_status"),
            timeout=8,
        )
    except Exception:
        return  # pula esse ciclo, tenta de novo no próximo
    status_obj = get_status_obj(database.get("type", "online"))

    names = database.get("names")
    if not names:  # Backwards compatibility
        name = database.get("name")
        names = [name] if name else []

    # Migra o status padrão antigo sem substituir uma personalização explícita.
    if names == ["👑 Kalux Store"]:
        names = ["FebreSellers"]
        database["names"] = names
        try:
            await loop.run_in_executor(None, db.save_document, "custom_status", database)
        except Exception:
            pass

    if not names:
        await bot.change_presence(status=status_obj, activity=None)
        return

    # Initialize or update cycler
    if not hasattr(bot, "_status_cycler") or getattr(bot, "_status_names", []) != names:
        bot._status_names = names
        bot._status_cycler = itertools.cycle(names)
    
    status_name = next(bot._status_cycler)

    if status_obj == disnake.Status.streaming:
        activity = disnake.Streaming(name=status_name, url="https://twitch.tv/discord")
    else:
        activity = disnake.CustomActivity(name=status_name)

    await bot.change_presence(status=status_obj, activity=activity)
