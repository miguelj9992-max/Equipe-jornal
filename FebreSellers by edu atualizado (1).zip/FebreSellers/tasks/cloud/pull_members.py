"""
Tarefa de puxar membros verificados para o servidor Lunar(Cloud)
"""
import asyncio
import aiohttp
import logging

logger = logging.getLogger(__name__)


async def pull_members_to_guild(
    bot,
    dest_guild_id: str | int,
    src_guild_id: str | int = None,
    limit: int = None,
) -> dict:
    """
    Puxa membros verificados para o servidor de destino.

    Args:
        bot: Instância do bot Discord
        dest_guild_id: ID do servidor de destino
        src_guild_id: ID do servidor de origem (None = usar banco global)
        limit: Quantidade máxima de membros a puxar (None = todos)

    Returns:
        dict: { pulled, already_in, roles_added, errors, total }
    """
    from modules.cloud.oauth_panel import get_oauth_verified_users, get_oauth_verified_role
    from functions.database import database as db

    dest_guild = bot.get_guild(int(dest_guild_id))
    if not dest_guild:
        return {"error": "Servidor de destino não encontrado."}

    # IMPORTANTE: o Discord exige que o token "Bot" usado para adicionar o
    # membro (escopo guilds.join) seja da MESMA aplicação que emitiu o
    # access_token durante a verificação OAuth2. O "bot exclusivo" de
    # verificação é uma aplicação Discord diferente do bot de vendas
    # principal, então usamos o token salvo em cloud_data["token"] em vez
    # de bot.http.token — senão o Discord retorna 403 "Invalid OAuth2
    # access token" (code 50025) mesmo com o access_token válido.
    cloud_data = db.get_document("cloud_data") or {}
    oauth_bot_token = cloud_data.get("token") or bot.http.token

    all_users = get_oauth_verified_users()

    # Filtrar por servidor de origem, se informado
    if src_guild_id and str(src_guild_id) != str(dest_guild_id):
        src_guild = bot.get_guild(int(src_guild_id))
        if src_guild:
            src_ids = {str(m.id) for m in src_guild.members}
            all_users = [u for u in all_users if str(u.get("id", "")) in src_ids]

    if limit:
        all_users = all_users[:limit]

    verified_role_id = get_oauth_verified_role()
    pulled = already_in = roles_added = errors = 0

    async with aiohttp.ClientSession() as session:
        for user_data in all_users:
            try:
                user_id = str(user_data.get("id", ""))
                if not user_id:
                    errors += 1
                    continue

                # Verificar se já está no servidor
                member = dest_guild.get_member(int(user_id))
                if not member:
                    try:
                        member = await dest_guild.fetch_member(int(user_id))
                        already_in += 1
                    except Exception:
                        member = None

                # Tentar adicionar ao servidor via access_token
                if not member:
                    access_token = user_data.get("access_token", "")
                    if access_token:
                        try:
                            async with session.put(
                                f"https://discord.com/api/v10/guilds/{dest_guild_id}/members/{user_id}",
                                headers={
                                    "Authorization": f"Bot {oauth_bot_token}",
                                    "Content-Type": "application/json",
                                },
                                json={"access_token": access_token},
                            ) as resp:
                                if resp.status in (200, 201):
                                    pulled += 1
                                    try:
                                        member = await dest_guild.fetch_member(int(user_id))
                                    except Exception:
                                        pass
                                elif resp.status == 204:
                                    already_in += 1
                                    try:
                                        member = await dest_guild.fetch_member(int(user_id))
                                    except Exception:
                                        pass
                                else:
                                    try:
                                        error_body = await resp.text()
                                    except Exception:
                                        error_body = "<sem corpo>"
                                    logger.warning(
                                        f"[PullMembers] Falha ao adicionar {user_id} "
                                        f"(status={resp.status}): {error_body}"
                                    )
                                    errors += 1
                                    continue
                        except Exception as e:
                            logger.warning(f"[PullMembers] Erro ao adicionar {user_id}: {e}")
                            errors += 1
                            continue
                    else:
                        errors += 1
                        continue

                # Atribuir cargo de verificado
                if member and verified_role_id:
                    role = dest_guild.get_role(int(verified_role_id))
                    if role and role not in member.roles:
                        try:
                            await member.add_roles(role, reason="FebreCloud — verificação OAuth2")
                            roles_added += 1
                        except Exception as e:
                            logger.warning(f"[PullMembers] Erro ao adicionar cargo para {user_id}: {e}")

                await asyncio.sleep(0.5)  # Rate limit básico

            except Exception as e:
                logger.error(f"[PullMembers] Erro geral para usuário {user_data.get('id', '?')}: {e}")
                errors += 1

    total = len(all_users)
    logger.info(
        f"[PullMembers] Concluído: total={total}, pulled={pulled}, "
        f"already_in={already_in}, roles_added={roles_added}, errors={errors}"
    )
    return {
        "total":        total,
        "pulled":       pulled,
        "already_in":   already_in,
        "roles_added":  roles_added,
        "errors":       errors,
    }