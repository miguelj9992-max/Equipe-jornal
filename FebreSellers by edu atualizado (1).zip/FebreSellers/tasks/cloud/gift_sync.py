"""
Loop de sincronização de resgates de Gift Card.

IMPLEMENTAÇÃO NOVA e independente do antigo sistema de gifts (que
dependia do SocketIOManager/HTTPPollingManager, ambos desativados -- ver
connections/socketio_manager.py e connections/http_polling.py). Este loop
fala direto com o MongoDB (mesmo padrão usado pela verificação OAuth2 em
modules/cloud/oauth_panel.py, já corrigido) e usa apenas chamadas REST
puras do Discord (add_member_to_guild_by_id, já existente e independente
de qualquer serviço externo) para adicionar membros verificados ao
servidor de destino.

A cada ciclo (30s):
  1. Busca gift cards com status "redeemed" (resgatados no site externo,
     ainda não processados pelo bot).
  2. Para cada um, pega até `members_count` membros verificados (com
     access_token salvo) que ainda NÃO estão no servidor de destino, e os
     adiciona via API do Discord.
  3. Marca o gift como "fulfilled" e envia um log no canal configurado.

IMPORTANTE: usamos print() em vez do módulo `logging` de propósito -- ver
o comentário equivalente em tasks/cloud/revalidate_auth.py (logger.warning
não aparece no console de hospedagem deste projeto).
"""
import asyncio
import random
import disnake
from disnake.ext import commands, tasks
from datetime import datetime

from functions.database import database as db
from functions.emoji import emoji
from modules.cloud.gift_cards import get_pending_fulfillment_cards, mark_gift_fulfilled, append_gift_log
from modules.cloud.oauth_panel import get_oauth_verified_users, get_oauth_log_channel


async def _process_redeemed_gifts(bot):
    from modules.cloud.update_api import add_member_to_guild_by_id

    pending = get_pending_fulfillment_cards()
    if not pending:
        return

    print(f"[GiftSync] {len(pending)} gift(s) resgatado(s) aguardando processamento.")

    verified_users = get_oauth_verified_users()
    candidates_pool = [u for u in verified_users if u.get("access_token") and u.get("id")]

    if not candidates_pool:
        print(
            f"[GiftSync] Nenhum candidato verificado com access_token disponível "
            f"({len(verified_users)} verificado(s) no total, 0 com token válido). "
            f"Gifts pendentes ficarão parados até haver membros verificados com token."
        )

    log_channel_id = get_oauth_log_channel()

    for card in pending:
        code = card.get("code")
        members_needed = int(card.get("members_count", 0) or 0)
        target_guild_id = card.get("redeemed_by_guild")

        # CORRECAO: histórico detalhado de tentativas/erros deste ciclo,
        # persistido no card (ver append_gift_log) e mandado em tempo real
        # pro canal de log -- antes só existia o print no console da
        # hospedagem, sem motivo de erro nenhum acessível de dentro do
        # Discord, e o log mandado era só "X/Y adicionados" sem detalhar
        # QUEM falhou e POR QUE.
        cycle_logs = []

        if not target_guild_id or members_needed <= 0:
            msg = f"Gift {code} com dados inválidos (guild={target_guild_id!r}, membros={members_needed}) -- pulando."
            print(f"[GiftSync] {msg}")
            cycle_logs.append({"level": "error", "message": msg})
            append_gift_log(code, cycle_logs)
            continue

        guild = bot.get_guild(int(target_guild_id))
        if not guild:
            try:
                guild = await bot.fetch_guild(int(target_guild_id))
            except Exception as e:
                msg = (
                    f"Bot não está no servidor {target_guild_id} (gift {code}): {e} -- "
                    f"não é possível adicionar membros ainda. Será tentado novamente no próximo ciclo."
                )
                print(f"[GiftSync] {msg}")
                cycle_logs.append({"level": "error", "message": msg})
                append_gift_log(code, cycle_logs)
                continue

        candidates = candidates_pool.copy()
        random.shuffle(candidates)

        added = 0
        attempted = 0
        already_counted = 0
        failures = []  # [(user_id, motivo)]
        for user_data in candidates:
            if added >= members_needed:
                break

            user_id = user_data.get("id")

            try:
                already_member = guild.get_member(int(user_id))
                if already_member is None:
                    try:
                        already_member = await guild.fetch_member(int(user_id))
                    except disnake.NotFound:
                        already_member = None
            except Exception:
                already_member = None

            if already_member is not None:
                # CORRECAO: antes esse candidato era pulado sem contar pra
                # meta (só "continue"). Se TODOS os candidatos verificados
                # já estivessem no servidor, o gift ficava preso para
                # sempre em 0/N, tentando de novo a cada ciclo sem nunca
                # completar. Agora, já estar no servidor conta como
                # requisito satisfeito.
                added += 1
                already_counted += 1
                msg = f"Membro {user_id} já estava no servidor {target_guild_id} (gift {code}) -- contabilizado."
                print(f"[GiftSync] {msg}")
                cycle_logs.append({"level": "success", "message": msg, "member_id": str(user_id)})
                continue

            attempted += 1
            success, error_msg = await add_member_to_guild_by_id(
                str(target_guild_id), int(user_id), user_data.get("access_token")
            )
            if success:
                added += 1
                msg = f"Membro {user_id} adicionado ao servidor {target_guild_id} (gift {code})."
                print(f"[GiftSync] {msg}")
                cycle_logs.append({"level": "success", "message": msg, "member_id": str(user_id)})
            else:
                failures.append((user_id, error_msg or "motivo desconhecido"))
                msg = f"Falha ao adicionar membro {user_id} (gift {code}): {error_msg}"
                print(f"[GiftSync] {msg}")
                cycle_logs.append({"level": "error", "message": msg, "member_id": str(user_id)})

            await asyncio.sleep(1)  # rate limit básico

        summary = f"Gift {code}: {added}/{members_needed} adicionado(s) neste ciclo ({attempted} tentativa(s), {already_counted} já no servidor)."
        print(f"[GiftSync] {summary}")
        cycle_logs.append({"level": "info", "message": summary})

        if added >= members_needed:
            mark_gift_fulfilled(code, added)
            print(f"[GiftSync] Gift {code} concluido: {added}/{members_needed} membro(s) adicionado(s).")
            cycle_logs.append({"level": "info", "message": f"Gift {code} concluído."})
        else:
            remaining_pool = len(candidates_pool) - attempted
            msg = (
                f"Gift {code} incompleto ({added}/{members_needed}). Mantido como "
                f"'redeemed' para nova tentativa no proximo ciclo (candidatos restantes: {max(remaining_pool, 0)})."
            )
            print(f"[GiftSync] {msg}")
            cycle_logs.append({"level": "info", "message": msg})

        append_gift_log(code, cycle_logs)

        if log_channel_id:
            await _send_gift_log(bot, log_channel_id, code, added, members_needed, target_guild_id, guild, failures)


async def _send_gift_log(bot, log_channel_id, code, added, requested, guild_id, guild, failures=None):
    try:
        channel = bot.get_channel(int(log_channel_id))
        if not channel:
            try:
                channel = await bot.fetch_channel(int(log_channel_id))
            except Exception:
                return

        custom_colors = db.get_document("custom_colors") or {}
        color_hex = custom_colors.get("primary", "#5865F2")
        failures = failures or []
        completed = added >= requested

        embed = disnake.Embed(
            title=f"{emoji.gift} Gift Card {'Concluído' if completed else 'Processado (parcial)'}",
            color=disnake.Colour(int(str(color_hex).replace("#", ""), 16)),
            timestamp=datetime.now()
        )
        embed.add_field(name="Código", value=f"`{code}`", inline=True)
        embed.add_field(name="Servidor", value=f"`{guild.name if guild else 'Desconhecido'}`\n`{guild_id}`", inline=True)
        embed.add_field(name="Membros Adicionados", value=f"`{added}/{requested}`", inline=True)

        # CORRECAO: antes o log so mostrava "X/Y adicionados", sem dizer
        # quem falhou nem por que. Agora lista os erros de verdade
        # (motivo vindo direto da resposta da API do Discord), pra dar pra
        # diagnosticar na hora (ex: token expirado, sem permissao, etc.)
        # em vez de precisar ir catar no console da hospedagem.
        if failures:
            lines = [f"`{uid}` — {reason}" for uid, reason in failures[:10]]
            if len(failures) > 10:
                lines.append(f"... e mais {len(failures) - 10} erro(s).")
            embed.add_field(
                name=f"{emoji.wrong} Falhas ({len(failures)})",
                value="\n".join(lines)[:1024],
                inline=False
            )

        if not completed:
            embed.add_field(
                name="Status",
                value="Gift mantido como pendente — será tentado novamente no próximo ciclo (30s).",
                inline=False
            )

        embed.set_footer(text="")

        await channel.send(embed=embed)
    except Exception as e:
        print(f"[GiftSync] Erro ao enviar log de gift: {e}")


class GiftSyncCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self._started = False

    @commands.Cog.listener("on_ready")
    async def on_ready(self):
        if not self._started:
            self._started = True
            await asyncio.sleep(20)
            self.gift_sync_loop.start()
            print("[GiftSync] Task de sincronização de gift cards iniciada (a cada 30s).")

    def cog_unload(self):
        self.gift_sync_loop.cancel()

    @tasks.loop(seconds=30)
    async def gift_sync_loop(self):
        try:
            await _process_redeemed_gifts(self.bot)
        except Exception as e:
            print(f"[GiftSync] Erro no loop de sincronização: {e}")
            import traceback
            traceback.print_exc()

    @gift_sync_loop.before_loop
    async def before_loop(self):
        await self.bot.wait_until_ready()


def setup(bot):
    bot.add_cog(GiftSyncCog(bot))