"""
Tarefa de enviar DM para usuários verificados do FebreCloud
"""
import asyncio
import logging
import disnake

logger = logging.getLogger(__name__)


async def send_dm_to_verified(
    bot,
    message_content: str = None,
    embed_data: dict = None,
    guild_id: str | int = None,
    limit: int = None,
) -> dict:
    """
    Envia DM para todos os usuários verificados.

    Args:
        bot: Instância do bot Discord
        message_content: Texto da mensagem (opcional)
        embed_data: Dicionário de embed (opcional)
        guild_id: Filtrar por servidor de origem (None = todos)
        limit: Limite de DMs a enviar (None = todos)

    Returns:
        dict: { sent, failed, total }
    """
    from modules.cloud.oauth_panel import get_oauth_verified_users

    users = get_oauth_verified_users()

    # Filtrar por guild
    if guild_id:
        users = [u for u in users if str(u.get("guild_id", "")) == str(guild_id)]

    if limit:
        users = users[:limit]

    sent = failed = 0
    total = len(users)

    # Preparar embed, se fornecido
    embed = disnake.Embed.from_dict(embed_data) if embed_data else None

    for user_data in users:
        user_id = user_data.get("id")
        if not user_id:
            failed += 1
            continue
        try:
            user = await bot.fetch_user(int(user_id))
            kwargs = {}
            if message_content:
                kwargs["content"] = message_content
            if embed:
                kwargs["embed"] = embed
            if kwargs:
                await user.send(**kwargs)
            sent += 1
        except disnake.Forbidden:
            # DMs desativadas
            failed += 1
        except disnake.NotFound:
            failed += 1
        except Exception as e:
            logger.warning(f"[SendDM] Erro ao enviar DM para {user_id}: {e}")
            failed += 1

        await asyncio.sleep(1.2)  # Respeitar rate limit do Discord

    logger.info(f"[SendDM] DMs enviadas: {sent}/{total}, falhas: {failed}")
    return {"total": total, "sent": sent, "failed": failed}
