"""
Tarefa de revalidacao periodica dos tokens OAuth2 dos usuarios verificados.

Antes disso nao existia nenhuma checagem: uma vez salvo no banco, o usuario
era considerado "verificado para sempre", mesmo que ele revogasse a
autorizacao do app em Configuracoes do Discord > Autorizacoes. Essa tarefa
tenta renovar o token de cada verificado; se o Discord recusar (token/
refresh_token revogado ou expirado sem possibilidade de renovacao), o cargo
de verificado e removido do membro e o registro e apagado do banco -- assim
ele deixa de contar em "Total Verificados" no painel.

IMPORTANTE: usamos print() em vez do modulo `logging` de proposito -- ver
o comentario equivalente em tasks/cloud/cog.py.
"""
import asyncio
import aiohttp
import disnake
from datetime import datetime
from functions.database import database as db
from functions.emoji import emoji

DISCORD_API = "https://discord.com/api/v10"


async def _try_refresh(session: aiohttp.ClientSession, client_id: str, client_secret: str, refresh_token: str):
    """Tenta renovar o access_token via refresh_token. Retorna (ok, dados_ou_erro)."""
    try:
        async with session.post(
            f"{DISCORD_API}/oauth2/token",
            data={
                "client_id": client_id,
                "client_secret": client_secret,
                "grant_type": "refresh_token",
                "refresh_token": refresh_token,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        ) as resp:
            if resp.status == 200:
                return True, await resp.json()
            body = await resp.text()
            return False, {"status": resp.status, "body": body}
    except Exception as e:
        return False, {"status": None, "body": str(e)}


async def _check_access_token(session: aiohttp.ClientSession, access_token: str) -> bool:
    """Fallback para usuarios sem refresh_token salvo: checa se o access_token
    atual ainda e aceito pelo Discord."""
    try:
        async with session.get(
            f"{DISCORD_API}/oauth2/@me",
            headers={"Authorization": f"Bearer {access_token}"},
        ) as resp:
            return resp.status == 200
    except Exception:
        return False


async def _revoke_user(bot, user_id: str, verified_role_id, log_channel_id) -> None:
    """Remove o cargo de verificado do usuario em todos os servidores em que
    ele estiver, e opcionalmente registra no canal de logs."""
    if verified_role_id:
        for guild in bot.guilds:
            try:
                member = guild.get_member(int(user_id))
                if not member:
                    continue
                role = guild.get_role(int(verified_role_id))
                if role and role in member.roles:
                    await member.remove_roles(
                        role, reason="FebreCloud -- autorizacao OAuth2 revogada pelo usuario"
                    )
                    print(
                        f"[RevalidateAuth] Cargo removido de {member.name} ({user_id}) -- token revogado."
                    )
            except Exception as e:
                print(f"[RevalidateAuth] Erro ao remover cargo de {user_id} em {guild.id}: {e}")
    else:
        print(f"[RevalidateAuth] verified_role_id nao configurado -- cargo de {user_id} NAO foi removido de lugar nenhum.")

    if log_channel_id:
        try:
            channel = bot.get_channel(int(log_channel_id))
            if channel:
                custom_colors = db.get_document("custom_colors") or {}
                color_hex = custom_colors.get("primary", "#5865F2")

                embed = disnake.Embed(
                    title=f"{emoji.wrong} Verificação Revogada",
                    description=f"<@{user_id}> revogou a autorização OAuth2 ().",
                    color=disnake.Colour(int(color_hex.replace("#", ""), 16)),
                    timestamp=datetime.now()
                )
                embed.add_field(
                    name=f"{emoji.member}**Usuário**",
                    value=f"`{user_id}`",
                    inline=True
                )
                embed.add_field(
                    name=f"{emoji.edit}**Ação Realizada**",
                    value="Cargo removido e verificação apagada do painel.",
                    inline=False
                )
                embed.set_footer(text="")

                await channel.send(embed=embed)
                print(f"[RevalidateAuth] Log de revogacao enviado para {user_id} no canal {log_channel_id}.")
            else:
                print(
                    f"[RevalidateAuth] Canal de logs {log_channel_id} nao encontrado "
                    f"(bot.get_channel retornou None) -- log de revogacao de {user_id} NAO enviado."
                )
        except Exception as e:
            print(f"[RevalidateAuth] Erro ao enviar log de revogacao de {user_id}: {e}")
            import traceback
            traceback.print_exc()
    else:
        print(
            f"[RevalidateAuth] log_channel_id nao configurado -- log de revogacao de {user_id} NAO enviado."
        )


async def revalidate_verified_users(bot) -> dict:
    """
    Percorre todos os usuarios verificados e tenta renovar o token de cada um.

    - Renovacao OK -> atualiza access_token/refresh_token salvos.
    - Renovacao falhou (refresh_token invalido/revogado) -> remove cargo +
      apaga registro (deixa de contar como verificado).
    - Sem refresh_token salvo (verificado antes dessa funcionalidade
      existir) -> checa o access_token atual; se invalido, mesma acao acima.

    Returns:
        dict: { checked, refreshed, revoked, no_refresh_token, errors }
    """
    from modules.cloud.oauth_panel import (
        get_oauth_verified_users_async,
        get_oauth_verified_role,
        get_oauth_client_id,
        get_oauth_client_secret,
        get_oauth_log_channel,
        update_oauth_user_tokens_async,
        remove_oauth_verified_user_async,
    )

    client_id = get_oauth_client_id()
    client_secret = get_oauth_client_secret()
    if not client_id or not client_secret:
        print("[RevalidateAuth] Client ID/Secret nao configurados -- ciclo abortado.")
        return {"error": "Client ID/Secret não configurados."}

    users = await get_oauth_verified_users_async()
    verified_role_id = get_oauth_verified_role()
    log_channel_id = get_oauth_log_channel()

    checked = refreshed = revoked = no_refresh_token = errors = 0

    async with aiohttp.ClientSession() as session:
        for user_data in users:
            user_id = str(user_data.get("id", ""))
            if not user_id:
                continue
            checked += 1

            refresh_token = user_data.get("refresh_token")
            still_valid = None

            try:
                if refresh_token:
                    ok, data = await _try_refresh(session, client_id, client_secret, refresh_token)
                    if ok:
                        refreshed += 1
                        still_valid = True
                        await update_oauth_user_tokens_async(
                            user_id,
                            access_token=data.get("access_token"),
                            refresh_token=data.get("refresh_token", refresh_token),
                        )
                    else:
                        still_valid = False
                        print(
                            f"[RevalidateAuth] Refresh falhou para {user_id}: {data}"
                        )
                else:
                    no_refresh_token += 1
                    access_token = user_data.get("access_token", "")
                    still_valid = await _check_access_token(session, access_token) if access_token else False
                    if still_valid is False:
                        print(f"[RevalidateAuth] {user_id} nao tem refresh_token salvo e o access_token atual foi rejeitado pelo Discord.")
            except Exception as e:
                print(f"[RevalidateAuth] Erro ao checar {user_id}: {e}")
                errors += 1
                continue

            if still_valid is False:
                # CORRECAO: antes de revogar, reconfere se o token testado
                # (capturado no INICIO deste ciclo, ha ate varios segundos)
                # ainda e o mesmo salvo agora. Se o usuario se desverificou e
                # se reverificou nesse meio-tempo, o site ja escreveu um
                # registro NOVO (com token novo) no Mongo -- e sem essa
                # checagem o bot removeria o cargo e apagaria justamente
                # esse registro novo (remove_oauth_verified_user apaga so
                # pelo user_id, sem saber que e uma verificacao diferente).
                # Isso causava reverificacoes legitimas sumirem sem log de
                # erro, dependendo puramente do timing entre o ciclo de 15s
                # e o momento da reverificacao.
                current_users = await get_oauth_verified_users_async()
                current_entry = next(
                    (u for u in current_users if str(u.get("id")) == user_id), None
                )
                current_token = (
                    current_entry.get("refresh_token") or current_entry.get("access_token")
                    if current_entry else None
                )
                tested_token = refresh_token or user_data.get("access_token")

                if current_entry is not None and current_token != tested_token:
                    print(
                        f"[RevalidateAuth] {user_id} tem um token diferente do que foi testado -- "
                        f"provavel reverificacao durante o ciclo, revogacao cancelada para nao apagar "
                        f"o registro novo. Sera testado de novo no proximo ciclo."
                    )
                    await asyncio.sleep(0.3)
                    continue

                revoked += 1
                try:
                    await _revoke_user(bot, user_id, verified_role_id, log_channel_id)
                except Exception as e:
                    print(f"[RevalidateAuth] Erro ao revogar {user_id}: {e}")
                    import traceback
                    traceback.print_exc()
                await remove_oauth_verified_user_async(user_id)

            await asyncio.sleep(0.3)  # rate limit basico

    print(
        f"[RevalidateAuth] Concluido: checked={checked}, refreshed={refreshed}, "
        f"revoked={revoked}, no_refresh_token={no_refresh_token}, errors={errors}"
    )
    return {
        "checked": checked,
        "refreshed": refreshed,
        "revoked": revoked,
        "no_refresh_token": no_refresh_token,
        "errors": errors,
    }