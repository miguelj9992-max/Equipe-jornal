"""
Tarefa de verificar membros autenticados no FebreCloud
Verifica se membros do servidor já são verificados e atribui o cargo automaticamente.
"""
import asyncio
import logging

logger = logging.getLogger(__name__)


async def sync_verified_roles(bot, guild_id: str | int = None) -> dict:
    """
    Para cada usuário verificado no banco, verifica se está no servidor
    e atribui o cargo de verificado caso não o tenha.

    Args:
        bot: Instância do bot Discord
        guild_id: ID do servidor (None = todos os servidores)

    Returns:
        dict: { checked, roles_added, already_had_role, not_in_guild, errors }
    """
    from modules.cloud.oauth_panel import get_oauth_verified_users, get_oauth_verified_role

    users = get_oauth_verified_users()
    verified_role_id = get_oauth_verified_role()

    if not verified_role_id:
        return {"error": "Cargo de verificado não configurado."}

    guilds = [bot.get_guild(int(guild_id))] if guild_id else list(bot.guilds)
    guilds = [g for g in guilds if g is not None]

    checked = roles_added = already_had_role = not_in_guild = errors = 0

    for user_data in users:
        user_id_str = str(user_data.get("id", ""))
        if not user_id_str:
            errors += 1
            continue

        checked += 1
        found_in_any = False

        for guild in guilds:
            try:
                member = guild.get_member(int(user_id_str))
                if not member:
                    continue

                found_in_any = True
                role = guild.get_role(int(verified_role_id))
                if not role:
                    continue

                if role in member.roles:
                    already_had_role += 1
                else:
                    await member.add_roles(role, reason="FebreCloud — sincronização automática")
                    roles_added += 1

            except Exception as e:
                logger.warning(f"[VerifyAuth] Erro para usuário {user_id_str} no guild {guild.id}: {e}")
                errors += 1

        if not found_in_any:
            not_in_guild += 1

        await asyncio.sleep(0.2)

    logger.info(
        f"[VerifyAuth] Sincronização concluída: checked={checked}, "
        f"roles_added={roles_added}, already_had={already_had_role}, "
        f"not_in_guild={not_in_guild}, errors={errors}"
    )
    return {
        "checked":        checked,
        "roles_added":    roles_added,
        "already_had_role": already_had_role,
        "not_in_guild":   not_in_guild,
        "errors":         errors,
    }


async def is_member_verified(bot, guild_id: str | int, user_id: str | int) -> bool:
    """
    Verifica se um membro específico está na lista de verificados.

    Args:
        bot: Instância do bot (não usado aqui, mas mantido para consistência)
        guild_id: ID do servidor
        user_id: ID do usuário

    Returns:
        bool: True se verificado
    """
    from modules.cloud.oauth_panel import get_oauth_verified_users

    users = get_oauth_verified_users()
    uid = str(user_id)
    for u in users:
        if str(u.get("id", "")) == uid:
            return True
    return False
