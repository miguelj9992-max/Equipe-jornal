"""
Task de sincronizacao automatica da Cloud (MongoDB -> Discord)
Monitora novos usuarios verificados no MongoDB e da cargo + envia log automaticamente.
A chave de controle e user_id + verified_at, entao cada nova verificacao e processada,
mesmo que o usuario ja tenha sido verificado antes.

IMPORTANTE: usamos print() em vez do modulo `logging` de proposito. O resto do
bot (Emojis, PaymentWS, etc.) tambem usa print(), e e isso que aparece
garantidamente no console do painel de hospedagem. Chamadas de logger.info/
warning/error sem uma configuracao explicita de logging (que este bot nao tem)
podem nao aparecer em lugar nenhum, o que tornaria impossivel diagnosticar
problemas so olhando o console.
"""
import asyncio
import time
import disnake
from datetime import datetime
from disnake.ext import commands, tasks

# Chaves ja processadas: "user_id:verified_at"
# Usar o timestamp garante que reverificacoes sejam detectadas
_processed_keys: set = set()
_PROCESSED_KEYS_DOC = "cloud_sync_processed_keys"


def _load_processed_keys() -> set:
    """Carrega as chaves ja processadas do banco de dados."""
    from functions.database import database as db
    data = db.get_document(_PROCESSED_KEYS_DOC) or {}
    return set(data.get("keys", []))


def _save_processed_keys(keys: set) -> None:
    """Salva as chaves processadas no banco de dados."""
    from functions.database import database as db
    db.save_document(_PROCESSED_KEYS_DOC, {"keys": list(keys)})


# Contas que deram "membro nao encontrado" (disnake.NotFound) ao tentar dar o
# cargo: "process_key" -> horario (epoch) da primeira vez que isso aconteceu.
# Continuamos tentando por _NOTFOUND_GRACE_SECONDS antes de desistir de
# verdade -- cobre o caso de o usuario se verificar pelo site e so entrar no
# servidor certo depois (o bot pode estar em mais de um servidor, mas so um
# e configurado para receber o cargo de verificado), ou um 404 passageiro do
# cache do Discord.
_notfound_first_seen: dict = {}
_NOTFOUND_FIRST_SEEN_DOC = "cloud_sync_notfound_first_seen"
_NOTFOUND_GRACE_SECONDS = 24 * 60 * 60  # 24 horas


def _load_notfound_first_seen() -> dict:
    from functions.database import database as db
    data = db.get_document(_NOTFOUND_FIRST_SEEN_DOC) or {}
    return dict(data.get("entries", {}))


def _save_notfound_first_seen(entries: dict) -> None:
    from functions.database import database as db
    db.save_document(_NOTFOUND_FIRST_SEEN_DOC, {"entries": entries})



class CloudSyncTask(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self._started = False

    @commands.Cog.listener("on_ready")
    async def on_ready(self):
        if not self._started:
            self._started = True
            print("[CloudSync] on_ready disparado, iniciando setup da task...")
            # Carregar chaves ja processadas do banco para nao reenviar logs apos reinicio
            global _processed_keys, _notfound_first_seen
            _processed_keys = _load_processed_keys()
            _notfound_first_seen = _load_notfound_first_seen()
            print(f"[CloudSync] {len(_processed_keys)} chaves carregadas do banco.")
            await asyncio.sleep(10)
            self.sync_verified_loop.start()
            print("[CloudSync] Task de sincronizacao iniciada (a cada 30s).")

            # Pequeno delay para nao concorrer com o sync inicial
            await asyncio.sleep(15)
            self.revalidate_auth_loop.start()
            print("[CloudSync] Task de revalidacao de tokens iniciada (a cada 15s).")

    def cog_unload(self):
        self.sync_verified_loop.cancel()
        self.revalidate_auth_loop.cancel()

    @tasks.loop(seconds=30)
    async def sync_verified_loop(self):
        try:
            await _process_new_verified_users(self.bot)
        except Exception as e:
            print(f"[CloudSync] Erro no loop: {e}")
            import traceback
            traceback.print_exc()

    @sync_verified_loop.before_loop
    async def before_loop(self):
        await self.bot.wait_until_ready()

    # Revalida o token OAuth2 de cada verificado a cada 15 segundos.
    # Se o usuario revogou a autorizacao do app (ou o refresh_token nao
    # pode mais ser renovado), remove o cargo de verificado e apaga o
    # registro -- assim ele deixa de contar em "Total Verificados".
    @tasks.loop(seconds=15)
    async def revalidate_auth_loop(self):
        try:
            from tasks.cloud.revalidate_auth import revalidate_verified_users
            result = await revalidate_verified_users(self.bot)
            if result.get("revoked"):
                print(f"[RevalidateAuth] {result['revoked']} usuario(s) removido(s) por token revogado.")
        except Exception as e:
            print(f"[RevalidateAuth] Erro no loop: {e}")
            import traceback
            traceback.print_exc()

    @revalidate_auth_loop.before_loop
    async def before_revalidate_loop(self):
        await self.bot.wait_until_ready()


async def _process_new_verified_users(bot):
    global _processed_keys, _notfound_first_seen

    from modules.cloud.oauth_panel import get_oauth_verified_users_async, get_oauth_verified_role, get_oauth_log_channel
    from functions.database import database as db

    cloud_data = db.get_document("cloud_data") or {}
    guild_id = db.obter("config.json").get("bot", {}).get("server")
    verified_role_id = get_oauth_verified_role() or (db.get_document("cargos") or {}).get("cargo_verificado")
    log_channel_id = get_oauth_log_channel() or cloud_data.get("log_channel_id")

    if not guild_id or not verified_role_id:
        print(
            f"[CloudSync] Configuracao incompleta -- guild_id={guild_id!r}, "
            f"verified_role_id={verified_role_id!r}. Configure o cargo de verificado "
            f"no painel para a sincronizacao funcionar."
        )
        return

    guild = bot.get_guild(int(guild_id))
    if not guild:
        print(f"[CloudSync] Servidor {guild_id} nao encontrado no cache do bot (bot.get_guild retornou None).")
        return

    verified_role = guild.get_role(int(verified_role_id))
    if not verified_role:
        print(f"[CloudSync] Cargo {verified_role_id} nao encontrado no servidor {guild_id}.")
        return

    all_users = await get_oauth_verified_users_async()
    print(f"[CloudSync] Ciclo de sincronizacao: {len(all_users)} usuario(s) verificado(s) no Mongo, "
          f"{len(_processed_keys)} chave(s) ja processada(s).")

    # Migracao das chaves antigas (formato "user_id", sem verified_at) para o novo
    # formato "user_id:verified_at". Sem isso, todo usuario ja verificado antes da
    # correcao do bug acima seria tratado como "novo" na proxima checagem e
    # receberia um log de verificacao duplicado.
    #
    # IMPORTANTE: esse bloco roda em TODO ciclo (a cada 30s), nao so uma vez. Se a
    # chave antiga (_legacy_key) nao for removida apos a migracao, ela continua no
    # set para sempre -- e a cada novo ciclo, para essas contas especificas, o
    # codigo pre-marca o verified_at ATUAL delas como "ja processado" antes mesmo
    # do loop principal rodar, mesmo em uma reverificacao genuina e nova. Isso
    # bloqueia cargo/log permanentemente so para quem tinha essa chave antiga --
    # exatamente o "funciona numa conta, noutra nao" que foi reportado.
    # CORRECAO: a migracao antiga marcava o verified_at ATUAL como "ja
    # processado" so por a conta ter uma chave legada, mesmo sem nunca ter
    # de fato recebido cargo/log para esse verified_at especifico (ex: quem
    # se reverificou depois da chave legada ter sido criada). Isso bloqueava
    # cargo/log permanentemente so para essas contas -- o "funciona numa
    # conta, noutra nao" relatado.
    #
    # Agora so marcamos como processado quem JA TEM o cargo de verificado
    # (prova de que aquela verificacao ja foi de fato processada antes).
    # Quem tem a chave legada mas NAO tem o cargo cai no loop principal
    # abaixo e recebe cargo + log normalmente, como uma verificacao nova.
    _migrated = False
    for user_data in all_users:
        _uid = str(user_data.get("id", ""))
        if not _uid:
            continue
        _legacy_key = _uid
        if _legacy_key not in _processed_keys:
            continue

        _processed_keys.discard(_legacy_key)
        _migrated = True

        _composite_key = f"{_uid}:{user_data.get('verified_at') or ''}"
        _member = guild.get_member(int(_uid)) if _uid.isdigit() else None
        if _member and verified_role in _member.roles:
            # Ja tinha o cargo -- essa verificacao ja foi processada de
            # verdade no passado. So atualiza a chave pro formato novo.
            _processed_keys.add(_composite_key)
        else:
            # Nao tem o cargo -- nao marca como processado, deixa o loop
            # principal dar cargo + log normalmente.
            print(
                f"[CloudSync] Migrando chave legada de {_uid}: conta sem o cargo de "
                f"verificado, sera reprocessada (cargo + log) neste ciclo."
            )
    if _migrated:
        _save_processed_keys(_processed_keys)

    for user_data in all_users:
        user_id = str(user_data.get("id", ""))
        if not user_id:
            continue

        # Chave unica por usuario + verified_at (conforme documentado no topo do arquivo).
        # IMPORTANTE: usar apenas o user_id aqui (sem o verified_at) e um bug -- faz com
        # que qualquer usuario que ja tenha sido processado UMA vez fique permanentemente
        # bloqueado de receber cargo/log em reverificacoes futuras (ex: desverificou e
        # verificou de novo), mesmo reiniciando o bot, ja que _processed_keys e persistido
        # no banco de dados e nunca e limpo automaticamente.
        verified_at_key = user_data.get("verified_at") or ""
        process_key = f"{user_id}:{verified_at_key}"

        if process_key in _processed_keys:
            continue

        print(f"[CloudSync] Novo evento de verificacao detectado: user_id={user_id}, verified_at={verified_at_key!r}")

        try:
            member = guild.get_member(int(user_id))
            if not member:
                try:
                    member = await guild.fetch_member(int(user_id))
                    # Encontrou dessa vez -- se estava na lista de "nao encontrado
                    # ainda" (ver bloco abaixo), remove, pois nao precisa mais
                    # do periodo de tolerancia.
                    _notfound_first_seen.pop(process_key, None)
                except disnake.NotFound:
                    # BUG CORRIGIDO: antes disso, um unico 404 aqui marcava o
                    # usuario como processado PARA SEMPRE, sem cargo/log, sem
                    # nenhuma nova tentativa -- mesmo que ele estivesse no
                    # servidor errado (o bot esta em mais de um servidor, mas
                    # so um e verificado aqui) por pouco tempo, ou entrasse no
                    # servidor certo horas depois de se verificar pelo site.
                    # Isso e exatamente o cenario de "autorizou no Discord mas
                    # nunca recebeu cargo/log/contagem": a verificacao ficava
                    # marcada como "ja tratada" permanentemente no primeiro
                    # 404, e nenhum ciclo seguinte tentava de novo.
                    #
                    # Agora, em vez de desistir na primeira vez, guardamos
                    # quando essa conta comecou a dar 404 e continuamos
                    # tentando por um periodo de tolerancia (24h) antes de
                    # desistir de verdade -- tempo suficiente para cobrir
                    # atrasos de cache do Discord ou o usuario entrar no
                    # servidor certo depois de ja ter se verificado no site.
                    primeiro_404_em = _notfound_first_seen.get(process_key)
                    agora = time.time()
                    if primeiro_404_em is None:
                        _notfound_first_seen[process_key] = agora
                        _save_notfound_first_seen(_notfound_first_seen)
                        print(
                            f"[CloudSync] Usuario {user_id} nao encontrado no servidor "
                            f"{guild_id} agora -- sera tentado novamente por ate "
                            f"{_NOTFOUND_GRACE_SECONDS // 3600}h antes de desistir "
                            f"(pode estar em outro servidor do bot, ou ainda nao ter "
                            f"entrado neste apos se verificar pelo site)."
                        )
                        continue
                    elif (agora - primeiro_404_em) < _NOTFOUND_GRACE_SECONDS:
                        print(
                            f"[CloudSync] Usuario {user_id} ainda nao encontrado no "
                            f"servidor {guild_id} (tentando ha "
                            f"{int((agora - primeiro_404_em) // 60)} min) -- tentando de "
                            f"novo no proximo ciclo."
                        )
                        continue
                    else:
                        print(
                            f"[CloudSync] Usuario {user_id} nao encontrado no servidor "
                            f"{guild_id} ha mais de {_NOTFOUND_GRACE_SECONDS // 3600}h -- "
                            f"desistindo e marcando como processado sem dar cargo/log."
                        )
                        _notfound_first_seen.pop(process_key, None)
                        _save_notfound_first_seen(_notfound_first_seen)
                        _processed_keys.add(process_key)
                        _save_processed_keys(_processed_keys)
                        continue
                except Exception as e:
                    # Erro passageiro (rate limit, latencia, etc.) -- NAO marcar como
                    # processado, para tentar de novo no proximo ciclo (30s depois)
                    # em vez de perder essa verificacao para sempre.
                    print(
                        f"[CloudSync] Falha temporaria ao buscar membro {user_id}, "
                        f"tentando de novo no proximo ciclo: {e}"
                    )
                    continue

            # Dar cargo
            if verified_role not in member.roles:
                try:
                    await member.add_roles(verified_role, reason="FebreCloud -- verificacao OAuth2")
                    print(f"[CloudSync] Cargo dado: {member.name} ({user_id})")
                except Exception as e:
                    print(f"[CloudSync] Erro ao dar cargo para {user_id}: {e}")
            else:
                print(f"[CloudSync] {member.name} ({user_id}) ja tinha o cargo de verificado.")

            # Marcar como processado e salvar NO BANCO ANTES de enviar o log
            # Assim, mesmo que o bot reinicie durante o envio, nao reenvia depois
            _processed_keys.add(process_key)
            _save_processed_keys(_processed_keys)

            # Enviar log
            if log_channel_id:
                await _send_verification_log(bot, member, user_data, log_channel_id)
            else:
                print(f"[CloudSync] log_channel_id nao configurado -- log de verificacao de {user_id} NAO enviado.")

            # Remover autorole se configurado
            definitions = cloud_data.get("definitions", {})
            if definitions.get("remove_autorole", {}).get("enabled", False):
                autorole_id = (db.get_document("cargos") or {}).get("cargo_auto_role")
                if autorole_id:
                    autorole = guild.get_role(int(autorole_id))
                    if autorole and autorole in member.roles:
                        try:
                            await member.remove_roles(autorole, reason="Remocao de autorole apos verificacao")
                        except Exception:
                            pass

            await asyncio.sleep(0.5)

        except Exception as e:
            print(f"[CloudSync] Erro ao processar {user_id}: {e}")
            import traceback
            traceback.print_exc()


async def _send_verification_log(bot, member, user_data: dict, log_channel_id):
    try:
        channel = bot.get_channel(int(log_channel_id))
        if not channel:
            print(
                f"[CloudSync] Canal de logs {log_channel_id} nao encontrado "
                f"(bot.get_channel retornou None) -- log de verificacao de {member.id} NAO enviado."
            )
            return

        from functions.database import database as db
        from functions.emoji import emoji
        import disnake

        mode = (db.get_document("custom_mode") or {}).get("mode", "embed")

        verified_at = user_data.get("verified_at") or datetime.now().isoformat()
        try:
            ts = int(datetime.fromisoformat(verified_at).timestamp())
            time_str = f"<t:{ts}:F>"
        except Exception:
            time_str = verified_at

        email = user_data.get("email", "Nao disponivel")
        ip = user_data.get("ip", "Desconhecido")

        if mode == "embed":
            embed = disnake.Embed(
                title=f"{emoji.shield} Log de Autenticacao",
                color=0x27ae60,
                timestamp=datetime.now()
            )
            embed.add_field(name=f"{emoji.member}**Usuario:**",
                            value=f"**{member.name}**\n`{member.id}`", inline=True)
            embed.add_field(name=f"{emoji.mail2}**Email:**", value=email, inline=True)
            embed.add_field(name=f"{emoji.wifi}**IP:**", value=f"`{ip}`", inline=True)
            embed.add_field(name=f"{emoji.clock}**Data/Hora:**", value=time_str, inline=True)
            embed.add_field(name=f"{emoji.correct}**Status:**", value="Verificado com sucesso", inline=True)

            view = disnake.ui.View()
            if ip and ip != "Desconhecido":
                view.add_item(disnake.ui.Button(
                    label="Ver Localizacao", style=disnake.ButtonStyle.link,
                    url=f"https://ipinfo.io/{ip}"
                ))
            await channel.send(embed=embed, view=view)
        else:
            color_hex = (db.get_document("custom_colors") or {}).get("primary", "#ffffff")
            content = (
                f"{emoji.member} **Usuario**: <@{member.id}> `{member.name}`\n"
                f"{emoji.mail2} **Email**: {email}\n"
                f"{emoji.wifi} **IP**: `{ip}`\n"
                f"{emoji.clock} **Data/Hora**: {time_str}"
            )
            container = disnake.ui.Container(
                disnake.ui.TextDisplay("# \n-# Membro Verificado"),
                disnake.ui.Separator(),
                disnake.ui.TextDisplay(content),
                accent_colour=disnake.Colour(int(color_hex.replace("#", ""), 16))
            )
            components = [container]
            if ip and ip != "Desconhecido":
                components.append(disnake.ui.ActionRow(
                    disnake.ui.Button(label="Ver Localizacao", style=disnake.ButtonStyle.link,
                                      url=f"https://ipinfo.io/{ip}")
                ))
            await channel.send(components=components,
                               flags=disnake.MessageFlags(is_components_v2=True))

        print(f"[CloudSync] Log de verificacao enviado para {member.name} ({member.id}) no canal {log_channel_id}.")

    except Exception as e:
        print(f"[CloudSync] Erro ao enviar log: {e}")
        import traceback
        traceback.print_exc()


def setup(bot):
    bot.add_cog(CloudSyncTask(bot))